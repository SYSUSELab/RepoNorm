# Rules for `repository root`

## Rule 001 — `**/*.py`

- **Rule:** Ruff's isort lint rule is configured with order-by-type = false, so imports are not ordered by type.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-010cc208586d45fa9f0da5d4.md)

## Rule 010 — `**`

- **Rule:** CI runs the full test suite when a pull request is submitted.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-10e2060f87ea893448355e90.md)

## Rule 026 — `**/*.py`

- **Rule:** Ruff's isort lint rule is configured with force-single-line = true, so imports are forced onto single lines.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-27e474d49e125263b6ba5053.md)

## Rule 076 — `**`

- **Rule:**
  ```text
  The tests job installs tox with pip and runs tox for the environment named by matrix.tox, defaulting to py<matrix.python>.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7dcc6102530a6e870b198a65.md)

## Rule 101 — `**/*.py`

- **Rule:** Code must be formatted using Black; this and other tools run automatically if pre-commit is installed.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-a408d42065383bf4a818f909.md)

## Rule 123 — `**`

- **Rule:**
  ```text
  The tox `style` test environment declares `pre-commit` as a dependency.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c003aa90ec90a222556ae063.md)

## Rule 130 — `**/*.css`

- **Rule:** CSS, HTML, JS, JSON, JSX, SCSS, TS, TSX, YAML, and YML files use an indent size of 2.
- **Applies to:**
  - `**/*.css`
  - `**/*.html`
  - `**/*.js`
  - `**/*.json`
  - `**/*.jsx`
  - `**/*.scss`
  - `**/*.ts`
  - `**/*.tsx`
  - `**/*.yaml`
  - `**/*.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ca0f468fabafbf8fc78e06a4.md)

## Rule 145 — `**/*.py`

- **Rule:** Ruff linting is configured to select the rule sets B (flake8-bugbear), E (pycodestyle error), F (pyflakes), I (isort), UP (pyupgrade), and W (pycodestyle warning).
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-e4d2cc886023e635a8cc3750.md)

## Rule 152 — `**/*.py`

- **Rule:**
  ```text
  The project declares a minimum supported Python version of 3.8 via requires-python = ">=3.8".
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f90ef79d34adaab7faa1b3e2.md)
