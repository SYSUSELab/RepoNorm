# Rules for `.github/workflows/pre-commit.yaml`

## Rule 049 — `.github/workflows/pre-commit.yaml`

- **Rule:** The pre-commit workflow runs the pre-commit/action step.
- **Applies to:**
  - `.github/workflows/pre-commit.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4682f4b89c2cd87ffd9f53d2.md)

## Rule 087 — `.github/workflows/pre-commit.yaml`

- **Rule:** The pre-commit-ci/lite-action step runs when the workflow has not been cancelled.
- **Applies to:**
  - `.github/workflows/pre-commit.yaml`
- **Condition:** workflow predicate: ${{ !cancelled() }}
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-97747fb96a5ec33c61dd8500.md)

## Rule 104 — `.github/workflows/pre-commit.yaml`

- **Rule:** The pre-commit workflow sets up Python version 3.x.
- **Applies to:**
  - `.github/workflows/pre-commit.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ab2025424f0881c1de97611e.md)
