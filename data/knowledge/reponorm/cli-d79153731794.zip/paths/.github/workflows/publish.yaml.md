# Rules for `.github/workflows/publish.yaml`

## Rule 012 — `.github/workflows/publish.yaml`

- **Rule:** The build job uploads the ./dist directory as an artifact.
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-12e7c4eb856adce5f9b84b17.md)

## Rule 016 — `.github/workflows/publish.yaml`

- **Rule:** The publish-pypi job then publishes the artifact/ directory to PyPI using the pypa/gh-action-pypi-publish action.
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-18bc78f6ad3d3e041e0ba20b.md)

## Rule 029 — `.github/workflows/publish.yaml`

- **Rule:** The build job builds the package with python -m build.
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2cf6ee19e09e058617e27eef.md)

## Rule 047 — `.github/workflows/publish.yaml`

- **Rule:** The build job generates a hash by running sha256sum over dist contents and base64-encoding the result into the hash step output.
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-44a9cf157228d89e53ad4ade.md)

## Rule 092 — `.github/workflows/publish.yaml`

- **Rule:** The publish-pypi job first publishes the artifact/ directory to the TestPyPI repository URL https://test.pypi.org/legacy/.
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9c0431ce1e13bf001811ee4b.md)

## Rule 093 — `.github/workflows/publish.yaml`

- **Rule:**
  ```text
  The build job sets SOURCE_DATE_EPOCH from the last commit date to use the commit date instead of the current date during the build.
  ```
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9c31decd9dfa1cf55e32f804.md)

## Rule 109 — `.github/workflows/publish.yaml`

- **Rule:** The build job installs build requirements via pip install -r requirements/build.txt.
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-af6c405fc4f618274aab8565.md)

## Rule 131 — `.github/workflows/publish.yaml`

- **Rule:**
  ```text
  The build job sets up Python version '3.x' with pip caching keyed on requirements*/*.txt.
  ```
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-cc7d2d6a8ae3f462d9f2104a.md)

## Rule 153 — `.github/workflows/publish.yaml`

- **Rule:**
  ```text
  The create-release job creates a draft GitHub release for the pushed tag containing the intoto provenance and artifact files, using GH_TOKEN from github.token.
  ```
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-fd3222ed7be366158c52a895.md)
