# Rules for `requirements/docs.in`

## Rule 070 — `requirements/docs.in`

- **Rule:** The update-requirements tox environment runs pip-compile on docs.in with -q and posargs defaulting to -U.
- **Applies to:**
  - `requirements/docs.in`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-73eb4e2aac639952f5bafd5d.md)
