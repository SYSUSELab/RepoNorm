# Rules for `requirements/build.in`

## Rule 071 — `requirements/build.in`

- **Rule:** The update-requirements tox environment runs pip-compile on build.in with -q and posargs defaulting to -U.
- **Applies to:**
  - `requirements/build.in`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-787d80c0623f0fbfcf935aef.md)
