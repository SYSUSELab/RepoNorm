# Rules for `requirements/docs.txt`

## Rule 077 — `requirements/docs.txt`

- **Rule:** Read the Docs installs documentation requirements from requirements/docs.txt.
- **Applies to:**
  - `requirements/docs.txt`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-7e608b64ad7b9d212193e72f.md)
