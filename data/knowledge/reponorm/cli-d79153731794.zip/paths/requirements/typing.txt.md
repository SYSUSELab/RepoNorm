# Rules for `requirements/typing.txt`

## Rule 024 — `requirements/typing.txt`

- **Rule:** The typing tox environment installs its dependencies from requirements/typing.txt.
- **Applies to:**
  - `requirements/typing.txt`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-24d52da028e737a59825a6b2.md)
