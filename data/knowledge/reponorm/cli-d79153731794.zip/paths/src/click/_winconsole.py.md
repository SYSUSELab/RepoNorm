# Rules for `src/click/_winconsole.py`

## Rule 008 — `src/click/_winconsole.py`

- **Rule:**
  ```text
  ConsoleStream must remain a Windows-specific stream wrapper in click._winconsole, preserving platform-specific console handling.
  ```
- **Applies to:**
  - `src/click/_winconsole.py`
- **Condition:** When modifying or relocating Windows console stream handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0df4255590f62b794fa23a20.md)

## Rule 039 — `src/click/_winconsole.py`

- **Rule:**
  ```text
  Windows console writer implementations must subclass _WindowsConsoleRawIOBase to provide the Windows console writer surface.
  ```
- **Applies to:**
  - `src/click/_winconsole.py`
- **Condition:** When adding or modifying a Windows console writer class.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3cf0e45460ef20f8c4c22e6c.md)

## Rule 057 — `src/click/_winconsole.py`

- **Rule:**
  ```text
  On PyPy, importing ctypes.pythonapi fails, so get_buffer must be set to None and buffer-based console operations must be unavailable.
  ```
- **Applies to:**
  - `src/click/_winconsole.py`
- **Condition:**
  ```text
  When modifying Windows console buffer handling or platform detection in click._winconsole.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-549cb93bd36215f09b2bcd2c.md)

## Rule 059 — `src/click/_winconsole.py`

- **Rule:**
  ```text
  _get_text_stdout must wrap a Windows console writer in a non-closing text wrapper using utf-16-le with strict errors and line buffering, then cast it to a ConsoleStream.
  ```
- **Applies to:**
  - `src/click/_winconsole.py`
- **Condition:**
  ```text
  When modifying _get_text_stdout or Windows console text stream construction.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5e7d9e6181affd73dfebdde7.md)

## Rule 120 — `src/click/_winconsole.py`

- **Rule:**
  ```text
  When modifying the Windows console stream's `isatty`, preserve that it calls `super().isatty()` and then unconditionally returns True, forcing TTY detection to true for that stream.
  ```
- **Applies to:**
  - `src/click/_winconsole.py`
- **Condition:** when changing Windows console TTY detection
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-be0c1fa0187beaaf2972f201.md)

## Rule 122 — `src/click/_winconsole.py`

- **Rule:** Windows console stdin must be wrapped as a UTF-16-LE text stream with strict error handling and line buffering, and the wrapper must be non-closing so the underlying buffer stream is not closed when the text stream is closed.
- **Applies to:**
  - `src/click/_winconsole.py`
- **Condition:** When modifying Windows console stdin wrapping or text stream configuration.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-bf84779eb05928452f77a409.md)
