# Rules for `src/click/_termui_impl.py`

## Rule 023 — `src/click/_termui_impl.py`

- **Rule:**
  ```text
  When modifying _pipepager, preserve the LESS-flag-driven color decision: enable color when LESS contains 'r' or 'R', otherwise set LESS='-R' and enable color; strip ANSI when color is disabled, and loop on c.wait() to ignore KeyboardInterrupt so less handles ^C.
  ```
- **Applies to:**
  - `src/click/_termui_impl.py`
- **Condition:**
  ```text
  When changing pager invocation, LESS environment handling, or color/ANSI stripping in _pipepager.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-21f888ed9d1e42f98937bd03.md)

## Rule 124 — `src/click/_termui_impl.py`

- **Rule:**
  ```text
  When modifying `_nullpager`, preserve its role as the ultimate fallback pager: write each generator chunk directly to the stream, stripping ANSI when color is false.
  ```
- **Applies to:**
  - `src/click/_termui_impl.py`
- **Condition:** when changing pager fallback behavior or ANSI stripping
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c100a0754ee5ec42da65fccc.md)

## Rule 133 — `src/click/_termui_impl.py`

- **Rule:**
  ```text
  _unquote_file must strip the 'file://' prefix and URL-unquote the remainder; non-file URLs are returned unchanged.
  ```
- **Applies to:**
  - `src/click/_termui_impl.py`
- **Condition:**
  ```text
  When modifying open_url's file URL handling or _unquote_file.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-cc93c8abae94fe4a2fbe3fa5.md)
