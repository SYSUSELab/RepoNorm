# Rules for `src/click/formatting.py`

## Rule 084 — `src/click/formatting.py`

- **Rule:** HelpFormatter.indentation must increase indentation on entry and guarantee dedent on exit via finally, so indentation is balanced even if the body raises.
- **Applies to:**
  - `src/click/formatting.py`
- **Condition:** When modifying HelpFormatter.indentation or its context-manager logic, preserve the finally-based dedent guarantee.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8980782c72337d50e6eae02a.md)

## Rule 090 — `src/click/formatting.py`

- **Rule:**
  ```text
  formatting.py must expose a module-level FORCED_WIDTH that can force a width, explicitly used by the test system.
  ```
- **Applies to:**
  - `src/click/formatting.py`
- **Condition:** When changing formatting width resolution or test-controlled width overrides.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9af8ade3cc81723a7e3b4acd.md)

## Rule 113 — `src/click/formatting.py`

- **Rule:**
  ```text
  When modifying measure_table, preserve computing per-column maximum term_len across rows and returning widths as a tuple ordered by column index.
  ```
- **Applies to:**
  - `src/click/formatting.py`
- **Condition:**
  ```text
  When changing table width measurement or column ordering in measure_table.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b56942ba6a9b3b6eec3158a0.md)
