# Rules for `src/click/testing.py`

## Rule 006 — `src/click/testing.py`

- **Rule:**
  ```text
  When _pause_echo is used as a context manager, set stream._paused=True on entry and False on exit, yielding immediately when stream is None, to control echo suppression during testing.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:**
  ```text
  Modifying _pause_echo or the echo-suppression context manager used in tests.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-08b5c06f07a6281d1f0bf1e6.md)

## Rule 027 — `src/click/testing.py`

- **Rule:**
  ```text
  isolated_filesystem must create a temporary directory, change CWD to it, restore the original CWD on exit, and not remove the created directory when temp_dir is provided.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:**
  ```text
  When modifying CliRunner.isolated_filesystem or temporary directory handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2969b0ef4700047d32a443c6.md)

## Rule 074 — `src/click/testing.py`

- **Rule:**
  ```text
  When modifying StreamMixer.flush, preserve flushing both the superclass stream and the copy_to target so mirrored output is flushed in tandem.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:** when changing StreamMixer flush behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-7c009ac3262b01729fcb2cd8.md)

## Rule 103 — `src/click/testing.py`

- **Rule:**
  ```text
  The visible_input helper must write the prompt to stdout, read a line from text_input, strip CR/LF, echo the value back to stdout, and flush, defining the observable input/output contract for tests using this helper.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:**
  ```text
  When modifying CliRunner.isolation.visible_input or test input/output helpers.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a811585c66eea265423bb83c.md)

## Rule 114 — `src/click/testing.py`

- **Rule:** When StreamMixer is used, it mixes stdout and stderr streams with the combined result available in the output attribute, as documented since version 8.2.
- **Applies to:**
  - `src/click/testing.py`
- **Condition:** Modifying StreamMixer or its documented output attribute contract.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b61d63efdf21bbf5a9fe8c50.md)

## Rule 135 — `src/click/testing.py`

- **Rule:** When a test stream wrapper is constructed, store name and mode separately and pass the underlying buffer to the superclass, preserving the original stream identity for testing.
- **Applies to:**
  - `src/click/testing.py`
- **Condition:**
  ```text
  Modifying _NamedTextIOWrapper.__init__ or the test stream wrapper construction.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ce5ddf1b58c177a26011f74e.md)
