# Rules for `src/click/decorators.py`

## Rule 037 — `src/click/decorators.py`

- **Rule:**
  ```text
  make_pass_decorator's new_func must retrieve the current context, ensure or find the object of the requested type, and raise RuntimeError when no such object exists, so pass_obj requires a context object of the specified type.
  ```
- **Applies to:**
  - `src/click/decorators.py`
- **Condition:**
  ```text
  When modifying make_pass_decorator or the pass_obj context-object resolution path.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3a62a53ad1abf1134dde4226.md)

## Rule 052 — `src/click/decorators.py`

- **Rule:**
  ```text
  _param_memo must append parameters directly to a Command's params list, or accumulate them in a __click_params__ attribute on plain functions for later conversion, defining how decorators attach parameters.
  ```
- **Applies to:**
  - `src/click/decorators.py`
- **Condition:** When changing how decorators attach parameters to commands or plain functions.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4aa77ae6373abb2425a34336.md)

## Rule 126 — `src/click/decorators.py`

- **Rule:**
  ```text
  When modifying pass_context, preserve wrapping the callback so it receives the current Context as its first argument and finalizing the wrapper with update_wrapper to preserve the original function metadata.
  ```
- **Applies to:**
  - `src/click/decorators.py`
- **Condition:**
  ```text
  When changing pass_context callback wrapping or metadata preservation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c20d7f2df8cddba07f5fc03b.md)
