# Rules for `src/click/termui.py`

## Rule 055 — `src/click/termui.py`

- **Rule:**
  ```text
  When modifying the termui module, preserve the module-level visible_prompt_func callable defaulting to input and the _getchar module-level hook used for unittesting getchar calls.
  ```
- **Applies to:**
  - `src/click/termui.py`
- **Condition:** when changing termui module-level prompt or getchar hooks
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5380aad82d9c2e664dffde10.md)

## Rule 065 — `src/click/termui.py`

- **Rule:** Color interpretation must encode int colors as 256-color SGR sequences and tuple/list colors as truecolor SGR sequences, with offset distinguishing foreground from background.
- **Applies to:**
  - `src/click/termui.py`
- **Condition:**
  ```text
  When modifying _interpret_color or color encoding logic.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-65e87a7d33f36fb3f2784baf.md)
