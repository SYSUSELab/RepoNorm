# Rules for `src/click/_textwrap.py`

## Rule 060 — `src/click/_textwrap.py`

- **Rule:**
  ```text
  When modifying `TextWrapper` in `_textwrap.py`, preserve that it subclasses `textwrap.TextWrapper` to customize standard-library text wrapping behavior.
  ```
- **Applies to:**
  - `src/click/_textwrap.py`
- **Condition:** when changing click's text wrapping customization
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5eb7138edfb10675685d6c2e.md)
