# Rules for `src/click/parser.py`

## Rule 102 — `src/click/parser.py`

- **Rule:**
  ```text
  When modifying _OptionParser.add_option, preserve normalization via _normalize_opt, updating _opt_prefixes from the option's prefixes, registering short and long opts into _short_opt and _long_opt, and requiring dest explicitly rather than inferring it.
  ```
- **Applies to:**
  - `src/click/parser.py`
- **Condition:**
  ```text
  When changing option registration, prefix tracking, or dest handling in _OptionParser.add_option.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a779b45b30dc21f10dbc9170.md)
