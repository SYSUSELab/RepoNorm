# Rules for `src/click/types.py`

## Rule 019 — `src/click/types.py`

- **Rule:**
  ```text
  _NumberRangeBase._describe_range must format numeric range help text using open/closed comparison operators based on min_open and max_open, producing strings like x<max, x>=min, or min<=x<=max.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When modifying _NumberRangeBase._describe_range or range help formatting, preserve the open/closed operator selection driven by min_open and max_open.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1972e8d68c5f16805afc2e58.md)

## Rule 025 — `src/click/types.py`

- **Rule:**
  ```text
  When modifying Path.to_info_dict, preserve extending the parent dict with exists, file_okay, dir_okay, writable, readable, and allow_dash.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When changing Path.to_info_dict's introspection fields.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2711e15babc473861151b547.md)

## Rule 028 — `src/click/types.py`

- **Rule:** CompositeParamType.arity must raise NotImplementedError, marking it as an abstract member that subclasses must override.
- **Applies to:**
  - `src/click/types.py`
- **Condition:** When modifying CompositeParamType or adding new composite parameter types.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2b54b2586ff01cebea8d9c0a.md)

## Rule 040 — `src/click/types.py`

- **Rule:**
  ```text
  Choice.convert must normalize the value and choices through ctx.token_normalize_func before casefolding when case_sensitive is False, and must report failures using the original value via get_invalid_choice_message.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:** When modifying Choice.convert or the normalization/casefolding path for choice conversion.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3d3588304db859dee7f150f7.md)

## Rule 043 — `src/click/types.py`

- **Rule:**
  ```text
  Tuple type conversion must convert each supplied type via convert_type and store the resulting sequence of ParamType instances.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When modifying Tuple.__init__ or the type conversion pipeline for composite types.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3f3f88533a23a5aeeaef083b.md)

## Rule 061 — `src/click/types.py`

- **Rule:** When modifying OptionHelpExtra, preserve the TypedDict contract with optional keys envvars, default, range, and required defining the extra help metadata for options.
- **Applies to:**
  - `src/click/types.py`
- **Condition:** When changing the OptionHelpExtra TypedDict or the extra help metadata keys for options.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5f3c4eb60b726b6750879840.md)

## Rule 080 — `src/click/types.py`

- **Rule:**
  ```text
  When modifying DateTime._try_to_convert_date, preserve attempting datetime.strptime and returning None on ValueError so callers treat unparseable values as non-matches rather than raising.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When changing date parsing or error handling in DateTime._try_to_convert_date.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-861db86231d09216609f1423.md)

## Rule 085 — `src/click/types.py`

- **Rule:**
  ```text
  Path.coerce_path_result must convert values to str via os.fsdecode, to bytes via os.fsencode, or to the configured self.type, returning the value unchanged when it already matches the configured type.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:** When modifying Path type coercion or adding new path result types.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-908d81f91534149e248ae919.md)

## Rule 140 — `src/click/types.py`

- **Rule:**
  ```text
  ParamType.to_info_dict must derive param_type by stripping 'ParamType'/'ParameterType' suffixes from the class name, falling back to that name when the instance has no name attribute, and return a dict with 'param_type' and 'name' keys.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When modifying ParamType.to_info_dict or adding ParamType subclasses, preserve the suffix-stripping derivation and the {'param_type', 'name'} return shape.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-dc6da1eaef46924e0c45191f.md)
