# Rules for `src/click/_compat.py`

## Rule 062 — `src/click/_compat.py`

- **Rule:** Atomic writes must reject append mode, exclusive mode, and any mode without "w", raising ValueError with guidance to use normal w-mode or the overwrite parameter.
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:** When changing atomic write mode validation or its error guidance.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6366e0e6798213f82a4141f5.md)

## Rule 066 — `src/click/_compat.py`

- **Rule:**
  ```text
  _force_correct_text_writer must delegate to _force_correct_text_stream with _is_binary_writer and _find_binary_writer so text-writer correction shares the same stream-detection protocol as text readers.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  When modifying _force_correct_text_writer or stream correction logic.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-67713e6508ab006682688948.md)

## Rule 072 — `src/click/_compat.py`

- **Rule:**
  ```text
  strip_ansi must remove ANSI escape sequences from a string using the module-level _ansi_re pattern.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  When modifying strip_ansi or the _ansi_re pattern in src/click/_compat.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-7895c182430a437c73f5e5d7.md)

## Rule 083 — `src/click/_compat.py`

- **Rule:**
  ```text
  When resolving the stderr text stream, first attempt the Windows console stream and fall back to _force_correct_text_writer with force_writable=True, preserving the defined resolution order.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  Modifying get_text_stderr or the stderr text-stream resolution path.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8865e30065e3a9ce4816a57e.md)

## Rule 091 — `src/click/_compat.py`

- **Rule:**
  ```text
  When a context manager wraps a file that may be deleted on error, close the file with delete=exc_type is not None so an exception during the with-block deletes the file while normal exit preserves it.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  Modifying __exit__ of the atomic file context manager.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9bf9c7e75c69d52c2b97c787.md)

## Rule 125 — `src/click/_compat.py`

- **Rule:**
  ```text
  get_best_encoding must return the stream's encoding or sys.getdefaultencoding(), but substitute 'utf-8' whenever the resolved encoding is an ASCII encoding.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  When modifying get_best_encoding or encoding fallback logic.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c115cecc267d3850cd31ff0f.md)

## Rule 134 — `src/click/_compat.py`

- **Rule:**
  ```text
  When modifying _make_text_stream, preserve the default encoding resolution via get_best_encoding(stream), the 'replace' error default, and wrapping in _NonClosingTextIOWrapper with line_buffering=True and the force_readable/force_writable flags.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  When changing text stream construction, encoding/error defaults, or wrapper flags in _make_text_stream.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-cd1c00403944e8b53a621eac.md)
