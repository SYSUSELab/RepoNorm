# Rules for `src/click/core.py`

## Rule 003 — `src/click/core.py`

- **Rule:**
  ```text
  When declaring an Argument, accept exactly one name; allow zero declarations only when expose_value is False, otherwise raise TypeError.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  Modifying Argument._parse_decls or argument name-declaration validation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-02e6881e25e7151292d8ea06.md)

## Rule 014 — `src/click/core.py`

- **Rule:**
  ```text
  Argument must be a Parameter subclass with param_type_name "argument"; arguments are positional, required by default, and support infinite nargs, unlike options.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:** When modifying Argument or adding new parameter types.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1578f25d09687b54b22655d7.md)

## Rule 017 — `src/click/core.py`

- **Rule:**
  ```text
  When building a usage string, delegate to format_usage and strip trailing newlines so callers receive a usage string without a trailing newline.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  Modifying Command.get_usage or the usage-string formatting path.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-18df819ada9d682666f601c5.md)

## Rule 100 — `src/click/core.py`

- **Rule:**
  ```text
  The help option callback must only echo help and exit when the option value is truthy and ctx.resilient_parsing is false, so help output must be suppressed during resilient parsing.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When modifying Command.get_help_option's show_help callback or the resilient-parsing handling around help output.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a2c8ee78e5f80a68e08ef331.md)

## Rule 105 — `src/click/core.py`

- **Rule:** Code that subclasses or type-checks against the command base class must use Command, not the removed BaseCommand alias.
- **Applies to:**
  - `src/click/core.py`
- **Condition:** When adding or modifying a command class or code that subclasses/type-checks the command base class.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ab2e49444548edcdf6282a81.md)

## Rule 129 — `src/click/core.py`

- **Rule:**
  ```text
  Since 8.1, help, epilog, and short_help must be stored unprocessed and formatting deferred to help output time, so code must not assume these attributes contain pre-wrapped text.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When modifying Command help, epilog, or short_help storage or formatting behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c8d173f3a60e1509d80dfe96.md)

## Rule 147 — `src/click/core.py`

- **Rule:**
  ```text
  When modifying Option.get_help_extra, preserve deriving envvar names from auto_envvar_prefix and option name, temporarily enabling resilient parsing while computing defaults, formatting defaults specially for lists, functions, boolean flags, and empty strings, and adding range info for number range types except count options with default range.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:** when changing help extra generation for options
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ecd06714083a4861254ca9da.md)
