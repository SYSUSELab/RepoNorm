# Rules for `src/click/utils.py`

## Rule 034 — `src/click/utils.py`

- **Rule:**
  ```text
  When a lazy file wrapper is closed, close the underlying file only if the wrapper opened it (should_close is true); never close files the wrapper did not open, such as stdin.
  ```
- **Applies to:**
  - `src/click/utils.py`
- **Condition:**
  ```text
  Modifying close_intelligently or the lazy file wrapper's close path.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-321626ade2cb4a7c0ffabd2a.md)

## Rule 045 — `src/click/utils.py`

- **Rule:**
  ```text
  LazyFile must defer opening regular files in read mode: it opens and closes once to surface errors early, then defers the real handle until first read; '-' is opened immediately via open_stream.
  ```
- **Applies to:**
  - `src/click/utils.py`
- **Condition:**
  ```text
  When modifying LazyFile.__init__ or its open/read behavior for regular files in read mode.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-42ede5748049dae2a99c8277.md)

## Rule 050 — `src/click/utils.py`

- **Rule:**
  ```text
  Wrapper classes that store a wrapped IO object must expose it as self.wrapped in __init__, defining the attribute name other code uses to access the underlying stream.
  ```
- **Applies to:**
  - `src/click/utils.py`
- **Condition:** When modifying PacifyFlushWrapper or other IO wrapper classes.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-46cd26f9540da8e2a8f09c98.md)

## Rule 151 — `src/click/utils.py`

- **Rule:**
  ```text
  When modifying `get_text_stream`, preserve that it raises `TypeError` for unknown stream names and otherwise delegates to the registered opener with encoding and errors.
  ```
- **Applies to:**
  - `src/click/utils.py`
- **Condition:**
  ```text
  when changing `get_text_stream`'s stream-name validation or opener delegation
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f8cef1e8491da7a16610799c.md)
