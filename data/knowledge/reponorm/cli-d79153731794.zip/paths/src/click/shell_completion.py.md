# Rules for `src/click/shell_completion.py`

## Rule 021 — `src/click/shell_completion.py`

- **Rule:**
  ```text
  When modifying ZshComplete.format_completion, preserve the three-line completion item of type, value, and help or '_' when help is absent.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:**
  ```text
  When changing format_completion's output line structure or help fallback.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1b82c955be34bcd6abc7cc3a.md)

## Rule 048 — `src/click/shell_completion.py`

- **Rule:**
  ```text
  When modifying _resolve_context, preserve resilient_parsing=True, hierarchy walking via resolve_command, chained-group handling with allow_extra_args=True and allow_interspersed_args=False, and returning the deepest context without triggering prompts or callbacks.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:**
  ```text
  When changing shell completion context resolution or command hierarchy walking in _resolve_context.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-44c38790d266166fdfa8ea0b.md)

## Rule 078 — `src/click/shell_completion.py`

- **Rule:**
  ```text
  ShellComplete.func_name must derive the completion function name from prog_name by replacing hyphens with underscores and stripping non-word characters, yielding "_{safe_name}_completion".
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:**
  ```text
  When modifying shell completion function name generation or prog_name handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8407562816bf52fc2d398f1f.md)

## Rule 081 — `src/click/shell_completion.py`

- **Rule:**
  ```text
  When modifying _resolve_incomplete, preserve '=' normalization by splitting and discarding it, returning the command for option-name completion when '--' is absent and the incomplete value starts like an option, and otherwise selecting the option or argument that should provide value completion.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:**
  ```text
  When changing incomplete-value normalization or completion target selection in _resolve_incomplete.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-86428926137ed5557576965f.md)

## Rule 106 — `src/click/shell_completion.py`

- **Rule:**
  ```text
  Bash shell completion must reject Bash versions older than 4.4 and must also fail when the version cannot be detected, so any change to BashComplete._check_version or its version-parsing path must preserve this hard compatibility boundary.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:**
  ```text
  When modifying BashComplete._check_version or the Bash version detection/parsing logic used by shell completion.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-abf339dcd2e10b560c8d1312.md)

## Rule 118 — `src/click/shell_completion.py`

- **Rule:**
  ```text
  When modifying _start_of_option, preserve returning False for an empty value and otherwise checking whether the first character is in ctx._opt_prefixes, so option detection is context-dependent.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:**
  ```text
  When changing option prefix detection or empty-value handling in _start_of_option.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-bd846287a96323a7bc7fc6c1.md)

## Rule 144 — `src/click/shell_completion.py`

- **Rule:**
  ```text
  When modifying `ShellComplete.complete`, preserve the wire format: join formatted completions with newlines after obtaining args and completions.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:** when changing shell completion output formatting or the complete method
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e2d64450b3f83e79bb8a7d02.md)
