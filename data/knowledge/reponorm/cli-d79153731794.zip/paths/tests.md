# Rules for `tests`

## Rule 022 — `CHANGES.rst`

- **Rule:** The flit sdist build includes docs/, requirements/, tests/, CHANGES.rst, and tox.ini in the source distribution.
- **Applies to:**
  - `CHANGES.rst`
  - `docs/**`
  - `requirements/**`
  - `tests/**`
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1d065bb8734bc157d796f0e9.md)

## Rule 089 — `click/**`

- **Rule:** Coverage measurement is configured to source from the click and tests packages.
- **Applies to:**
  - `click/**`
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9aeaa14caa63bc7d00c05067.md)

## Rule 119 — `tests/**`

- **Rule:**
  ```text
  Pytest test discovery is restricted to the tests directory via testpaths = ["tests"].
  ```
- **Applies to:**
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-bd8d44fe836bf4f6dc5dfb0f.md)
