# Repository knowledge

Apply rules within their stated scope and when their conditions hold, respecting
exceptions. `required`, `recommended`, and `observed` have different strength:
an observed convention does not by itself prohibit a change requested by the task.
`reference_only` is context, not a default action.
Evidence locations identify sources, not the rule's scope.
Commands in rules do not authorize unrelated changes or external side effects.
Use relevant rules alongside the task and repository code; keep edits focused.

## Find rules

Path links and the [full catalog](catalog.md) are alternative routes. Search or
open relevant files directly; open claim details when evidence or a conflict matters.
Paths are navigation anchors, not a replacement for each rule's complete scope.

- `repository root`: [Read rules](paths/repository.md)
- `.github/workflows/lock.yaml`: [Read rules](paths/.github/workflows/lock.yaml.md)
- `.github/workflows/pre-commit.yaml`: [Read rules](paths/.github/workflows/pre-commit.yaml.md)
- `.github/workflows/publish.yaml`: [Read rules](paths/.github/workflows/publish.yaml.md)
- `CHANGES.rst`: [Read rules](paths/CHANGES.rst.md)
- `click`: [Read rules](paths/click.md)
- `docs`: [Read rules](paths/docs.md)
- `docs/_build`: [Read rules](paths/docs/_build.md)
- `docs/conf.py`: [Read rules](paths/docs/conf.py.md)
- `examples`: [Read rules](paths/examples.md)
- `examples/complex/complex/cli.py`: [Read rules](paths/examples/complex/complex/cli.py.md)
- `examples/complex/complex/commands/cmd_status.py`: [Read rules](paths/examples/complex/complex/commands/cmd_status.py.md)
- `examples/imagepipe/imagepipe.py`: [Read rules](paths/examples/imagepipe/imagepipe.py.md)
- `examples/repo/repo.py`: [Read rules](paths/examples/repo/repo.py.md)
- `examples/termui/termui.py`: [Read rules](paths/examples/termui/termui.py.md)
- `requirements`: [Read rules](paths/requirements.md)
- `requirements/build.in`: [Read rules](paths/requirements/build.in.md)
- `requirements/dev.in`: [Read rules](paths/requirements/dev.in.md)
- `requirements/docs.in`: [Read rules](paths/requirements/docs.in.md)
- `requirements/docs.txt`: [Read rules](paths/requirements/docs.txt.md)
- `requirements/tests.in`: [Read rules](paths/requirements/tests.in.md)
- `requirements/typing.in`: [Read rules](paths/requirements/typing.in.md)
- `requirements/typing.txt`: [Read rules](paths/requirements/typing.txt.md)
- `src/click`: [Read rules](paths/src/click.md)
- `src/click/_compat.py`: [Read rules](paths/src/click/_compat.py.md)
- `src/click/_termui_impl.py`: [Read rules](paths/src/click/_termui_impl.py.md)
- `src/click/_textwrap.py`: [Read rules](paths/src/click/_textwrap.py.md)
- `src/click/_winconsole.py`: [Read rules](paths/src/click/_winconsole.py.md)
- `src/click/core.py`: [Read rules](paths/src/click/core.py.md)
- `src/click/decorators.py`: [Read rules](paths/src/click/decorators.py.md)
- `src/click/exceptions.py`: [Read rules](paths/src/click/exceptions.py.md)
- `src/click/formatting.py`: [Read rules](paths/src/click/formatting.py.md)
- `src/click/parser.py`: [Read rules](paths/src/click/parser.py.md)
- `src/click/shell_completion.py`: [Read rules](paths/src/click/shell_completion.py.md)
- `src/click/termui.py`: [Read rules](paths/src/click/termui.py.md)
- `src/click/testing.py`: [Read rules](paths/src/click/testing.py.md)
- `src/click/types.py`: [Read rules](paths/src/click/types.py.md)
- `src/click/utils.py`: [Read rules](paths/src/click/utils.py.md)
- `tests`: [Read rules](paths/tests.md)
- `tests/conftest.py`: [Read rules](paths/tests/conftest.py.md)
- `tests/test_arguments.py`: [Read rules](paths/tests/test_arguments.py.md)
- `tests/test_compat.py`: [Read rules](paths/tests/test_compat.py.md)
- `tests/test_formatting.py`: [Read rules](paths/tests/test_formatting.py.md)
- `tests/test_info_dict.py`: [Read rules](paths/tests/test_info_dict.py.md)
- `tests/test_normalization.py`: [Read rules](paths/tests/test_normalization.py.md)
- `tests/test_options.py`: [Read rules](paths/tests/test_options.py.md)
- `tests/test_parser.py`: [Read rules](paths/tests/test_parser.py.md)
- `tests/test_shell_completion.py`: [Read rules](paths/tests/test_shell_completion.py.md)
- `tests/test_termui.py`: [Read rules](paths/tests/test_termui.py.md)
- `tests/test_testing.py`: [Read rules](paths/tests/test_testing.py.md)
- `tests/typing`: [Read rules](paths/tests/typing.md)
- `tests/typing/typing_aliased_group.py`: [Read rules](paths/tests/typing/typing_aliased_group.py.md)
- `tox.ini`: [Read rules](paths/tox.ini.md)
