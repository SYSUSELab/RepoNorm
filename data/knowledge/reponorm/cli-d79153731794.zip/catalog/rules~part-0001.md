# Full rule catalog

## Rule 001 — `**/*.py`

- **Rule:** Ruff's isort lint rule is configured with order-by-type = false, so imports are not ordered by type.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-010cc208586d45fa9f0da5d4.md)

## Rule 002 — `tests/test_formatting.py`

- **Rule:** Tests for usage-error formatting must preserve the convention that a missing required argument produces exit code 2 and a four-line usage/error output including a blank line before the Error line.
- **Applies to:**
  - `tests/test_formatting.py`
- **Condition:** When modifying usage-error formatting tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-022c1a552ce02c81588d1173.md)

## Rule 003 — `src/click/core.py`

- **Rule:**
  ```text
  When declaring an Argument, accept exactly one name; allow zero declarations only when expose_value is False, otherwise raise TypeError.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  Modifying Argument._parse_decls or argument name-declaration validation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-02e6881e25e7151292d8ea06.md)

## Rule 004 — `tests/test_arguments.py`

- **Rule:** Tests for CLI decorator composition must preserve the convention that a group command can combine click.argument('arg2') and click.option('--opt2') on the same callback.
- **Applies to:**
  - `tests/test_arguments.py`
- **Condition:** When modifying tests that compose group, argument, and option decorators on one callback.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-044d4b6d08edeb272eaa376a.md)

## Rule 005 — `examples/complex/complex/cli.py`

- **Rule:** The complex example's vlog method must log to stderr only when verbose is enabled, preserving the conditional logging pattern.
- **Applies to:**
  - `examples/complex/complex/cli.py`
- **Condition:** When modifying the vlog method or verbose logging behavior in the complex example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-06517565780ec21f5dc13ed9.md)

## Rule 006 — `src/click/testing.py`

- **Rule:**
  ```text
  When _pause_echo is used as a context manager, set stream._paused=True on entry and False on exit, yielding immediately when stream is None, to control echo suppression during testing.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:**
  ```text
  Modifying _pause_echo or the echo-suppression context manager used in tests.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-08b5c06f07a6281d1f0bf1e6.md)

## Rule 007 — `tests/test_options.py`

- **Rule:**
  ```text
  Tests that assert duplicate option-name detection must invoke the CLI and expect a `UserWarning`, covering both duplicate short names and duplicate long names.
  ```
- **Applies to:**
  - `tests/test_options.py`
- **Condition:**
  ```text
  When adding or modifying duplicate option-name detection tests in tests/test_options.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0d396bf4da64442a8797836e.md)

## Rule 008 — `src/click/_winconsole.py`

- **Rule:**
  ```text
  ConsoleStream must remain a Windows-specific stream wrapper in click._winconsole, preserving platform-specific console handling.
  ```
- **Applies to:**
  - `src/click/_winconsole.py`
- **Condition:** When modifying or relocating Windows console stream handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0df4255590f62b794fa23a20.md)

## Rule 009 — `tox.ini`

- **Rule:**
  ```text
  The update-requirements tox environment sets skip_install to true.
  ```
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0f04a1dc27abdebee6e89d9b.md)

## Rule 010 — `**`

- **Rule:** CI runs the full test suite when a pull request is submitted.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-10e2060f87ea893448355e90.md)

## Rule 011 — `tests/test_info_dict.py`

- **Rule:**
  ```text
  Tests that pin Click's public parameter/option introspection contract must keep the exact to_info_dict field set and values for each parameter kind (STRING/INT/BOOL, help option, name argument, number option, command, group), including group-only fields commands and chain.
  ```
- **Applies to:**
  - `tests/test_info_dict.py`
- **Condition:**
  ```text
  When modifying or extending the expected to_info_dict structures in the info-dict contract test.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1126906c942ed89f50f7d7af.md)

## Rule 012 — `.github/workflows/publish.yaml`

- **Rule:** The build job uploads the ./dist directory as an artifact.
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-12e7c4eb856adce5f9b84b17.md)

## Rule 013 — `tests/test_options.py`

- **Rule:**
  ```text
  Tests for flag_value typing must preserve the convention that an Option with flag_value infers click.INT regardless of whether a default is also supplied.
  ```
- **Applies to:**
  - `tests/test_options.py`
- **Condition:**
  ```text
  When modifying flag_value type-inference tests.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1328422207e30d4f3548a151.md)

## Rule 014 — `src/click/core.py`

- **Rule:**
  ```text
  Argument must be a Parameter subclass with param_type_name "argument"; arguments are positional, required by default, and support infinite nargs, unlike options.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:** When modifying Argument or adding new parameter types.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1578f25d09687b54b22655d7.md)

## Rule 015 — `src/click/exceptions.py`

- **Rule:**
  ```text
  When modifying ClickException.format_message, preserve returning self.message directly so subclasses can override message formatting by setting the message attribute.
  ```
- **Applies to:**
  - `src/click/exceptions.py`
- **Condition:** when changing exception message formatting
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-171debb17a4b05be083c8d2c.md)

## Rule 016 — `.github/workflows/publish.yaml`

- **Rule:** The publish-pypi job then publishes the artifact/ directory to PyPI using the pypa/gh-action-pypi-publish action.
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-18bc78f6ad3d3e041e0ba20b.md)

## Rule 017 — `src/click/core.py`

- **Rule:**
  ```text
  When building a usage string, delegate to format_usage and strip trailing newlines so callers receive a usage string without a trailing newline.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  Modifying Command.get_usage or the usage-string formatting path.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-18df819ada9d682666f601c5.md)

## Rule 018 — `examples/imagepipe/imagepipe.py`

- **Rule:** Imagepipe processor commands must be implemented as generator functions decorated with @processor that yield transformed images, so the pipeline can stream results and echo progress.
- **Applies to:**
  - `examples/imagepipe/imagepipe.py`
- **Condition:** When adding or modifying an imagepipe subcommand that transforms images.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-19364f0289f93bfcde4bf129.md)
