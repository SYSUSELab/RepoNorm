# Full rule catalog

## Rule 109 — `.github/workflows/publish.yaml`

- **Rule:** The build job installs build requirements via pip install -r requirements/build.txt.
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-af6c405fc4f618274aab8565.md)

## Rule 110 — `examples/termui/termui.py`

- **Rule:** The termui example must remain a standalone demo script that imports math, random, time, and click, preserving these runtime dependencies.
- **Applies to:**
  - `examples/termui/termui.py`
- **Condition:** When modifying imports or runtime dependencies of the termui example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-afe018134cdb3abb56add0a3.md)

## Rule 111 — `.github/workflows/lock.yaml`

- **Rule:** The lock workflow uses the dessant/lock-threads action pinned to commit 1bf7ec25051fe7c00bdd17e6a7cf3d7bfb7dc771 (v5.0.1) with issue-inactive-days, pr-inactive-days, and discussion-inactive-days all set to 14.
- **Applies to:**
  - `.github/workflows/lock.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b20b8fc2ffd95a4ab31e8a10.md)

## Rule 112 — `tests/test_options.py`

- **Rule:** Tests for option naming must preserve the convention that Click accepts multi-character single-dash option names such as "-whatever".
- **Applies to:**
  - `tests/test_options.py`
- **Condition:** When modifying option-naming tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b4d37864e51f0ed1c1b4e35c.md)

## Rule 113 — `src/click/formatting.py`

- **Rule:**
  ```text
  When modifying measure_table, preserve computing per-column maximum term_len across rows and returning widths as a tuple ordered by column index.
  ```
- **Applies to:**
  - `src/click/formatting.py`
- **Condition:**
  ```text
  When changing table width measurement or column ordering in measure_table.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b56942ba6a9b3b6eec3158a0.md)

## Rule 114 — `src/click/testing.py`

- **Rule:** When StreamMixer is used, it mixes stdout and stderr streams with the combined result available in the output attribute, as documented since version 8.2.
- **Applies to:**
  - `src/click/testing.py`
- **Condition:** Modifying StreamMixer or its documented output attribute contract.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b61d63efdf21bbf5a9fe8c50.md)

## Rule 115 — `tests/test_shell_completion.py`

- **Rule:**
  ```text
  Tests that exercise shell-completion behavior must isolate the global `click.shell_completion._available_shells` state by snapshotting it before the test and restoring the previous contents afterward.
  ```
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:**
  ```text
  When adding or modifying a test that reads or mutates shell-completion state in tests/test_shell_completion.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b6e507d6349bbfcd5dadec33.md)

## Rule 116 — `tests/test_compat.py`

- **Rule:**
  ```text
  should_strip_ansi must return False for streams whose __module__ is "ipykernel.faked", i.e. Jupyter kernel output streams are detected by module name and not stripped.
  ```
- **Applies to:**
  - `tests/test_compat.py`
- **Condition:** Modifying or adding tests that assert ANSI stripping behavior for Jupyter kernel output streams.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ba8093b71b7e08f5fbb8f1cd.md)

## Rule 117 — `examples/complex/complex/cli.py`

- **Rule:** Example CLI context initialization must set default state values such as verbose to False and home to os.getcwd(), establishing the default context state used by the example.
- **Applies to:**
  - `examples/complex/complex/cli.py`
- **Condition:** when adding or modifying the CLI context initialization in the complex example
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-bcd96def3d19788305000d23.md)

## Rule 118 — `src/click/shell_completion.py`

- **Rule:**
  ```text
  When modifying _start_of_option, preserve returning False for an empty value and otherwise checking whether the first character is in ctx._opt_prefixes, so option detection is context-dependent.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:**
  ```text
  When changing option prefix detection or empty-value handling in _start_of_option.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-bd846287a96323a7bc7fc6c1.md)

## Rule 119 — `tests/**`

- **Rule:**
  ```text
  Pytest test discovery is restricted to the tests directory via testpaths = ["tests"].
  ```
- **Applies to:**
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-bd8d44fe836bf4f6dc5dfb0f.md)

## Rule 120 — `src/click/_winconsole.py`

- **Rule:**
  ```text
  When modifying the Windows console stream's `isatty`, preserve that it calls `super().isatty()` and then unconditionally returns True, forcing TTY detection to true for that stream.
  ```
- **Applies to:**
  - `src/click/_winconsole.py`
- **Condition:** when changing Windows console TTY detection
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-be0c1fa0187beaaf2972f201.md)

## Rule 121 — `tox.ini`

- **Rule:** The testenv environment constrains package dependencies.
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-be3e246bc4dca498f1f8e863.md)

## Rule 122 — `src/click/_winconsole.py`

- **Rule:** Windows console stdin must be wrapped as a UTF-16-LE text stream with strict error handling and line buffering, and the wrapper must be non-closing so the underlying buffer stream is not closed when the text stream is closed.
- **Applies to:**
  - `src/click/_winconsole.py`
- **Condition:** When modifying Windows console stdin wrapping or text stream configuration.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-bf84779eb05928452f77a409.md)

## Rule 123 — `**`

- **Rule:**
  ```text
  The tox `style` test environment declares `pre-commit` as a dependency.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c003aa90ec90a222556ae063.md)

## Rule 124 — `src/click/_termui_impl.py`

- **Rule:**
  ```text
  When modifying `_nullpager`, preserve its role as the ultimate fallback pager: write each generator chunk directly to the stream, stripping ANSI when color is false.
  ```
- **Applies to:**
  - `src/click/_termui_impl.py`
- **Condition:** when changing pager fallback behavior or ANSI stripping
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c100a0754ee5ec42da65fccc.md)

## Rule 125 — `src/click/_compat.py`

- **Rule:**
  ```text
  get_best_encoding must return the stream's encoding or sys.getdefaultencoding(), but substitute 'utf-8' whenever the resolved encoding is an ASCII encoding.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  When modifying get_best_encoding or encoding fallback logic.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c115cecc267d3850cd31ff0f.md)

## Rule 126 — `src/click/decorators.py`

- **Rule:**
  ```text
  When modifying pass_context, preserve wrapping the callback so it receives the current Context as its first argument and finalizing the wrapper with update_wrapper to preserve the original function metadata.
  ```
- **Applies to:**
  - `src/click/decorators.py`
- **Condition:**
  ```text
  When changing pass_context callback wrapping or metadata preservation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c20d7f2df8cddba07f5fc03b.md)
