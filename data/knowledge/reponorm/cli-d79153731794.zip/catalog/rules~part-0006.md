# Full rule catalog

## Rule 091 — `src/click/_compat.py`

- **Rule:**
  ```text
  When a context manager wraps a file that may be deleted on error, close the file with delete=exc_type is not None so an exception during the with-block deletes the file while normal exit preserves it.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  Modifying __exit__ of the atomic file context manager.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9bf9c7e75c69d52c2b97c787.md)

## Rule 092 — `.github/workflows/publish.yaml`

- **Rule:** The publish-pypi job first publishes the artifact/ directory to the TestPyPI repository URL https://test.pypi.org/legacy/.
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9c0431ce1e13bf001811ee4b.md)

## Rule 093 — `.github/workflows/publish.yaml`

- **Rule:**
  ```text
  The build job sets SOURCE_DATE_EPOCH from the last commit date to use the commit date instead of the current date during the build.
  ```
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9c31decd9dfa1cf55e32f804.md)

## Rule 094 — `tests/test_normalization.py`

- **Rule:**
  ```text
  Normalization tests must preserve the convention that CONTEXT_SETTINGS uses token_normalize_func=lambda x: x.lower(), establishing lowercase token normalization as the tested convention.
  ```
- **Applies to:**
  - `tests/test_normalization.py`
- **Condition:** When modifying token normalization tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9c5e243fcd27c4912ad43a3a.md)

## Rule 095 — `tox.ini`

- **Rule:**
  ```text
  The tox environment `update-pre_commit` runs `pre-commit autoupdate -j4` as its command.
  ```
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9cc6c0ab9ea73efc20c5ce5d.md)

## Rule 096 — `src/click/exceptions.py`

- **Rule:**
  ```text
  _join_param_hints must join a sequence of param hints with ' / ' using repr() of each element, while returning a plain string hint unchanged, defining how multiple parameter hints are rendered in error messages.
  ```
- **Applies to:**
  - `src/click/exceptions.py`
- **Condition:** When changing parameter hint rendering in error messages.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9e88b475cc9509a1f0f583c1.md)

## Rule 097 — `tests/test_normalization.py`

- **Rule:** Tests that assert CLI option-name normalization must verify that uppercase long options and short options are accepted case-insensitively while the echoed values remain unchanged.
- **Applies to:**
  - `tests/test_normalization.py`
- **Condition:**
  ```text
  When adding or modifying option-normalization tests in tests/test_normalization.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a0cdb589a7168598a613000f.md)

## Rule 098 — `tests/test_parser.py`

- **Rule:**
  ```text
  split_arg_string must tolerate unbalanced quotes and trailing backslashes, yielding the documented token lists (e.g. "cli 'my file" -> ["cli","my file"], "cli my\\" -> ["cli","my"], "cli my\\ file" -> ["cli","my file"]); tests must preserve these exact outputs.
  ```
- **Applies to:**
  - `tests/test_parser.py`
- **Condition:**
  ```text
  Modifying or adding tests for split_arg_string's handling of malformed quoting or trailing backslashes.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a1817483a8fa11a820bbc1c2.md)

## Rule 099 — `tox.ini`

- **Rule:** The update-requirements tox environment declares pip-tools as its dependency.
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a2a275c4ef65e73bd28aa9ad.md)

## Rule 100 — `src/click/core.py`

- **Rule:**
  ```text
  The help option callback must only echo help and exit when the option value is truthy and ctx.resilient_parsing is false, so help output must be suppressed during resilient parsing.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When modifying Command.get_help_option's show_help callback or the resilient-parsing handling around help output.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a2c8ee78e5f80a68e08ef331.md)

## Rule 101 — `**/*.py`

- **Rule:** Code must be formatted using Black; this and other tools run automatically if pre-commit is installed.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-a408d42065383bf4a818f909.md)

## Rule 102 — `src/click/parser.py`

- **Rule:**
  ```text
  When modifying _OptionParser.add_option, preserve normalization via _normalize_opt, updating _opt_prefixes from the option's prefixes, registering short and long opts into _short_opt and _long_opt, and requiring dest explicitly rather than inferring it.
  ```
- **Applies to:**
  - `src/click/parser.py`
- **Condition:**
  ```text
  When changing option registration, prefix tracking, or dest handling in _OptionParser.add_option.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a779b45b30dc21f10dbc9170.md)

## Rule 103 — `src/click/testing.py`

- **Rule:**
  ```text
  The visible_input helper must write the prompt to stdout, read a line from text_input, strip CR/LF, echo the value back to stdout, and flush, defining the observable input/output contract for tests using this helper.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:**
  ```text
  When modifying CliRunner.isolation.visible_input or test input/output helpers.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a811585c66eea265423bb83c.md)

## Rule 104 — `.github/workflows/pre-commit.yaml`

- **Rule:** The pre-commit workflow sets up Python version 3.x.
- **Applies to:**
  - `.github/workflows/pre-commit.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ab2025424f0881c1de97611e.md)

## Rule 105 — `src/click/core.py`

- **Rule:** Code that subclasses or type-checks against the command base class must use Command, not the removed BaseCommand alias.
- **Applies to:**
  - `src/click/core.py`
- **Condition:** When adding or modifying a command class or code that subclasses/type-checks the command base class.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ab2e49444548edcdf6282a81.md)

## Rule 106 — `src/click/shell_completion.py`

- **Rule:**
  ```text
  Bash shell completion must reject Bash versions older than 4.4 and must also fail when the version cannot be detected, so any change to BashComplete._check_version or its version-parsing path must preserve this hard compatibility boundary.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:**
  ```text
  When modifying BashComplete._check_version or the Bash version detection/parsing logic used by shell completion.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-abf339dcd2e10b560c8d1312.md)

## Rule 107 — `examples/**`

- **Rule:** Ruff excludes the examples/ directory from linting via extend-exclude.
- **Applies to:**
  - `examples/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ac8f67bed5db1ab64f6db0e4.md)

## Rule 108 — `requirements/tests.in`

- **Rule:** The update-requirements tox environment runs pip-compile on tests.in with -q and posargs defaulting to -U.
- **Applies to:**
  - `requirements/tests.in`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-adfe8cae096b7ce8d2265718.md)
