# Full rule catalog

## Rule 127 — `tests/test_shell_completion.py`

- **Rule:**
  ```text
  Tests that assert shell-completion type mapping must verify that `File()` and `Path()` map to completion type 'file' while `Path(file_okay=False)` maps to 'dir'.
  ```
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:**
  ```text
  When adding or modifying shell-completion type-mapping tests in tests/test_shell_completion.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c50aff1e527b48eab2f05269.md)

## Rule 128 — `tox.ini`

- **Rule:** Tox skips environments whose interpreter is missing rather than failing.
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c8bcaee4108758565b8a29df.md)

## Rule 129 — `src/click/core.py`

- **Rule:**
  ```text
  Since 8.1, help, epilog, and short_help must be stored unprocessed and formatting deferred to help output time, so code must not assume these attributes contain pre-wrapped text.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When modifying Command help, epilog, or short_help storage or formatting behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c8d173f3a60e1509d80dfe96.md)

## Rule 130 — `**/*.css`

- **Rule:** CSS, HTML, JS, JSON, JSX, SCSS, TS, TSX, YAML, and YML files use an indent size of 2.
- **Applies to:**
  - `**/*.css`
  - `**/*.html`
  - `**/*.js`
  - `**/*.json`
  - `**/*.jsx`
  - `**/*.scss`
  - `**/*.ts`
  - `**/*.tsx`
  - `**/*.yaml`
  - `**/*.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ca0f468fabafbf8fc78e06a4.md)

## Rule 131 — `.github/workflows/publish.yaml`

- **Rule:**
  ```text
  The build job sets up Python version '3.x' with pip caching keyed on requirements*/*.txt.
  ```
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-cc7d2d6a8ae3f462d9f2104a.md)

## Rule 132 — `src/click/exceptions.py`

- **Rule:**
  ```text
  When modifying MissingParameter, preserve its BadParameter subclassing and the documented param_type values 'parameter', 'option', or 'argument', defaulting to inheriting the type from the given param.
  ```
- **Applies to:**
  - `src/click/exceptions.py`
- **Condition:**
  ```text
  When changing MissingParameter's inheritance or param_type defaulting.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-cc8ecf9febf3dfcb085eb5e4.md)

## Rule 133 — `src/click/_termui_impl.py`

- **Rule:**
  ```text
  _unquote_file must strip the 'file://' prefix and URL-unquote the remainder; non-file URLs are returned unchanged.
  ```
- **Applies to:**
  - `src/click/_termui_impl.py`
- **Condition:**
  ```text
  When modifying open_url's file URL handling or _unquote_file.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-cc93c8abae94fe4a2fbe3fa5.md)

## Rule 134 — `src/click/_compat.py`

- **Rule:**
  ```text
  When modifying _make_text_stream, preserve the default encoding resolution via get_best_encoding(stream), the 'replace' error default, and wrapping in _NonClosingTextIOWrapper with line_buffering=True and the force_readable/force_writable flags.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  When changing text stream construction, encoding/error defaults, or wrapper flags in _make_text_stream.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-cd1c00403944e8b53a621eac.md)

## Rule 135 — `src/click/testing.py`

- **Rule:** When a test stream wrapper is constructed, store name and mode separately and pass the underlying buffer to the superclass, preserving the original stream identity for testing.
- **Applies to:**
  - `src/click/testing.py`
- **Condition:**
  ```text
  Modifying _NamedTextIOWrapper.__init__ or the test stream wrapper construction.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ce5ddf1b58c177a26011f74e.md)

## Rule 136 — `docs/_build/**`

- **Rule:**
  ```text
  The flit sdist build excludes docs/_build/ from the source distribution.
  ```
- **Applies to:**
  - `docs/_build/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-cebafb991183ec8e3efc4110.md)

## Rule 137 — `**`

- **Rule:**
  ```text
  The tox `style` test environment runs `pre-commit run --all-files` as its command.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Use:** `reference_only`
- **Execution risk:** `repository_wide_mutation`
- **Detail:** [Open claim details](../claims/CLAIM-d1e98512944a2dae291236bb.md)

## Rule 138 — `tox.ini`

- **Rule:** The testenv environment runs pytest with -v, --tb=short, --basetemp={envtmpdir}, and {posargs}.
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d9eac712828b6a112adb51f3.md)

## Rule 139 — `examples/imagepipe/imagepipe.py`

- **Rule:**
  ```text
  The example demonstrates a command with a show_default option and a processor decorator that yields processed images, showing the supported image processing pipeline pattern.
  ```
- **Applies to:**
  - `examples/imagepipe/imagepipe.py`
- **Condition:** When modifying or adding commands with processor decorators in the imagepipe example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-dc4a849e05cbff2eff95ebbb.md)

## Rule 140 — `src/click/types.py`

- **Rule:**
  ```text
  ParamType.to_info_dict must derive param_type by stripping 'ParamType'/'ParameterType' suffixes from the class name, falling back to that name when the instance has no name attribute, and return a dict with 'param_type' and 'name' keys.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When modifying ParamType.to_info_dict or adding ParamType subclasses, preserve the suffix-stripping derivation and the {'param_type', 'name'} return shape.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-dc6da1eaef46924e0c45191f.md)

## Rule 141 — `requirements/dev.in`

- **Rule:** The update-requirements tox environment runs pip-compile on dev.in with -q and posargs defaulting to -U.
- **Applies to:**
  - `requirements/dev.in`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e0a6747d3bd6951821a73b2e.md)

## Rule 142 — `src/click/exceptions.py`

- **Rule:**
  ```text
  When modifying `MissingParameter.format_message`, preserve the missing-parameter message construction: resolve `param_hint` from `param.get_error_hint`, append the type's missing message, and translate `param_type` into 'Missing argument', 'Missing option', 'Missing parameter', or a generic 'Missing {param_type}'.
  ```
- **Applies to:**
  - `src/click/exceptions.py`
- **Condition:** when changing missing-parameter error message formatting
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e20f23e5237707244fe1280f.md)

## Rule 143 — `docs/conf.py`

- **Rule:**
  ```text
  Sphinx documentation builds must be configured through docs/conf.py, which sets autodoc_member_order='bysource', autodoc_typehints='description', autodoc_preserve_defaults=True, extlinks for issue/pr references, intersphinx to Python docs, and the click HTML theme; changes to documentation build behavior must preserve or deliberately update these settings.
  ```
- **Applies to:**
  - `docs/conf.py`
- **Condition:** When modifying the Sphinx documentation build configuration in docs/conf.py, including autodoc ordering, typehint rendering, default preservation, external link roles, intersphinx mappings, or the HTML theme.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e2680efe734f2a64a8fef620.md)
