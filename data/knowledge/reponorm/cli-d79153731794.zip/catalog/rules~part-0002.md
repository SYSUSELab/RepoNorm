# Full rule catalog

## Rule 019 — `src/click/types.py`

- **Rule:**
  ```text
  _NumberRangeBase._describe_range must format numeric range help text using open/closed comparison operators based on min_open and max_open, producing strings like x<max, x>=min, or min<=x<=max.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When modifying _NumberRangeBase._describe_range or range help formatting, preserve the open/closed operator selection driven by min_open and max_open.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1972e8d68c5f16805afc2e58.md)

## Rule 020 — `tests/test_shell_completion.py`

- **Rule:**
  ```text
  Shell completion tests must use a _get_words helper that maps _get_completions results to their .value strings for assertions.
  ```
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:** Modifying or adding shell completion tests that assert completion values.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-19c86316c3b175ebc72c143c.md)

## Rule 021 — `src/click/shell_completion.py`

- **Rule:**
  ```text
  When modifying ZshComplete.format_completion, preserve the three-line completion item of type, value, and help or '_' when help is absent.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:**
  ```text
  When changing format_completion's output line structure or help fallback.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1b82c955be34bcd6abc7cc3a.md)

## Rule 022 — `CHANGES.rst`

- **Rule:** The flit sdist build includes docs/, requirements/, tests/, CHANGES.rst, and tox.ini in the source distribution.
- **Applies to:**
  - `CHANGES.rst`
  - `docs/**`
  - `requirements/**`
  - `tests/**`
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1d065bb8734bc157d796f0e9.md)

## Rule 023 — `src/click/_termui_impl.py`

- **Rule:**
  ```text
  When modifying _pipepager, preserve the LESS-flag-driven color decision: enable color when LESS contains 'r' or 'R', otherwise set LESS='-R' and enable color; strip ANSI when color is disabled, and loop on c.wait() to ignore KeyboardInterrupt so less handles ^C.
  ```
- **Applies to:**
  - `src/click/_termui_impl.py`
- **Condition:**
  ```text
  When changing pager invocation, LESS environment handling, or color/ANSI stripping in _pipepager.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-21f888ed9d1e42f98937bd03.md)

## Rule 024 — `requirements/typing.txt`

- **Rule:** The typing tox environment installs its dependencies from requirements/typing.txt.
- **Applies to:**
  - `requirements/typing.txt`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-24d52da028e737a59825a6b2.md)

## Rule 025 — `src/click/types.py`

- **Rule:**
  ```text
  When modifying Path.to_info_dict, preserve extending the parent dict with exists, file_okay, dir_okay, writable, readable, and allow_dash.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When changing Path.to_info_dict's introspection fields.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-2711e15babc473861151b547.md)

## Rule 026 — `**/*.py`

- **Rule:** Ruff's isort lint rule is configured with force-single-line = true, so imports are forced onto single lines.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-27e474d49e125263b6ba5053.md)

## Rule 027 — `src/click/testing.py`

- **Rule:**
  ```text
  isolated_filesystem must create a temporary directory, change CWD to it, restore the original CWD on exit, and not remove the created directory when temp_dir is provided.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:**
  ```text
  When modifying CliRunner.isolated_filesystem or temporary directory handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-2969b0ef4700047d32a443c6.md)

## Rule 028 — `src/click/types.py`

- **Rule:** CompositeParamType.arity must raise NotImplementedError, marking it as an abstract member that subclasses must override.
- **Applies to:**
  - `src/click/types.py`
- **Condition:** When modifying CompositeParamType or adding new composite parameter types.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-2b54b2586ff01cebea8d9c0a.md)

## Rule 029 — `.github/workflows/publish.yaml`

- **Rule:** The build job builds the package with python -m build.
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-2cf6ee19e09e058617e27eef.md)

## Rule 030 — `requirements/typing.in`

- **Rule:** The update-requirements tox environment runs pip-compile on typing.in with -q and posargs defaulting to -U.
- **Applies to:**
  - `requirements/typing.in`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-2cfb302228522e3ec36118c0.md)

## Rule 031 — `tox.ini`

- **Rule:** The testenv environment installs dependencies from requirements/tests.txt.
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Use:** `reference_only`
- **Execution risk:** `external_side_effect`
- **Detail:** [Open claim details](../claims/CLAIM-2edc440016a78c6c1ecc277a.md)

## Rule 032 — `tests/conftest.py`

- **Rule:**
  ```text
  The shared test suite must import `CliRunner` from `click.testing` in `tests/conftest.py`, establishing the common runner fixture source.
  ```
- **Applies to:**
  - `tests/conftest.py`
- **Condition:** When adding or modifying shared test fixtures in tests/conftest.py
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-2f93c69e4e79885c2764ab9e.md)

## Rule 033 — `examples/complex/complex/commands/cmd_status.py`

- **Rule:**
  ```text
  Example commands that use the environment logging extension must use @pass_environment and call ctx.log and ctx.vlog to emit normal and debug messages.
  ```
- **Applies to:**
  - `examples/complex/complex/commands/cmd_status.py`
- **Condition:** when adding or modifying a command that uses the environment logging extension in the complex example
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3037aa7de01dfc46ca0112b5.md)

## Rule 034 — `src/click/utils.py`

- **Rule:**
  ```text
  When a lazy file wrapper is closed, close the underlying file only if the wrapper opened it (should_close is true); never close files the wrapper did not open, such as stdin.
  ```
- **Applies to:**
  - `src/click/utils.py`
- **Condition:**
  ```text
  Modifying close_intelligently or the lazy file wrapper's close path.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-321626ade2cb4a7c0ffabd2a.md)

## Rule 035 — `src/click/exceptions.py`

- **Rule:**
  ```text
  UsageError must be a ClickException subclass with exit_code = 2, and its constructor must accept an optional ctx that Click fills in automatically in some situations.
  ```
- **Applies to:**
  - `src/click/exceptions.py`
- **Condition:** When modifying UsageError or adding new exception types.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-399a27ca153a755adb384edf.md)

## Rule 036 — `examples/complex/complex/cli.py`

- **Rule:** examples/complex/complex/cli.py defines an Environment class, part of the complex example's structure.
- **Applies to:**
  - `examples/complex/complex/cli.py`
- **Condition:** When modifying or adding environment classes in the complex example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3a4c3665298c0ab9334ba7ab.md)
