# Full rule catalog

## Rule 037 — `src/click/decorators.py`

- **Rule:**
  ```text
  make_pass_decorator's new_func must retrieve the current context, ensure or find the object of the requested type, and raise RuntimeError when no such object exists, so pass_obj requires a context object of the specified type.
  ```
- **Applies to:**
  - `src/click/decorators.py`
- **Condition:**
  ```text
  When modifying make_pass_decorator or the pass_obj context-object resolution path.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3a62a53ad1abf1134dde4226.md)

## Rule 038 — `tests/test_options.py`

- **Rule:**
  ```text
  Tests for option default validation must preserve the convention that constructing click.Option with an invalid default for the given multiple/nargs combination raises ValueError matching 'default', covering (False,2,[1]) and (True,2,[[1]]).
  ```
- **Applies to:**
  - `tests/test_options.py`
- **Condition:** When modifying option default validation tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3b8c270227634f4f93b09755.md)

## Rule 039 — `src/click/_winconsole.py`

- **Rule:**
  ```text
  Windows console writer implementations must subclass _WindowsConsoleRawIOBase to provide the Windows console writer surface.
  ```
- **Applies to:**
  - `src/click/_winconsole.py`
- **Condition:** When adding or modifying a Windows console writer class.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3cf0e45460ef20f8c4c22e6c.md)

## Rule 040 — `src/click/types.py`

- **Rule:**
  ```text
  Choice.convert must normalize the value and choices through ctx.token_normalize_func before casefolding when case_sensitive is False, and must report failures using the original value via get_invalid_choice_message.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:** When modifying Choice.convert or the normalization/casefolding path for choice conversion.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3d3588304db859dee7f150f7.md)

## Rule 041 — `tests/test_termui.py`

- **Rule:**
  ```text
  Tests that assert progressbar ETA formatting must pin outputs including large values rendered as "1157407d 09:46:39" and `None` rendered as an empty string.
  ```
- **Applies to:**
  - `tests/test_termui.py`
- **Condition:**
  ```text
  When adding or modifying progressbar ETA formatting tests in tests/test_termui.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3e27d5b7f4ae3a47d6301a96.md)

## Rule 042 — `tox.ini`

- **Rule:**
  ```text
  The tox testenv `update-actions` declares `gha-update` as a dependency.
  ```
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3f025800f2017d83bb644c80.md)

## Rule 043 — `src/click/types.py`

- **Rule:**
  ```text
  Tuple type conversion must convert each supplied type via convert_type and store the resulting sequence of ParamType instances.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When modifying Tuple.__init__ or the type conversion pipeline for composite types.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3f3f88533a23a5aeeaef083b.md)

## Rule 044 — `tests/typing/typing_aliased_group.py`

- **Rule:** Typing tests for aliased groups must preserve the convention that the cli object is an AliasedGroup subclass of click.Group, tying the documented command-aliases example to the AliasedGroup type contract.
- **Applies to:**
  - `tests/typing/typing_aliased_group.py`
- **Condition:** When modifying typing tests for aliased groups.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-40d7f33cda41b4555684be80.md)

## Rule 045 — `src/click/utils.py`

- **Rule:**
  ```text
  LazyFile must defer opening regular files in read mode: it opens and closes once to surface errors early, then defers the real handle until first read; '-' is opened immediately via open_stream.
  ```
- **Applies to:**
  - `src/click/utils.py`
- **Condition:**
  ```text
  When modifying LazyFile.__init__ or its open/read behavior for regular files in read mode.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-42ede5748049dae2a99c8277.md)

## Rule 046 — `tests/test_arguments.py`

- **Rule:**
  ```text
  Tests that assert unbounded `nargs=-1` arguments must verify that supplying a default raises `TypeError` matching 'nargs=-1'.
  ```
- **Applies to:**
  - `tests/test_arguments.py`
- **Condition:**
  ```text
  When adding or modifying argument-validation tests in tests/test_arguments.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-43198279193c122547207733.md)

## Rule 047 — `.github/workflows/publish.yaml`

- **Rule:** The build job generates a hash by running sha256sum over dist contents and base64-encoding the result into the hash step output.
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-44a9cf157228d89e53ad4ade.md)

## Rule 048 — `src/click/shell_completion.py`

- **Rule:**
  ```text
  When modifying _resolve_context, preserve resilient_parsing=True, hierarchy walking via resolve_command, chained-group handling with allow_extra_args=True and allow_interspersed_args=False, and returning the deepest context without triggering prompts or callbacks.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:**
  ```text
  When changing shell completion context resolution or command hierarchy walking in _resolve_context.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-44c38790d266166fdfa8ea0b.md)

## Rule 049 — `.github/workflows/pre-commit.yaml`

- **Rule:** The pre-commit workflow runs the pre-commit/action step.
- **Applies to:**
  - `.github/workflows/pre-commit.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-4682f4b89c2cd87ffd9f53d2.md)

## Rule 050 — `src/click/utils.py`

- **Rule:**
  ```text
  Wrapper classes that store a wrapped IO object must expose it as self.wrapped in __init__, defining the attribute name other code uses to access the underlying stream.
  ```
- **Applies to:**
  - `src/click/utils.py`
- **Condition:** When modifying PacifyFlushWrapper or other IO wrapper classes.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-46cd26f9540da8e2a8f09c98.md)

## Rule 051 — `tests/test_parser.py`

- **Rule:**
  ```text
  Option prefixes are collected dynamically: adding options with '+p' and '!e' expands _opt_prefixes to include '-', '--', '+', and '!'.
  ```
- **Applies to:**
  - `tests/test_parser.py`
- **Condition:** When modifying option prefix collection logic or adding tests for dynamic prefix expansion.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-49318b7e2d838cb311936aac.md)

## Rule 052 — `src/click/decorators.py`

- **Rule:**
  ```text
  _param_memo must append parameters directly to a Command's params list, or accumulate them in a __click_params__ attribute on plain functions for later conversion, defining how decorators attach parameters.
  ```
- **Applies to:**
  - `src/click/decorators.py`
- **Condition:** When changing how decorators attach parameters to commands or plain functions.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-4aa77ae6373abb2425a34336.md)

## Rule 053 — `src/click/**`

- **Rule:** mypy is configured to check the files under src/click and tests/typing.
- **Applies to:**
  - `src/click/**`
  - `tests/typing/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-50a30bf391a7e1f55b47a4b9.md)
