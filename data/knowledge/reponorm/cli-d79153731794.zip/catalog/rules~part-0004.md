# Full rule catalog

## Rule 054 — `tests/test_formatting.py`

- **Rule:** Tests that exercise a metavar override on a positional argument must define the argument with metavar="metavar" and assert the supported override.
- **Applies to:**
  - `tests/test_formatting.py`
- **Condition:** When adding or modifying tests for metavar override on a positional argument, preserve the use of metavar="metavar" and the assertion of the supported override.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-536a723aadfdcb51b0daf585.md)

## Rule 055 — `src/click/termui.py`

- **Rule:**
  ```text
  When modifying the termui module, preserve the module-level visible_prompt_func callable defaulting to input and the _getchar module-level hook used for unittesting getchar calls.
  ```
- **Applies to:**
  - `src/click/termui.py`
- **Condition:** when changing termui module-level prompt or getchar hooks
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5380aad82d9c2e664dffde10.md)

## Rule 056 — `tests/test_arguments.py`

- **Rule:** Tests covering envvar population of variadic arguments must preserve the convention that nargs=-1 accepts any count of envvar-split values while a fixed nargs (e.g. nargs=2) raises BadParameter when the value count differs.
- **Applies to:**
  - `tests/test_arguments.py`
- **Condition:** When modifying envvar handling tests for variadic or fixed-nargs arguments.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-53ef2debcc52aaedb8ed88d8.md)

## Rule 057 — `src/click/_winconsole.py`

- **Rule:**
  ```text
  On PyPy, importing ctypes.pythonapi fails, so get_buffer must be set to None and buffer-based console operations must be unavailable.
  ```
- **Applies to:**
  - `src/click/_winconsole.py`
- **Condition:**
  ```text
  When modifying Windows console buffer handling or platform detection in click._winconsole.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-549cb93bd36215f09b2bcd2c.md)

## Rule 058 — `tox.ini`

- **Rule:** The testenv environment builds the package as a wheel.
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5d3937932aafa73fc32d6851.md)

## Rule 059 — `src/click/_winconsole.py`

- **Rule:**
  ```text
  _get_text_stdout must wrap a Windows console writer in a non-closing text wrapper using utf-16-le with strict errors and line buffering, then cast it to a ConsoleStream.
  ```
- **Applies to:**
  - `src/click/_winconsole.py`
- **Condition:**
  ```text
  When modifying _get_text_stdout or Windows console text stream construction.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5e7d9e6181affd73dfebdde7.md)

## Rule 060 — `src/click/_textwrap.py`

- **Rule:**
  ```text
  When modifying `TextWrapper` in `_textwrap.py`, preserve that it subclasses `textwrap.TextWrapper` to customize standard-library text wrapping behavior.
  ```
- **Applies to:**
  - `src/click/_textwrap.py`
- **Condition:** when changing click's text wrapping customization
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5eb7138edfb10675685d6c2e.md)

## Rule 061 — `src/click/types.py`

- **Rule:** When modifying OptionHelpExtra, preserve the TypedDict contract with optional keys envvars, default, range, and required defining the extra help metadata for options.
- **Applies to:**
  - `src/click/types.py`
- **Condition:** When changing the OptionHelpExtra TypedDict or the extra help metadata keys for options.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5f3c4eb60b726b6750879840.md)

## Rule 062 — `src/click/_compat.py`

- **Rule:** Atomic writes must reject append mode, exclusive mode, and any mode without "w", raising ValueError with guidance to use normal w-mode or the overwrite parameter.
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:** When changing atomic write mode validation or its error guidance.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6366e0e6798213f82a4141f5.md)

## Rule 063 — `src/click/exceptions.py`

- **Rule:**
  ```text
  ClickException.__init__ must store the context and derive cmd from ctx.command when a context is provided, linking exceptions to their command.
  ```
- **Applies to:**
  - `src/click/exceptions.py`
- **Condition:**
  ```text
  When modifying ClickException.__init__ or exception construction, preserve storing ctx and deriving cmd from ctx.command.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-64943979968dcbbcdaa5bb05.md)

## Rule 064 — `tox.ini`

- **Rule:** The update-requirements tox environment changes directory to requirements before running its commands.
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-64b6be0952fad831d91f08e1.md)

## Rule 065 — `src/click/termui.py`

- **Rule:** Color interpretation must encode int colors as 256-color SGR sequences and tuple/list colors as truecolor SGR sequences, with offset distinguishing foreground from background.
- **Applies to:**
  - `src/click/termui.py`
- **Condition:**
  ```text
  When modifying _interpret_color or color encoding logic.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-65e87a7d33f36fb3f2784baf.md)

## Rule 066 — `src/click/_compat.py`

- **Rule:**
  ```text
  _force_correct_text_writer must delegate to _force_correct_text_stream with _is_binary_writer and _find_binary_writer so text-writer correction shares the same stream-detection protocol as text readers.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  When modifying _force_correct_text_writer or stream correction logic.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-67713e6508ab006682688948.md)

## Rule 067 — `examples/complex/complex/cli.py`

- **Rule:**
  ```text
  Subcommands in the complex example are discovered dynamically: list_commands scans the cmd_folder for files named cmd_*.py, strips the cmd_ prefix and .py suffix, and sorts the names; get_command then imports complex.commands.cmd_{name} and returns its cli attribute, silently returning None on ImportError. New subcommands must therefore be added as cmd_<name>.py modules exposing a cli attribute rather than registered statically.
  ```
- **Applies to:**
  - `examples/complex/complex/cli.py`
- **Condition:** When adding or renaming a subcommand in the complex example, or changing how its command modules are discovered or loaded.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-694821764909ce0c2dad27e0.md)

## Rule 068 — `tests/test_termui.py`

- **Rule:**
  ```text
  Tests that assert `ProgressBar.time_per_iteration` must verify that an empty average list returns 0.0 and [1, 4] returns 2.5, defining the averaging behavior for iteration timing.
  ```
- **Applies to:**
  - `tests/test_termui.py`
- **Condition:**
  ```text
  When adding or modifying `ProgressBar.time_per_iteration` tests in tests/test_termui.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6caf35c74823e199473feead.md)

## Rule 069 — `tox.ini`

- **Rule:** The testenv environment uses frozen constraints.
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6e592693bb2c580f4394955a.md)

## Rule 070 — `requirements/docs.in`

- **Rule:** The update-requirements tox environment runs pip-compile on docs.in with -q and posargs defaulting to -U.
- **Applies to:**
  - `requirements/docs.in`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-73eb4e2aac639952f5bafd5d.md)
