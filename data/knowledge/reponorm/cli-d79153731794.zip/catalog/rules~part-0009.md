# Full rule catalog

## Rule 144 — `src/click/shell_completion.py`

- **Rule:**
  ```text
  When modifying `ShellComplete.complete`, preserve the wire format: join formatted completions with newlines after obtaining args and completions.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:** when changing shell completion output formatting or the complete method
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e2d64450b3f83e79bb8a7d02.md)

## Rule 145 — `**/*.py`

- **Rule:** Ruff linting is configured to select the rule sets B (flake8-bugbear), E (pycodestyle error), F (pyflakes), I (isort), UP (pyupgrade), and W (pycodestyle warning).
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-e4d2cc886023e635a8cc3750.md)

## Rule 146 — `tests/test_testing.py`

- **Rule:** Tests for CliRunner.invoke with input must preserve the convention that provided input is echoed back in result.output without raising an exception.
- **Applies to:**
  - `tests/test_testing.py`
- **Condition:** When modifying CliRunner input-echo tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e5052f59e756a39f33bbda2b.md)

## Rule 147 — `src/click/core.py`

- **Rule:**
  ```text
  When modifying Option.get_help_extra, preserve deriving envvar names from auto_envvar_prefix and option name, temporarily enabling resilient parsing while computing defaults, formatting defaults specially for lists, functions, boolean flags, and empty strings, and adding range info for number range types except count options with default range.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:** when changing help extra generation for options
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ecd06714083a4861254ca9da.md)

## Rule 148 — `tests/test_termui.py`

- **Rule:**
  ```text
  Tests for confirmed hidden input must preserve the convention that a password option combines prompt, hide_input=True, default, and confirmation_prompt.
  ```
- **Applies to:**
  - `tests/test_termui.py`
- **Condition:** When modifying tests for confirmed hidden input options.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ed5145baea9e817a4400e4a7.md)

## Rule 149 — `tests/test_termui.py`

- **Rule:**
  ```text
  Tests for prompt_required=False must preserve the convention that a flag without a value prompts while a flag with a value does not, and the next option flag is not consumed as the value.
  ```
- **Applies to:**
  - `tests/test_termui.py`
- **Condition:**
  ```text
  When modifying prompt_required=False parametrized tests.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f1d38b12266a6cc75a866326.md)

## Rule 150 — `examples/repo/repo.py`

- **Rule:** The repo example's state object initializes home, an empty config dict, and verbose=False, establishing the default configuration shape used by the example.
- **Applies to:**
  - `examples/repo/repo.py`
- **Condition:** When modifying or adding state initialization in the repo example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f62e03069b3597863f6c19d7.md)

## Rule 151 — `src/click/utils.py`

- **Rule:**
  ```text
  When modifying `get_text_stream`, preserve that it raises `TypeError` for unknown stream names and otherwise delegates to the registered opener with encoding and errors.
  ```
- **Applies to:**
  - `src/click/utils.py`
- **Condition:**
  ```text
  when changing `get_text_stream`'s stream-name validation or opener delegation
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f8cef1e8491da7a16610799c.md)

## Rule 152 — `**/*.py`

- **Rule:**
  ```text
  The project declares a minimum supported Python version of 3.8 via requires-python = ">=3.8".
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f90ef79d34adaab7faa1b3e2.md)

## Rule 153 — `.github/workflows/publish.yaml`

- **Rule:**
  ```text
  The create-release job creates a draft GitHub release for the pushed tag containing the intoto provenance and artifact files, using GH_TOKEN from github.token.
  ```
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-fd3222ed7be366158c52a895.md)
