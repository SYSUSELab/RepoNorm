# Full rule catalog

## Rule 071 — `requirements/build.in`

- **Rule:** The update-requirements tox environment runs pip-compile on build.in with -q and posargs defaulting to -U.
- **Applies to:**
  - `requirements/build.in`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-787d80c0623f0fbfcf935aef.md)

## Rule 072 — `src/click/_compat.py`

- **Rule:**
  ```text
  strip_ansi must remove ANSI escape sequences from a string using the module-level _ansi_re pattern.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  When modifying strip_ansi or the _ansi_re pattern in src/click/_compat.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7895c182430a437c73f5e5d7.md)

## Rule 073 — `src/click/**`

- **Rule:** Pyright type checking is scoped to the src/click and tests/typing directories.
- **Applies to:**
  - `src/click/**`
  - `tests/typing/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7bb17a22481594b0c5dcc52c.md)

## Rule 074 — `src/click/testing.py`

- **Rule:**
  ```text
  When modifying StreamMixer.flush, preserve flushing both the superclass stream and the copy_to target so mirrored output is flushed in tandem.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:** when changing StreamMixer flush behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7c009ac3262b01729fcb2cd8.md)

## Rule 075 — `tests/typing/**`

- **Rule:** The typing tox environment runs pyright on tests/typing.
- **Applies to:**
  - `tests/typing/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7d162940f9e14224e5a7954f.md)

## Rule 076 — `**`

- **Rule:**
  ```text
  The tests job installs tox with pip and runs tox for the environment named by matrix.tox, defaulting to py<matrix.python>.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7dcc6102530a6e870b198a65.md)

## Rule 077 — `requirements/docs.txt`

- **Rule:** Read the Docs installs documentation requirements from requirements/docs.txt.
- **Applies to:**
  - `requirements/docs.txt`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7e608b64ad7b9d212193e72f.md)

## Rule 078 — `src/click/shell_completion.py`

- **Rule:**
  ```text
  ShellComplete.func_name must derive the completion function name from prog_name by replacing hyphens with underscores and stripping non-word characters, yielding "_{safe_name}_completion".
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:**
  ```text
  When modifying shell completion function name generation or prog_name handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8407562816bf52fc2d398f1f.md)

## Rule 079 — `tox.ini`

- **Rule:** The tox envlist defines environments py38, py39, py310, py311, py312, py313, pypy310, style, typing, and docs.
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-85624daa819c6f7aef5c8844.md)

## Rule 080 — `src/click/types.py`

- **Rule:**
  ```text
  When modifying DateTime._try_to_convert_date, preserve attempting datetime.strptime and returning None on ValueError so callers treat unparseable values as non-matches rather than raising.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When changing date parsing or error handling in DateTime._try_to_convert_date.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-861db86231d09216609f1423.md)

## Rule 081 — `src/click/shell_completion.py`

- **Rule:**
  ```text
  When modifying _resolve_incomplete, preserve '=' normalization by splitting and discarding it, returning the command for option-name completion when '--' is absent and the incomplete value starts like an option, and otherwise selecting the option or argument that should provide value completion.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:**
  ```text
  When changing incomplete-value normalization or completion target selection in _resolve_incomplete.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-86428926137ed5557576965f.md)

## Rule 082 — `tox.ini`

- **Rule:**
  ```text
  The tox testenv `update-actions` runs the command `gha-update`.
  ```
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-87a718e83f2513c13e73f92e.md)

## Rule 083 — `src/click/_compat.py`

- **Rule:**
  ```text
  When resolving the stderr text stream, first attempt the Windows console stream and fall back to _force_correct_text_writer with force_writable=True, preserving the defined resolution order.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  Modifying get_text_stderr or the stderr text-stream resolution path.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8865e30065e3a9ce4816a57e.md)

## Rule 084 — `src/click/formatting.py`

- **Rule:** HelpFormatter.indentation must increase indentation on entry and guarantee dedent on exit via finally, so indentation is balanced even if the body raises.
- **Applies to:**
  - `src/click/formatting.py`
- **Condition:** When modifying HelpFormatter.indentation or its context-manager logic, preserve the finally-based dedent guarantee.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8980782c72337d50e6eae02a.md)

## Rule 085 — `src/click/types.py`

- **Rule:**
  ```text
  Path.coerce_path_result must convert values to str via os.fsdecode, to bytes via os.fsencode, or to the configured self.type, returning the value unchanged when it already matches the configured type.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:** When modifying Path type coercion or adding new path result types.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-908d81f91534149e248ae919.md)

## Rule 086 — `tests/test_options.py`

- **Rule:** Tests that assert dynamic-default help output must verify that an unset dynamic default renders as '(dynamic)' without leaking the lambda source text, while still listing the option name.
- **Applies to:**
  - `tests/test_options.py`
- **Condition:**
  ```text
  When adding or modifying dynamic-default help tests in tests/test_options.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-92cd2c926c8790235d4f0a37.md)

## Rule 087 — `.github/workflows/pre-commit.yaml`

- **Rule:** The pre-commit-ci/lite-action step runs when the workflow has not been cancelled.
- **Applies to:**
  - `.github/workflows/pre-commit.yaml`
- **Condition:** workflow predicate: ${{ !cancelled() }}
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-97747fb96a5ec33c61dd8500.md)

## Rule 088 — `tox.ini`

- **Rule:** The testenv environment uses .pkg as the wheel build environment.
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-99f6267df723362e8f0f6adf.md)

## Rule 089 — `click/**`

- **Rule:** Coverage measurement is configured to source from the click and tests packages.
- **Applies to:**
  - `click/**`
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9aeaa14caa63bc7d00c05067.md)

## Rule 090 — `src/click/formatting.py`

- **Rule:**
  ```text
  formatting.py must expose a module-level FORCED_WIDTH that can force a width, explicitly used by the test system.
  ```
- **Applies to:**
  - `src/click/formatting.py`
- **Condition:** When changing formatting width resolution or test-controlled width overrides.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9af8ade3cc81723a7e3b4acd.md)
