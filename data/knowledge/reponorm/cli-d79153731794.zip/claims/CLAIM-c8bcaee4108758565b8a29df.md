# Rule details

- **Rule:** Tox skips environments whose interpreter is missing rather than failing.
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
skip_missing_interpreters = true

```

- **Sources:**
  - `tox.ini:8`
