# Rule details

- **Rule:**
  ```text
  When modifying measure_table, preserve computing per-column maximum term_len across rows and returning widths as a tuple ordered by column index.
  ```
- **Applies to:**
  - `src/click/formatting.py`
- **Condition:**
  ```text
  When changing table width measurement or column ordering in measure_table.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
measure_table computes per-column maximum term_len across rows and returns widths as a tuple ordered by column index, matching the rule.
```

- **Sources:**
  - `src/click/formatting.py:14-21`
