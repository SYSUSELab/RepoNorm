# Rule details

- **Rule:** The build job uploads the ./dist directory as an artifact.
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
      - uses: actions/upload-artifact@b4b15b8c7c6ac21ea08fcf65892d2ee8f75cf882 # v4.4.3
        with:
          path: ./dist

```

- **Sources:**
  - `.github/workflows/publish.yaml:26-28`
