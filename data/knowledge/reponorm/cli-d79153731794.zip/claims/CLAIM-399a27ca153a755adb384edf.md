# Rule details

- **Rule:**
  ```text
  UsageError must be a ClickException subclass with exit_code = 2, and its constructor must accept an optional ctx that Click fills in automatically in some situations.
  ```
- **Applies to:**
  - `src/click/exceptions.py`
- **Condition:** When modifying UsageError or adding new exception types.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
UsageError is a ClickException subclass with exit_code = 2 and an __init__ accepting an optional ctx, matching the exception contract rule.
```

- **Sources:**
  - `src/click/exceptions.py:56-92`
