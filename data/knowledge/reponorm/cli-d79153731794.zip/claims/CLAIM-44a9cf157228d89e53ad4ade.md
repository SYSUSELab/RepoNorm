# Rule details

- **Rule:** The build job generates a hash by running sha256sum over dist contents and base64-encoding the result into the hash step output.
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
      - name: generate hash
        id: hash
        run: cd dist && echo "hash=$(sha256sum * | base64 -w0)" >> $GITHUB_OUTPUT

```

- **Sources:**
  - `.github/workflows/publish.yaml:23-25`
