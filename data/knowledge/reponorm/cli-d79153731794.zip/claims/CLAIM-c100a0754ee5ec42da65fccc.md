# Rule details

- **Rule:**
  ```text
  When modifying `_nullpager`, preserve its role as the ultimate fallback pager: write each generator chunk directly to the stream, stripping ANSI when color is false.
  ```
- **Applies to:**
  - `src/click/_termui_impl.py`
- **Condition:** when changing pager fallback behavior or ANSI stripping
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
_nullpager writes each generator chunk directly to the stream and strips ANSI when color is false, matching the fallback pager rule.
```

- **Sources:**
  - `src/click/_termui_impl.py:471-478`
