# Rule details

- **Rule:** The testenv environment runs pytest with -v, --tb=short, --basetemp={envtmpdir}, and {posargs}.
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
commands = pytest -v --tb=short --basetemp={envtmpdir} {posargs}

```

- **Sources:**
  - `tox.ini:16`
