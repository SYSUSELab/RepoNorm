# Rule details

- **Rule:**
  ```text
  ParamType.to_info_dict must derive param_type by stripping 'ParamType'/'ParameterType' suffixes from the class name, falling back to that name when the instance has no name attribute, and return a dict with 'param_type' and 'name' keys.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When modifying ParamType.to_info_dict or adding ParamType subclasses, preserve the suffix-stripping derivation and the {'param_type', 'name'} return shape.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
ParamType.to_info_dict strips ParamType/ParameterType suffixes, falls back to the derived name, and returns a dict with param_type and name keys.
```

- **Sources:**
  - `src/click/types.py:59-78`
