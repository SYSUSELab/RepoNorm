# Rule details

- **Rule:** CSS, HTML, JS, JSON, JSX, SCSS, TS, TSX, YAML, and YML files use an indent size of 2.
- **Applies to:**
  - `**/*.css`
  - `**/*.html`
  - `**/*.js`
  - `**/*.json`
  - `**/*.jsx`
  - `**/*.scss`
  - `**/*.ts`
  - `**/*.tsx`
  - `**/*.yaml`
  - `**/*.yml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
indent_size = 2

```

- **Sources:**
  - `.editorconfig:13`
