# Rule details

- **Rule:** The build job builds the package with python -m build.
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
      - run: python -m build

```

- **Sources:**
  - `.github/workflows/publish.yaml:21`
