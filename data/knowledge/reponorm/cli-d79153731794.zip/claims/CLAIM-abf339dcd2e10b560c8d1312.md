# Rule details

- **Rule:**
  ```text
  Bash shell completion must reject Bash versions older than 4.4 and must also fail when the version cannot be detected, so any change to BashComplete._check_version or its version-parsing path must preserve this hard compatibility boundary.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:**
  ```text
  When modifying BashComplete._check_version or the Bash version detection/parsing logic used by shell completion.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
BashComplete._check_version rejects Bash versions older than 4.4 and errors when the version cannot be detected, preserving the hard compatibility boundary.
```

- **Sources:**
  - `src/click/shell_completion.py:305-328`
