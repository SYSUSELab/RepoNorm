# Rule details

- **Rule:**
  ```text
  The example demonstrates a command with a show_default option and a processor decorator that yields processed images, showing the supported image processing pipeline pattern.
  ```
- **Applies to:**
  - `examples/imagepipe/imagepipe.py`
- **Condition:** When modifying or adding commands with processor decorators in the imagepipe example.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
crop_cmd is decorated with a processor decorator and a show_default option, yielding processed images, demonstrating the imagepipe processor pipeline pattern.
```

- **Sources:**
  - `examples/imagepipe/imagepipe.py:151-162`

### Evidence 2 — current_observation

```text
blur_cmd is decorated with the processor decorator and a click.option with show_default=True, and yields processed images, demonstrating the processor pipeline pattern.
```

- **Sources:**
  - `examples/imagepipe/imagepipe.py:212-217`
