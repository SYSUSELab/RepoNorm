# Rule details

- **Rule:**
  ```text
  The help option callback must only echo help and exit when the option value is truthy and ctx.resilient_parsing is false, so help output must be suppressed during resilient parsing.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When modifying Command.get_help_option's show_help callback or the resilient-parsing handling around help output.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
show_help echoes help and exits only when value is truthy and ctx.resilient_parsing is false, preserving suppression during resilient parsing.
```

- **Sources:**
  - `src/click/core.py:1020-1023`
