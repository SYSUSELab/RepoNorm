# Rule details

- **Rule:** The publish-pypi job then publishes the artifact/ directory to PyPI using the pypa/gh-action-pypi-publish action.
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
      - uses: pypa/gh-action-pypi-publish@f7600683efdcb7656dec5b29656edb7bc586e597 # v1.10.3
        with:
          packages-dir: artifact/

```

- **Sources:**
  - `.github/workflows/publish.yaml:71-73`
