# Rule details

- **Rule:**
  ```text
  make_pass_decorator's new_func must retrieve the current context, ensure or find the object of the requested type, and raise RuntimeError when no such object exists, so pass_obj requires a context object of the specified type.
  ```
- **Applies to:**
  - `src/click/decorators.py`
- **Condition:**
  ```text
  When modifying make_pass_decorator or the pass_obj context-object resolution path.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
new_func retrieves the current context, ensures or finds the requested object type, and raises RuntimeError when no such object exists, preserving the pass_obj invariant.
```

- **Sources:**
  - `src/click/decorators.py:78-94`
