# Rule details

- **Rule:** The update-requirements tox environment runs pip-compile on build.in with -q and posargs defaulting to -U.
- **Applies to:**
  - `requirements/build.in`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
commands =
    pip-compile build.in -q {posargs:-U}
    pip-compile docs.in -q {posargs:-U}
    pip-compile tests.in -q {posargs:-U}
    pip-compile typing.in -q {posargs:-U}
    pip-compile dev.in -q {posargs:-U}

```

- **Sources:**
  - `tox.ini:50-55`
