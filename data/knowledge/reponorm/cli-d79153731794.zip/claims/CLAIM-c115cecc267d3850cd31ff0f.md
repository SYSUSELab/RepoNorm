# Rule details

- **Rule:**
  ```text
  get_best_encoding must return the stream's encoding or sys.getdefaultencoding(), but substitute 'utf-8' whenever the resolved encoding is an ASCII encoding.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  When modifying get_best_encoding or encoding fallback logic.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
get_best_encoding returns the stream encoding or default and substitutes 'utf-8' when the resolved encoding is ASCII.
```

- **Sources:**
  - `src/click/_compat.py:48-53`
