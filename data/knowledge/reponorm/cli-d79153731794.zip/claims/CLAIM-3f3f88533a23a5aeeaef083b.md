# Rule details

- **Rule:**
  ```text
  Tuple type conversion must convert each supplied type via convert_type and store the resulting sequence of ParamType instances.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When modifying Tuple.__init__ or the type conversion pipeline for composite types.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
Tuple.__init__ calls convert_type on each supplied type and stores the resulting sequence as ParamType instances.
```

- **Sources:**
  - `src/click/types.py:976-977`
