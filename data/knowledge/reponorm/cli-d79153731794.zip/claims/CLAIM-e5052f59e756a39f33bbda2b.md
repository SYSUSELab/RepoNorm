# Rule details

- **Rule:** Tests for CliRunner.invoke with input must preserve the convention that provided input is echoed back in result.output without raising an exception.
- **Applies to:**
  - `tests/test_testing.py`
- **Condition:** When modifying CliRunner input-echo tests.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
tests/test_testing.py contains test_with_color_errors, which defines a command raising CLIError("Red error") and asserts the resulting error output, matching the rule.
```

- **Sources:**
  - `tests/test_testing.py`
