# Rule details

- **Rule:**
  ```text
  Sphinx documentation builds must be configured through docs/conf.py, which sets autodoc_member_order='bysource', autodoc_typehints='description', autodoc_preserve_defaults=True, extlinks for issue/pr references, intersphinx to Python docs, and the click HTML theme; changes to documentation build behavior must preserve or deliberately update these settings.
  ```
- **Applies to:**
  - `docs/conf.py`
- **Condition:** When modifying the Sphinx documentation build configuration in docs/conf.py, including autodoc ordering, typehint rendering, default preservation, external link roles, intersphinx mappings, or the HTML theme.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
docs/conf.py contains the Sphinx configuration with autodoc settings, extlinks, intersphinx, and the click HTML theme, matching the documented build contract.
```

- **Sources:**
  - `docs/conf.py`
