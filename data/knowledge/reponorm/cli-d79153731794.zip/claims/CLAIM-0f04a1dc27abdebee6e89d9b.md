# Rule details

- **Rule:**
  ```text
  The update-requirements tox environment sets skip_install to true.
  ```
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
skip_install = true

```

- **Sources:**
  - `tox.ini:48`
