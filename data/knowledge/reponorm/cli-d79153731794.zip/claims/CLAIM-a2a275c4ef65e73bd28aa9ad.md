# Rule details

- **Rule:** The update-requirements tox environment declares pip-tools as its dependency.
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
deps = pip-tools

```

- **Sources:**
  - `tox.ini:47`
