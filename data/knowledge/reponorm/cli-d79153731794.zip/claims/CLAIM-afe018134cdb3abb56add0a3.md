# Rule details

- **Rule:** The termui example must remain a standalone demo script that imports math, random, time, and click, preserving these runtime dependencies.
- **Applies to:**
  - `examples/termui/termui.py`
- **Condition:** When modifying imports or runtime dependencies of the termui example.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The termui example file imports math, random, time, and click at module level, matching the standalone demo script rule.
```

- **Sources:**
  - `examples/termui/termui.py`
