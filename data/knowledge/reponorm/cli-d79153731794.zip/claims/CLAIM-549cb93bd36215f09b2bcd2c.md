# Rule details

- **Rule:**
  ```text
  On PyPy, importing ctypes.pythonapi fails, so get_buffer must be set to None and buffer-based console operations must be unavailable.
  ```
- **Applies to:**
  - `src/click/_winconsole.py`
- **Condition:**
  ```text
  When modifying Windows console buffer handling or platform detection in click._winconsole.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The module wraps the ctypes.pythonapi import in try/except ImportError and sets get_buffer = None on failure, handling the PyPy case where ctypes.pythonapi is unavailable.
```

- **Sources:**
  - `src/click/_winconsole.py`
