# Rule details

- **Rule:**
  ```text
  should_strip_ansi must return False for streams whose __module__ is "ipykernel.faked", i.e. Jupyter kernel output streams are detected by module name and not stripped.
  ```
- **Applies to:**
  - `tests/test_compat.py`
- **Condition:** Modifying or adding tests that assert ANSI stripping behavior for Jupyter kernel output streams.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The test sets JupyterKernelFakeStream.__module__ to "ipykernel.faked" and asserts should_strip_ansi returns False, confirming the ipykernel module-name detection behavior.
```

- **Sources:**
  - `tests/test_compat.py:4-10`
