# Rule details

- **Rule:**
  ```text
  The flit sdist build excludes docs/_build/ from the source distribution.
  ```
- **Applies to:**
  - `docs/_build/**`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
exclude = [
    "docs/_build/",
]

```

- **Sources:**
  - `pyproject.toml:43-45`
