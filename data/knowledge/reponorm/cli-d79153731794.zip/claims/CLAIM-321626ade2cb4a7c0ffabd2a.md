# Rule details

- **Rule:**
  ```text
  When a lazy file wrapper is closed, close the underlying file only if the wrapper opened it (should_close is true); never close files the wrapper did not open, such as stdin.
  ```
- **Applies to:**
  - `src/click/utils.py`
- **Condition:**
  ```text
  Modifying close_intelligently or the lazy file wrapper's close path.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
LazyFile.close_intelligently closes the underlying file only when should_close is true, matching the rule that wrapper-owned files are closed and caller-owned streams such as stdin are not.
```

- **Sources:**
  - `src/click/utils.py:174-179`
