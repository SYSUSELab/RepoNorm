# Rule details

- **Rule:**
  ```text
  When modifying the Windows console stream's `isatty`, preserve that it calls `super().isatty()` and then unconditionally returns True, forcing TTY detection to true for that stream.
  ```
- **Applies to:**
  - `src/click/_winconsole.py`
- **Condition:** when changing Windows console TTY detection
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
_WindowsConsoleRawIOBase.isatty calls super().isatty() and then unconditionally returns True, preserving the forced TTY detection behavior.
```

- **Sources:**
  - `src/click/_winconsole.py:112-114`
