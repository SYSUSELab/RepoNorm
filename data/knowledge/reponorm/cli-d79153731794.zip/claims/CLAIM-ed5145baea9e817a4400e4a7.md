# Rule details

- **Rule:**
  ```text
  Tests for confirmed hidden input must preserve the convention that a password option combines prompt, hide_input=True, default, and confirmation_prompt.
  ```
- **Applies to:**
  - `tests/test_termui.py`
- **Condition:** When modifying tests for confirmed hidden input options.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
tests/test_termui.py contains test_confirmation_prompt, which defines a password option combining prompt, hide_input=True, default, and confirmation_prompt, matching the hypothesis.
```

- **Sources:**
  - `tests/test_termui.py`
