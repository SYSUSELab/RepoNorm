# Rule details

- **Rule:**
  ```text
  The project declares a minimum supported Python version of 3.8 via requires-python = ">=3.8".
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
requires-python = ">=3.8"

```

- **Sources:**
  - `pyproject.toml:16`
