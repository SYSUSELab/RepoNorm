# Rule details

- **Rule:** Ruff excludes the examples/ directory from linting via extend-exclude.
- **Applies to:**
  - `examples/**`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
extend-exclude = ["examples/"]

```

- **Sources:**
  - `pyproject.toml:79`
