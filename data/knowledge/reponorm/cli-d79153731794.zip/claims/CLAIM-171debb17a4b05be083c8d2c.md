# Rule details

- **Rule:**
  ```text
  When modifying ClickException.format_message, preserve returning self.message directly so subclasses can override message formatting by setting the message attribute.
  ```
- **Applies to:**
  - `src/click/exceptions.py`
- **Condition:** when changing exception message formatting
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
ClickException.format_message returns self.message directly, preserving the override-by-message-attribute behavior required by the rule.
```

- **Sources:**
  - `src/click/exceptions.py:39-40`
