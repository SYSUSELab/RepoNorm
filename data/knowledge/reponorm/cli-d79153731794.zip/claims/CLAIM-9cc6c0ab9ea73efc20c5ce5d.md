# Rule details

- **Rule:**
  ```text
  The tox environment `update-pre_commit` runs `pre-commit autoupdate -j4` as its command.
  ```
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
commands = pre-commit autoupdate -j4

```

- **Sources:**
  - `tox.ini:43`
