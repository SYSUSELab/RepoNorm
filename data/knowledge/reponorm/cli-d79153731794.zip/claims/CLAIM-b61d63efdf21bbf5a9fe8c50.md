# Rule details

- **Rule:** When StreamMixer is used, it mixes stdout and stderr streams with the combined result available in the output attribute, as documented since version 8.2.
- **Applies to:**
  - `src/click/testing.py`
- **Condition:** Modifying StreamMixer or its documented output attribute contract.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
StreamMixer is documented as mixing stdout and stderr streams with the combined result available in the output attribute, matching the documented contract.
```

- **Sources:**
  - `src/click/testing.py:89-100`
