# Rule details

- **Rule:**
  ```text
  Tests that assert shell-completion type mapping must verify that `File()` and `Path()` map to completion type 'file' while `Path(file_okay=False)` maps to 'dir'.
  ```
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:**
  ```text
  When adding or modifying shell-completion type-mapping tests in tests/test_shell_completion.py
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
tests/test_shell_completion.py contains test_path_types asserting File() and Path() map to completion type 'file' and Path(file_okay=False) maps to 'dir', matching the type-mapping rule.
```

- **Sources:**
  - `tests/test_shell_completion.py`
