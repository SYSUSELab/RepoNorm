# Rule details

- **Rule:**
  ```text
  _unquote_file must strip the 'file://' prefix and URL-unquote the remainder; non-file URLs are returned unchanged.
  ```
- **Applies to:**
  - `src/click/_termui_impl.py`
- **Condition:**
  ```text
  When modifying open_url's file URL handling or _unquote_file.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
_unquote_file strips the 'file://' prefix, unquotes the remainder, and returns non-file URLs unchanged, matching the implementation rule.
```

- **Sources:**
  - `src/click/_termui_impl.py:581-587`
