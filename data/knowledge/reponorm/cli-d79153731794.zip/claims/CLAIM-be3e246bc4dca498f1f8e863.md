# Rule details

- **Rule:** The testenv environment constrains package dependencies.
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
constrain_package_deps = true

```

- **Sources:**
  - `tox.ini:13`
