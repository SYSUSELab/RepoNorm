# Rule details

- **Rule:** Tests for CLI decorator composition must preserve the convention that a group command can combine click.argument('arg2') and click.option('--opt2') on the same callback.
- **Applies to:**
  - `tests/test_arguments.py`
- **Condition:** When modifying tests that compose group, argument, and option decorators on one callback.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
tests/test_arguments.py contains test_nested_subcommand_help which composes @click.group, @click.argument('arg2'), and @click.option('--opt2') on the same callback, matching the decorator composition convention.
```

- **Sources:**
  - `tests/test_arguments.py`
