# Rule details

- **Rule:** The lock workflow uses the dessant/lock-threads action pinned to commit 1bf7ec25051fe7c00bdd17e6a7cf3d7bfb7dc771 (v5.0.1) with issue-inactive-days, pr-inactive-days, and discussion-inactive-days all set to 14.
- **Applies to:**
  - `.github/workflows/lock.yaml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
      - uses: dessant/lock-threads@1bf7ec25051fe7c00bdd17e6a7cf3d7bfb7dc771 # v5.0.1
        with:
          issue-inactive-days: 14
          pr-inactive-days: 14
          discussion-inactive-days: 14

```

- **Sources:**
  - `.github/workflows/lock.yaml:19-23`
