# Rule details

- **Rule:** CompositeParamType.arity must raise NotImplementedError, marking it as an abstract member that subclasses must override.
- **Applies to:**
  - `src/click/types.py`
- **Condition:** When modifying CompositeParamType or adding new composite parameter types.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
CompositeParamType.arity is a property whose body raises NotImplementedError, matching the abstract-member contract requiring subclass override.
```

- **Sources:**
  - `src/click/types.py:164-165`
