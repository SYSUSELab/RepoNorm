# Rule details

- **Rule:** Coverage measurement is configured to source from the click and tests packages.
- **Applies to:**
  - `click/**`
  - `tests/**`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
source = ["click", "tests"]

```

- **Sources:**
  - `pyproject.toml:55`
