# Rule details

- **Rule:**
  ```text
  ClickException.__init__ must store the context and derive cmd from ctx.command when a context is provided, linking exceptions to their command.
  ```
- **Applies to:**
  - `src/click/exceptions.py`
- **Condition:**
  ```text
  When modifying ClickException.__init__ or exception construction, preserve storing ctx and deriving cmd from ctx.command.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
UsageError.__init__ stores self.ctx and derives self.cmd from ctx.command when a context is provided, linking the exception to its command.
```

- **Sources:**
  - `src/click/exceptions.py:67-70`
