# Rule details

- **Rule:**
  ```text
  Example commands that use the environment logging extension must use @pass_environment and call ctx.log and ctx.vlog to emit normal and debug messages.
  ```
- **Applies to:**
  - `examples/complex/complex/commands/cmd_status.py`
- **Condition:** when adding or modifying a command that uses the environment logging extension in the complex example
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
cli is decorated with @pass_environment and calls ctx.log and ctx.vlog to emit normal and debug messages, matching the r15 environment logging predicate.
```

- **Sources:**
  - `examples/complex/complex/commands/cmd_status.py:8-11`
