# Full rule catalog

- [Rules 001–018](catalog/rules~part-0001.md)
- [Rules 019–036](catalog/rules~part-0002.md)
- [Rules 037–053](catalog/rules~part-0003.md)
- [Rules 054–070](catalog/rules~part-0004.md)
- [Rules 071–090](catalog/rules~part-0005.md)
- [Rules 091–108](catalog/rules~part-0006.md)
- [Rules 109–126](catalog/rules~part-0007.md)
- [Rules 127–143](catalog/rules~part-0008.md)
- [Rules 144–153](catalog/rules~part-0009.md)
