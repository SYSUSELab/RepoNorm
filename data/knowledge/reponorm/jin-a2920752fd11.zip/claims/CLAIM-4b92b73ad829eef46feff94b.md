# Rule details

- **Rule:**
  ```text
  A fragment cache extension must key cache entries by environment.fragment_cache_prefix + name, return the cached value when present, and otherwise call caller() and store the result with the timeout via fragment_cache.add.
  ```
- **Applies to:**
  - `docs/examples/cache_extension.py`
- **Condition:** when implementing or modifying the fragment cache extension's cache-support helper
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The _cache_support method body constructs the key as fragment_cache_prefix + name, returns the cached value when present, and otherwise calls caller() and stores the result via fragment_cache.add with the timeout, matching the fragment cache extension rule.
```

- **Sources:**
  - `docs/examples/cache_extension.py:42-54`
