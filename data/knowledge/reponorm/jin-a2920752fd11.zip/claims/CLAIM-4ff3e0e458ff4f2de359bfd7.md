# Rule details

- **Rule:**
  ```text
  When modifying the striptags filter, preserve the __html__ protocol check: do_striptags must consult __html__ on the value and use its result before stripping tags via Markup.striptags.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  changing how do_striptags handles objects implementing __html__
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
do_striptags checks __html__ on the value and uses its result before calling Markup.striptags, preserving the protocol.
```

- **Sources:**
  - `src/jinja2/filters.py:1010-1015`
