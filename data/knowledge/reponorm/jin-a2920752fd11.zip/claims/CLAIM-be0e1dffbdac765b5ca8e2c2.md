# Rule details

- **Rule:** CI runs the full test suite when a pull request is submitted.
- **Applies to:**
  - `**`
- **Normative strength:** `required`

## Supporting evidence

### Evidence 1 — explicit

```text
sufficient. CI will run the full suite when you submit your pull
request. You can run the full test suite with tox if you don't want to

```

- **Sources:**
  - `CONTRIBUTING.rst:183-184`
