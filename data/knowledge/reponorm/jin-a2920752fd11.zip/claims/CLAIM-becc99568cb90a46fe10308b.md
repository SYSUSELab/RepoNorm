# Rule details

- **Rule:** When modifying TemplateModule, preserve its module-like API: exported names are attributes and converting the module to a string renders the template contents.
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:** changing TemplateModule's attribute export or string conversion behavior
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
TemplateModule's class definition and docstring show exported names are available as attributes and converting it to a string renders the contents, preserving the module-like API.
```

- **Sources:**
  - `src/jinja2/environment.py:1505-1542`
