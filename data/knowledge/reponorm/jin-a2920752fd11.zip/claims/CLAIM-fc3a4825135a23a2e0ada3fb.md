# Rule details

- **Rule:**
  ```text
  When modifying test_test, preserve the membership check against env.tests so templates can conditionally use optional tests by name.
  ```
- **Applies to:**
  - `src/jinja2/tests.py`
- **Condition:**
  ```text
  When changing the test_test function or the environment tests registry lookup.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_test returns value in env.tests, preserving the membership check against the environment tests registry.
```

- **Sources:**
  - `src/jinja2/tests.py:70-88`
