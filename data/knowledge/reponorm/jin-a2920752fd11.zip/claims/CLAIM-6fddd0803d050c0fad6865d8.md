# Rule details

- **Rule:**
  ```text
  ModuleLoader.get_module_filename must derive the module filename by appending '.py' to the template key, tying module file naming to the template key scheme.
  ```
- **Applies to:**
  - `src/jinja2/loaders.py`
- **Condition:**
  ```text
  When modifying ModuleLoader.get_module_filename, keep the '.py' suffix appended to the template key.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
get_module_filename returns ModuleLoader.get_template_key(name) + ".py", appending the .py suffix to the template key as the rule requires.
```

- **Sources:**
  - `src/jinja2/loaders.py:623-624`
