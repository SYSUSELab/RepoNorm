# Rule details

- **Rule:**
  ```text
  wordwrap with width 20 preserves existing newlines in the input and wraps the long line, producing 'Hello!\nThis is Jinja saying\nsomething.' when newline_sequence is set to '\n'.
  ```
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:**
  ```text
  When modifying the wordwrap filter or its newline handling, preserve existing newlines and wrap long lines according to the configured newline_sequence.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_wordwrap sets newline_sequence to '\n' and asserts wordwrap(20) preserves the existing newline and wraps the long line as expected.
```

- **Sources:**
  - `tests/test_filters.py:823-827`
