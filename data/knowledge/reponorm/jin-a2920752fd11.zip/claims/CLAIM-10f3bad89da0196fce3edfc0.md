# Rule details

- **Rule:** The pre-commit configuration enables the fix-byte-order-marker hook.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
      - id: fix-byte-order-marker

```

- **Sources:**
  - `.pre-commit-config.yaml:32`
