# Rule details

- **Rule:**
  ```text
  When modifying prepare_map, preserve the filter-argument protocol: accept either an 'attribute' keyword (with optional 'default') or a positional filter name; supplying extra keyword arguments alongside 'attribute' raises FilterArgumentError, and missing a filter argument raises FilterArgumentError('map requires a filter argument').
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  Changing prepare_map or its argument validation.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
prepare_map implements the filter-argument protocol: accepts 'attribute' keyword with optional 'default', raises FilterArgumentError for extra keywords, and raises FilterArgumentError('map requires a filter argument') when the positional filter name is missing.
```

- **Sources:**
  - `src/jinja2/filters.py:1691-1716`
