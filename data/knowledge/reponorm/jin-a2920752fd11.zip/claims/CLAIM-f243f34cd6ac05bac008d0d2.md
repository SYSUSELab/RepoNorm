# Rule details

- **Rule:**
  ```text
  When modifying the default finalize behavior, preserve the contract that _default_finalize returns str(value) and is the fallback finalize, also applied to constants when the environment defines a finalize function.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  Changing CodeGenerator._default_finalize or the fallback finalize behavior.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
CodeGenerator._default_finalize returns str(value), preserving the default finalize fallback contract.
```

- **Sources:**
  - `src/jinja2/compiler.py:1367-1372`
