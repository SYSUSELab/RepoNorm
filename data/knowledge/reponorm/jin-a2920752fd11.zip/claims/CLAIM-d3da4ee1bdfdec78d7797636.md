# Rule details

- **Rule:**
  ```text
  An inline gettext extension must implement inline gettext blocks using _(...) syntax and requires the i18n extension to be loaded and configured.
  ```
- **Applies to:**
  - `docs/examples/inline_gettext_extension.py`
- **Condition:** when implementing or modifying the inline gettext extension
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The InlineGettext class docstring documents inline gettext blocks using _(...) syntax and states the i18n extension must be loaded and configured.
```

- **Sources:**
  - `docs/examples/inline_gettext_extension.py:13-72`
