# Rule details

- **Rule:**
  ```text
  When modifying CodeGenerator.return_buffer_contents, preserve autoescape-aware buffer return: emit Markup(concat(buffer)) when autoescape is active, concat(buffer) otherwise, and a runtime branch on context.eval_ctx.autoescape when autoescape is volatile.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  Changing CodeGenerator.return_buffer_contents or its autoescape-dependent buffer emission.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
return_buffer_contents preserves autoescape-aware buffer return: Markup(concat(buffer)) under active autoescape, concat(buffer) otherwise, and a runtime branch on context.eval_ctx.autoescape when volatile.
```

- **Sources:**
  - `src/jinja2/compiler.py:394-412`
