# Rule details

- **Rule:**
  ```text
  When modifying Context.derived, preserve the derivation semantics: create a new independent context via new_context with the same environment/name and get_all(), copy eval_ctx, and copy blocks as lists, so derived contexts share blocks but are otherwise independent.
  ```
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:** When changing Context.derived or how derived contexts share or copy state.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
Context.derived creates a new context via new_context with the same environment/name and get_all(), copies eval_ctx, and copies blocks as lists, preserving derived-context semantics.
```

- **Sources:**
  - `src/jinja2/runtime.py:305-315`
