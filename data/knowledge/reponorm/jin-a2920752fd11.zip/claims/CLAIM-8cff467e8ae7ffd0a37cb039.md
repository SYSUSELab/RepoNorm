# Rule details

- **Rule:** The workflow installs tox and runs the tox environment selected by the matrix tox value.
- **Applies to:**
  - `.github/workflows/tests.yaml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
      - run: pip install tox
      - run: tox -e ${{ matrix.tox }}

```

- **Sources:**
  - `.github/workflows/tests.yaml:54-55`
