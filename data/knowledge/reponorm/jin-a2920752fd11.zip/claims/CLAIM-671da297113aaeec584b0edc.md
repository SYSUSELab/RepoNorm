# Rule details

- **Rule:**
  ```text
  When modifying Node.find_all, preserve recursive descendant traversal: it yields descendants matching a node type or tuple of types, including nested matches.
  ```
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:**
  ```text
  Changing Node.find_all or its recursive descendant matching behavior.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
Node.find_all recursively yields descendants matching a node type or tuple of types, including nested matches via child.find_all.
```

- **Sources:**
  - `src/jinja2/nodes.py:193-202`
