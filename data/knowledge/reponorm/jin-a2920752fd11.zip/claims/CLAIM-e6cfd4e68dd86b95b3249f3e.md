# Rule details

- **Rule:** When modifying the Neg AST node, preserve that it is a UnaryExpr subclass whose operator attribute is "-", defining negation code generation.
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** Changing the Neg node or its operator attribute.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
Neg subclasses UnaryExpr with operator "-", preserving the negation code-generation contract.
```

- **Sources:**
  - `src/jinja2/nodes.py:1015-1018`
