# Rule details

- **Rule:**
  ```text
  An inline gettext extension's filter_stream must track parenthesis depth to decide whether to emit trans/endtrans block tokens, and must raise TemplateSyntaxError for an unclosed gettext expression at end of stream.
  ```
- **Applies to:**
  - `docs/examples/inline_gettext_extension.py`
- **Condition:**
  ```text
  when implementing or modifying the filter_stream method of the inline gettext extension
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The filter_stream body tracks paren_stack depth to decide trans/endtrans emission and raises TemplateSyntaxError for an unclosed gettext expression at end of stream, matching the filter_stream protocol rule.
```

- **Sources:**
  - `docs/examples/inline_gettext_extension.py:22-72`
