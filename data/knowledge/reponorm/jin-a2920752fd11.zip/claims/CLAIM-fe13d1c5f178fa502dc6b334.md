# Rule details

- **Rule:**
  ```text
  When modifying jinja2.nodes, preserve the extension API protocol: NodeType.__new__ is replaced with a failing staticmethod and the helper is deleted, so creating custom Node subclasses via NodeType is intentionally blocked; extensions must use the provided node classes.
  ```
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** Changing NodeType or the node class creation mechanism.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The jinja2.nodes module body shows NodeType.__new__ replaced with a failing staticmethod and the helper deleted, preserving the intentional block on creating custom Node subclasses via NodeType.
```

- **Sources:**
  - `src/jinja2/nodes.py`
