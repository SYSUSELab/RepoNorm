# Rule details

- **Rule:**
  ```text
  Compare.as_const must fold chained comparisons by applying each operator in sequence, short-circuiting to False as soon as a comparison is false, and converting any exception during folding to Impossible.
  ```
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:**
  ```text
  When modifying Compare.as_const constant folding, preserve sequential operator application, short-circuit to False on a false comparison, and exception-to-Impossible conversion.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
Compare.as_const applies each operator sequentially, short-circuits to False on a false comparison, and converts exceptions to Impossible.
```

- **Sources:**
  - `src/jinja2/nodes.py:918-934`
