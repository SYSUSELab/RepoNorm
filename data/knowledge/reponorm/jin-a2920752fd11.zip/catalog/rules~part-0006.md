# Full rule catalog

## Rule 087 — `src/jinja2/bccache.py`

- **Rule:**
  ```text
  When modifying Bucket.write_bytecode, preserve the on-disk bytecode format: raise TypeError('can't write empty bucket') when code is None, otherwise write bc_magic, pickle the checksum with protocol 2, and marshal the code.
  ```
- **Applies to:**
  - `src/jinja2/bccache.py`
- **Condition:** When changing how bytecode buckets are serialized to disk or how empty buckets are handled.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-edf3d2177ea473b8d38e3611.md)

## Rule 088 — `**/*.py`

- **Rule:** flake8 selects the B, E, F, W, B9, and ISC rule codes.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f11d249d940b132cd1d09de5.md)

## Rule 089 — `src/jinja2/compiler.py`

- **Rule:**
  ```text
  When modifying the default finalize behavior, preserve the contract that _default_finalize returns str(value) and is the fallback finalize, also applied to constants when the environment defines a finalize function.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  Changing CodeGenerator._default_finalize or the fallback finalize behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f243f34cd6ac05bac008d0d2.md)

## Rule 090 — `src/jinja2/compiler.py`

- **Rule:**
  ```text
  When modifying CodeGenerator.return_buffer_contents, preserve autoescape-aware buffer return: emit Markup(concat(buffer)) when autoescape is active, concat(buffer) otherwise, and a runtime branch on context.eval_ctx.autoescape when autoescape is volatile.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  Changing CodeGenerator.return_buffer_contents or its autoescape-dependent buffer emission.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f2dba4dcd20734e497231e2f.md)

## Rule 091 — `src/jinja2/environment.py`

- **Rule:**
  ```text
  When modifying the default template class binding, preserve that Environment.template_class is assigned to Template at import time and remains user-overridable.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:** Changing the default template class binding or its import-time assignment.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f71be49ed05751c3187ccb97.md)

## Rule 092 — `src/jinja2/filters.py`

- **Rule:** When modifying the HasHTML protocol, preserve its structural typing contract for HTML-like objects as declared inside filters.
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:** changing the HasHTML protocol declaration or its structural typing contract
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f99c9a3895a5e5e42b44841d.md)

## Rule 093 — `src/jinja2/tests.py`

- **Rule:**
  ```text
  When modifying test_test, preserve the membership check against env.tests so templates can conditionally use optional tests by name.
  ```
- **Applies to:**
  - `src/jinja2/tests.py`
- **Condition:**
  ```text
  When changing the test_test function or the environment tests registry lookup.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-fc3a4825135a23a2e0ada3fb.md)

## Rule 094 — `src/jinja2/nodes.py`

- **Rule:**
  ```text
  When modifying jinja2.nodes, preserve the extension API protocol: NodeType.__new__ is replaced with a failing staticmethod and the helper is deleted, so creating custom Node subclasses via NodeType is intentionally blocked; extensions must use the provided node classes.
  ```
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** Changing NodeType or the node class creation mechanism.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-fe13d1c5f178fa502dc6b334.md)
