# Full rule catalog

## Rule 035 — `**`

- **Rule:**
  ```text
  Trailing whitespace is trimmed (trim_trailing_whitespace = true) for files matched by the [*] section.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6c93e77d25b1b36837c35126.md)

## Rule 036 — `src/jinja2/loaders.py`

- **Rule:**
  ```text
  ModuleLoader.get_module_filename must derive the module filename by appending '.py' to the template key, tying module file naming to the template key scheme.
  ```
- **Applies to:**
  - `src/jinja2/loaders.py`
- **Condition:**
  ```text
  When modifying ModuleLoader.get_module_filename, keep the '.py' suffix appended to the template key.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6fddd0803d050c0fad6865d8.md)

## Rule 037 — `src/jinja2/meta.py`

- **Rule:**
  ```text
  When modifying the undeclared-identifier analysis, preserve enter_frame's exclusion: a symbol is recorded as undeclared only when its load action is resolve and the parameter is not present in environment.globals.
  ```
- **Applies to:**
  - `src/jinja2/meta.py`
- **Condition:**
  ```text
  changing how enter_frame decides whether a symbol is undeclared
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-74a369e24bdc588d5c8610a6.md)

## Rule 038 — `**`

- **Rule:**
  ```text
  Line endings use LF (end_of_line = lf) for files matched by the [*] section.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-772f4ba987b1939af58e05b3.md)

## Rule 039 — `tests/test_api.py`

- **Rule:**
  ```text
  A finalize callback decorated with pass_environment receives the environment and the value, and can use environment variable delimiters to format output.
  ```
- **Applies to:**
  - `tests/test_api.py`
- **Condition:**
  ```text
  When modifying finalize callback handling or the pass_environment decorator, preserve that the environment and value are passed to finalize.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-778d0a8f3552a46b6ae17a62.md)

## Rule 040 — `**/*.css`

- **Rule:**
  ```text
  YAML, JSON, JavaScript, CSS, and HTML files use an indent size of 2 (indent_size = 2).
  ```
- **Applies to:**
  - `**/*.css`
  - `**/*.html`
  - `**/*.js`
  - `**/*.json`
  - `**/*.yaml`
  - `**/*.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-79769d3d7e586d171f691e00.md)

## Rule 041 — `src/jinja2/filters.py`

- **Rule:**
  ```text
  When modifying the async do_slice variant, preserve the requirement that it awaits auto_to_list(value) before delegating to the sync slicing implementation, so async iterables are materialized before slicing.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  Changing the async do_slice variant or its materialization of async iterables.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7a8365dd59665f94236ad22a.md)

## Rule 042 — `.github/workflows/tests.yaml`

- **Rule:**
  ```text
  The workflow caches ./.mypy_cache keyed by the matrix Python version and the hash of setup.cfg, only when the matrix tox value is 'typing'.
  ```
- **Applies to:**
  - `.github/workflows/tests.yaml`
- **Condition:** workflow predicate: matrix.tox == 'typing'
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7a8974b891758de41224517d.md)

## Rule 043 — `**/*.py`

- **Rule:** flake8 ignores E203, E501, E722, and W503.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7b6f826d81d69804ebd1c31f.md)

## Rule 044 — `tests/test_tests.py`

- **Rule:** When a name is undefined, an if-guarded test expression ({{ x is f }}) is not evaluated and renders empty; when x is defined, an unknown test name raises TemplateRuntimeError with message "No test named 'f'".
- **Applies to:**
  - `tests/test_tests.py`
- **Condition:** When modifying test-expression evaluation or undefined-name handling, preserve that if-guarded test expressions are not evaluated for undefined names and that unknown test names raise TemplateRuntimeError when the name is defined.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7eb9bcdceb4917c9341d5fe2.md)

## Rule 045 — `src/jinja2/compiler.py`

- **Rule:**
  ```text
  CodeGenerator.visit_ExtensionAttribute must emit a direct subscript into environment.extensions keyed by the node identifier followed by attribute access, coupling extension attribute resolution to the runtime environment.extensions mapping rather than a generic getattr path.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  When modifying CodeGenerator.visit_ExtensionAttribute, keep the direct environment.extensions subscript keyed by the node identifier followed by attribute access.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-860d2f13f70ba54399f18c6c.md)

## Rule 046 — `.github/workflows/tests.yaml`

- **Rule:** The workflow installs tox and runs the tox environment selected by the matrix tox value.
- **Applies to:**
  - `.github/workflows/tests.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8cff467e8ae7ffd0a37cb039.md)

## Rule 047 — `src/jinja2/__init__.py`

- **Rule:**
  ```text
  flake8 ignores F401 in src/jinja2/__init__.py.
  ```
- **Applies to:**
  - `src/jinja2/__init__.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8d5ab39383239e7a489de646.md)

## Rule 048 — `setup.cfg`

- **Rule:**
  ```text
  The babel.extractors entry point registers the jinja2 extractor as jinja2.ext:babel_extract[i18n].
  ```
- **Applies to:**
  - `setup.cfg`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8f7a8501542d9b71616e99e1.md)

## Rule 049 — `requirements/docs.txt`

- **Rule:** Read the Docs installs documentation dependencies from requirements/docs.txt.
- **Applies to:**
  - `requirements/docs.txt`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-994d950463927c662dcdc2da.md)

## Rule 050 — `src/jinja2/runtime.py`

- **Rule:**
  ```text
  When modifying Context.derived, preserve the derivation semantics: create a new independent context via new_context with the same environment/name and get_all(), copy eval_ctx, and copy blocks as lists, so derived contexts share blocks but are otherwise independent.
  ```
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:** When changing Context.derived or how derived contexts share or copy state.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9bdc3119727cabc770f8ef6f.md)

## Rule 051 — `**`

- **Rule:**
  ```text
  Character encoding is UTF-8 (charset = utf-8) for files matched by the [*] section.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a0181e41d26c5c0d3013a49e.md)

## Rule 052 — `tests/test_idtracking.py`

- **Rule:**
  ```text
  symbols_for_node assigns scoped names like l_0_foo and records loads as ('undefined', None), ('resolve', name), or ('param', None) depending on whether the name is assigned, resolved from outer scope, or a loop parameter.
  ```
- **Applies to:**
  - `tests/test_idtracking.py`
- **Condition:** When modifying symbol tracking or id-tracking logic, preserve the scoped-name and load-classification conventions for assigned, resolved, and loop-parameter names.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a01d94833c9daf14e720afe9.md)
