# Full rule catalog

## Rule 001 — `tox.ini`

- **Rule:** The tox envlist defines environments py311, py310, py39, py38, py37, pypy38, pypy37, style, typing, and docs.
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-009b3b6f88866be1ab531e0d.md)

## Rule 002 — `src/jinja2/compiler.py`

- **Rule:**
  ```text
  When modifying the autoescape code generation, preserve visit_MarkSafeIfAutoescape's conditional emission: select Markup when context.eval_ctx.autoescape is true and identity otherwise, so the same expression is marked safe only under autoescape.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  changing how visit_MarkSafeIfAutoescape emits the conditional Markup/identity call
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0403849c7ca683802a61dd4c.md)

## Rule 003 — `tests/conftest.py`

- **Rule:** The env fixture in tests/conftest.py must return a fresh Environment() instance, establishing the convention that tests receive a new environment per test.
- **Applies to:**
  - `tests/conftest.py`
- **Condition:** when adding or modifying the env fixture in tests/conftest.py
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-067387bcdab409f527d5580e.md)

## Rule 004 — `**`

- **Rule:**
  ```text
  Indent size is 4 (indent_size = 4) for files matched by the [*] section.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0f82da36c0b11a923f7a83f8.md)

## Rule 005 — `**`

- **Rule:** The pre-commit configuration enables the fix-byte-order-marker hook.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-10f3bad89da0196fce3edfc0.md)

## Rule 006 — `src/jinja2/runtime.py`

- **Rule:** When modifying the Macro runtime wrapper, preserve its documented contract of wrapping a macro function as the runtime wrapper for macro callables.
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:** Changing the Macro runtime wrapper or its wrapping contract.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-13cf307a21c3452c8f547d9a.md)

## Rule 007 — `.pre-commit-config.yaml`

- **Rule:** The pre-commit CI autoupdate branch is 3.0.x.
- **Applies to:**
  - `.pre-commit-config.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-161b30c27b0292ac29bef22e.md)

## Rule 008 — `src/jinja2/compiler.py`

- **Rule:**
  ```text
  When modifying the compiler's context-reference tracking, preserve push_context_reference's stack operation: it appends a target string to _context_reference_stack.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  changing how push_context_reference records context references
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1c3b442580b28912562d2cdd.md)

## Rule 009 — `src/jinja2/compiler.py`

- **Rule:**
  ```text
  When modifying parameter-definition handling in the compiler, preserve the stack discipline: parameter definitions are maintained as a stack and pop_parameter_definitions removes the most recent set.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** When changing how parameter definitions are pushed or popped during code generation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1e5de810617306a67adabd73.md)

## Rule 010 — `**/*.py`

- **Rule:** Use Black to format code; Black and other tools run automatically if pre-commit is installed using the instructions below.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-1f647350267102d53890f09d.md)

## Rule 011 — `docs/examples/cache_extension.py`

- **Rule:**
  ```text
  A cache extension must call environment.extend with fragment_cache_prefix and fragment_cache defaults to add the documented environment attributes.
  ```
- **Applies to:**
  - `docs/examples/cache_extension.py`
- **Condition:** when initializing the fragment cache extension and registering its environment attributes
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-204d36961943dbf845fc2099.md)

## Rule 012 — `src/jinja2/runtime.py`

- **Rule:** When modifying LoopContext.previtem, preserve the first-iteration boundary: it returns an Undefined with the message "there is no previous item" during the first iteration and otherwise returns the previous item.
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:** Changing LoopContext.previtem behavior or its first-iteration handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-213b36ce0785aea889c1b966.md)

## Rule 013 — `src/jinja2/filters.py`

- **Rule:**
  ```text
  When modifying the attribute filter, preserve _prepare_attribute_parts normalization: None yields an empty part list, string attributes are split on '.' with digit segments converted to int, and non-string attributes are wrapped as a single-element list.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:** changing how dotted attribute paths are parsed or normalized in the attribute filter
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-239c923dabe5819d88b8d958.md)

## Rule 014 — `tox.ini`

- **Rule:** tox skips missing interpreters instead of failing when an interpreter is unavailable.
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-24ce76a614d51f32e70ea63e.md)

## Rule 015 — `src/jinja2/lexer.py`

- **Rule:** When modifying TokenStreamIterator, preserve its termination contract: iteration continues until the eof token is reached.
- **Applies to:**
  - `src/jinja2/lexer.py`
- **Condition:** changing TokenStreamIterator's iteration termination logic
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-29d01ca64019d2f93313e7d2.md)

## Rule 016 — `src/jinja2/nodes.py`

- **Rule:** When modifying the Block node schema, preserve the field tuple ('name', 'body', 'scoped', 'required'), including the 'required' field added in version 3.0.0, as a compatibility boundary for node consumers.
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** Changing the Block node fields or their compatibility contract.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-2ac95c1bd92a0f28092b4632.md)

## Rule 017 — `.github/workflows/tests.yaml`

- **Rule:**
  ```text
  The workflow sets up Python using the matrix Python version and caches pip dependencies based on requirements/*.txt.
  ```
- **Applies to:**
  - `.github/workflows/tests.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-2d650129194144016ed3f79f.md)

## Rule 018 — `tests/test_nativetypes.py`

- **Rule:** A NativeTemplate constructed without an environment must receive a NativeEnvironment instance so that standalone use still yields native-type rendering behavior.
- **Applies to:**
  - `tests/test_nativetypes.py`
- **Condition:** When adding or modifying tests for standalone NativeTemplate construction without an explicit environment.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-36a334faecb90bdcc28bf0a0.md)
