# Full rule catalog

## Rule 070 — `docs/examples/inline_gettext_extension.py`

- **Rule:**
  ```text
  An inline gettext extension must implement inline gettext blocks using _(...) syntax and requires the i18n extension to be loaded and configured.
  ```
- **Applies to:**
  - `docs/examples/inline_gettext_extension.py`
- **Condition:** when implementing or modifying the inline gettext extension
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d3da4ee1bdfdec78d7797636.md)

## Rule 071 — `jinja2/**`

- **Rule:** Coverage source measurement is limited to the jinja2 and tests directories.
- **Applies to:**
  - `jinja2/**`
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d48095fc26cdaf1cf672d333.md)

## Rule 072 — `src/jinja2/filters.py`

- **Rule:**
  ```text
  When modifying do_urlencode, preserve the two-mode quoting behavior: plain strings are quoted directly without quoting '/', while dicts or iterables of pairs are joined as a query string with both keys and values quoted for query-string use.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:** When changing the urlencode filter's handling of strings versus mappings/iterables of pairs.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d564249bc3b92d5fa93c71e9.md)

## Rule 073 — `**`

- **Rule:** The pre-commit configuration enables the end-of-file-fixer hook.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-da5005339ebe5d03790a46b6.md)

## Rule 074 — `src/jinja2/runtime.py`

- **Rule:**
  ```text
  When modifying Macro._invoke, preserve the async/autoescape dispatch contract: dispatch to _async_invoke when the environment is async, otherwise call the function directly and wrap the result in Markup when autoescape is enabled.
  ```
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:**
  ```text
  Changing Macro._invoke or its async/autoescape dispatch.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-db627aa006fcbefb757f187b.md)

## Rule 075 — `setup.py`

- **Rule:**
  ```text
  Keep setup.py's install_requires and extras declarations consistent with the authoritative metadata in setup.cfg; setup.py entries exist only to feed GitHub's dependency graph and must not diverge from setup.cfg.
  ```
- **Applies to:**
  - `setup.py`
- **Condition:** When editing dependency declarations in setup.py
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-debc912f39400b889ba693d9.md)

## Rule 076 — `src/jinja2/loaders.py`

- **Rule:**
  ```text
  When modifying FunctionLoader.__init__, preserve the load_func contract: store the supplied callable, which must accept a template name and return either a string or a (source, filename, uptodate) tuple.
  ```
- **Applies to:**
  - `src/jinja2/loaders.py`
- **Condition:**
  ```text
  When changing FunctionLoader initialization or the expected load_func signature/return shape.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e0f2e954b62411e4ff0bc49c.md)

## Rule 077 — `src/jinja2/environment.py`

- **Rule:** When modifying TemplateStream.dump, preserve the API contract: accept a path string or file-like object; when given a path, default encoding to utf-8, open the file in binary mode, and close it afterward.
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:** Changing TemplateStream.dump or its path/file-like handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e12d093bf6ab633c5cedb4a0.md)

## Rule 078 — `**`

- **Rule:**
  ```text
  The tox testenv:style environment runs `pre-commit run --all-files --show-diff-on-failure` as its command.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Use:** `reference_only`
- **Execution risk:** `repository_wide_mutation`
- **Detail:** [Open claim details](../claims/CLAIM-e25cd1c51aa71a79cf35d3c4.md)

## Rule 079 — `src/jinja2/filters.py`

- **Rule:**
  ```text
  When modifying the indent filter, preserve do_indent semantics: accept int or string width, preserve Markup types for indention and newline, do not indent blank lines unless blank=True, and only indent the first line when first=True.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  changing do_indent's width handling, blank-line behavior, or first-line-only behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e31417044e7bee0a30a745ef.md)

## Rule 080 — `docs/examples/cache_extension.py`

- **Rule:** A cache extension must register its template tag by declaring tags = {"cache"} on the extension class.
- **Applies to:**
  - `docs/examples/cache_extension.py`
- **Condition:** when adding or modifying the fragment cache extension's template tag registration
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e3eda6b951fcf725fc0821f6.md)

## Rule 081 — `src/jinja2/compiler.py`

- **Rule:**
  ```text
  When modifying the binop visitor generation, preserve _make_binop's factory contract: it returns a visitor callable for binary expression nodes, parameterized by operator, used to generate CodeGenerator binop visitors.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  changing how _make_binop generates binop visitors
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e4597e1367b51a3591907954.md)

## Rule 082 — `requirements/typing.txt`

- **Rule:** The tox testenv:typing environment installs its dependencies from requirements/typing.txt.
- **Applies to:**
  - `requirements/typing.txt`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e4fecc23a68fed33443f76ca.md)

## Rule 083 — `src/jinja2/nodes.py`

- **Rule:** When modifying the Neg AST node, preserve that it is a UnaryExpr subclass whose operator attribute is "-", defining negation code generation.
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** Changing the Neg node or its operator attribute.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e6cfd4e68dd86b95b3249f3e.md)

## Rule 084 — `docs/examples/cache_extension.py`

- **Rule:**
  ```text
  A custom tag extension must parse its tag by consuming the name token for lineno, parsing one expression as the cache key, optionally a second expression after a comma for timeout (defaulting to Const(None)), then parsing statements up to `endcache` with drop_needle=True and returning a CallBlock calling the extension helper.
  ```
- **Applies to:**
  - `docs/examples/cache_extension.py`
- **Condition:** when implementing or modifying the parse method of a custom tag extension
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e71b2a3938986a17b888a857.md)

## Rule 085 — `tests/test_filters.py`

- **Rule:**
  ```text
  wordwrap with width 20 preserves existing newlines in the input and wraps the long line, producing 'Hello!\nThis is Jinja saying\nsomething.' when newline_sequence is set to '\n'.
  ```
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:**
  ```text
  When modifying the wordwrap filter or its newline handling, preserve existing newlines and wrap long lines according to the configured newline_sequence.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e7d01fd4be23c0e80d9bf774.md)

## Rule 086 — `src/jinja2/**`

- **Rule:** mypy is configured to check the files under src/jinja2.
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-eda4d85facea218b20faab1e.md)
