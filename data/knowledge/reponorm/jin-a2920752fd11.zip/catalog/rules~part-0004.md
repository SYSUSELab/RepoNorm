# Full rule catalog

## Rule 053 — `src/jinja2/ext.py`

- **Rule:**
  ```text
  When modifying the extension token-stream initializer, preserve that it stores tokens and comment_tags and initializes offset=0 and last_lineno=0 as the mutable cursor state used while parsing extension tokens.
  ```
- **Applies to:**
  - `src/jinja2/ext.py`
- **Condition:** Changing the extension token-stream initializer or its cursor state initialization.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a39d059ec6b67086a14ec9ee.md)

## Rule 054 — `tests/test_async.py`

- **Rule:**
  ```text
  The async_func helper must be a coroutine returning 42, used as a minimal awaitable fixture in async tests.
  ```
- **Applies to:**
  - `tests/test_async.py`
- **Condition:** when modifying async test helpers or awaitable fixtures in the async tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a57a0b61d7d5cfc4b84cf218.md)

## Rule 055 — `src/jinja2/compiler.py`

- **Rule:**
  ```text
  When modifying CodeGenerator.visit_Include, preserve include compilation selection: use get_template for constant string templates, select_template for constant tuple/list templates, and get_or_select_template otherwise; ignore_missing wraps lookup in try/except TemplateNotFound, and with_context renders via root_render_func with a new context.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  Changing CodeGenerator.visit_Include or its template lookup and rendering behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a9514d854155a64587cac113.md)

## Rule 056 — `src/jinja2/runtime.py`

- **Rule:**
  ```text
  When modifying LoopContext, preserve the initialization contract: index0 starts at -1, _after, _current, _before, and _last_changed_value use a sentinel missing value, and _length defaults to None.
  ```
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:** Changing LoopContext initialization or its sentinel/default values.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-aa400ab17939edb6e323e777.md)

## Rule 057 — `docs/examples/inline_gettext_extension.py`

- **Rule:**
  ```text
  An inline gettext extension's filter_stream must track parenthesis depth to decide whether to emit trans/endtrans block tokens, and must raise TemplateSyntaxError for an unclosed gettext expression at end of stream.
  ```
- **Applies to:**
  - `docs/examples/inline_gettext_extension.py`
- **Condition:**
  ```text
  when implementing or modifying the filter_stream method of the inline gettext extension
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ab51b5eef8fe656a2f9735e0.md)

## Rule 058 — `tests/**`

- **Rule:** Pytest test discovery is restricted to the tests directory via testpaths = tests.
- **Applies to:**
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ad836813cd6a1b4a85305ff5.md)

## Rule 059 — `**`

- **Rule:**
  ```text
  Indentation uses spaces (indent_style = space) for files matched by the [*] section.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-aeaaaab4dc092724a8204200.md)

## Rule 060 — `src/jinja2/compiler.py`

- **Rule:**
  ```text
  When modifying CodeGenerator.visit_If, preserve the soft-frame branch isolation: compile the test and all branches using a soft frame so if/elif/else blocks share the same if_frame and branch bodies do not leak symbol changes into the outer frame.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** When changing if/elif/else code generation or frame handling in the compiler.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b29392f15d6d83f91ecd88cc.md)

## Rule 061 — `tests/test_nativetypes.py`

- **Rule:**
  ```text
  Rendering a constant dunder expression such as true.__class__|string must produce a string, not a type object, and the result must match either the Python 2 or Python 3 bool repr form.
  ```
- **Applies to:**
  - `tests/test_nativetypes.py`
- **Condition:** When modifying native-type rendering or dunder expression handling, preserve that constant dunder expressions render as strings matching the bool repr form.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b392331dd0780eb04a9e4e91.md)

## Rule 062 — `**`

- **Rule:**
  ```text
  The tox testenv:style environment sets skip_install to true.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b7613278091531b430091012.md)

## Rule 063 — `**`

- **Rule:** CI runs the full test suite when a pull request is submitted.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-be0e1dffbdac765b5ca8e2c2.md)

## Rule 064 — `src/jinja2/environment.py`

- **Rule:** When modifying TemplateModule, preserve its module-like API: exported names are attributes and converting the module to a string renders the template contents.
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:** changing TemplateModule's attribute export or string conversion behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-becc99568cb90a46fe10308b.md)

## Rule 065 — `**`

- **Rule:**
  ```text
  Files end with a final newline (insert_final_newline = true) for files matched by the [*] section.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c94d140e6b13520059a8d1fc.md)

## Rule 066 — `src/jinja2/runtime.py`

- **Rule:** When modifying LoopContext, preserve the public index invariant: index is defined as index0 + 1, so index is 1-based while index0 remains 0-based.
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:** changing LoopContext.index or index0 definitions
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ca7176c4d7182dd57917f576.md)

## Rule 067 — `.github/workflows/tests.yaml`

- **Rule:** The workflow updates wheel, setuptools, and pip before running tests.
- **Applies to:**
  - `.github/workflows/tests.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ccdca53e520b890248ddec56.md)

## Rule 068 — `src/jinja2/nodes.py`

- **Rule:**
  ```text
  Compare.as_const must fold chained comparisons by applying each operator in sequence, short-circuiting to False as soon as a comparison is false, and converting any exception during folding to Impossible.
  ```
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:**
  ```text
  When modifying Compare.as_const constant folding, preserve sequential operator application, short-circuit to False on a false comparison, and exception-to-Impossible conversion.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-cec6cc240a2b0b93ca2d6199.md)

## Rule 069 — `src/jinja2/sandbox.py`

- **Rule:**
  ```text
  The @unsafe decorator must mark a callable by setting unsafe_callable=True and returning it, and is_safe_callable must treat a callable as unsafe when unsafe_callable=True or Django's alters_data=True, otherwise safe by default.
  ```
- **Applies to:**
  - `src/jinja2/sandbox.py`
- **Condition:**
  ```text
  when adding or modifying callable-safety marking or the is_safe_callable check
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d2af45581120c59e820f8dd6.md)
