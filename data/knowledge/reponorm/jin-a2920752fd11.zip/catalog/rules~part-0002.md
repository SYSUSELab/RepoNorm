# Full rule catalog

## Rule 019 — `src/jinja2/filters.py`

- **Rule:**
  ```text
  do_wordwrap must wrap each line separately (splitting on existing newlines) because textwrap.wrap ignores existing newlines, and must default wrapstring to environment.newline_sequence.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  When modifying do_wordwrap, preserve per-line wrapping on existing newlines and the default wrapstring of environment.newline_sequence.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-39a44cb080e34d505234e69b.md)

## Rule 020 — `src/jinja2/compiler.py`

- **Rule:**
  ```text
  CodeGenerator.visit_Template must assert no root frame is allowed, emit imports of exported runtime names, detect extends to decide whether inheritance code is needed, reject duplicate block names, and generate root and block render functions with distinct frame handling.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  When modifying CodeGenerator.visit_Template, preserve the no-root-frame assertion, exported-name imports, extends-based inheritance decision, duplicate-block rejection, and distinct root/block frame handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-40b8c29a1a179b521cddecc5.md)

## Rule 021 — `src/jinja2/compiler.py`

- **Rule:**
  ```text
  When modifying CodeGenerator.visit_Block, preserve block codegen guards: skip emitting block-call code when a known extends exists at top level, otherwise guard block output with a parent_template check, and emit a runtime error for required blocks with no override.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** When changing block code generation, extends handling, or required-block override behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-41220cc5199878c3bfd8e2e7.md)

## Rule 022 — `src/jinja2/filters.py`

- **Rule:**
  ```text
  When modifying do_mark_safe, preserve the safety mechanism: the value is wrapped in Markup so autoescape-enabled environments do not escape it.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  Changing do_mark_safe or its Markup wrapping behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-4204a58ae69803e6131a4840.md)

## Rule 023 — `**/*.py`

- **Rule:** flake8 enforces a maximum line length of 80.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-434ee96c05406f218a2f1314.md)

## Rule 024 — `src/jinja2/lexer.py`

- **Rule:**
  ```text
  When modifying TokenStreamIterator.__init__, preserve the stream attribute contract: store the TokenStream on self.stream so token iteration can rely on that attribute.
  ```
- **Applies to:**
  - `src/jinja2/lexer.py`
- **Condition:** When changing TokenStreamIterator initialization or token iteration state.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-47e568c853b408fa8da2e4e8.md)

## Rule 025 — `docs/examples/cache_extension.py`

- **Rule:**
  ```text
  A fragment cache extension must key cache entries by environment.fragment_cache_prefix + name, return the cached value when present, and otherwise call caller() and store the result with the timeout via fragment_cache.add.
  ```
- **Applies to:**
  - `docs/examples/cache_extension.py`
- **Condition:** when implementing or modifying the fragment cache extension's cache-support helper
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-4b92b73ad829eef46feff94b.md)

## Rule 026 — `src/jinja2/filters.py`

- **Rule:**
  ```text
  When modifying the striptags filter, preserve the __html__ protocol check: do_striptags must consult __html__ on the value and use its result before stripping tags via Markup.striptags.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  changing how do_striptags handles objects implementing __html__
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-4ff3e0e458ff4f2de359bfd7.md)

## Rule 027 — `src/jinja2/idtracking.py`

- **Rule:**
  ```text
  When modifying Symbols.__init__, preserve the nesting-level invariant: level is derived from parent.level + 1 when level is None and a parent exists, otherwise 0, and refs, loads, and stores containers are initialized.
  ```
- **Applies to:**
  - `src/jinja2/idtracking.py`
- **Condition:**
  ```text
  Changing Symbols.__init__ or its level derivation and container initialization.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-51f04bf3adc01a9b79b4eb88.md)

## Rule 028 — `**`

- **Rule:** Read the Docs builds use Ubuntu 20.04 as the build OS.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-53e9fee1286200f505482821.md)

## Rule 029 — `.pre-commit-config.yaml`

- **Rule:** The pre-commit CI autoupdate schedule is monthly.
- **Applies to:**
  - `.pre-commit-config.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5615114fa213fc4cb7262dc6.md)

## Rule 030 — `src/jinja2/filters.py`

- **Rule:**
  ```text
  When modifying prepare_map, preserve the filter-argument protocol: accept either an 'attribute' keyword (with optional 'default') or a positional filter name; supplying extra keyword arguments alongside 'attribute' raises FilterArgumentError, and missing a filter argument raises FilterArgumentError('map requires a filter argument').
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  Changing prepare_map or its argument validation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-587eef8eb1c0e364f12cdc76.md)

## Rule 031 — `src/jinja2/idtracking.py`

- **Rule:**
  ```text
  When modifying the idtracking visitor, preserve visit_For's boundary behavior: the visitor stops at for blocks but still visits the iter expression as part of the outer scope.
  ```
- **Applies to:**
  - `src/jinja2/idtracking.py`
- **Condition:**
  ```text
  changing how FrameSymbolVisitor.visit_For handles for blocks and their iter expressions
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5f57bd57bff7cc886f629cce.md)

## Rule 032 — `src/jinja2/idtracking.py`

- **Rule:**
  ```text
  When modifying the idtracking load-kind vocabulary, preserve the four VAR_LOAD_* constants (param, resolve, alias, undefined) that classify how a variable is loaded.
  ```
- **Applies to:**
  - `src/jinja2/idtracking.py`
- **Condition:**
  ```text
  Changing the VAR_LOAD_* load-kind constants or their classification vocabulary.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-613ee772f91d36f01a3c9718.md)

## Rule 033 — `src/jinja2/nodes.py`

- **Rule:**
  ```text
  When modifying Node.find_all, preserve recursive descendant traversal: it yields descendants matching a node type or tuple of types, including nested matches.
  ```
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:**
  ```text
  Changing Node.find_all or its recursive descendant matching behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-671da297113aaeec584b0edc.md)

## Rule 034 — `src/jinja2/compiler.py`

- **Rule:**
  ```text
  When modifying CodeGenerator.visit_Dict, preserve the dict emission contract: emit a Python dict literal by visiting each key and value in order and joining with ', ', so dict node items must be visited pairwise to preserve ordering.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  Changing CodeGenerator.visit_Dict or its key/value emission order.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-683dec6d3d66599915b9ced3.md)
