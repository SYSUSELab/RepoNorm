# Rules for `.github/workflows/tests.yaml`

## Rule 017 — `.github/workflows/tests.yaml`

- **Rule:**
  ```text
  The workflow sets up Python using the matrix Python version and caches pip dependencies based on requirements/*.txt.
  ```
- **Applies to:**
  - `.github/workflows/tests.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2d650129194144016ed3f79f.md)

## Rule 042 — `.github/workflows/tests.yaml`

- **Rule:**
  ```text
  The workflow caches ./.mypy_cache keyed by the matrix Python version and the hash of setup.cfg, only when the matrix tox value is 'typing'.
  ```
- **Applies to:**
  - `.github/workflows/tests.yaml`
- **Condition:** workflow predicate: matrix.tox == 'typing'
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-7a8974b891758de41224517d.md)

## Rule 046 — `.github/workflows/tests.yaml`

- **Rule:** The workflow installs tox and runs the tox environment selected by the matrix tox value.
- **Applies to:**
  - `.github/workflows/tests.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8cff467e8ae7ffd0a37cb039.md)

## Rule 067 — `.github/workflows/tests.yaml`

- **Rule:** The workflow updates wheel, setuptools, and pip before running tests.
- **Applies to:**
  - `.github/workflows/tests.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ccdca53e520b890248ddec56.md)
