# Rules for `repository root`

## Rule 004 — `**`

- **Rule:**
  ```text
  Indent size is 4 (indent_size = 4) for files matched by the [*] section.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0f82da36c0b11a923f7a83f8.md)

## Rule 005 — `**`

- **Rule:** The pre-commit configuration enables the fix-byte-order-marker hook.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-10f3bad89da0196fce3edfc0.md)

## Rule 010 — `**/*.py`

- **Rule:** Use Black to format code; Black and other tools run automatically if pre-commit is installed using the instructions below.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-1f647350267102d53890f09d.md)

## Rule 023 — `**/*.py`

- **Rule:** flake8 enforces a maximum line length of 80.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-434ee96c05406f218a2f1314.md)

## Rule 028 — `**`

- **Rule:** Read the Docs builds use Ubuntu 20.04 as the build OS.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-53e9fee1286200f505482821.md)

## Rule 035 — `**`

- **Rule:**
  ```text
  Trailing whitespace is trimmed (trim_trailing_whitespace = true) for files matched by the [*] section.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6c93e77d25b1b36837c35126.md)

## Rule 038 — `**`

- **Rule:**
  ```text
  Line endings use LF (end_of_line = lf) for files matched by the [*] section.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-772f4ba987b1939af58e05b3.md)

## Rule 040 — `**/*.css`

- **Rule:**
  ```text
  YAML, JSON, JavaScript, CSS, and HTML files use an indent size of 2 (indent_size = 2).
  ```
- **Applies to:**
  - `**/*.css`
  - `**/*.html`
  - `**/*.js`
  - `**/*.json`
  - `**/*.yaml`
  - `**/*.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-79769d3d7e586d171f691e00.md)

## Rule 043 — `**/*.py`

- **Rule:** flake8 ignores E203, E501, E722, and W503.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7b6f826d81d69804ebd1c31f.md)

## Rule 051 — `**`

- **Rule:**
  ```text
  Character encoding is UTF-8 (charset = utf-8) for files matched by the [*] section.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a0181e41d26c5c0d3013a49e.md)

## Rule 059 — `**`

- **Rule:**
  ```text
  Indentation uses spaces (indent_style = space) for files matched by the [*] section.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-aeaaaab4dc092724a8204200.md)

## Rule 062 — `**`

- **Rule:**
  ```text
  The tox testenv:style environment sets skip_install to true.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b7613278091531b430091012.md)

## Rule 063 — `**`

- **Rule:** CI runs the full test suite when a pull request is submitted.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-be0e1dffbdac765b5ca8e2c2.md)

## Rule 065 — `**`

- **Rule:**
  ```text
  Files end with a final newline (insert_final_newline = true) for files matched by the [*] section.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c94d140e6b13520059a8d1fc.md)

## Rule 073 — `**`

- **Rule:** The pre-commit configuration enables the end-of-file-fixer hook.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-da5005339ebe5d03790a46b6.md)

## Rule 088 — `**/*.py`

- **Rule:** flake8 selects the B, E, F, W, B9, and ISC rule codes.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f11d249d940b132cd1d09de5.md)
