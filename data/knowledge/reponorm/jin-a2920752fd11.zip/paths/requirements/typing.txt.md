# Rules for `requirements/typing.txt`

## Rule 082 — `requirements/typing.txt`

- **Rule:** The tox testenv:typing environment installs its dependencies from requirements/typing.txt.
- **Applies to:**
  - `requirements/typing.txt`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-e4fecc23a68fed33443f76ca.md)
