# Rules for `requirements/docs.txt`

## Rule 049 — `requirements/docs.txt`

- **Rule:** Read the Docs installs documentation dependencies from requirements/docs.txt.
- **Applies to:**
  - `requirements/docs.txt`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-994d950463927c662dcdc2da.md)
