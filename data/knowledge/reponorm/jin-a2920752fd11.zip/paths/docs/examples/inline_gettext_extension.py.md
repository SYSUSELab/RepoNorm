# Rules for `docs/examples/inline_gettext_extension.py`

## Rule 057 — `docs/examples/inline_gettext_extension.py`

- **Rule:**
  ```text
  An inline gettext extension's filter_stream must track parenthesis depth to decide whether to emit trans/endtrans block tokens, and must raise TemplateSyntaxError for an unclosed gettext expression at end of stream.
  ```
- **Applies to:**
  - `docs/examples/inline_gettext_extension.py`
- **Condition:**
  ```text
  when implementing or modifying the filter_stream method of the inline gettext extension
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ab51b5eef8fe656a2f9735e0.md)

## Rule 070 — `docs/examples/inline_gettext_extension.py`

- **Rule:**
  ```text
  An inline gettext extension must implement inline gettext blocks using _(...) syntax and requires the i18n extension to be loaded and configured.
  ```
- **Applies to:**
  - `docs/examples/inline_gettext_extension.py`
- **Condition:** when implementing or modifying the inline gettext extension
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d3da4ee1bdfdec78d7797636.md)
