# Rules for `jinja2`

## Rule 071 — `jinja2/**`

- **Rule:** Coverage source measurement is limited to the jinja2 and tests directories.
- **Applies to:**
  - `jinja2/**`
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d48095fc26cdaf1cf672d333.md)
