# Rules for `src/jinja2/sandbox.py`

## Rule 069 — `src/jinja2/sandbox.py`

- **Rule:**
  ```text
  The @unsafe decorator must mark a callable by setting unsafe_callable=True and returning it, and is_safe_callable must treat a callable as unsafe when unsafe_callable=True or Django's alters_data=True, otherwise safe by default.
  ```
- **Applies to:**
  - `src/jinja2/sandbox.py`
- **Condition:**
  ```text
  when adding or modifying callable-safety marking or the is_safe_callable check
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d2af45581120c59e820f8dd6.md)
