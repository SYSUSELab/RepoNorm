# Rules for `src/jinja2/ext.py`

## Rule 053 — `src/jinja2/ext.py`

- **Rule:**
  ```text
  When modifying the extension token-stream initializer, preserve that it stores tokens and comment_tags and initializes offset=0 and last_lineno=0 as the mutable cursor state used while parsing extension tokens.
  ```
- **Applies to:**
  - `src/jinja2/ext.py`
- **Condition:** Changing the extension token-stream initializer or its cursor state initialization.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a39d059ec6b67086a14ec9ee.md)
