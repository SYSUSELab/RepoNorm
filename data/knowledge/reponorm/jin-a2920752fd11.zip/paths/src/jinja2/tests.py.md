# Rules for `src/jinja2/tests.py`

## Rule 093 — `src/jinja2/tests.py`

- **Rule:**
  ```text
  When modifying test_test, preserve the membership check against env.tests so templates can conditionally use optional tests by name.
  ```
- **Applies to:**
  - `src/jinja2/tests.py`
- **Condition:**
  ```text
  When changing the test_test function or the environment tests registry lookup.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-fc3a4825135a23a2e0ada3fb.md)
