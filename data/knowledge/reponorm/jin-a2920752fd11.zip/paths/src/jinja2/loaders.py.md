# Rules for `src/jinja2/loaders.py`

## Rule 036 — `src/jinja2/loaders.py`

- **Rule:**
  ```text
  ModuleLoader.get_module_filename must derive the module filename by appending '.py' to the template key, tying module file naming to the template key scheme.
  ```
- **Applies to:**
  - `src/jinja2/loaders.py`
- **Condition:**
  ```text
  When modifying ModuleLoader.get_module_filename, keep the '.py' suffix appended to the template key.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6fddd0803d050c0fad6865d8.md)

## Rule 076 — `src/jinja2/loaders.py`

- **Rule:**
  ```text
  When modifying FunctionLoader.__init__, preserve the load_func contract: store the supplied callable, which must accept a template name and return either a string or a (source, filename, uptodate) tuple.
  ```
- **Applies to:**
  - `src/jinja2/loaders.py`
- **Condition:**
  ```text
  When changing FunctionLoader initialization or the expected load_func signature/return shape.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e0f2e954b62411e4ff0bc49c.md)
