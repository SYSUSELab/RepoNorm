# Rules for `src/jinja2/__init__.py`

## Rule 047 — `src/jinja2/__init__.py`

- **Rule:**
  ```text
  flake8 ignores F401 in src/jinja2/__init__.py.
  ```
- **Applies to:**
  - `src/jinja2/__init__.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8d5ab39383239e7a489de646.md)
