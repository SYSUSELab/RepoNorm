# Rules for `src/jinja2/meta.py`

## Rule 037 — `src/jinja2/meta.py`

- **Rule:**
  ```text
  When modifying the undeclared-identifier analysis, preserve enter_frame's exclusion: a symbol is recorded as undeclared only when its load action is resolve and the parameter is not present in environment.globals.
  ```
- **Applies to:**
  - `src/jinja2/meta.py`
- **Condition:**
  ```text
  changing how enter_frame decides whether a symbol is undeclared
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-74a369e24bdc588d5c8610a6.md)
