# Rules for `src/jinja2/nodes.py`

## Rule 016 — `src/jinja2/nodes.py`

- **Rule:** When modifying the Block node schema, preserve the field tuple ('name', 'body', 'scoped', 'required'), including the 'required' field added in version 3.0.0, as a compatibility boundary for node consumers.
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** Changing the Block node fields or their compatibility contract.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2ac95c1bd92a0f28092b4632.md)

## Rule 033 — `src/jinja2/nodes.py`

- **Rule:**
  ```text
  When modifying Node.find_all, preserve recursive descendant traversal: it yields descendants matching a node type or tuple of types, including nested matches.
  ```
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:**
  ```text
  Changing Node.find_all or its recursive descendant matching behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-671da297113aaeec584b0edc.md)

## Rule 068 — `src/jinja2/nodes.py`

- **Rule:**
  ```text
  Compare.as_const must fold chained comparisons by applying each operator in sequence, short-circuiting to False as soon as a comparison is false, and converting any exception during folding to Impossible.
  ```
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:**
  ```text
  When modifying Compare.as_const constant folding, preserve sequential operator application, short-circuit to False on a false comparison, and exception-to-Impossible conversion.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-cec6cc240a2b0b93ca2d6199.md)

## Rule 083 — `src/jinja2/nodes.py`

- **Rule:** When modifying the Neg AST node, preserve that it is a UnaryExpr subclass whose operator attribute is "-", defining negation code generation.
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** Changing the Neg node or its operator attribute.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e6cfd4e68dd86b95b3249f3e.md)

## Rule 094 — `src/jinja2/nodes.py`

- **Rule:**
  ```text
  When modifying jinja2.nodes, preserve the extension API protocol: NodeType.__new__ is replaced with a failing staticmethod and the helper is deleted, so creating custom Node subclasses via NodeType is intentionally blocked; extensions must use the provided node classes.
  ```
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** Changing NodeType or the node class creation mechanism.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-fe13d1c5f178fa502dc6b334.md)
