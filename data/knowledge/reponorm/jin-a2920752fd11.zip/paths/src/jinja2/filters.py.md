# Rules for `src/jinja2/filters.py`

## Rule 013 — `src/jinja2/filters.py`

- **Rule:**
  ```text
  When modifying the attribute filter, preserve _prepare_attribute_parts normalization: None yields an empty part list, string attributes are split on '.' with digit segments converted to int, and non-string attributes are wrapped as a single-element list.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:** changing how dotted attribute paths are parsed or normalized in the attribute filter
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-239c923dabe5819d88b8d958.md)

## Rule 019 — `src/jinja2/filters.py`

- **Rule:**
  ```text
  do_wordwrap must wrap each line separately (splitting on existing newlines) because textwrap.wrap ignores existing newlines, and must default wrapstring to environment.newline_sequence.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  When modifying do_wordwrap, preserve per-line wrapping on existing newlines and the default wrapstring of environment.newline_sequence.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-39a44cb080e34d505234e69b.md)

## Rule 022 — `src/jinja2/filters.py`

- **Rule:**
  ```text
  When modifying do_mark_safe, preserve the safety mechanism: the value is wrapped in Markup so autoescape-enabled environments do not escape it.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  Changing do_mark_safe or its Markup wrapping behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4204a58ae69803e6131a4840.md)

## Rule 026 — `src/jinja2/filters.py`

- **Rule:**
  ```text
  When modifying the striptags filter, preserve the __html__ protocol check: do_striptags must consult __html__ on the value and use its result before stripping tags via Markup.striptags.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  changing how do_striptags handles objects implementing __html__
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4ff3e0e458ff4f2de359bfd7.md)

## Rule 030 — `src/jinja2/filters.py`

- **Rule:**
  ```text
  When modifying prepare_map, preserve the filter-argument protocol: accept either an 'attribute' keyword (with optional 'default') or a positional filter name; supplying extra keyword arguments alongside 'attribute' raises FilterArgumentError, and missing a filter argument raises FilterArgumentError('map requires a filter argument').
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  Changing prepare_map or its argument validation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-587eef8eb1c0e364f12cdc76.md)

## Rule 041 — `src/jinja2/filters.py`

- **Rule:**
  ```text
  When modifying the async do_slice variant, preserve the requirement that it awaits auto_to_list(value) before delegating to the sync slicing implementation, so async iterables are materialized before slicing.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  Changing the async do_slice variant or its materialization of async iterables.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-7a8365dd59665f94236ad22a.md)

## Rule 072 — `src/jinja2/filters.py`

- **Rule:**
  ```text
  When modifying do_urlencode, preserve the two-mode quoting behavior: plain strings are quoted directly without quoting '/', while dicts or iterables of pairs are joined as a query string with both keys and values quoted for query-string use.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:** When changing the urlencode filter's handling of strings versus mappings/iterables of pairs.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d564249bc3b92d5fa93c71e9.md)

## Rule 079 — `src/jinja2/filters.py`

- **Rule:**
  ```text
  When modifying the indent filter, preserve do_indent semantics: accept int or string width, preserve Markup types for indention and newline, do not indent blank lines unless blank=True, and only indent the first line when first=True.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  changing do_indent's width handling, blank-line behavior, or first-line-only behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e31417044e7bee0a30a745ef.md)

## Rule 092 — `src/jinja2/filters.py`

- **Rule:** When modifying the HasHTML protocol, preserve its structural typing contract for HTML-like objects as declared inside filters.
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:** changing the HasHTML protocol declaration or its structural typing contract
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f99c9a3895a5e5e42b44841d.md)
