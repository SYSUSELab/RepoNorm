# Rules for `src/jinja2/bccache.py`

## Rule 087 — `src/jinja2/bccache.py`

- **Rule:**
  ```text
  When modifying Bucket.write_bytecode, preserve the on-disk bytecode format: raise TypeError('can't write empty bucket') when code is None, otherwise write bc_magic, pickle the checksum with protocol 2, and marshal the code.
  ```
- **Applies to:**
  - `src/jinja2/bccache.py`
- **Condition:** When changing how bytecode buckets are serialized to disk or how empty buckets are handled.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-edf3d2177ea473b8d38e3611.md)
