# Rules for `src/jinja2/lexer.py`

## Rule 015 — `src/jinja2/lexer.py`

- **Rule:** When modifying TokenStreamIterator, preserve its termination contract: iteration continues until the eof token is reached.
- **Applies to:**
  - `src/jinja2/lexer.py`
- **Condition:** changing TokenStreamIterator's iteration termination logic
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-29d01ca64019d2f93313e7d2.md)

## Rule 024 — `src/jinja2/lexer.py`

- **Rule:**
  ```text
  When modifying TokenStreamIterator.__init__, preserve the stream attribute contract: store the TokenStream on self.stream so token iteration can rely on that attribute.
  ```
- **Applies to:**
  - `src/jinja2/lexer.py`
- **Condition:** When changing TokenStreamIterator initialization or token iteration state.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-47e568c853b408fa8da2e4e8.md)
