# Rules for `src/jinja2/environment.py`

## Rule 064 — `src/jinja2/environment.py`

- **Rule:** When modifying TemplateModule, preserve its module-like API: exported names are attributes and converting the module to a string renders the template contents.
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:** changing TemplateModule's attribute export or string conversion behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-becc99568cb90a46fe10308b.md)

## Rule 077 — `src/jinja2/environment.py`

- **Rule:** When modifying TemplateStream.dump, preserve the API contract: accept a path string or file-like object; when given a path, default encoding to utf-8, open the file in binary mode, and close it afterward.
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:** Changing TemplateStream.dump or its path/file-like handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e12d093bf6ab633c5cedb4a0.md)

## Rule 091 — `src/jinja2/environment.py`

- **Rule:**
  ```text
  When modifying the default template class binding, preserve that Environment.template_class is assigned to Template at import time and remains user-overridable.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:** Changing the default template class binding or its import-time assignment.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f71be49ed05751c3187ccb97.md)
