# Rules for `src/jinja2/compiler.py`

## Rule 002 — `src/jinja2/compiler.py`

- **Rule:**
  ```text
  When modifying the autoescape code generation, preserve visit_MarkSafeIfAutoescape's conditional emission: select Markup when context.eval_ctx.autoescape is true and identity otherwise, so the same expression is marked safe only under autoescape.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  changing how visit_MarkSafeIfAutoescape emits the conditional Markup/identity call
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0403849c7ca683802a61dd4c.md)

## Rule 008 — `src/jinja2/compiler.py`

- **Rule:**
  ```text
  When modifying the compiler's context-reference tracking, preserve push_context_reference's stack operation: it appends a target string to _context_reference_stack.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  changing how push_context_reference records context references
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1c3b442580b28912562d2cdd.md)

## Rule 009 — `src/jinja2/compiler.py`

- **Rule:**
  ```text
  When modifying parameter-definition handling in the compiler, preserve the stack discipline: parameter definitions are maintained as a stack and pop_parameter_definitions removes the most recent set.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** When changing how parameter definitions are pushed or popped during code generation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1e5de810617306a67adabd73.md)

## Rule 020 — `src/jinja2/compiler.py`

- **Rule:**
  ```text
  CodeGenerator.visit_Template must assert no root frame is allowed, emit imports of exported runtime names, detect extends to decide whether inheritance code is needed, reject duplicate block names, and generate root and block render functions with distinct frame handling.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  When modifying CodeGenerator.visit_Template, preserve the no-root-frame assertion, exported-name imports, extends-based inheritance decision, duplicate-block rejection, and distinct root/block frame handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-40b8c29a1a179b521cddecc5.md)

## Rule 021 — `src/jinja2/compiler.py`

- **Rule:**
  ```text
  When modifying CodeGenerator.visit_Block, preserve block codegen guards: skip emitting block-call code when a known extends exists at top level, otherwise guard block output with a parent_template check, and emit a runtime error for required blocks with no override.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** When changing block code generation, extends handling, or required-block override behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-41220cc5199878c3bfd8e2e7.md)

## Rule 034 — `src/jinja2/compiler.py`

- **Rule:**
  ```text
  When modifying CodeGenerator.visit_Dict, preserve the dict emission contract: emit a Python dict literal by visiting each key and value in order and joining with ', ', so dict node items must be visited pairwise to preserve ordering.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  Changing CodeGenerator.visit_Dict or its key/value emission order.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-683dec6d3d66599915b9ced3.md)

## Rule 045 — `src/jinja2/compiler.py`

- **Rule:**
  ```text
  CodeGenerator.visit_ExtensionAttribute must emit a direct subscript into environment.extensions keyed by the node identifier followed by attribute access, coupling extension attribute resolution to the runtime environment.extensions mapping rather than a generic getattr path.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  When modifying CodeGenerator.visit_ExtensionAttribute, keep the direct environment.extensions subscript keyed by the node identifier followed by attribute access.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-860d2f13f70ba54399f18c6c.md)

## Rule 055 — `src/jinja2/compiler.py`

- **Rule:**
  ```text
  When modifying CodeGenerator.visit_Include, preserve include compilation selection: use get_template for constant string templates, select_template for constant tuple/list templates, and get_or_select_template otherwise; ignore_missing wraps lookup in try/except TemplateNotFound, and with_context renders via root_render_func with a new context.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  Changing CodeGenerator.visit_Include or its template lookup and rendering behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a9514d854155a64587cac113.md)

## Rule 060 — `src/jinja2/compiler.py`

- **Rule:**
  ```text
  When modifying CodeGenerator.visit_If, preserve the soft-frame branch isolation: compile the test and all branches using a soft frame so if/elif/else blocks share the same if_frame and branch bodies do not leak symbol changes into the outer frame.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** When changing if/elif/else code generation or frame handling in the compiler.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b29392f15d6d83f91ecd88cc.md)

## Rule 081 — `src/jinja2/compiler.py`

- **Rule:**
  ```text
  When modifying the binop visitor generation, preserve _make_binop's factory contract: it returns a visitor callable for binary expression nodes, parameterized by operator, used to generate CodeGenerator binop visitors.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  changing how _make_binop generates binop visitors
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e4597e1367b51a3591907954.md)

## Rule 089 — `src/jinja2/compiler.py`

- **Rule:**
  ```text
  When modifying the default finalize behavior, preserve the contract that _default_finalize returns str(value) and is the fallback finalize, also applied to constants when the environment defines a finalize function.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  Changing CodeGenerator._default_finalize or the fallback finalize behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f243f34cd6ac05bac008d0d2.md)

## Rule 090 — `src/jinja2/compiler.py`

- **Rule:**
  ```text
  When modifying CodeGenerator.return_buffer_contents, preserve autoescape-aware buffer return: emit Markup(concat(buffer)) when autoescape is active, concat(buffer) otherwise, and a runtime branch on context.eval_ctx.autoescape when autoescape is volatile.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  Changing CodeGenerator.return_buffer_contents or its autoescape-dependent buffer emission.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f2dba4dcd20734e497231e2f.md)
