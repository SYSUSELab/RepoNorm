# Rules for `src/jinja2/runtime.py`

## Rule 006 — `src/jinja2/runtime.py`

- **Rule:** When modifying the Macro runtime wrapper, preserve its documented contract of wrapping a macro function as the runtime wrapper for macro callables.
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:** Changing the Macro runtime wrapper or its wrapping contract.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-13cf307a21c3452c8f547d9a.md)

## Rule 012 — `src/jinja2/runtime.py`

- **Rule:** When modifying LoopContext.previtem, preserve the first-iteration boundary: it returns an Undefined with the message "there is no previous item" during the first iteration and otherwise returns the previous item.
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:** Changing LoopContext.previtem behavior or its first-iteration handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-213b36ce0785aea889c1b966.md)

## Rule 050 — `src/jinja2/runtime.py`

- **Rule:**
  ```text
  When modifying Context.derived, preserve the derivation semantics: create a new independent context via new_context with the same environment/name and get_all(), copy eval_ctx, and copy blocks as lists, so derived contexts share blocks but are otherwise independent.
  ```
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:** When changing Context.derived or how derived contexts share or copy state.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9bdc3119727cabc770f8ef6f.md)

## Rule 056 — `src/jinja2/runtime.py`

- **Rule:**
  ```text
  When modifying LoopContext, preserve the initialization contract: index0 starts at -1, _after, _current, _before, and _last_changed_value use a sentinel missing value, and _length defaults to None.
  ```
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:** Changing LoopContext initialization or its sentinel/default values.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-aa400ab17939edb6e323e777.md)

## Rule 066 — `src/jinja2/runtime.py`

- **Rule:** When modifying LoopContext, preserve the public index invariant: index is defined as index0 + 1, so index is 1-based while index0 remains 0-based.
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:** changing LoopContext.index or index0 definitions
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ca7176c4d7182dd57917f576.md)

## Rule 074 — `src/jinja2/runtime.py`

- **Rule:**
  ```text
  When modifying Macro._invoke, preserve the async/autoescape dispatch contract: dispatch to _async_invoke when the environment is async, otherwise call the function directly and wrap the result in Markup when autoescape is enabled.
  ```
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:**
  ```text
  Changing Macro._invoke or its async/autoescape dispatch.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-db627aa006fcbefb757f187b.md)
