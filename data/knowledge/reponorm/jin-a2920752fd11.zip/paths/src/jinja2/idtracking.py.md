# Rules for `src/jinja2/idtracking.py`

## Rule 027 — `src/jinja2/idtracking.py`

- **Rule:**
  ```text
  When modifying Symbols.__init__, preserve the nesting-level invariant: level is derived from parent.level + 1 when level is None and a parent exists, otherwise 0, and refs, loads, and stores containers are initialized.
  ```
- **Applies to:**
  - `src/jinja2/idtracking.py`
- **Condition:**
  ```text
  Changing Symbols.__init__ or its level derivation and container initialization.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-51f04bf3adc01a9b79b4eb88.md)

## Rule 031 — `src/jinja2/idtracking.py`

- **Rule:**
  ```text
  When modifying the idtracking visitor, preserve visit_For's boundary behavior: the visitor stops at for blocks but still visits the iter expression as part of the outer scope.
  ```
- **Applies to:**
  - `src/jinja2/idtracking.py`
- **Condition:**
  ```text
  changing how FrameSymbolVisitor.visit_For handles for blocks and their iter expressions
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5f57bd57bff7cc886f629cce.md)

## Rule 032 — `src/jinja2/idtracking.py`

- **Rule:**
  ```text
  When modifying the idtracking load-kind vocabulary, preserve the four VAR_LOAD_* constants (param, resolve, alias, undefined) that classify how a variable is loaded.
  ```
- **Applies to:**
  - `src/jinja2/idtracking.py`
- **Condition:**
  ```text
  Changing the VAR_LOAD_* load-kind constants or their classification vocabulary.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-613ee772f91d36f01a3c9718.md)
