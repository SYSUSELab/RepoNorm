# Rules for `src/jinja2`

## Rule 086 — `src/jinja2/**`

- **Rule:** mypy is configured to check the files under src/jinja2.
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-eda4d85facea218b20faab1e.md)
