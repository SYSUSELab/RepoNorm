# Rules for `tests/test_nativetypes.py`

## Rule 018 — `tests/test_nativetypes.py`

- **Rule:** A NativeTemplate constructed without an environment must receive a NativeEnvironment instance so that standalone use still yields native-type rendering behavior.
- **Applies to:**
  - `tests/test_nativetypes.py`
- **Condition:** When adding or modifying tests for standalone NativeTemplate construction without an explicit environment.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-36a334faecb90bdcc28bf0a0.md)

## Rule 061 — `tests/test_nativetypes.py`

- **Rule:**
  ```text
  Rendering a constant dunder expression such as true.__class__|string must produce a string, not a type object, and the result must match either the Python 2 or Python 3 bool repr form.
  ```
- **Applies to:**
  - `tests/test_nativetypes.py`
- **Condition:** When modifying native-type rendering or dunder expression handling, preserve that constant dunder expressions render as strings matching the bool repr form.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-b392331dd0780eb04a9e4e91.md)
