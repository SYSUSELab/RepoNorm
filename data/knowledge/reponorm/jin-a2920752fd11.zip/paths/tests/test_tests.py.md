# Rules for `tests/test_tests.py`

## Rule 044 — `tests/test_tests.py`

- **Rule:** When a name is undefined, an if-guarded test expression ({{ x is f }}) is not evaluated and renders empty; when x is defined, an unknown test name raises TemplateRuntimeError with message "No test named 'f'".
- **Applies to:**
  - `tests/test_tests.py`
- **Condition:** When modifying test-expression evaluation or undefined-name handling, preserve that if-guarded test expressions are not evaluated for undefined names and that unknown test names raise TemplateRuntimeError when the name is defined.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-7eb9bcdceb4917c9341d5fe2.md)
