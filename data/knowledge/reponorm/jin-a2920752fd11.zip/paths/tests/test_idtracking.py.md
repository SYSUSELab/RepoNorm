# Rules for `tests/test_idtracking.py`

## Rule 052 — `tests/test_idtracking.py`

- **Rule:**
  ```text
  symbols_for_node assigns scoped names like l_0_foo and records loads as ('undefined', None), ('resolve', name), or ('param', None) depending on whether the name is assigned, resolved from outer scope, or a loop parameter.
  ```
- **Applies to:**
  - `tests/test_idtracking.py`
- **Condition:** When modifying symbol tracking or id-tracking logic, preserve the scoped-name and load-classification conventions for assigned, resolved, and loop-parameter names.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-a01d94833c9daf14e720afe9.md)
