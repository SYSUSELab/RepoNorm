# Rules for `tests/test_async.py`

## Rule 054 — `tests/test_async.py`

- **Rule:**
  ```text
  The async_func helper must be a coroutine returning 42, used as a minimal awaitable fixture in async tests.
  ```
- **Applies to:**
  - `tests/test_async.py`
- **Condition:** when modifying async test helpers or awaitable fixtures in the async tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-a57a0b61d7d5cfc4b84cf218.md)
