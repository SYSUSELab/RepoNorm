# Rules for `tests/conftest.py`

## Rule 003 — `tests/conftest.py`

- **Rule:** The env fixture in tests/conftest.py must return a fresh Environment() instance, establishing the convention that tests receive a new environment per test.
- **Applies to:**
  - `tests/conftest.py`
- **Condition:** when adding or modifying the env fixture in tests/conftest.py
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-067387bcdab409f527d5580e.md)
