# Rules for `tests/test_api.py`

## Rule 039 — `tests/test_api.py`

- **Rule:**
  ```text
  A finalize callback decorated with pass_environment receives the environment and the value, and can use environment variable delimiters to format output.
  ```
- **Applies to:**
  - `tests/test_api.py`
- **Condition:**
  ```text
  When modifying finalize callback handling or the pass_environment decorator, preserve that the environment and value are passed to finalize.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-778d0a8f3552a46b6ae17a62.md)
