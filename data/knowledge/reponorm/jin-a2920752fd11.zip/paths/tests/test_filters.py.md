# Rules for `tests/test_filters.py`

## Rule 085 — `tests/test_filters.py`

- **Rule:**
  ```text
  wordwrap with width 20 preserves existing newlines in the input and wraps the long line, producing 'Hello!\nThis is Jinja saying\nsomething.' when newline_sequence is set to '\n'.
  ```
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:**
  ```text
  When modifying the wordwrap filter or its newline handling, preserve existing newlines and wrap long lines according to the configured newline_sequence.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-e7d01fd4be23c0e80d9bf774.md)
