# Rule details

- **Rule:** CommandCollection must remain a Group subclass that looks up subcommands first on itself then on each source group in order, without merging source parameters or invoking source callbacks, effectively flattening commands.
- **Applies to:**
  - `src/click/core.py`
- **Condition:** Modifying CommandCollection or its subcommand lookup and source-group handling.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
CommandCollection is a Group subclass whose documented contract is self-first then source-group lookup without merging source parameters or invoking source callbacks, matching the flattening rule.
```

- **Sources:**
  - `src/click/core.py:1918-1971`
