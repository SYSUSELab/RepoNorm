# Rule details

- **Rule:**
  ```text
  The tox environment `update-actions` sets `skip_install = true`.
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
skip_install = true

```

- **Sources:**
  - `pyproject.toml:192`
