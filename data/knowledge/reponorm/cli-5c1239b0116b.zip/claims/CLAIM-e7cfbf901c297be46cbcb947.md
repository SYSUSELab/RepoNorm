# Rule details

- **Rule:**
  ```text
  add_completion_class must register a ShellComplete subclass in _available_shells under the given name, defaulting to the class's name attribute, and return the class so custom shells are registered by name for lookup during completion.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:**
  ```text
  Modifying add_completion_class or the shell registration lookup used during completion.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
add_completion_class defaults name to cls.name, registers the class in _available_shells under that name, and returns the class, matching the registration contract.
```

- **Sources:**
  - `src/click/shell_completion.py:414-431`
