# Rule details

- **Rule:** When modifying ConsoleStream.writelines, it must continue to delegate each line to self.write, so write's encoding/error handling applies uniformly to line batches.
- **Applies to:**
  - `src/click/_winconsole.py`
- **Condition:** When changing ConsoleStream.writelines or Windows console line writing.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
ConsoleStream.writelines iterates over lines and delegates each line to self.write, preserving per-line delegation.
```

- **Sources:**
  - `src/click/_winconsole.py:212-214`
