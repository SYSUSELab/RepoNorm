# Rule details

- **Rule:**
  ```text
  Repo.set_config must store the key/value in self.config and, when verbose is true, echo the assignment to stderr, so verbose mode routes diagnostic output to stderr.
  ```
- **Applies to:**
  - `examples/repo/repo.py`
- **Condition:** When modifying configuration storage or verbose output in the repo example
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
Repo.set_config stores the key/value in self.config and, when verbose is true, echoes the assignment to stderr, matching the rule.
```

- **Sources:**
  - `examples/repo/repo.py:14-17`
