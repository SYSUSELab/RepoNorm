# Rule details

- **Rule:**
  ```text
  Pyright type checking is limited to the src and tests/typing directories via include = ["src", "tests/typing"].
  ```
- **Applies to:**
  - `src/**`
  - `tests/typing/**`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
include = ["src", "tests/typing"]

```

- **Sources:**
  - `pyproject.toml:116`
