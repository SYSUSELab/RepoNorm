# Rule details

- **Rule:**
  ```text
  The testing shim's _getchar must read one char from sys.stdin, optionally echo it to stdout, flush, and return it, wrapped with _pause_echo.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:**
  ```text
  When modifying the testing shim's _getchar or the simulated stdin character-reading path.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The testing shim's _getchar reads one char from sys.stdin, optionally echoes to stdout, flushes, returns it, and is wrapped with _pause_echo.
```

- **Sources:**
  - `src/click/testing.py:363-370`
