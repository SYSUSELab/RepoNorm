# Rule details

- **Rule:** The pre-commit configuration runs the uv-lock hook from the astral-sh/uv-pre-commit repository at revision a621b109bab2e7e832d98c88fd3e83399f4e6657 (frozen: 0.7.12).
- **Applies to:**
  - `**`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
  - repo: https://github.com/astral-sh/uv-pre-commit
    rev: a621b109bab2e7e832d98c88fd3e83399f4e6657  # frozen: 0.7.12
    hooks:
      - id: uv-lock

```

- **Sources:**
  - `.pre-commit-config.yaml:7-10`
