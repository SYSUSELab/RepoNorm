# Rule details

- **Rule:**
  ```text
  Tests for command forwarding must assert that invoking the group with 'dist' produces output 'Count: 1\nCount: 42\n' with no exception.
  ```
- **Applies to:**
  - `tests/test_commands.py`
- **Condition:** When modifying or adding tests that check command forwarding behavior.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_other_command_forward invokes the group with 'dist' and asserts no exception plus output 'Count: 1\nCount: 42\n', matching the command-forwarding rule.
```

- **Sources:**
  - `tests/test_commands.py:24-41`
