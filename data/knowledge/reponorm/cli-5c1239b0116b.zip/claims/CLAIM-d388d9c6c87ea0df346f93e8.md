# Rule details

- **Rule:** Read the Docs builds use Python 3.13.
- **Applies to:**
  - `.readthedocs.yaml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
    python: '3.13'

```

- **Sources:**
  - `.readthedocs.yaml:8`
