# Rule details

- **Rule:**
  ```text
  The tox environment `update-actions` runs the `gha-update` command.
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
commands = [["gha-update"]]

```

- **Sources:**
  - `pyproject.toml:193`
