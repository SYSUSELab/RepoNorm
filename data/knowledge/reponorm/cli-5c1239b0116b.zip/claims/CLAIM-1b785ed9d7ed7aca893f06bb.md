# Rule details

- **Rule:**
  ```text
  Pytest test discovery is restricted to the tests directory via testpaths = ["tests"].
  ```
- **Applies to:**
  - `tests/**`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
testpaths = ["tests"]

```

- **Sources:**
  - `pyproject.toml:82`
