# Rule details

- **Rule:**
  ```text
  The tox environment `update-requirements` is labeled `update`.
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
labels = ["update"]

```

- **Sources:**
  - `pyproject.toml:204`
