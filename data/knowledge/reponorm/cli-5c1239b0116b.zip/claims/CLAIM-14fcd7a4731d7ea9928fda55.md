# Rule details

- **Rule:**
  ```text
  The tox environment `update-actions` uses the `gha-update` dependency group.
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
dependency_groups = ["gha-update"]

```

- **Sources:**
  - `pyproject.toml:191`
