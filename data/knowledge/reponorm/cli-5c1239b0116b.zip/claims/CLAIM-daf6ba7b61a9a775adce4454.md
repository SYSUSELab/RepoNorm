# Rule details

- **Rule:** Tests that exercise Click's ANSI styling and unstyling helpers must assert exact escape-sequence output, including that reset=False omits the trailing reset and that unstyle reverses both color and non-color ANSI codes.
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:**
  ```text
  When adding or modifying tests for click.style or click.unstyle in tests/test_utils.py
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_styling asserts exact ANSI escape sequences for click.style and verifies click.unstyle reverses them, including reset=False omitting the reset and non-color codes.
```

- **Sources:**
  - `tests/test_utils.py:100-102`

### Evidence 2 — current_observation

```text
test_unstyle_other_ansi asserts exact unstyle output for non-color ANSI codes, verifying that unstyle reverses non-color ANSI sequences.
```

- **Sources:**
  - `tests/test_utils.py:106-107`
