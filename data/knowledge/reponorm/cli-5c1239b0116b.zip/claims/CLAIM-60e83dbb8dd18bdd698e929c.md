# Rule details

- **Rule:**
  ```text
  _unpack_args must fill missing items with None, treat nargs -1 as a wildcard consuming all remaining arguments, raise TypeError when two nargs < 0 specifications are present, and reverse the wildcard remainder when the wildcard position is not first.
  ```
- **Applies to:**
  - `src/click/parser.py`
- **Condition:**
  ```text
  When modifying _unpack_args or the argument-unpacking path that maps parsed values onto declared nargs specifications.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
_unpack_args fills missing items with None via _fetch, treats nargs -1 as a wildcard consuming remaining args, raises TypeError for two nargs < 0, and reverses the wildcard remainder when spos is not first, preserving the documented contract.
```

- **Sources:**
  - `src/click/parser.py:52-109`
