# Rule details

- **Rule:**
  ```text
  When modifying command classes, preserve _BaseCommand as a deprecated compatibility shim (deprecated since 8.2, scheduled for removal in Click 9.0) that directs users to Command; do not remove it before the 9.0 boundary.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:** Changing or removing deprecated command base classes.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
_BaseCommand is documented as deprecated since 8.2 and scheduled for removal in Click 9.0, directing users to Command.
```

- **Sources:**
  - `src/click/core.py:1453-1457`
