# Rule details

- **Rule:**
  ```text
  ComplexCLI must subclass click.Group and its list_commands must scan cmd_folder for files ending in '.py' and starting with 'cmd_', strip the prefix and suffix to derive command names, and sort them.
  ```
- **Applies to:**
  - `examples/complex/complex/cli.py`
- **Condition:** When modifying command discovery or group behavior in the complex example
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
ComplexCLI.list_commands scans cmd_folder for files ending in '.py' and starting with 'cmd_', strips the prefix and suffix, and sorts the resulting names.
```

- **Sources:**
  - `examples/complex/complex/cli.py:32-38`
