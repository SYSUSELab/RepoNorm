# Rule details

- **Rule:**
  ```text
  Py_buffer must be defined as a ctypes Structure with fields buf, obj, len, itemsize, readonly, ndim, format, shape, strides, suboffsets, and internal, matching the CPython buffer protocol layout for Windows console handling.
  ```
- **Applies to:**
  - `src/click/_winconsole.py`
- **Condition:**
  ```text
  When modifying Py_buffer or Windows console FFI structures that must match the CPython buffer protocol layout.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
Py_buffer is defined as a ctypes Structure with fields buf, obj, len, itemsize, readonly, ndim, format, shape, strides, suboffsets, and internal, matching the CPython buffer protocol layout.
```

- **Sources:**
  - `src/click/_winconsole.py:87-100`
