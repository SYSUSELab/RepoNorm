# Rule details

- **Rule:**
  ```text
  _split_opt must treat a leading alphanumeric as no prefix, a doubled leading character as a two-character prefix, and otherwise a single-character prefix, defining how option prefixes are separated from names.
  ```
- **Applies to:**
  - `src/click/parser.py`
- **Condition:**
  ```text
  when modifying _split_opt or the option prefix separation logic
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
_split_opt returns no prefix for a leading alphanumeric, a two-character prefix for a doubled leading character, and a single-character prefix otherwise, preserving the three-way prefix rule.
```

- **Sources:**
  - `src/click/parser.py:112-118`
