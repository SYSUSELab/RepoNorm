# Rule details

- **Rule:** When modifying the argument decorator, preserve that it defaults cls to Argument when not provided and forwards all other keyword arguments unchanged to the parameter class constructor, establishing the extension contract for custom argument classes.
- **Applies to:**
  - `src/click/decorators.py`
- **Condition:** Changing the argument decorator's cls default or keyword forwarding.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The argument decorator in src/click/decorators.py defaults cls to Argument when None and forwards remaining keyword arguments unchanged to the parameter class constructor, preserving the extension contract.
```

- **Sources:**
  - `src/click/decorators.py:324-349`
