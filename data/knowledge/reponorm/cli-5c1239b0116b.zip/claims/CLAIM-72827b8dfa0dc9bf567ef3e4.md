# Rule details

- **Rule:**
  ```text
  The project requires Python >=3.10.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
requires-python = ">=3.10"

```

- **Sources:**
  - `pyproject.toml:16`
