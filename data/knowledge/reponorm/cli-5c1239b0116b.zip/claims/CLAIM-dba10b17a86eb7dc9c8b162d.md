# Rule details

- **Rule:**
  ```text
  The pre-commit-ci/lite-action step runs even when the job is cancelled, as gated by `if: ${{ !cancelled() }}`.
  ```
- **Applies to:**
  - `**`
- **Condition:** workflow predicate: ${{ !cancelled() }}
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
      - uses: pre-commit-ci/lite-action@5d6cc0eb514c891a40562a58a8e71576c5c7fb43 # v1.1.0
        if: ${{ !cancelled() }}

```

- **Sources:**
  - `.github/workflows/pre-commit.yaml:24-25`
