# Rule details

- **Rule:** The repo example's clone command derives DEST from the last path component of SRC when DEST is omitted, falling back to '.' if that component is empty.
- **Applies to:**
  - `examples/repo/repo.py`
- **Condition:** When modifying the clone command or its DEST derivation logic in the repo example.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The clone command derives DEST from the last path component of SRC when DEST is omitted, falling back to '.'.
```

- **Sources:**
  - `examples/repo/repo.py:72-85`
