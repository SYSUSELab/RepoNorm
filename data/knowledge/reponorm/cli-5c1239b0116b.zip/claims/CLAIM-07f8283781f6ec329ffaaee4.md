# Rule details

- **Rule:**
  ```text
  When LazyFile is represented, __repr__ must return repr of the underlying file when opened, otherwise a synthetic "<unopened file 'name' mode>" string using format_filename, so repr is stable before the file is opened.
  ```
- **Applies to:**
  - `src/click/utils.py`
- **Condition:** Modifying LazyFile representation or its pre-open state handling.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
LazyFile.__repr__ returns repr of the underlying file when opened and otherwise builds the synthetic unopened-file string using format_filename.
```

- **Sources:**
  - `src/click/utils.py:146-149`
