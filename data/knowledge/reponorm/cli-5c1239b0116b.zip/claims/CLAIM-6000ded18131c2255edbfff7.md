# Rule details

- **Rule:**
  ```text
  A range type's __repr__ must include the range description and append ' clamped' when self.clamp is set.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When modifying _NumberRangeBase.__repr__ or range representation, preserve inclusion of the range description and the ' clamped' suffix when clamp is set.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
_NumberRangeBase.__repr__ includes the range description via self._describe_range() and appends ' clamped' when self.clamp is set.
```

- **Sources:**
  - `src/click/types.py:571-573`
