# Rule details

- **Rule:** Coverage measurement is configured to cover the click package and the tests directory.
- **Applies to:**
  - `click/**`
  - `tests/**`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
source = ["click", "tests"]

```

- **Sources:**
  - `pyproject.toml:89`
