# Rule details

- **Rule:**
  ```text
  The tox env_run_base environment installs the tests dependency group.
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
dependency_groups = ["tests"]

```

- **Sources:**
  - `pyproject.toml:159`
