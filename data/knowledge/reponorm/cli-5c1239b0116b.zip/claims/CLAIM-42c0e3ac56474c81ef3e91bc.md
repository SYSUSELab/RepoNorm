# Rule details

- **Rule:**
  ```text
  _normalize_opt must apply ctx.token_normalize_func only to the option name portion after _split_opt, preserving the prefix; when ctx is None or no normalize func is set, the option must be returned unchanged.
  ```
- **Applies to:**
  - `src/click/parser.py`
- **Condition:**
  ```text
  Modifying _normalize_opt or option-name normalization in the parser.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
_normalize_opt returns opt unchanged when ctx is None or no token_normalize_func, and otherwise applies the normalize func only to the name portion after _split_opt, preserving the prefix.
```

- **Sources:**
  - `src/click/parser.py:121-125`
