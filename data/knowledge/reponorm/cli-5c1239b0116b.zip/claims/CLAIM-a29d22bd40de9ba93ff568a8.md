# Rule details

- **Rule:** The colors example must demonstrate click.style usage with fg, bold, reverse, blink, and underline, and document that ANSI styles are automatically stripped when output is piped to a file.
- **Applies to:**
  - `examples/colors/colors.py`
- **Condition:** when modifying or extending the colors example's style demonstration
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The colors cli uses click.style with fg, bold, reverse, blink, and underline and documents automatic ANSI stripping when output is piped.
```

- **Sources:**
  - `examples/colors/colors.py:25-39`
