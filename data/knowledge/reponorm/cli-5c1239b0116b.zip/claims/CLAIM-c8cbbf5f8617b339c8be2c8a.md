# Rule details

- **Rule:**
  ```text
  parser.py must remain a stdlib-optparse-derived module with features removed and intentional divergence from optparse to avoid gettext and 2.x/3.x error-message differences, using the _flag_needs_value sentinel to signal a flag passed without a value.
  ```
- **Applies to:**
  - `src/click/parser.py`
- **Condition:** Modifying parser.py or its optparse-derived parsing behavior and sentinel handling.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
parser.py retains its optparse-derived structure with intentional divergence (no gettext, no 2.x/3.x error-message differences) and defines the _flag_needs_value sentinel for flags passed without a value.
```

- **Sources:**
  - `src/click/parser.py`
