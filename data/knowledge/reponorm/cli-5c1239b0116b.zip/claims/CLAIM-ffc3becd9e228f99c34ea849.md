# Rule details

- **Rule:** Eager boolean flag callbacks must abort the context when the value is false, terminating parsing rather than continuing with a false flag.
- **Applies to:**
  - `src/click/decorators.py`
- **Condition:**
  ```text
  when modifying eager boolean flag callbacks such as confirmation_option.callback
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
confirmation_option.callback aborts the context when the flag value is false, preserving the eager boolean flag abort contract.
```

- **Sources:**
  - `src/click/decorators.py:389-391`
