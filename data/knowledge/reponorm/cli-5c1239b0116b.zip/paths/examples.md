# Rules for `examples`

## Rule 157 — `examples/**`

- **Rule:** Ruff excludes the examples/ directory from its checks via extend-exclude.
- **Applies to:**
  - `examples/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f34d92e6cf63e41b32bc1389.md)
