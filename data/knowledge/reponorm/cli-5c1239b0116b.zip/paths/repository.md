# Rules for `repository root`

## Rule 043 — `**/*.css`

- **Rule:** CSS, HTML, JS, JSON, JSX, SCSS, TS, TSX, YAML, and YML files use an indent size of 2.
- **Applies to:**
  - `**/*.css`
  - `**/*.html`
  - `**/*.js`
  - `**/*.json`
  - `**/*.jsx`
  - `**/*.scss`
  - `**/*.ts`
  - `**/*.tsx`
  - `**/*.yaml`
  - `**/*.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3aa1ff1bf121289d4dcaca48.md)

## Rule 044 — `**`

- **Rule:** The pre-commit configuration runs the uv-lock hook from the astral-sh/uv-pre-commit repository at revision a621b109bab2e7e832d98c88fd3e83399f4e6657 (frozen: 0.7.12).
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3b0c6e9cfaa03c5e85ae6706.md)

## Rule 077 — `**/*.py`

- **Rule:**
  ```text
  The project requires Python >=3.10.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-72827b8dfa0dc9bf567ef3e4.md)

## Rule 085 — `**`

- **Rule:**
  ```text
  The pre-commit workflow runs pre-commit via `uv run --locked --group pre-commit pre-commit run --show-diff-on-failure --color=always --all-files`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-834d0594f6dc5ee4dcb02700.md)

## Rule 086 — `**/*.py`

- **Rule:** Ruff linting ignores rule UP038 to keep isinstance tuple syntax.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-84156b62b7efe5c3933315e2.md)

## Rule 104 — `**`

- **Rule:**
  ```text
  The typing job runs `uv run --locked tox run -e typing`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a90be6e33b7a71725199b83e.md)

## Rule 119 — `**/*.py`

- **Rule:** Ruff linting selects the rule sets B (flake8-bugbear), E (pycodestyle error), F (pyflakes), I (isort), UP (pyupgrade), and W (pycodestyle warning).
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-c1a5a3a9be86c2c898fffaf2.md)

## Rule 142 — `**`

- **Rule:**
  ```text
  The pre-commit-ci/lite-action step runs even when the job is cancelled, as gated by `if: ${{ !cancelled() }}`.
  ```
- **Applies to:**
  - `**`
- **Condition:** workflow predicate: ${{ !cancelled() }}
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-dba10b17a86eb7dc9c8b162d.md)

## Rule 145 — `**/*.py`

- **Rule:** Ruff's isort lint rule is configured with force-single-line = true, so imports are enforced to be on single lines.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-dbfbf93282d8251beba1eabd.md)
