# Rules for `src/click/exceptions.py`

## Rule 048 — `src/click/exceptions.py`

- **Rule:** Abort must remain a RuntimeError subclass used as an internal signalling exception to abort Click processing.
- **Applies to:**
  - `src/click/exceptions.py`
- **Condition:** When modifying Abort or exception handling that catches it as an internal abort signal.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-414c19e4be10dead63efb74e.md)

## Rule 051 — `src/click/exceptions.py`

- **Rule:**
  ```text
  MissingParameter.format_message must build the message from param_hint (or param.get_error_hint), append the type's missing message, and map param_type names to translated "Missing argument"/"Missing option"/"Missing parameter" prefixes.
  ```
- **Applies to:**
  - `src/click/exceptions.py`
- **Condition:**
  ```text
  Modifying MissingParameter.format_message or the missing-parameter error message format.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-482ab33439ced9154b632d83.md)

## Rule 092 — `src/click/exceptions.py`

- **Rule:**
  ```text
  Exit must remain a RuntimeError subclass with __slots__ = ("exit_code",), carrying the exit status as an attribute on the exception rather than via a separate mechanism.
  ```
- **Applies to:**
  - `src/click/exceptions.py`
- **Condition:** Modifying the Exit exception class or how exit status is carried.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8d5443c448f25c1aca904fe2.md)

## Rule 118 — `src/click/exceptions.py`

- **Rule:**
  ```text
  FileError.format_message must use the translated template 'Could not open file {filename!r}: {message}' with ui_filename and message, defining the user-facing error format for file open failures.
  ```
- **Applies to:**
  - `src/click/exceptions.py`
- **Condition:**
  ```text
  When modifying FileError.format_message or the user-facing message for file open failures.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c03ff8c484588109fd8043d2.md)
