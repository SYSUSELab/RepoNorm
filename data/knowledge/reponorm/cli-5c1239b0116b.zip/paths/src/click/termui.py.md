# Rules for `src/click/termui.py`

## Rule 068 — `src/click/termui.py`

- **Rule:**
  ```text
  unstyle must remove ANSI styling via strip_ansi, and echo already strips styling automatically when necessary.
  ```
- **Applies to:**
  - `src/click/termui.py`
- **Condition:**
  ```text
  When modifying unstyle or echo styling behavior, keep unstyle implemented via strip_ansi and preserve echo's automatic styling strip when necessary.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-622da652c451ca859cea80ae.md)
