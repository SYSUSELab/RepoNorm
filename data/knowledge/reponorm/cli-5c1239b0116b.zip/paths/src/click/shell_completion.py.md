# Rules for `src/click/shell_completion.py`

## Rule 022 — `src/click/shell_completion.py`

- **Rule:**
  ```text
  ZshComplete.get_completion_args must read COMP_WORDS and COMP_CWORD from the environment, slice args between the program name and current word, and treat a missing current word as an empty incomplete string.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:**
  ```text
  Modifying ZshComplete.get_completion_args or the environment-based completion argument parsing.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1758b8ac740f59e00b4c22aa.md)

## Rule 097 — `src/click/shell_completion.py`

- **Rule:**
  ```text
  ShellComplete.source_vars must return exactly complete_func, complete_var, and prog_name, defining the variable contract available to source_template formatting.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:**
  ```text
  When modifying ShellComplete.source_vars or the completion source template that consumes these variables.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-955d97bc611a5532ee98f575.md)

## Rule 109 — `src/click/shell_completion.py`

- **Rule:**
  ```text
  CompletionItem must use __slots__ and expose arbitrary metadata passed as kwargs via item.attr, returning None for attributes that were not passed, so custom type completions paired with custom shell support can rely on this access pattern.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:** Modifying CompletionItem or the attribute access used by custom type completions and custom shell support.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b72ee28bb7c998929ff0ca39.md)

## Rule 122 — `src/click/shell_completion.py`

- **Rule:**
  ```text
  get_completion_class must look up the shell name in the _available_shells registry and return None for unregistered names, so new shells are added by registering them in that registry rather than by branching in the lookup function.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:** Adding or modifying shell completion support or the shell-name lookup path.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c4d7622e150a88693aebf71e.md)

## Rule 151 — `src/click/shell_completion.py`

- **Rule:**
  ```text
  When modifying shell completion, preserve the contract that _is_incomplete_argument treats an argument as still accepting values when nargs is -1, when its value did not originate from the command line, or when a multi-value argument has fewer values than nargs; the value is read from ctx.params, which may be None when expose_value is False.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:** Changing how shell completion decides whether an argument still accepts values.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e1eee9761bf8b75d8ea4d64f.md)

## Rule 153 — `src/click/shell_completion.py`

- **Rule:**
  ```text
  add_completion_class must register a ShellComplete subclass in _available_shells under the given name, defaulting to the class's name attribute, and return the class so custom shells are registered by name for lookup during completion.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:**
  ```text
  Modifying add_completion_class or the shell registration lookup used during completion.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e7cfbf901c297be46cbcb947.md)
