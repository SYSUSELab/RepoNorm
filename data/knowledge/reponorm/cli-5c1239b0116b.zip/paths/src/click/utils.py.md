# Rules for `src/click/utils.py`

## Rule 007 — `src/click/utils.py`

- **Rule:**
  ```text
  When LazyFile is represented, __repr__ must return repr of the underlying file when opened, otherwise a synthetic "<unopened file 'name' mode>" string using format_filename, so repr is stable before the file is opened.
  ```
- **Applies to:**
  - `src/click/utils.py`
- **Condition:** Modifying LazyFile representation or its pre-open state handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-07f8283781f6ec329ffaaee4.md)

## Rule 083 — `src/click/utils.py`

- **Rule:**
  ```text
  When modifying Windows argument expansion, preserve that _expand_args simulates Unix shell expansion on Windows; since 8.1 invalid glob patterns are treated as empty expansions rather than raising, and unmatched args are kept as-is.
  ```
- **Applies to:**
  - `src/click/utils.py`
- **Condition:** Changing Windows argument expansion or glob handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-81eade044616fc064a2a6883.md)
