# Rules for `src/click/_compat.py`

## Rule 015 — `src/click/_compat.py`

- **Rule:**
  ```text
  The stream wrapper constructor must store force_readable and force_writable flags alongside the wrapped stream, establishing the internal state used to override stream capability detection.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  When modifying the stream wrapper constructor or capability-override logic that reads force_readable/force_writable.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0fb11479e93129c68d450a3e.md)

## Rule 024 — `src/click/_compat.py`

- **Rule:**
  ```text
  _is_binary_reader must determine binary-ness by calling stream.read(0) and checking for bytes, swallowing any exception and returning the caller-supplied default, so detection tolerates streams that raise on zero-length reads.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  When modifying _is_binary_reader or stream capability detection that must tolerate streams raising on zero-length reads.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-19250a4bee3b097540e5d0dc.md)

## Rule 031 — `src/click/_compat.py`

- **Rule:**
  ```text
  When modifying get_binary_stdin, it must continue to raise RuntimeError when no binary reader can be determined for sys.stdin, making binary stdin availability a hard precondition rather than returning None.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  When changing get_binary_stdin or binary stdin detection.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-22986b8bb9fcdcd7cb9b3e65.md)

## Rule 032 — `src/click/_compat.py`

- **Rule:**
  ```text
  _AtomicFile.__getattr__ must delegate attribute access to the wrapped file object, making the wrapper transparent for arbitrary attributes.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  Modifying _AtomicFile.__getattr__ or the wrapper's attribute delegation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-23f76373bee29ac46482a549.md)

## Rule 069 — `src/click/_compat.py`

- **Rule:**
  ```text
  When modifying _AtomicFile.__repr__, it must continue to delegate to repr(self._f), exposing the underlying file's representation.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  When changing _AtomicFile.__repr__ or wrapper representation behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6736e9231639eea61377059d.md)

## Rule 091 — `src/click/_compat.py`

- **Rule:**
  ```text
  When modifying _compat.isatty, it must continue to return stream.isatty() but catch any Exception and return False, so TTY detection never raises.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  When changing _compat.isatty or TTY detection behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8ce6b74c79613b3c6ea0d793.md)

## Rule 156 — `src/click/_compat.py`

- **Rule:**
  ```text
  When converting or wrapping text streams, _force_correct_text_stream must return a compatible text stream as-is unless encoding is None and the stream is misconfigured, fall back to the original text stream when no binary reader can be found, and default errors to "replace" when errors is None.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:** Modifying text-stream compatibility handling or encoding/errors defaults.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-eb1eb48d319104088e67a0e5.md)
