# Rules for `src/click/types.py`

## Rule 001 — `src/click/types.py`

- **Rule:**
  ```text
  Choice.get_invalid_choice_message must build the invalid-choice error via ngettext with singular/plural forms and normalized mapping values so the message stays localized and plural-aware.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:** When changing Choice error reporting or choice normalization, keep the invalid-choice message localized through ngettext with plural handling and normalized mapping values.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-00d6429191b255be6b98fad1.md)

## Rule 025 — `src/click/types.py`

- **Rule:**
  ```text
  File.to_info_dict must add 'mode' and 'encoding' to the base info dict, defining the serialization contract for file parameters.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  Modifying File.to_info_dict or the serialized info dict for file parameters.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1a609469c6e2cc90984c7ebe.md)

## Rule 027 — `src/click/types.py`

- **Rule:**
  ```text
  When modifying Choice._normalized_mapping, it must remain an internal/unsupported surface: callers should use normalize_choice instead, and the wrapper's documented role is a simple wrapper around normalize_choice.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When changing Choice._normalized_mapping or its callers.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1f2dc689b06bb3dce755f015.md)

## Rule 033 — `src/click/types.py`

- **Rule:**
  ```text
  UnprocessedParamType.__repr__ must return the literal string 'UNPROCESSED'.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When modifying UnprocessedParamType or its repr, keep __repr__ returning the literal 'UNPROCESSED'.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-291eb946e178ce537032e572.md)

## Rule 041 — `src/click/types.py`

- **Rule:** The arity property of a composite ParamType must equal len(self.types), so composite arity is the number of contained types.
- **Applies to:**
  - `src/click/types.py`
- **Condition:** When modifying Tuple.arity or composite ParamType arity, keep arity equal to the number of contained types.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-38fc5f02064d2c18575276ca.md)

## Rule 045 — `src/click/types.py`

- **Rule:**
  ```text
  When modifying IntParamType, integer parameter behavior must continue to be derived from the shared _NumberParamTypeBase numeric base (name "integer", _number_class int) rather than implemented independently.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:** When changing IntParamType or integer parameter behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3bb1ce02553cd14265e02045.md)

## Rule 046 — `src/click/types.py`

- **Rule:**
  ```text
  When modifying the Choice type, preserve that Choice accepts any iterable of choices (converted to a tuple and iterated once), supports non-str choices since 8.2.0, allows normalization overrides via normalize_choice, and always returns a value that is one of the originally passed choices.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:** Changing Choice construction, normalization, or conversion behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3defc0d434245941d78ae986.md)

## Rule 050 — `src/click/types.py`

- **Rule:** When the datetime type is used without explicit formats, it must default to the three accepted input shapes: date-only, ISO datetime with T separator, and space-separated datetime.
- **Applies to:**
  - `src/click/types.py`
- **Condition:** Modifying DateTime format defaults or accepted input shapes.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4582b1d759040ee7d8ce1a20.md)

## Rule 057 — `src/click/types.py`

- **Rule:**
  ```text
  Choice.get_metavar must build a '|'-joined choices string, deduplicating type names for options without show_choices, and wrap it in curly braces for required arguments or square brackets otherwise.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  when modifying Choice.get_metavar or the metavar formatting for choice parameters
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-51fc7aca58e5c157d2ad4f94.md)

## Rule 062 — `src/click/types.py`

- **Rule:**
  ```text
  A range type's __repr__ must include the range description and append ' clamped' when self.clamp is set.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When modifying _NumberRangeBase.__repr__ or range representation, preserve inclusion of the range description and the ' clamped' suffix when clamp is set.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6000ded18131c2255edbfff7.md)

## Rule 075 — `src/click/types.py`

- **Rule:**
  ```text
  When modifying FloatRange._clamp, it must continue to raise RuntimeError('Clamping is not supported for open bounds.') for open bounds, explicitly leaving open float range clamping to a user callback.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When changing FloatRange._clamp or float range clamping behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-700ee4e10eb6ff883fc40cba.md)

## Rule 084 — `src/click/types.py`

- **Rule:** Numeric conversion must catch ValueError from the number class and route it through self.fail with a localized message naming the value and number type, so invalid numeric input produces a parameter failure rather than a raw ValueError.
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When modifying _NumberParamTypeBase.convert or numeric parsing, preserve catching ValueError and routing through self.fail with a localized message naming the value and number type.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8341b95d190c8b4ef52d9e80.md)

## Rule 093 — `src/click/types.py`

- **Rule:**
  ```text
  to_info_dict for a type with formats must extend the superclass info dict by adding a 'formats' key, defining the info-dict extension contract for format-bearing types.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When modifying to_info_dict for a format-bearing type or adding a new type that must expose formats in its info dict.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9245f321b6ff932999317806.md)

## Rule 098 — `src/click/types.py`

- **Rule:**
  ```text
  Choice.__init__ must eagerly convert the choices iterable to a tuple and store case_sensitive, so later membership checks operate on a stable sequence rather than a one-shot iterable.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When modifying Choice.__init__ or choice storage, preserve eager tuple conversion of choices and storage of case_sensitive for stable membership checks.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-99345ff620d3be42da72f072.md)

## Rule 154 — `src/click/types.py`

- **Rule:**
  ```text
  Choice.to_info_dict must extend the base info dict with 'choices' and 'case_sensitive', establishing the serialization contract for choice parameters.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  when modifying Choice.to_info_dict or the serialized info dict for choice parameters
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e8836ce2e614f14184a64231.md)
