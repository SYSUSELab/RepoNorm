# Rules for `src/click/formatting.py`

## Rule 079 — `src/click/formatting.py`

- **Rule:**
  ```text
  write_text must re-indent and rewrap text using the formatter width with preserve_paragraphs=True, then append a newline, so paragraph structure is preserved in help output.
  ```
- **Applies to:**
  - `src/click/formatting.py`
- **Condition:**
  ```text
  Modifying HelpFormatter.write_text or help text wrapping behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-75c2884041416bf872840adf.md)

## Rule 094 — `src/click/formatting.py`

- **Rule:**
  ```text
  write_heading must write the heading indented to the current indent level followed by a colon and newline, defining the exact heading format in help output.
  ```
- **Applies to:**
  - `src/click/formatting.py`
- **Condition:**
  ```text
  Modifying HelpFormatter.write_heading or the heading format in help output.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9283e4021318383eb9bd09a0.md)

## Rule 113 — `src/click/formatting.py`

- **Rule:**
  ```text
  When modifying measure_table, it must continue to compute per-column maximum term_len widths and return them in column order, defining the table-width measurement used by formatting.
  ```
- **Applies to:**
  - `src/click/formatting.py`
- **Condition:**
  ```text
  When changing measure_table or table-width measurement used by formatting.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b97b28ffd004d015ca9abf65.md)

## Rule 135 — `src/click/formatting.py`

- **Rule:**
  ```text
  HelpFormatter.write_paragraph must only emit a newline when the buffer is non-empty, preventing a leading blank line in formatted output.
  ```
- **Applies to:**
  - `src/click/formatting.py`
- **Condition:**
  ```text
  when modifying HelpFormatter.write_paragraph or the paragraph formatting logic
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d56eabad827dea71a6c760d0.md)

## Rule 139 — `src/click/formatting.py`

- **Rule:**
  ```text
  HelpFormatter width must default to terminal columns capped by max_width (default 80) minus 2, with a minimum of 50, unless FORCED_WIDTH is set.
  ```
- **Applies to:**
  - `src/click/formatting.py`
- **Condition:**
  ```text
  Modifying HelpFormatter.__init__ or the help formatter width computation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-da63e23367f36c55d2b6ab73.md)

## Rule 159 — `src/click/formatting.py`

- **Rule:** HelpFormatter must write into memory and remain exposed for developers to write custom outputs, with width defaulting to terminal width clamped to a maximum of 78.
- **Applies to:**
  - `src/click/formatting.py`
- **Condition:** Modifying HelpFormatter or its width defaulting and output-writing behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f86f938436b892a661aa758a.md)
