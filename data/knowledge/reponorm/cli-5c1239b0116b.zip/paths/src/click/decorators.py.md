# Rules for `src/click/decorators.py`

## Rule 011 — `src/click/decorators.py`

- **Rule:**
  ```text
  The pass-context decorator wrapper must call f(get_current_context(), *args, **kwargs), injecting the context as the first positional argument before any user arguments.
  ```
- **Applies to:**
  - `src/click/decorators.py`
- **Condition:** When modifying the pass-context decorator wrapper or any context-injection decorator that must preserve argument ordering.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0a96e29cb780c9f131878f90.md)

## Rule 054 — `src/click/decorators.py`

- **Rule:**
  ```text
  confirmation_option must default param_decls to ('--yes',) and set is_flag=True, callback, expose_value=False, prompt 'Do you want to continue?', and help text, so the confirmation flag is not exposed to the command callback.
  ```
- **Applies to:**
  - `src/click/decorators.py`
- **Condition:**
  ```text
  When modifying confirmation_option or its option defaults, preserve the ('--yes',) param_decls, is_flag=True, callback, expose_value=False, prompt, and help text so the flag stays hidden from the callback.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4f6862ab1c9f7a272bd1761a.md)

## Rule 088 — `src/click/decorators.py`

- **Rule:** The option decorator must forward all keyword arguments unchanged to the parameter class constructor except cls, and must default cls to Option when not supplied, preserving this as the documented extension point for custom option classes.
- **Applies to:**
  - `src/click/decorators.py`
- **Condition:** When modifying the option decorator or adding custom option classes that rely on keyword forwarding and the default cls.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-873b6526cbe1880e1420012f.md)

## Rule 106 — `src/click/decorators.py`

- **Rule:** When modifying the argument decorator, preserve that it defaults cls to Argument when not provided and forwards all other keyword arguments unchanged to the parameter class constructor, establishing the extension contract for custom argument classes.
- **Applies to:**
  - `src/click/decorators.py`
- **Condition:** Changing the argument decorator's cls default or keyword forwarding.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-aebef0e06f64f1fda09c2010.md)

## Rule 134 — `src/click/decorators.py`

- **Rule:** decorators.py must document and support the @command/@group call variants: no-call direct decorator, positional name with positional or keyword cls, name omitted with cls as keyword-only, and optional string name with no cls.
- **Applies to:**
  - `src/click/decorators.py`
- **Condition:** Modifying the @command/@group decorator signatures or their documented call variants.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d4e74bc09025f1f47f3603b7.md)

## Rule 163 — `src/click/decorators.py`

- **Rule:** Eager boolean flag callbacks must abort the context when the value is false, terminating parsing rather than continuing with a false flag.
- **Applies to:**
  - `src/click/decorators.py`
- **Condition:**
  ```text
  when modifying eager boolean flag callbacks such as confirmation_option.callback
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ffc3becd9e228f99c34ea849.md)
