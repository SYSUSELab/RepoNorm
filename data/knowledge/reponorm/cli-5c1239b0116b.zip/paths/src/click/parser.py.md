# Rules for `src/click/parser.py`

## Rule 049 — `src/click/parser.py`

- **Rule:**
  ```text
  _normalize_opt must apply ctx.token_normalize_func only to the option name portion after _split_opt, preserving the prefix; when ctx is None or no normalize func is set, the option must be returned unchanged.
  ```
- **Applies to:**
  - `src/click/parser.py`
- **Condition:**
  ```text
  Modifying _normalize_opt or option-name normalization in the parser.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-42c0e3ac56474c81ef3e91bc.md)

## Rule 067 — `src/click/parser.py`

- **Rule:**
  ```text
  _unpack_args must fill missing items with None, treat nargs -1 as a wildcard consuming all remaining arguments, raise TypeError when two nargs < 0 specifications are present, and reverse the wildcard remainder when the wildcard position is not first.
  ```
- **Applies to:**
  - `src/click/parser.py`
- **Condition:**
  ```text
  When modifying _unpack_args or the argument-unpacking path that maps parsed values onto declared nargs specifications.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-60e83dbb8dd18bdd698e929c.md)

## Rule 073 — `src/click/parser.py`

- **Rule:**
  ```text
  When modifying _OptionParser.parse_args, UsageError must be suppressed only when a context exists and resilient_parsing is enabled; otherwise it must be re-raised, and the return value must include values, leftover args, and an order list that records repeated arguments multiple times.
  ```
- **Applies to:**
  - `src/click/parser.py`
- **Condition:**
  ```text
  When changing _OptionParser.parse_args or its error handling and return contract.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6ceda3d2059f15178789aa8a.md)

## Rule 078 — `src/click/parser.py`

- **Rule:**
  ```text
  _Option.__init__ must split each option string via _split_opt, raise ValueError for an empty prefix, classify single-character prefix+value as short options and everything else as long options, and default action to 'store'.
  ```
- **Applies to:**
  - `src/click/parser.py`
- **Condition:**
  ```text
  When modifying _Option.__init__ or the option-string parsing path that classifies short versus long options.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-7418f4a332c5a3c862941557.md)

## Rule 123 — `src/click/parser.py`

- **Rule:**
  ```text
  parser.py must remain a stdlib-optparse-derived module with features removed and intentional divergence from optparse to avoid gettext and 2.x/3.x error-message differences, using the _flag_needs_value sentinel to signal a flag passed without a value.
  ```
- **Applies to:**
  - `src/click/parser.py`
- **Condition:** Modifying parser.py or its optparse-derived parsing behavior and sentinel handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c8cbbf5f8617b339c8be2c8a.md)

## Rule 147 — `src/click/parser.py`

- **Rule:**
  ```text
  _split_opt must treat a leading alphanumeric as no prefix, a doubled leading character as a two-character prefix, and otherwise a single-character prefix, defining how option prefixes are separated from names.
  ```
- **Applies to:**
  - `src/click/parser.py`
- **Condition:**
  ```text
  when modifying _split_opt or the option prefix separation logic
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-dfab43cae3acd166efad9afe.md)
