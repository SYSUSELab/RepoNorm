# Rules for `src/click/_winconsole.py`

## Rule 112 — `src/click/_winconsole.py`

- **Rule:**
  ```text
  Py_buffer must be defined as a ctypes Structure with fields buf, obj, len, itemsize, readonly, ndim, format, shape, strides, suboffsets, and internal, matching the CPython buffer protocol layout for Windows console handling.
  ```
- **Applies to:**
  - `src/click/_winconsole.py`
- **Condition:**
  ```text
  When modifying Py_buffer or Windows console FFI structures that must match the CPython buffer protocol layout.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b9547dccfd4168af6b7cd402.md)

## Rule 126 — `src/click/_winconsole.py`

- **Rule:** When modifying ConsoleStream.writelines, it must continue to delegate each line to self.write, so write's encoding/error handling applies uniformly to line batches.
- **Applies to:**
  - `src/click/_winconsole.py`
- **Condition:** When changing ConsoleStream.writelines or Windows console line writing.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-cb3e03cb7f07405b816cccc2.md)

## Rule 150 — `src/click/_winconsole.py`

- **Rule:**
  ```text
  When modifying Windows console output, preserve that _WindowsConsole write flushes before writing bytes and swallows flush exceptions so byte writes proceed even if flushing fails, while str input is routed to the text stream instead.
  ```
- **Applies to:**
  - `src/click/_winconsole.py`
- **Condition:** Changing Windows console stream write behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e1a61473720927cb0d13351b.md)

## Rule 160 — `src/click/_winconsole.py`

- **Rule:**
  ```text
  _is_console must return False when the stream lacks fileno or raises OSError/io.UnsupportedOperation, and otherwise probe GetConsoleMode, guarding Windows console detection against non-file streams.
  ```
- **Applies to:**
  - `src/click/_winconsole.py`
- **Condition:**
  ```text
  when modifying _is_console or Windows console detection logic
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-fa4e1678a5b0a1258e16dc22.md)
