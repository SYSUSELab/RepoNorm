# Rules for `src/click/core.py`

## Rule 014 — `src/click/core.py`

- **Rule:**
  ```text
  When modifying Parameter, its documented compatibility boundaries must be preserved: deprecated parameters cannot be required (ValueError otherwise), duplicate parameter names warn since 8.2, process_value validates required/bounded nargs and invokes callbacks since 8.0, autocompletion is renamed to shell_complete, and empty env vars are ignored since 7.1.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:** When changing Parameter or its documented compatibility behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0f594f230677e8826eeca692.md)

## Rule 038 — `src/click/core.py`

- **Rule:**
  ```text
  When modifying Group.shell_complete, subcommand completion must remain additive: visible subcommands contribute CompletionItems (using each command's short help) and the parent implementation's completions are then extended, not replaced.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When changing Group.shell_complete or the completion behavior of a group command.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2eb8c532eb504e7a58e1d0f3.md)

## Rule 082 — `src/click/core.py`

- **Rule:**
  ```text
  When modifying command classes, preserve _BaseCommand as a deprecated compatibility shim (deprecated since 8.2, scheduled for removal in Click 9.0) that directs users to Command; do not remove it before the 9.0 boundary.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:** Changing or removing deprecated command base classes.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-7ff21a0fafda4c89fb6b432d.md)

## Rule 095 — `src/click/core.py`

- **Rule:**
  ```text
  When modifying command resolution, preserve that resolve_command applies ctx.token_normalize_func to the command name when the initial lookup fails, and when the command is still missing and parsing is not resilient, it re-parses args if the first token looks like an option before failing with a no-such-command error.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:** Changing command lookup or fallback resolution behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-92c9d39f3687d6514913bef6.md)

## Rule 116 — `src/click/core.py`

- **Rule:**
  ```text
  When a parameter's envvar value is read, split it via type.split_envvar_value only when nargs != 1; single-value parameters must bypass splitting so the raw envvar string is used directly.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  Modifying Parameter.value_from_envvar or envvar value handling for parameters with nargs.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-be35f6065ff452bc23cfe70c.md)

## Rule 117 — `src/click/core.py`

- **Rule:**
  ```text
  Parameter.value_is_missing must treat None as missing, and must treat an empty tuple as missing only when nargs != 1 or multiple is set; other empty/None-like values must not be reported as missing.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When modifying Parameter.value_is_missing or the parameter value-handling path that decides whether a supplied value counts as absent.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-bf27bbaa7b895fd9310e7fb2.md)

## Rule 130 — `src/click/core.py`

- **Rule:**
  ```text
  Argument must remain a positional parameter that is required by default, can have infinite nargs, and reports param_type_name 'argument', distinguishing argument defaults from option defaults.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  Modifying Argument or the defaults and param_type_name that distinguish arguments from options.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d13c7f62497c5f316c668486.md)

## Rule 161 — `src/click/core.py`

- **Rule:** CommandCollection must remain a Group subclass that looks up subcommands first on itself then on each source group in order, without merging source parameters or invoking source callbacks, effectively flattening commands.
- **Applies to:**
  - `src/click/core.py`
- **Condition:** Modifying CommandCollection or its subcommand lookup and source-group handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-fccbe986abaf237a6e993818.md)
