# Rules for `examples/completion/completion.py`

## Rule 004 — `examples/completion/completion.py`

- **Rule:**
  ```text
  The completion example's ls command must define a --dir option typed as click.Path(file_okay=False) to constrain completion to directories.
  ```
- **Applies to:**
  - `examples/completion/completion.py`
- **Condition:** when modifying or extending the ls command in the completion example
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-04ac9b0c81b1fa9a3f5767de.md)
