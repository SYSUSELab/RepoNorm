# Rules for `examples/complex/complex/cli.py`

## Rule 018 — `examples/complex/complex/cli.py`

- **Rule:**
  ```text
  ComplexCLI must subclass click.Group and its list_commands must scan cmd_folder for files ending in '.py' and starting with 'cmd_', strip the prefix and suffix to derive command names, and sort them.
  ```
- **Applies to:**
  - `examples/complex/complex/cli.py`
- **Condition:** When modifying command discovery or group behavior in the complex example
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-114a15bb8f560f7f38daeb87.md)

## Rule 053 — `examples/complex/complex/cli.py`

- **Rule:** The complex example's Environment.log method must format msg with args when present and write to stderr via click.echo, and Environment.vlog must log to stderr only when self.verbose is truthy.
- **Applies to:**
  - `examples/complex/complex/cli.py`
- **Condition:** When modifying logging behavior in the complex example
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4b77d3c548463fe5b10a3041.md)

## Rule 059 — `examples/complex/complex/cli.py`

- **Rule:**
  ```text
  The complex example's dynamic command loader must import complex.commands.cmd_<name> and return its cli attribute, and must silently return None on ImportError so unknown commands fall through to normal error handling.
  ```
- **Applies to:**
  - `examples/complex/complex/cli.py`
- **Condition:**
  ```text
  when modifying or extending the get_command method that resolves subcommands dynamically
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-553b1e22beed754d71cd8ea1.md)

## Rule 089 — `examples/complex/complex/cli.py`

- **Rule:** The complex example's Environment class must be used as the pass-object context for its CLI, with verbose initialized to False and home initialized to os.getcwd().
- **Applies to:**
  - `examples/complex/complex/cli.py`
- **Condition:** when modifying the Environment class or its initialization in the complex example
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-87cce84e33289283e3a49c7f.md)
