# Rules for `examples/imagepipe/imagepipe.py`

## Rule 099 — `examples/imagepipe/imagepipe.py`

- **Rule:**
  ```text
  The imagepipe flip callback maps both lr/leftright and tb/topbottom/upsidedown/ud to Image.FLIP_LEFT_RIGHT, so the top-bottom aliases do not actually select a top-bottom flip in this example.
  ```
- **Applies to:**
  - `examples/imagepipe/imagepipe.py`
- **Condition:** When modifying the flip callback or its alias mapping in the imagepipe example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9d81a042806730ff73812b47.md)

## Rule 141 — `examples/imagepipe/imagepipe.py`

- **Rule:** The imagepipe resize command yields images after thumbnail resizing, preserving aspect ratio and using width/height or original dimensions.
- **Applies to:**
  - `examples/imagepipe/imagepipe.py`
- **Condition:** When modifying the resize command or its dimension handling in the imagepipe example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-dba101122d32682d45482a7b.md)
