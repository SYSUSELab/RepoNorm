# Rules for `examples/inout/inout.py`

## Rule 036 — `examples/inout/inout.py`

- **Rule:** The inout example uses click.File("rb") with nargs=-1 for input and click.File("wb") for output, documents the "-" convention for stdin/stdout, and copies in 1024-byte chunks with flush.
- **Applies to:**
  - `examples/inout/inout.py`
- **Condition:** When modifying the inout example's file handling or copy loop.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2da15c85f0e071cf698af737.md)
