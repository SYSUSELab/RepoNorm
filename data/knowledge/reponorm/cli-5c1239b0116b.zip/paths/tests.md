# Rules for `tests`

## Rule 006 — `CHANGES.rst`

- **Rule:** The flit sdist build includes docs/, tests/, CHANGES.rst, and uv.lock in the source distribution.
- **Applies to:**
  - `CHANGES.rst`
  - `docs/**`
  - `tests/**`
  - `uv.lock`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-05aa953bcf90e341895f2c76.md)

## Rule 026 — `tests/**`

- **Rule:**
  ```text
  Pytest test discovery is restricted to the tests directory via testpaths = ["tests"].
  ```
- **Applies to:**
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1b785ed9d7ed7aca893f06bb.md)

## Rule 162 — `click/**`

- **Rule:** Coverage measurement is configured to cover the click package and the tests directory.
- **Applies to:**
  - `click/**`
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ff0a8671cfc5d5c80dfc78d3.md)
