# Rules for `.github/workflows/publish.yaml`

## Rule 034 — `.github/workflows/publish.yaml`

- **Rule:** The publish-pypi job publishes packages from the artifact/ directory using pypa/gh-action-pypi-publish.
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-29862d795941e7b171ce185e.md)

## Rule 052 — `.github/workflows/publish.yaml`

- **Rule:** The build job sets up Python using the version specified in pyproject.toml.
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4b70ecb4b44e26050561cd81.md)

## Rule 065 — `.github/workflows/publish.yaml`

- **Rule:** The build job uploads the ./dist directory as an artifact.
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-603f43d4973244b59d8d5eb3.md)

## Rule 090 — `.github/workflows/publish.yaml`

- **Rule:**
  ```text
  The build job runs `uv build` to build the package.
  ```
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-89e4160b7cc2ac1bfc673096.md)

## Rule 101 — `.github/workflows/publish.yaml`

- **Rule:**
  ```text
  The create-release job runs `gh release create --draft` against the repository using the ref name and artifact/* files.
  ```
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a292a81201c517f81dd23fcb.md)
