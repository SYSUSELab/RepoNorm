# Rules for `.github/workflows/lock.yaml`

## Rule 148 — `.github/workflows/lock.yaml`

- **Rule:** The lock job uses the dessant/lock-threads action (v5.0.1) with issue-inactive-days, pr-inactive-days, and discussion-inactive-days all set to 14.
- **Applies to:**
  - `.github/workflows/lock.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e01673eb971b093ef1a613bf.md)
