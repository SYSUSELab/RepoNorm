# Rules for `tests/test_shell_completion.py`

## Rule 047 — `tests/test_shell_completion.py`

- **Rule:** Shell completion tests for nested Group/Command structures must assert word-by-word completion: empty word lists subcommands, '-' lists options including --help, and a fully consumed command yields no completions.
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:** When modifying or adding shell completion tests for nested groups and commands.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-401a6a9857d9be848c88fa5c.md)

## Rule 072 — `tests/test_shell_completion.py`

- **Rule:**
  ```text
  Shell completion tests must use the _patch_for_completion fixture to monkeypatch BashComplete._check_version to always return True, isolating completion tests from the installed bash version.
  ```
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:** When modifying or adding shell completion tests that depend on bash version.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-697336c3da806347c975498c.md)

## Rule 080 — `tests/test_shell_completion.py`

- **Rule:**
  ```text
  Tests for Click's shell completion registration must verify that an unregistered shell name is absent from _available_shells, that add_completion_class returns the class, and that after registration the shell appears in _available_shells mapped to that class.
  ```
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:**
  ```text
  When adding or modifying tests for add_completion_class or _available_shells in tests/test_shell_completion.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-7cb93d40b3b2d3337ef4016a.md)

## Rule 129 — `tests/test_shell_completion.py`

- **Rule:**
  ```text
  Shell completion tests for count options must assert that completing an empty word yields no completions, while completing '-' yields ['--help'].
  ```
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:** When modifying or adding shell completion tests for count options.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-d0c5ebaf841f6403acb34538.md)

## Rule 144 — `tests/test_shell_completion.py`

- **Rule:**
  ```text
  Tests for add_completion_class must assert that using it as a decorator registers the new shell immediately in click.shell_completion._available_shells and that the registered value is the class itself.
  ```
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:**
  ```text
  when adding or modifying tests for add_completion_class decorator registration
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-dbf23097e9d89ed1dfe9a13e.md)
