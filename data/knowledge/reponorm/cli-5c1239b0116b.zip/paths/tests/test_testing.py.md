# Rules for `tests/test_testing.py`

## Rule 058 — `tests/test_testing.py`

- **Rule:** Tests for Click's testing runner must verify that getchar input is handled, that multiple prompt-enabled options are prompted sequentially, and that an Abort during a hidden prompt produces the expected interrupted output (with platform-specific skips where behavior differs).
- **Applies to:**
  - `tests/test_testing.py`
  - `tests/test_utils.py`
- **Condition:** When adding or modifying tests for the Click testing runner's input handling, sequential prompting, or prompt-abort behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-545660df4b2ab5781a3d64e0.md)
