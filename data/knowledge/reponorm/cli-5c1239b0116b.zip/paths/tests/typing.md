# Rules for `tests/typing`

## Rule 017 — `src/**`

- **Rule:**
  ```text
  Pyright type checking is limited to the src and tests/typing directories via include = ["src", "tests/typing"].
  ```
- **Applies to:**
  - `src/**`
  - `tests/typing/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-10fdc422ff55589e1c7c75ca.md)

## Rule 133 — `src/**`

- **Rule:** mypy type-checks the files under src and tests/typing.
- **Applies to:**
  - `src/**`
  - `tests/typing/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-d3c79538002c059eaca6f2fa.md)
