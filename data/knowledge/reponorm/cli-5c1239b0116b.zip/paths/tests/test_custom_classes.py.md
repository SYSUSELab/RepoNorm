# Rules for `tests/test_custom_classes.py`

## Rule 149 — `tests/test_custom_classes.py`

- **Rule:** Tests for custom context invoke type must assert that a command invoked from a custom context receives a new context with the same type, and that invoking the first command produces no exception.
- **Applies to:**
  - `tests/test_custom_classes.py`
- **Condition:** When modifying or adding tests that check custom context invoke type behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-e054f207d50d3d7f5960b75d.md)
