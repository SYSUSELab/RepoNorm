# Rules for `tests/test_defaults.py`

## Rule 107 — `tests/test_defaults.py`

- **Rule:**
  ```text
  Tests that verify default value rendering must assert the exact bracket formatting convention, e.g. a default value is displayed as "FOO:[42.0]".
  ```
- **Applies to:**
  - `tests/test_defaults.py`
- **Condition:** When modifying or adding tests that check how default values are rendered in command output.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-b0d687cb01670d2f73fed35d.md)
