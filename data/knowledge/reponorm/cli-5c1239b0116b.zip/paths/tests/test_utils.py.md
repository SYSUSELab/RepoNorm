# Rules for `tests/test_utils.py`

## Rule 023 — `tests/test_utils.py`

- **Rule:**
  ```text
  Tests for Click's program name detection must verify that _detect_program_name returns the basename for plain paths, python -m module for __main__.py, python -m package.module for module files, and strips ./ prefixes.
  ```
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:**
  ```text
  When adding or modifying tests for _detect_program_name in tests/test_utils.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-187db22e0085cc37d12dc7e3.md)

## Rule 035 — `tests/test_utils.py`

- **Rule:**
  ```text
  MockMain test helper must use __slots__ = '__package__' to constrain the mock to only that attribute for main-module detection tests.
  ```
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:** When modifying or adding test helpers for main-module detection.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-2d7ec76f83b5017df4031dc9.md)

## Rule 058 — `tests/test_testing.py`

- **Rule:** Tests for Click's testing runner must verify that getchar input is handled, that multiple prompt-enabled options are prompted sequentially, and that an Abort during a hidden prompt produces the expected interrupted output (with platform-specific skips where behavior differs).
- **Applies to:**
  - `tests/test_testing.py`
  - `tests/test_utils.py`
- **Condition:** When adding or modifying tests for the Click testing runner's input handling, sequential prompting, or prompt-abort behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-545660df4b2ab5781a3d64e0.md)

## Rule 140 — `tests/test_utils.py`

- **Rule:** Tests that exercise Click's ANSI styling and unstyling helpers must assert exact escape-sequence output, including that reset=False omits the trailing reset and that unstyle reverses both color and non-color ANSI codes.
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:**
  ```text
  When adding or modifying tests for click.style or click.unstyle in tests/test_utils.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-daf6ba7b61a9a775adce4454.md)
