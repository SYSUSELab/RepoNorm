# Rules for `tests/test_info_dict.py`

## Rule 076 — `tests/test_info_dict.py`

- **Rule:**
  ```text
  Tests that verify the info_dict shape must preserve the exact metadata fields including is_flag True, flag_value True, and default False for HELP_OPTION, and default 1 for NUMBER_OPTION.
  ```
- **Applies to:**
  - `tests/test_info_dict.py`
- **Condition:**
  ```text
  When modifying or adding tests for parameter info_dict metadata.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-726725cd24a7e7692895275a.md)
