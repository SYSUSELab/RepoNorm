# Rules for `tests/test_types.py`

## Rule 114 — `tests/test_types.py`

- **Rule:** Tests that depend on symlink support must use a helper that probes by creating a temporary symlink and returns False on OSError, so tests can skip when symlinks are unavailable.
- **Applies to:**
  - `tests/test_types.py`
- **Condition:** When modifying or adding tests that require symlink support.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-bc4738e92e0678df1b135045.md)

## Rule 124 — `tests/test_types.py`

- **Rule:** Tests for path surrogates must be skipped when the OS/FS lacks non-UTF-8 filename support and must assert BadParameter messages for non-existent, file, directory, unreadable, unwritable, and non-executable paths using surrogate filenames.
- **Applies to:**
  - `tests/test_types.py`
- **Condition:** When modifying or adding tests that check path validation with surrogate filenames.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-cb136c1d564c1bd5465a9a21.md)
