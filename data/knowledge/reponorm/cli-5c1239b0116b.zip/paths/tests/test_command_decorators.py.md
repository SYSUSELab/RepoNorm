# Rules for `tests/test_command_decorators.py`

## Rule 008 — `tests/test_command_decorators.py`

- **Rule:** Tests that verify positional argument ordering must assert that Argument objects are registered in order with names 'a' and 'b' and that invoking with '1 2' yields output '1 2'.
- **Applies to:**
  - `tests/test_command_decorators.py`
- **Condition:** When modifying or adding tests that check positional argument ordering.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-09655316ac7389d605a68186.md)
