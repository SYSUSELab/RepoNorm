# Rules for `tests/test_arguments.py`

## Rule 060 — `tests/test_arguments.py`

- **Rule:** Tests for implicit optional arguments must assert that invoking with no arguments exits 0 and outputs 'test', establishing that an argument without required=True is implicitly optional.
- **Applies to:**
  - `tests/test_arguments.py`
- **Condition:** When modifying or adding tests that check implicit optional argument behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-5545b7880a22664c4d6ec769.md)
