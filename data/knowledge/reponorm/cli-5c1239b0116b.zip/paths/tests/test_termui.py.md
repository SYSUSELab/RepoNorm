# Rules for `tests/test_termui.py`

## Rule 110 — `tests/test_termui.py`

- **Rule:**
  ```text
  Tests for progress bar formatting must assert exact format_progress_line() output for a given width, including zero-length progress, omitted percent/position variants, and full completion.
  ```
- **Applies to:**
  - `tests/test_termui.py`
- **Condition:** When modifying or adding tests that check progress bar line formatting.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-b7e2c801f126f7dc9718588f.md)
