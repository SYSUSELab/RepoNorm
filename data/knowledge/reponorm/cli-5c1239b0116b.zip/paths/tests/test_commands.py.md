# Rules for `tests/test_commands.py`

## Rule 020 — `tests/test_commands.py`

- **Rule:**
  ```text
  Command.parse_args must populate ctx._opt_prefixes with the set {"-", "--", "+", "!"}, establishing the recognized option prefix characters.
  ```
- **Applies to:**
  - `tests/test_commands.py`
- **Condition:**
  ```text
  When modifying or adding tests that check Command.parse_args option prefix collection.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-1500638ae6ead8718957f423.md)

## Rule 029 — `tests/test_commands.py`

- **Rule:**
  ```text
  Tests for command forwarding must assert that invoking the group with 'dist' produces output 'Count: 1\nCount: 42\n' with no exception.
  ```
- **Applies to:**
  - `tests/test_commands.py`
- **Condition:** When modifying or adding tests that check command forwarding behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-1fd93cf68832eeed081cc701.md)
