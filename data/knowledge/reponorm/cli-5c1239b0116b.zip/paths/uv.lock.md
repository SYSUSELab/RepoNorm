# Rules for `uv.lock`

## Rule 006 — `CHANGES.rst`

- **Rule:** The flit sdist build includes docs/, tests/, CHANGES.rst, and uv.lock in the source distribution.
- **Applies to:**
  - `CHANGES.rst`
  - `docs/**`
  - `tests/**`
  - `uv.lock`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-05aa953bcf90e341895f2c76.md)
