# Rules for `docs/_build`

## Rule 155 — `docs/_build/**`

- **Rule:**
  ```text
  The flit sdist build excludes docs/_build/ from the source distribution.
  ```
- **Applies to:**
  - `docs/_build/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-e980d9a345204f0f7047f46b.md)
