# Rules for `docs/conf.py`

## Rule 137 — `docs/conf.py`

- **Rule:**
  ```text
  Sphinx autodoc configuration in docs/conf.py must keep autodoc_member_order='bysource', autodoc_typehints='description', and autodoc_preserve_defaults=True so generated documentation reflects source declaration order and preserved default values.
  ```
- **Applies to:**
  - `docs/conf.py`
- **Condition:** When modifying Sphinx autodoc settings in docs/conf.py, preserve the source-order member ordering, description-style type hints, and default-value preservation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-d725f209a53e5ef79b780e29.md)
