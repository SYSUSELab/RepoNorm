# Rules for `click`

## Rule 162 — `click/**`

- **Rule:** Coverage measurement is configured to cover the click package and the tests directory.
- **Applies to:**
  - `click/**`
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ff0a8671cfc5d5c80dfc78d3.md)
