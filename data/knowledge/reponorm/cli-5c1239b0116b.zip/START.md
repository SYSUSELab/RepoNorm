# Repository knowledge

Apply rules within their stated scope and when their conditions hold, respecting
exceptions. `required`, `recommended`, and `observed` have different strength:
an observed convention does not by itself prohibit a change requested by the task.
`reference_only` is context, not a default action.
Evidence locations identify sources, not the rule's scope.
Commands in rules do not authorize unrelated changes or external side effects.
Use relevant rules alongside the task and repository code; keep edits focused.

## Find rules

Path links and the [full catalog](catalog.md) are alternative routes. Search or
open relevant files directly; open claim details when evidence or a conflict matters.
Paths are navigation anchors, not a replacement for each rule's complete scope.

- `repository root`: [Read rules](paths/repository.md)
- `.github/workflows/lock.yaml`: [Read rules](paths/.github/workflows/lock.yaml.md)
- `.github/workflows/publish.yaml`: [Read rules](paths/.github/workflows/publish.yaml.md)
- `.pre-commit-config.yaml`: [Read rules](paths/.pre-commit-config.yaml.md)
- `.readthedocs.yaml`: [Read rules](paths/.readthedocs.yaml.md)
- `CHANGES.rst`: [Read rules](paths/CHANGES.rst.md)
- `click`: [Read rules](paths/click.md)
- `docs`: [Read rules](paths/docs.md)
- `docs/_build`: [Read rules](paths/docs/_build.md)
- `docs/conf.py`: [Read rules](paths/docs/conf.py.md)
- `examples`: [Read rules](paths/examples.md)
- `examples/colors/colors.py`: [Read rules](paths/examples/colors/colors.py.md)
- `examples/completion/completion.py`: [Read rules](paths/examples/completion/completion.py.md)
- `examples/complex/complex/cli.py`: [Read rules](paths/examples/complex/complex/cli.py.md)
- `examples/imagepipe/imagepipe.py`: [Read rules](paths/examples/imagepipe/imagepipe.py.md)
- `examples/inout/inout.py`: [Read rules](paths/examples/inout/inout.py.md)
- `examples/repo/repo.py`: [Read rules](paths/examples/repo/repo.py.md)
- `examples/validation/validation.py`: [Read rules](paths/examples/validation/validation.py.md)
- `pyproject.toml`: [Read rules](paths/pyproject.toml.md)
- `src`: [Read rules](paths/src.md)
- `src/click/_compat.py`: [Read rules](paths/src/click/_compat.py.md)
- `src/click/_winconsole.py`: [Read rules](paths/src/click/_winconsole.py.md)
- `src/click/core.py`: [Read rules](paths/src/click/core.py.md)
- `src/click/decorators.py`: [Read rules](paths/src/click/decorators.py.md)
- `src/click/exceptions.py`: [Read rules](paths/src/click/exceptions.py.md)
- `src/click/formatting.py`: [Read rules](paths/src/click/formatting.py.md)
- `src/click/parser.py`: [Read rules](paths/src/click/parser.py.md)
- `src/click/shell_completion.py`: [Read rules](paths/src/click/shell_completion.py.md)
- `src/click/termui.py`: [Read rules](paths/src/click/termui.py.md)
- `src/click/testing.py`: [Read rules](paths/src/click/testing.py.md)
- `src/click/types.py`: [Read rules](paths/src/click/types.py.md)
- `src/click/utils.py`: [Read rules](paths/src/click/utils.py.md)
- `tests`: [Read rules](paths/tests.md)
- `tests/test_arguments.py`: [Read rules](paths/tests/test_arguments.py.md)
- `tests/test_command_decorators.py`: [Read rules](paths/tests/test_command_decorators.py.md)
- `tests/test_commands.py`: [Read rules](paths/tests/test_commands.py.md)
- `tests/test_custom_classes.py`: [Read rules](paths/tests/test_custom_classes.py.md)
- `tests/test_defaults.py`: [Read rules](paths/tests/test_defaults.py.md)
- `tests/test_info_dict.py`: [Read rules](paths/tests/test_info_dict.py.md)
- `tests/test_shell_completion.py`: [Read rules](paths/tests/test_shell_completion.py.md)
- `tests/test_termui.py`: [Read rules](paths/tests/test_termui.py.md)
- `tests/test_testing.py`: [Read rules](paths/tests/test_testing.py.md)
- `tests/test_types.py`: [Read rules](paths/tests/test_types.py.md)
- `tests/test_utils.py`: [Read rules](paths/tests/test_utils.py.md)
- `tests/typing`: [Read rules](paths/tests/typing.md)
- `uv.lock`: [Read rules](paths/uv.lock.md)
