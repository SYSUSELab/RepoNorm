# Full rule catalog

## Rule 134 — `src/click/decorators.py`

- **Rule:** decorators.py must document and support the @command/@group call variants: no-call direct decorator, positional name with positional or keyword cls, name omitted with cls as keyword-only, and optional string name with no cls.
- **Applies to:**
  - `src/click/decorators.py`
- **Condition:** Modifying the @command/@group decorator signatures or their documented call variants.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d4e74bc09025f1f47f3603b7.md)

## Rule 135 — `src/click/formatting.py`

- **Rule:**
  ```text
  HelpFormatter.write_paragraph must only emit a newline when the buffer is non-empty, preventing a leading blank line in formatted output.
  ```
- **Applies to:**
  - `src/click/formatting.py`
- **Condition:**
  ```text
  when modifying HelpFormatter.write_paragraph or the paragraph formatting logic
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d56eabad827dea71a6c760d0.md)

## Rule 136 — `pyproject.toml`

- **Rule:**
  ```text
  The tox env_run_base environment uses .pkg as its wheel build environment.
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d697379c439a75f32439e739.md)

## Rule 137 — `docs/conf.py`

- **Rule:**
  ```text
  Sphinx autodoc configuration in docs/conf.py must keep autodoc_member_order='bysource', autodoc_typehints='description', and autodoc_preserve_defaults=True so generated documentation reflects source declaration order and preserved default values.
  ```
- **Applies to:**
  - `docs/conf.py`
- **Condition:** When modifying Sphinx autodoc settings in docs/conf.py, preserve the source-order member ordering, description-style type hints, and default-value preservation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d725f209a53e5ef79b780e29.md)

## Rule 138 — `pyproject.toml`

- **Rule:**
  ```text
  The tox env_run_base environment builds a wheel package.
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d7bec6a488ee1f198b40269b.md)

## Rule 139 — `src/click/formatting.py`

- **Rule:**
  ```text
  HelpFormatter width must default to terminal columns capped by max_width (default 80) minus 2, with a minimum of 50, unless FORCED_WIDTH is set.
  ```
- **Applies to:**
  - `src/click/formatting.py`
- **Condition:**
  ```text
  Modifying HelpFormatter.__init__ or the help formatter width computation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-da63e23367f36c55d2b6ab73.md)

## Rule 140 — `tests/test_utils.py`

- **Rule:** Tests that exercise Click's ANSI styling and unstyling helpers must assert exact escape-sequence output, including that reset=False omits the trailing reset and that unstyle reverses both color and non-color ANSI codes.
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:**
  ```text
  When adding or modifying tests for click.style or click.unstyle in tests/test_utils.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-daf6ba7b61a9a775adce4454.md)

## Rule 141 — `examples/imagepipe/imagepipe.py`

- **Rule:** The imagepipe resize command yields images after thumbnail resizing, preserving aspect ratio and using width/height or original dimensions.
- **Applies to:**
  - `examples/imagepipe/imagepipe.py`
- **Condition:** When modifying the resize command or its dimension handling in the imagepipe example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-dba101122d32682d45482a7b.md)

## Rule 142 — `**`

- **Rule:**
  ```text
  The pre-commit-ci/lite-action step runs even when the job is cancelled, as gated by `if: ${{ !cancelled() }}`.
  ```
- **Applies to:**
  - `**`
- **Condition:** workflow predicate: ${{ !cancelled() }}
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-dba10b17a86eb7dc9c8b162d.md)

## Rule 143 — `pyproject.toml`

- **Rule:**
  ```text
  The tox environment `update-requirements` sets `skip_install = true`.
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-dbd9d284c4f077a222e96653.md)

## Rule 144 — `tests/test_shell_completion.py`

- **Rule:**
  ```text
  Tests for add_completion_class must assert that using it as a decorator registers the new shell immediately in click.shell_completion._available_shells and that the registered value is the class itself.
  ```
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:**
  ```text
  when adding or modifying tests for add_completion_class decorator registration
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-dbf23097e9d89ed1dfe9a13e.md)

## Rule 145 — `**/*.py`

- **Rule:** Ruff's isort lint rule is configured with force-single-line = true, so imports are enforced to be on single lines.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-dbfbf93282d8251beba1eabd.md)

## Rule 146 — `examples/validation/validation.py`

- **Rule:**
  ```text
  The validation example must demonstrate three distinct validation mechanisms in one command: a callback for --count, a custom ParamType (URL) for --url, and manual BadParameter raising with param_hint for --foo.
  ```
- **Applies to:**
  - `examples/validation/validation.py`
- **Condition:** when modifying or extending the validation example command
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-dd54b671f8912172957aff65.md)

## Rule 147 — `src/click/parser.py`

- **Rule:**
  ```text
  _split_opt must treat a leading alphanumeric as no prefix, a doubled leading character as a two-character prefix, and otherwise a single-character prefix, defining how option prefixes are separated from names.
  ```
- **Applies to:**
  - `src/click/parser.py`
- **Condition:**
  ```text
  when modifying _split_opt or the option prefix separation logic
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-dfab43cae3acd166efad9afe.md)

## Rule 148 — `.github/workflows/lock.yaml`

- **Rule:** The lock job uses the dessant/lock-threads action (v5.0.1) with issue-inactive-days, pr-inactive-days, and discussion-inactive-days all set to 14.
- **Applies to:**
  - `.github/workflows/lock.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e01673eb971b093ef1a613bf.md)

## Rule 149 — `tests/test_custom_classes.py`

- **Rule:** Tests for custom context invoke type must assert that a command invoked from a custom context receives a new context with the same type, and that invoking the first command produces no exception.
- **Applies to:**
  - `tests/test_custom_classes.py`
- **Condition:** When modifying or adding tests that check custom context invoke type behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e054f207d50d3d7f5960b75d.md)

## Rule 150 — `src/click/_winconsole.py`

- **Rule:**
  ```text
  When modifying Windows console output, preserve that _WindowsConsole write flushes before writing bytes and swallows flush exceptions so byte writes proceed even if flushing fails, while str input is routed to the text stream instead.
  ```
- **Applies to:**
  - `src/click/_winconsole.py`
- **Condition:** Changing Windows console stream write behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e1a61473720927cb0d13351b.md)
