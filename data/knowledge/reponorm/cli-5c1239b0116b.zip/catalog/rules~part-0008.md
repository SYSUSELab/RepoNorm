# Full rule catalog

## Rule 116 — `src/click/core.py`

- **Rule:**
  ```text
  When a parameter's envvar value is read, split it via type.split_envvar_value only when nargs != 1; single-value parameters must bypass splitting so the raw envvar string is used directly.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  Modifying Parameter.value_from_envvar or envvar value handling for parameters with nargs.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-be35f6065ff452bc23cfe70c.md)

## Rule 117 — `src/click/core.py`

- **Rule:**
  ```text
  Parameter.value_is_missing must treat None as missing, and must treat an empty tuple as missing only when nargs != 1 or multiple is set; other empty/None-like values must not be reported as missing.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When modifying Parameter.value_is_missing or the parameter value-handling path that decides whether a supplied value counts as absent.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-bf27bbaa7b895fd9310e7fb2.md)

## Rule 118 — `src/click/exceptions.py`

- **Rule:**
  ```text
  FileError.format_message must use the translated template 'Could not open file {filename!r}: {message}' with ui_filename and message, defining the user-facing error format for file open failures.
  ```
- **Applies to:**
  - `src/click/exceptions.py`
- **Condition:**
  ```text
  When modifying FileError.format_message or the user-facing message for file open failures.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c03ff8c484588109fd8043d2.md)

## Rule 119 — `**/*.py`

- **Rule:** Ruff linting selects the rule sets B (flake8-bugbear), E (pycodestyle error), F (pyflakes), I (isort), UP (pyupgrade), and W (pycodestyle warning).
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-c1a5a3a9be86c2c898fffaf2.md)

## Rule 120 — `pyproject.toml`

- **Rule:**
  ```text
  The tox env_run_base environment installs the tests dependency group.
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c43e0dc2a7e1ba26381eb508.md)

## Rule 121 — `src/click/testing.py`

- **Rule:**
  ```text
  When modifying the testing input wrapper, preserve that __getattr__ forwards unknown attributes to _input, transparently exposing the underlying input stream API.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:** Changing the testing input wrapper's attribute access behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c49876e606b752ed90c69a95.md)

## Rule 122 — `src/click/shell_completion.py`

- **Rule:**
  ```text
  get_completion_class must look up the shell name in the _available_shells registry and return None for unregistered names, so new shells are added by registering them in that registry rather than by branching in the lookup function.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:** Adding or modifying shell completion support or the shell-name lookup path.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c4d7622e150a88693aebf71e.md)

## Rule 123 — `src/click/parser.py`

- **Rule:**
  ```text
  parser.py must remain a stdlib-optparse-derived module with features removed and intentional divergence from optparse to avoid gettext and 2.x/3.x error-message differences, using the _flag_needs_value sentinel to signal a flag passed without a value.
  ```
- **Applies to:**
  - `src/click/parser.py`
- **Condition:** Modifying parser.py or its optparse-derived parsing behavior and sentinel handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c8cbbf5f8617b339c8be2c8a.md)

## Rule 124 — `tests/test_types.py`

- **Rule:** Tests for path surrogates must be skipped when the OS/FS lacks non-UTF-8 filename support and must assert BadParameter messages for non-existent, file, directory, unreadable, unwritable, and non-executable paths using surrogate filenames.
- **Applies to:**
  - `tests/test_types.py`
- **Condition:** When modifying or adding tests that check path validation with surrogate filenames.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-cb136c1d564c1bd5465a9a21.md)

## Rule 125 — `pyproject.toml`

- **Rule:**
  ```text
  The tox environment `update-actions` runs the `gha-update` command.
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-cb3712c42bb4f1192bbce351.md)

## Rule 126 — `src/click/_winconsole.py`

- **Rule:** When modifying ConsoleStream.writelines, it must continue to delegate each line to self.write, so write's encoding/error handling applies uniformly to line batches.
- **Applies to:**
  - `src/click/_winconsole.py`
- **Condition:** When changing ConsoleStream.writelines or Windows console line writing.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-cb3e03cb7f07405b816cccc2.md)

## Rule 127 — `.readthedocs.yaml`

- **Rule:**
  ```text
  The Read the Docs install job runs `asdf plugin add uv`.
  ```
- **Applies to:**
  - `.readthedocs.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-cc4c3c888a18906eda551ce5.md)

## Rule 128 — `.readthedocs.yaml`

- **Rule:**
  ```text
  The Read the Docs install job runs `asdf global uv latest`.
  ```
- **Applies to:**
  - `.readthedocs.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-cd1d40231096a077666b09e3.md)

## Rule 129 — `tests/test_shell_completion.py`

- **Rule:**
  ```text
  Shell completion tests for count options must assert that completing an empty word yields no completions, while completing '-' yields ['--help'].
  ```
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:** When modifying or adding shell completion tests for count options.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d0c5ebaf841f6403acb34538.md)

## Rule 130 — `src/click/core.py`

- **Rule:**
  ```text
  Argument must remain a positional parameter that is required by default, can have infinite nargs, and reports param_type_name 'argument', distinguishing argument defaults from option defaults.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  Modifying Argument or the defaults and param_type_name that distinguish arguments from options.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d13c7f62497c5f316c668486.md)

## Rule 131 — `src/click/testing.py`

- **Rule:**
  ```text
  CliRunner's Result.stdout must decode stdout_bytes using the runner charset with 'replace' errors and normalize CRLF to LF, defining the text output contract that tests rely on.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:** when modifying Result.stdout or the runner's output decoding behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d1961af689f198aed7abd33a.md)

## Rule 132 — `.readthedocs.yaml`

- **Rule:** Read the Docs builds use Python 3.13.
- **Applies to:**
  - `.readthedocs.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d388d9c6c87ea0df346f93e8.md)

## Rule 133 — `src/**`

- **Rule:** mypy type-checks the files under src and tests/typing.
- **Applies to:**
  - `src/**`
  - `tests/typing/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d3c79538002c059eaca6f2fa.md)
