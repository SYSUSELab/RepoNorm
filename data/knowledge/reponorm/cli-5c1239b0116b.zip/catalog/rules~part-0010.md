# Full rule catalog

## Rule 151 — `src/click/shell_completion.py`

- **Rule:**
  ```text
  When modifying shell completion, preserve the contract that _is_incomplete_argument treats an argument as still accepting values when nargs is -1, when its value did not originate from the command line, or when a multi-value argument has fewer values than nargs; the value is read from ctx.params, which may be None when expose_value is False.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:** Changing how shell completion decides whether an argument still accepts values.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e1eee9761bf8b75d8ea4d64f.md)

## Rule 152 — `examples/validation/validation.py`

- **Rule:** The validation example's URL ParamType convert method must parse values with urlparse and fail with an error message when the scheme is not http or https.
- **Applies to:**
  - `examples/validation/validation.py`
- **Condition:** when modifying URL type validation in the validation example
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e4370861becdd753897965f9.md)

## Rule 153 — `src/click/shell_completion.py`

- **Rule:**
  ```text
  add_completion_class must register a ShellComplete subclass in _available_shells under the given name, defaulting to the class's name attribute, and return the class so custom shells are registered by name for lookup during completion.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:**
  ```text
  Modifying add_completion_class or the shell registration lookup used during completion.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e7cfbf901c297be46cbcb947.md)

## Rule 154 — `src/click/types.py`

- **Rule:**
  ```text
  Choice.to_info_dict must extend the base info dict with 'choices' and 'case_sensitive', establishing the serialization contract for choice parameters.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  when modifying Choice.to_info_dict or the serialized info dict for choice parameters
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e8836ce2e614f14184a64231.md)

## Rule 155 — `docs/_build/**`

- **Rule:**
  ```text
  The flit sdist build excludes docs/_build/ from the source distribution.
  ```
- **Applies to:**
  - `docs/_build/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e980d9a345204f0f7047f46b.md)

## Rule 156 — `src/click/_compat.py`

- **Rule:**
  ```text
  When converting or wrapping text streams, _force_correct_text_stream must return a compatible text stream as-is unless encoding is None and the stream is misconfigured, fall back to the original text stream when no binary reader can be found, and default errors to "replace" when errors is None.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:** Modifying text-stream compatibility handling or encoding/errors defaults.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-eb1eb48d319104088e67a0e5.md)

## Rule 157 — `examples/**`

- **Rule:** Ruff excludes the examples/ directory from its checks via extend-exclude.
- **Applies to:**
  - `examples/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f34d92e6cf63e41b32bc1389.md)

## Rule 158 — `.readthedocs.yaml`

- **Rule:** Read the Docs builds use Ubuntu 24.04 as the build OS.
- **Applies to:**
  - `.readthedocs.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f45f2f61747d3fe3a0709e57.md)

## Rule 159 — `src/click/formatting.py`

- **Rule:** HelpFormatter must write into memory and remain exposed for developers to write custom outputs, with width defaulting to terminal width clamped to a maximum of 78.
- **Applies to:**
  - `src/click/formatting.py`
- **Condition:** Modifying HelpFormatter or its width defaulting and output-writing behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f86f938436b892a661aa758a.md)

## Rule 160 — `src/click/_winconsole.py`

- **Rule:**
  ```text
  _is_console must return False when the stream lacks fileno or raises OSError/io.UnsupportedOperation, and otherwise probe GetConsoleMode, guarding Windows console detection against non-file streams.
  ```
- **Applies to:**
  - `src/click/_winconsole.py`
- **Condition:**
  ```text
  when modifying _is_console or Windows console detection logic
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-fa4e1678a5b0a1258e16dc22.md)

## Rule 161 — `src/click/core.py`

- **Rule:** CommandCollection must remain a Group subclass that looks up subcommands first on itself then on each source group in order, without merging source parameters or invoking source callbacks, effectively flattening commands.
- **Applies to:**
  - `src/click/core.py`
- **Condition:** Modifying CommandCollection or its subcommand lookup and source-group handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-fccbe986abaf237a6e993818.md)

## Rule 162 — `click/**`

- **Rule:** Coverage measurement is configured to cover the click package and the tests directory.
- **Applies to:**
  - `click/**`
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ff0a8671cfc5d5c80dfc78d3.md)

## Rule 163 — `src/click/decorators.py`

- **Rule:** Eager boolean flag callbacks must abort the context when the value is false, terminating parsing rather than continuing with a false flag.
- **Applies to:**
  - `src/click/decorators.py`
- **Condition:**
  ```text
  when modifying eager boolean flag callbacks such as confirmation_option.callback
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ffc3becd9e228f99c34ea849.md)
