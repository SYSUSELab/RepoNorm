# Full rule catalog

## Rule 084 — `src/click/types.py`

- **Rule:** Numeric conversion must catch ValueError from the number class and route it through self.fail with a localized message naming the value and number type, so invalid numeric input produces a parameter failure rather than a raw ValueError.
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When modifying _NumberParamTypeBase.convert or numeric parsing, preserve catching ValueError and routing through self.fail with a localized message naming the value and number type.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8341b95d190c8b4ef52d9e80.md)

## Rule 085 — `**`

- **Rule:**
  ```text
  The pre-commit workflow runs pre-commit via `uv run --locked --group pre-commit pre-commit run --show-diff-on-failure --color=always --all-files`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-834d0594f6dc5ee4dcb02700.md)

## Rule 086 — `**/*.py`

- **Rule:** Ruff linting ignores rule UP038 to keep isinstance tuple syntax.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-84156b62b7efe5c3933315e2.md)

## Rule 087 — `pyproject.toml`

- **Rule:**
  ```text
  The tox environment `update-actions` sets `skip_install = true`.
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-86dbfb3cf788130fd83855bc.md)

## Rule 088 — `src/click/decorators.py`

- **Rule:** The option decorator must forward all keyword arguments unchanged to the parameter class constructor except cls, and must default cls to Option when not supplied, preserving this as the documented extension point for custom option classes.
- **Applies to:**
  - `src/click/decorators.py`
- **Condition:** When modifying the option decorator or adding custom option classes that rely on keyword forwarding and the default cls.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-873b6526cbe1880e1420012f.md)

## Rule 089 — `examples/complex/complex/cli.py`

- **Rule:** The complex example's Environment class must be used as the pass-object context for its CLI, with verbose initialized to False and home initialized to os.getcwd().
- **Applies to:**
  - `examples/complex/complex/cli.py`
- **Condition:** when modifying the Environment class or its initialization in the complex example
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-87cce84e33289283e3a49c7f.md)

## Rule 090 — `.github/workflows/publish.yaml`

- **Rule:**
  ```text
  The build job runs `uv build` to build the package.
  ```
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-89e4160b7cc2ac1bfc673096.md)

## Rule 091 — `src/click/_compat.py`

- **Rule:**
  ```text
  When modifying _compat.isatty, it must continue to return stream.isatty() but catch any Exception and return False, so TTY detection never raises.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  When changing _compat.isatty or TTY detection behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8ce6b74c79613b3c6ea0d793.md)

## Rule 092 — `src/click/exceptions.py`

- **Rule:**
  ```text
  Exit must remain a RuntimeError subclass with __slots__ = ("exit_code",), carrying the exit status as an attribute on the exception rather than via a separate mechanism.
  ```
- **Applies to:**
  - `src/click/exceptions.py`
- **Condition:** Modifying the Exit exception class or how exit status is carried.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8d5443c448f25c1aca904fe2.md)

## Rule 093 — `src/click/types.py`

- **Rule:**
  ```text
  to_info_dict for a type with formats must extend the superclass info dict by adding a 'formats' key, defining the info-dict extension contract for format-bearing types.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When modifying to_info_dict for a format-bearing type or adding a new type that must expose formats in its info dict.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9245f321b6ff932999317806.md)

## Rule 094 — `src/click/formatting.py`

- **Rule:**
  ```text
  write_heading must write the heading indented to the current indent level followed by a colon and newline, defining the exact heading format in help output.
  ```
- **Applies to:**
  - `src/click/formatting.py`
- **Condition:**
  ```text
  Modifying HelpFormatter.write_heading or the heading format in help output.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9283e4021318383eb9bd09a0.md)

## Rule 095 — `src/click/core.py`

- **Rule:**
  ```text
  When modifying command resolution, preserve that resolve_command applies ctx.token_normalize_func to the command name when the initial lookup fails, and when the command is still missing and parsing is not resilient, it re-parses args if the first token looks like an option before failing with a no-such-command error.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:** Changing command lookup or fallback resolution behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-92c9d39f3687d6514913bef6.md)

## Rule 096 — `src/click/testing.py`

- **Rule:**
  ```text
  When the testing harness simulates hidden input, hidden_input must write the prompt plus a newline to stdout and return the next line from the scripted text input with trailing CR/LF stripped.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:** Modifying the testing harness's hidden-input simulation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-93e339416019365735be5890.md)

## Rule 097 — `src/click/shell_completion.py`

- **Rule:**
  ```text
  ShellComplete.source_vars must return exactly complete_func, complete_var, and prog_name, defining the variable contract available to source_template formatting.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:**
  ```text
  When modifying ShellComplete.source_vars or the completion source template that consumes these variables.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-955d97bc611a5532ee98f575.md)

## Rule 098 — `src/click/types.py`

- **Rule:**
  ```text
  Choice.__init__ must eagerly convert the choices iterable to a tuple and store case_sensitive, so later membership checks operate on a stable sequence rather than a one-shot iterable.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When modifying Choice.__init__ or choice storage, preserve eager tuple conversion of choices and storage of case_sensitive for stable membership checks.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-99345ff620d3be42da72f072.md)

## Rule 099 — `examples/imagepipe/imagepipe.py`

- **Rule:**
  ```text
  The imagepipe flip callback maps both lr/leftright and tb/topbottom/upsidedown/ud to Image.FLIP_LEFT_RIGHT, so the top-bottom aliases do not actually select a top-bottom flip in this example.
  ```
- **Applies to:**
  - `examples/imagepipe/imagepipe.py`
- **Condition:** When modifying the flip callback or its alias mapping in the imagepipe example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9d81a042806730ff73812b47.md)
