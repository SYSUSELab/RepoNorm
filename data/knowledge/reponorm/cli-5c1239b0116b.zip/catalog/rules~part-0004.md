# Full rule catalog

## Rule 052 — `.github/workflows/publish.yaml`

- **Rule:** The build job sets up Python using the version specified in pyproject.toml.
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-4b70ecb4b44e26050561cd81.md)

## Rule 053 — `examples/complex/complex/cli.py`

- **Rule:** The complex example's Environment.log method must format msg with args when present and write to stderr via click.echo, and Environment.vlog must log to stderr only when self.verbose is truthy.
- **Applies to:**
  - `examples/complex/complex/cli.py`
- **Condition:** When modifying logging behavior in the complex example
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-4b77d3c548463fe5b10a3041.md)

## Rule 054 — `src/click/decorators.py`

- **Rule:**
  ```text
  confirmation_option must default param_decls to ('--yes',) and set is_flag=True, callback, expose_value=False, prompt 'Do you want to continue?', and help text, so the confirmation flag is not exposed to the command callback.
  ```
- **Applies to:**
  - `src/click/decorators.py`
- **Condition:**
  ```text
  When modifying confirmation_option or its option defaults, preserve the ('--yes',) param_decls, is_flag=True, callback, expose_value=False, prompt, and help text so the flag stays hidden from the callback.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-4f6862ab1c9f7a272bd1761a.md)

## Rule 055 — `src/click/testing.py`

- **Rule:**
  ```text
  When modifying EchoingStdin.read1, it must continue to delegate to self._input.read1(n) and pass the result through self._echo, so reads from the testing input stream are echoed.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:** When changing EchoingStdin.read1 or testing input stream echo behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-500df2a87f95bee66ba5a8e3.md)

## Rule 056 — `pyproject.toml`

- **Rule:** uv's default dependency groups are "dev", "pre-commit", "tests", and "typing".
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-51478ae42044d697cbb780ef.md)

## Rule 057 — `src/click/types.py`

- **Rule:**
  ```text
  Choice.get_metavar must build a '|'-joined choices string, deduplicating type names for options without show_choices, and wrap it in curly braces for required arguments or square brackets otherwise.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  when modifying Choice.get_metavar or the metavar formatting for choice parameters
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-51fc7aca58e5c157d2ad4f94.md)

## Rule 058 — `tests/test_testing.py`

- **Rule:** Tests for Click's testing runner must verify that getchar input is handled, that multiple prompt-enabled options are prompted sequentially, and that an Abort during a hidden prompt produces the expected interrupted output (with platform-specific skips where behavior differs).
- **Applies to:**
  - `tests/test_testing.py`
  - `tests/test_utils.py`
- **Condition:** When adding or modifying tests for the Click testing runner's input handling, sequential prompting, or prompt-abort behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-545660df4b2ab5781a3d64e0.md)

## Rule 059 — `examples/complex/complex/cli.py`

- **Rule:**
  ```text
  The complex example's dynamic command loader must import complex.commands.cmd_<name> and return its cli attribute, and must silently return None on ImportError so unknown commands fall through to normal error handling.
  ```
- **Applies to:**
  - `examples/complex/complex/cli.py`
- **Condition:**
  ```text
  when modifying or extending the get_command method that resolves subcommands dynamically
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-553b1e22beed754d71cd8ea1.md)

## Rule 060 — `tests/test_arguments.py`

- **Rule:** Tests for implicit optional arguments must assert that invoking with no arguments exits 0 and outputs 'test', establishing that an argument without required=True is implicitly optional.
- **Applies to:**
  - `tests/test_arguments.py`
- **Condition:** When modifying or adding tests that check implicit optional argument behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5545b7880a22664c4d6ec769.md)

## Rule 061 — `src/click/testing.py`

- **Rule:**
  ```text
  _pause_echo must set _paused=True on the echoing stdin stream before yielding and reset it to False afterward, so the pause state is scoped to the context manager body.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:**
  ```text
  Modifying _pause_echo or the pause-state handling of the echoing stdin stream.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-58fa013d4c70184592c6f7f1.md)

## Rule 062 — `src/click/types.py`

- **Rule:**
  ```text
  A range type's __repr__ must include the range description and append ' clamped' when self.clamp is set.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When modifying _NumberRangeBase.__repr__ or range representation, preserve inclusion of the range description and the ' clamped' suffix when clamp is set.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6000ded18131c2255edbfff7.md)

## Rule 063 — `pyproject.toml`

- **Rule:**
  ```text
  The tox environment `update-requirements` runs `uv lock` with posargs replacing the default `-U` and extending it.
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-600d545f56fb970c81a2d526.md)

## Rule 064 — `src/click/testing.py`

- **Rule:**
  ```text
  CliRunner.make_env must copy the runner's base environment and overlay caller-provided overrides, so per-invocation env changes never mutate the runner's stored base environment.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:**
  ```text
  Modifying CliRunner.make_env or how invocation environments are assembled.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-602ce3b9d689c409a0613e86.md)

## Rule 065 — `.github/workflows/publish.yaml`

- **Rule:** The build job uploads the ./dist directory as an artifact.
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-603f43d4973244b59d8d5eb3.md)

## Rule 066 — `.pre-commit-config.yaml`

- **Rule:** The pre-commit cache is keyed on the hashes of pyproject.toml and .pre-commit-config.yaml.
- **Applies to:**
  - `.pre-commit-config.yaml`
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-60ad6627db477093c391b21b.md)

## Rule 067 — `src/click/parser.py`

- **Rule:**
  ```text
  _unpack_args must fill missing items with None, treat nargs -1 as a wildcard consuming all remaining arguments, raise TypeError when two nargs < 0 specifications are present, and reverse the wildcard remainder when the wildcard position is not first.
  ```
- **Applies to:**
  - `src/click/parser.py`
- **Condition:**
  ```text
  When modifying _unpack_args or the argument-unpacking path that maps parsed values onto declared nargs specifications.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-60e83dbb8dd18bdd698e929c.md)
