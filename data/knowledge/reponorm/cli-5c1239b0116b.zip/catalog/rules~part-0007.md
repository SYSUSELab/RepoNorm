# Full rule catalog

## Rule 100 — `src/click/testing.py`

- **Rule:**
  ```text
  The testing shim's _getchar must read one char from sys.stdin, optionally echo it to stdout, flush, and return it, wrapped with _pause_echo.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:**
  ```text
  When modifying the testing shim's _getchar or the simulated stdin character-reading path.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a1b5315c78cdf1b99fe435cd.md)

## Rule 101 — `.github/workflows/publish.yaml`

- **Rule:**
  ```text
  The create-release job runs `gh release create --draft` against the repository using the ref name and artifact/* files.
  ```
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a292a81201c517f81dd23fcb.md)

## Rule 102 — `examples/colors/colors.py`

- **Rule:** The colors example must demonstrate click.style usage with fg, bold, reverse, blink, and underline, and document that ANSI styles are automatically stripped when output is piped to a file.
- **Applies to:**
  - `examples/colors/colors.py`
- **Condition:** when modifying or extending the colors example's style demonstration
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a29d22bd40de9ba93ff568a8.md)

## Rule 103 — `examples/repo/repo.py`

- **Rule:**
  ```text
  The repo example's setuser command must combine prompt=True options with click.password_option and pass_repo, and must store the password masked as '*' * len(password).
  ```
- **Applies to:**
  - `examples/repo/repo.py`
- **Condition:** when modifying credential prompting or password storage in the repo example
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a3e773a68313e0387393ce0f.md)

## Rule 104 — `**`

- **Rule:**
  ```text
  The typing job runs `uv run --locked tox run -e typing`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a90be6e33b7a71725199b83e.md)

## Rule 105 — `pyproject.toml`

- **Rule:**
  ```text
  The tox env_run_base environment runs pytest with -v, --tb=short, and --basetemp={env_tmp_dir}, extending posargs with a default of no extra arguments.
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-abceebea6998aa87baa55d9a.md)

## Rule 106 — `src/click/decorators.py`

- **Rule:** When modifying the argument decorator, preserve that it defaults cls to Argument when not provided and forwards all other keyword arguments unchanged to the parameter class constructor, establishing the extension contract for custom argument classes.
- **Applies to:**
  - `src/click/decorators.py`
- **Condition:** Changing the argument decorator's cls default or keyword forwarding.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-aebef0e06f64f1fda09c2010.md)

## Rule 107 — `tests/test_defaults.py`

- **Rule:**
  ```text
  Tests that verify default value rendering must assert the exact bracket formatting convention, e.g. a default value is displayed as "FOO:[42.0]".
  ```
- **Applies to:**
  - `tests/test_defaults.py`
- **Condition:** When modifying or adding tests that check how default values are rendered in command output.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b0d687cb01670d2f73fed35d.md)

## Rule 108 — `pyproject.toml`

- **Rule:**
  ```text
  The tox environment `update-requirements` sets `no_default_groups = true` and an empty `dependency_groups` list.
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b5e10c876f53a0f5174b1fe5.md)

## Rule 109 — `src/click/shell_completion.py`

- **Rule:**
  ```text
  CompletionItem must use __slots__ and expose arbitrary metadata passed as kwargs via item.attr, returning None for attributes that were not passed, so custom type completions paired with custom shell support can rely on this access pattern.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:** Modifying CompletionItem or the attribute access used by custom type completions and custom shell support.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b72ee28bb7c998929ff0ca39.md)

## Rule 110 — `tests/test_termui.py`

- **Rule:**
  ```text
  Tests for progress bar formatting must assert exact format_progress_line() output for a given width, including zero-length progress, omitted percent/position variants, and full completion.
  ```
- **Applies to:**
  - `tests/test_termui.py`
- **Condition:** When modifying or adding tests that check progress bar line formatting.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b7e2c801f126f7dc9718588f.md)

## Rule 111 — `pyproject.toml`

- **Rule:**
  ```text
  The typing job caches ./.mypy_cache keyed by mypy|hashFiles('pyproject.toml').
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b89dd123ca2ca9356a64cc1d.md)

## Rule 112 — `src/click/_winconsole.py`

- **Rule:**
  ```text
  Py_buffer must be defined as a ctypes Structure with fields buf, obj, len, itemsize, readonly, ndim, format, shape, strides, suboffsets, and internal, matching the CPython buffer protocol layout for Windows console handling.
  ```
- **Applies to:**
  - `src/click/_winconsole.py`
- **Condition:**
  ```text
  When modifying Py_buffer or Windows console FFI structures that must match the CPython buffer protocol layout.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b9547dccfd4168af6b7cd402.md)

## Rule 113 — `src/click/formatting.py`

- **Rule:**
  ```text
  When modifying measure_table, it must continue to compute per-column maximum term_len widths and return them in column order, defining the table-width measurement used by formatting.
  ```
- **Applies to:**
  - `src/click/formatting.py`
- **Condition:**
  ```text
  When changing measure_table or table-width measurement used by formatting.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b97b28ffd004d015ca9abf65.md)

## Rule 114 — `tests/test_types.py`

- **Rule:** Tests that depend on symlink support must use a helper that probes by creating a temporary symlink and returns False on OSError, so tests can skip when symlinks are unavailable.
- **Applies to:**
  - `tests/test_types.py`
- **Condition:** When modifying or adding tests that require symlink support.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-bc4738e92e0678df1b135045.md)

## Rule 115 — `src/click/testing.py`

- **Rule:**
  ```text
  CliRunner.invoke must preserve its versioned result-object contract: since 8.2 the result has output_bytes mixing stdout and stderr and always returns stderr_bytes; since 8.0 it has return_value; since 3.0 it has exc_info; a string args is treated as a Unix shell command via shlex.split; and non-integer SystemExit codes are normalized to exit code 1 after writing the code to stdout.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:** When modifying CliRunner.invoke or the result object it returns, including argument handling and SystemExit normalization.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-bc6d2d7d34a46b6ab095ac2c.md)
