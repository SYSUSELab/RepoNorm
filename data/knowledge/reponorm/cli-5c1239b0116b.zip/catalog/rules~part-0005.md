# Full rule catalog

## Rule 068 — `src/click/termui.py`

- **Rule:**
  ```text
  unstyle must remove ANSI styling via strip_ansi, and echo already strips styling automatically when necessary.
  ```
- **Applies to:**
  - `src/click/termui.py`
- **Condition:**
  ```text
  When modifying unstyle or echo styling behavior, keep unstyle implemented via strip_ansi and preserve echo's automatic styling strip when necessary.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-622da652c451ca859cea80ae.md)

## Rule 069 — `src/click/_compat.py`

- **Rule:**
  ```text
  When modifying _AtomicFile.__repr__, it must continue to delegate to repr(self._f), exposing the underlying file's representation.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  When changing _AtomicFile.__repr__ or wrapper representation behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6736e9231639eea61377059d.md)

## Rule 070 — `pyproject.toml`

- **Rule:**
  ```text
  The tox env_run_base environment uses frozen constraints.
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-673ed6a78cbe951f56430f92.md)

## Rule 071 — `src/click/testing.py`

- **Rule:**
  ```text
  CliRunner.get_default_prog_name must return cli.name or 'root' when unset, defining the default program name used in test invocations.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:**
  ```text
  Modifying CliRunner.get_default_prog_name or the default program name used in test invocations.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-689722a3db41994c7f77b030.md)

## Rule 072 — `tests/test_shell_completion.py`

- **Rule:**
  ```text
  Shell completion tests must use the _patch_for_completion fixture to monkeypatch BashComplete._check_version to always return True, isolating completion tests from the installed bash version.
  ```
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:** When modifying or adding shell completion tests that depend on bash version.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-697336c3da806347c975498c.md)

## Rule 073 — `src/click/parser.py`

- **Rule:**
  ```text
  When modifying _OptionParser.parse_args, UsageError must be suppressed only when a context exists and resilient_parsing is enabled; otherwise it must be re-raised, and the return value must include values, leftover args, and an order list that records repeated arguments multiple times.
  ```
- **Applies to:**
  - `src/click/parser.py`
- **Condition:**
  ```text
  When changing _OptionParser.parse_args or its error handling and return contract.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6ceda3d2059f15178789aa8a.md)

## Rule 074 — `src/click/testing.py`

- **Rule:**
  ```text
  BytesIOCopy.__init__ must store the provided copy_to BytesIO as the copy target used when capturing output in CliRunner.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:**
  ```text
  Modifying BytesIOCopy.__init__ or the copy target used by CliRunner output capture.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6f00bf7057591eec8f94bde7.md)

## Rule 075 — `src/click/types.py`

- **Rule:**
  ```text
  When modifying FloatRange._clamp, it must continue to raise RuntimeError('Clamping is not supported for open bounds.') for open bounds, explicitly leaving open float range clamping to a user callback.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When changing FloatRange._clamp or float range clamping behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-700ee4e10eb6ff883fc40cba.md)

## Rule 076 — `tests/test_info_dict.py`

- **Rule:**
  ```text
  Tests that verify the info_dict shape must preserve the exact metadata fields including is_flag True, flag_value True, and default False for HELP_OPTION, and default 1 for NUMBER_OPTION.
  ```
- **Applies to:**
  - `tests/test_info_dict.py`
- **Condition:**
  ```text
  When modifying or adding tests for parameter info_dict metadata.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-726725cd24a7e7692895275a.md)

## Rule 077 — `**/*.py`

- **Rule:**
  ```text
  The project requires Python >=3.10.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-72827b8dfa0dc9bf567ef3e4.md)

## Rule 078 — `src/click/parser.py`

- **Rule:**
  ```text
  _Option.__init__ must split each option string via _split_opt, raise ValueError for an empty prefix, classify single-character prefix+value as short options and everything else as long options, and default action to 'store'.
  ```
- **Applies to:**
  - `src/click/parser.py`
- **Condition:**
  ```text
  When modifying _Option.__init__ or the option-string parsing path that classifies short versus long options.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7418f4a332c5a3c862941557.md)

## Rule 079 — `src/click/formatting.py`

- **Rule:**
  ```text
  write_text must re-indent and rewrap text using the formatter width with preserve_paragraphs=True, then append a newline, so paragraph structure is preserved in help output.
  ```
- **Applies to:**
  - `src/click/formatting.py`
- **Condition:**
  ```text
  Modifying HelpFormatter.write_text or help text wrapping behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-75c2884041416bf872840adf.md)

## Rule 080 — `tests/test_shell_completion.py`

- **Rule:**
  ```text
  Tests for Click's shell completion registration must verify that an unregistered shell name is absent from _available_shells, that add_completion_class returns the class, and that after registration the shell appears in _available_shells mapped to that class.
  ```
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:**
  ```text
  When adding or modifying tests for add_completion_class or _available_shells in tests/test_shell_completion.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7cb93d40b3b2d3337ef4016a.md)

## Rule 081 — `.readthedocs.yaml`

- **Rule:**
  ```text
  The Read the Docs install job runs `asdf install uv latest`.
  ```
- **Applies to:**
  - `.readthedocs.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7f55f42658e863a6e5f28e48.md)

## Rule 082 — `src/click/core.py`

- **Rule:**
  ```text
  When modifying command classes, preserve _BaseCommand as a deprecated compatibility shim (deprecated since 8.2, scheduled for removal in Click 9.0) that directs users to Command; do not remove it before the 9.0 boundary.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:** Changing or removing deprecated command base classes.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7ff21a0fafda4c89fb6b432d.md)

## Rule 083 — `src/click/utils.py`

- **Rule:**
  ```text
  When modifying Windows argument expansion, preserve that _expand_args simulates Unix shell expansion on Windows; since 8.1 invalid glob patterns are treated as empty expansions rather than raising, and unmatched args are kept as-is.
  ```
- **Applies to:**
  - `src/click/utils.py`
- **Condition:** Changing Windows argument expansion or glob handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-81eade044616fc064a2a6883.md)
