# Full rule catalog

## Rule 035 — `tests/test_utils.py`

- **Rule:**
  ```text
  MockMain test helper must use __slots__ = '__package__' to constrain the mock to only that attribute for main-module detection tests.
  ```
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:** When modifying or adding test helpers for main-module detection.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-2d7ec76f83b5017df4031dc9.md)

## Rule 036 — `examples/inout/inout.py`

- **Rule:** The inout example uses click.File("rb") with nargs=-1 for input and click.File("wb") for output, documents the "-" convention for stdin/stdout, and copies in 1024-byte chunks with flush.
- **Applies to:**
  - `examples/inout/inout.py`
- **Condition:** When modifying the inout example's file handling or copy loop.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-2da15c85f0e071cf698af737.md)

## Rule 037 — `pyproject.toml`

- **Rule:**
  ```text
  The tox environment `update-requirements` is labeled `update`.
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-2e0ce4aff2698bb99b505fe1.md)

## Rule 038 — `src/click/core.py`

- **Rule:**
  ```text
  When modifying Group.shell_complete, subcommand completion must remain additive: visible subcommands contribute CompletionItems (using each command's short help) and the parent implementation's completions are then extended, not replaced.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When changing Group.shell_complete or the completion behavior of a group command.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-2eb8c532eb504e7a58e1d0f3.md)

## Rule 039 — `examples/repo/repo.py`

- **Rule:**
  ```text
  Repo.set_config must store the key/value in self.config and, when verbose is true, echo the assignment to stderr, so verbose mode routes diagnostic output to stderr.
  ```
- **Applies to:**
  - `examples/repo/repo.py`
- **Condition:** When modifying configuration storage or verbose output in the repo example
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-324c359efacc440bdad8dfea.md)

## Rule 040 — `src/click/testing.py`

- **Rule:**
  ```text
  When the test runner decides whether to strip ANSI codes, should_strip_ansi must return not default_color when color is None, otherwise not color, so the default color decision is preserved.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:** Modifying the test runner's ANSI-stripping decision or its color default handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-332440a1825df4855d11c74e.md)

## Rule 041 — `src/click/types.py`

- **Rule:** The arity property of a composite ParamType must equal len(self.types), so composite arity is the number of contained types.
- **Applies to:**
  - `src/click/types.py`
- **Condition:** When modifying Tuple.arity or composite ParamType arity, keep arity equal to the number of contained types.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-38fc5f02064d2c18575276ca.md)

## Rule 042 — `pyproject.toml`

- **Rule:** The workflow's Python version is taken from pyproject.toml via actions/setup-python's python-version-file input.
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3a637350121197a32d063fcd.md)

## Rule 043 — `**/*.css`

- **Rule:** CSS, HTML, JS, JSON, JSX, SCSS, TS, TSX, YAML, and YML files use an indent size of 2.
- **Applies to:**
  - `**/*.css`
  - `**/*.html`
  - `**/*.js`
  - `**/*.json`
  - `**/*.jsx`
  - `**/*.scss`
  - `**/*.ts`
  - `**/*.tsx`
  - `**/*.yaml`
  - `**/*.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3aa1ff1bf121289d4dcaca48.md)

## Rule 044 — `**`

- **Rule:** The pre-commit configuration runs the uv-lock hook from the astral-sh/uv-pre-commit repository at revision a621b109bab2e7e832d98c88fd3e83399f4e6657 (frozen: 0.7.12).
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3b0c6e9cfaa03c5e85ae6706.md)

## Rule 045 — `src/click/types.py`

- **Rule:**
  ```text
  When modifying IntParamType, integer parameter behavior must continue to be derived from the shared _NumberParamTypeBase numeric base (name "integer", _number_class int) rather than implemented independently.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:** When changing IntParamType or integer parameter behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3bb1ce02553cd14265e02045.md)

## Rule 046 — `src/click/types.py`

- **Rule:**
  ```text
  When modifying the Choice type, preserve that Choice accepts any iterable of choices (converted to a tuple and iterated once), supports non-str choices since 8.2.0, allows normalization overrides via normalize_choice, and always returns a value that is one of the originally passed choices.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:** Changing Choice construction, normalization, or conversion behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3defc0d434245941d78ae986.md)

## Rule 047 — `tests/test_shell_completion.py`

- **Rule:** Shell completion tests for nested Group/Command structures must assert word-by-word completion: empty word lists subcommands, '-' lists options including --help, and a fully consumed command yields no completions.
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:** When modifying or adding shell completion tests for nested groups and commands.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-401a6a9857d9be848c88fa5c.md)

## Rule 048 — `src/click/exceptions.py`

- **Rule:** Abort must remain a RuntimeError subclass used as an internal signalling exception to abort Click processing.
- **Applies to:**
  - `src/click/exceptions.py`
- **Condition:** When modifying Abort or exception handling that catches it as an internal abort signal.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-414c19e4be10dead63efb74e.md)

## Rule 049 — `src/click/parser.py`

- **Rule:**
  ```text
  _normalize_opt must apply ctx.token_normalize_func only to the option name portion after _split_opt, preserving the prefix; when ctx is None or no normalize func is set, the option must be returned unchanged.
  ```
- **Applies to:**
  - `src/click/parser.py`
- **Condition:**
  ```text
  Modifying _normalize_opt or option-name normalization in the parser.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-42c0e3ac56474c81ef3e91bc.md)

## Rule 050 — `src/click/types.py`

- **Rule:** When the datetime type is used without explicit formats, it must default to the three accepted input shapes: date-only, ISO datetime with T separator, and space-separated datetime.
- **Applies to:**
  - `src/click/types.py`
- **Condition:** Modifying DateTime format defaults or accepted input shapes.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-4582b1d759040ee7d8ce1a20.md)

## Rule 051 — `src/click/exceptions.py`

- **Rule:**
  ```text
  MissingParameter.format_message must build the message from param_hint (or param.get_error_hint), append the type's missing message, and map param_type names to translated "Missing argument"/"Missing option"/"Missing parameter" prefixes.
  ```
- **Applies to:**
  - `src/click/exceptions.py`
- **Condition:**
  ```text
  Modifying MissingParameter.format_message or the missing-parameter error message format.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-482ab33439ced9154b632d83.md)
