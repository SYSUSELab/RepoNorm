# Full rule catalog

## Rule 001 — `src/click/types.py`

- **Rule:**
  ```text
  Choice.get_invalid_choice_message must build the invalid-choice error via ngettext with singular/plural forms and normalized mapping values so the message stays localized and plural-aware.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:** When changing Choice error reporting or choice normalization, keep the invalid-choice message localized through ngettext with plural handling and normalized mapping values.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-00d6429191b255be6b98fad1.md)

## Rule 002 — `pyproject.toml`

- **Rule:**
  ```text
  The tox env_run_base environment uses the uv-venv-lock-runner runner.
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0238ebc2d7c58061d09520b4.md)

## Rule 003 — `.readthedocs.yaml`

- **Rule:**
  ```text
  The Read the Docs HTML build runs `uv run --group docs sphinx-build -W -b dirhtml docs $READTHEDOCS_OUTPUT/html`.
  ```
- **Applies to:**
  - `.readthedocs.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0462a8e5054686e58c88a744.md)

## Rule 004 — `examples/completion/completion.py`

- **Rule:**
  ```text
  The completion example's ls command must define a --dir option typed as click.Path(file_okay=False) to constrain completion to directories.
  ```
- **Applies to:**
  - `examples/completion/completion.py`
- **Condition:** when modifying or extending the ls command in the completion example
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-04ac9b0c81b1fa9a3f5767de.md)

## Rule 005 — `src/click/testing.py`

- **Rule:**
  ```text
  EchoingStdin.__repr__ must return repr of its internal _input, exposing the input value in representations.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:**
  ```text
  when modifying EchoingStdin.__repr__ or its internal _input representation
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-04fa76ceecbd29954a611f80.md)

## Rule 006 — `CHANGES.rst`

- **Rule:** The flit sdist build includes docs/, tests/, CHANGES.rst, and uv.lock in the source distribution.
- **Applies to:**
  - `CHANGES.rst`
  - `docs/**`
  - `tests/**`
  - `uv.lock`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-05aa953bcf90e341895f2c76.md)

## Rule 007 — `src/click/utils.py`

- **Rule:**
  ```text
  When LazyFile is represented, __repr__ must return repr of the underlying file when opened, otherwise a synthetic "<unopened file 'name' mode>" string using format_filename, so repr is stable before the file is opened.
  ```
- **Applies to:**
  - `src/click/utils.py`
- **Condition:** Modifying LazyFile representation or its pre-open state handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-07f8283781f6ec329ffaaee4.md)

## Rule 008 — `tests/test_command_decorators.py`

- **Rule:** Tests that verify positional argument ordering must assert that Argument objects are registered in order with names 'a' and 'b' and that invoking with '1 2' yields output '1 2'.
- **Applies to:**
  - `tests/test_command_decorators.py`
- **Condition:** When modifying or adding tests that check positional argument ordering.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-09655316ac7389d605a68186.md)

## Rule 009 — `examples/repo/repo.py`

- **Rule:**
  ```text
  The repo example's delete command stacks click.confirmation_option() with pass_repo, so invoking delete prompts for confirmation before executing and receives the repo via the pass decorator.
  ```
- **Applies to:**
  - `examples/repo/repo.py`
- **Condition:** When modifying the delete command or its decorator stack in the repo example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-09ce301e94ae855d03c2c88f.md)

## Rule 010 — `CHANGES.rst`

- **Rule:** Add an entry in CHANGES.rst summarizing the change and linking to the issue.
- **Applies to:**
  - `CHANGES.rst`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-09da50bbbf77ac13e6327177.md)

## Rule 011 — `src/click/decorators.py`

- **Rule:**
  ```text
  The pass-context decorator wrapper must call f(get_current_context(), *args, **kwargs), injecting the context as the first positional argument before any user arguments.
  ```
- **Applies to:**
  - `src/click/decorators.py`
- **Condition:** When modifying the pass-context decorator wrapper or any context-injection decorator that must preserve argument ordering.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0a96e29cb780c9f131878f90.md)

## Rule 012 — `examples/colors/colors.py`

- **Rule:**
  ```text
  The colors example defines all_colors as the fixed set of 16 supported color names, including bright_* variants, which serves as the canonical list of color values exercised by the example.
  ```
- **Applies to:**
  - `examples/colors/colors.py`
- **Condition:** When modifying the colors example's color list or its usage.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0b9dd30506e787d0ef357bf0.md)

## Rule 013 — `src/click/testing.py`

- **Rule:**
  ```text
  CliRunner.__init__ must default to charset="utf-8", echo_stdin=False, and catch_exceptions=True, and must normalize a None env mapping to an empty dict.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:**
  ```text
  Modifying CliRunner.__init__ or its default configuration.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0c459f4bd38087c2b11fd6f1.md)

## Rule 014 — `src/click/core.py`

- **Rule:**
  ```text
  When modifying Parameter, its documented compatibility boundaries must be preserved: deprecated parameters cannot be required (ValueError otherwise), duplicate parameter names warn since 8.2, process_value validates required/bounded nargs and invokes callbacks since 8.0, autocompletion is renamed to shell_complete, and empty env vars are ignored since 7.1.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:** When changing Parameter or its documented compatibility behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0f594f230677e8826eeca692.md)

## Rule 015 — `src/click/_compat.py`

- **Rule:**
  ```text
  The stream wrapper constructor must store force_readable and force_writable flags alongside the wrapped stream, establishing the internal state used to override stream capability detection.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  When modifying the stream wrapper constructor or capability-override logic that reads force_readable/force_writable.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0fb11479e93129c68d450a3e.md)

## Rule 016 — `examples/repo/repo.py`

- **Rule:** The repo example's clone command derives DEST from the last path component of SRC when DEST is omitted, falling back to '.' if that component is empty.
- **Applies to:**
  - `examples/repo/repo.py`
- **Condition:** When modifying the clone command or its DEST derivation logic in the repo example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-10517b1ef2f71e653fea9ff8.md)

## Rule 017 — `src/**`

- **Rule:**
  ```text
  Pyright type checking is limited to the src and tests/typing directories via include = ["src", "tests/typing"].
  ```
- **Applies to:**
  - `src/**`
  - `tests/typing/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-10fdc422ff55589e1c7c75ca.md)
