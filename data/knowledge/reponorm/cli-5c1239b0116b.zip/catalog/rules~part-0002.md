# Full rule catalog

## Rule 018 — `examples/complex/complex/cli.py`

- **Rule:**
  ```text
  ComplexCLI must subclass click.Group and its list_commands must scan cmd_folder for files ending in '.py' and starting with 'cmd_', strip the prefix and suffix to derive command names, and sort them.
  ```
- **Applies to:**
  - `examples/complex/complex/cli.py`
- **Condition:** When modifying command discovery or group behavior in the complex example
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-114a15bb8f560f7f38daeb87.md)

## Rule 019 — `pyproject.toml`

- **Rule:**
  ```text
  The tox environment `update-actions` uses the `gha-update` dependency group.
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-14fcd7a4731d7ea9928fda55.md)

## Rule 020 — `tests/test_commands.py`

- **Rule:**
  ```text
  Command.parse_args must populate ctx._opt_prefixes with the set {"-", "--", "+", "!"}, establishing the recognized option prefix characters.
  ```
- **Applies to:**
  - `tests/test_commands.py`
- **Condition:**
  ```text
  When modifying or adding tests that check Command.parse_args option prefix collection.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1500638ae6ead8718957f423.md)

## Rule 021 — `pyproject.toml`

- **Rule:**
  ```text
  The tox env_run_base environment constrains package dependencies.
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-159c92ca46196a31f357927c.md)

## Rule 022 — `src/click/shell_completion.py`

- **Rule:**
  ```text
  ZshComplete.get_completion_args must read COMP_WORDS and COMP_CWORD from the environment, slice args between the program name and current word, and treat a missing current word as an empty incomplete string.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:**
  ```text
  Modifying ZshComplete.get_completion_args or the environment-based completion argument parsing.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1758b8ac740f59e00b4c22aa.md)

## Rule 023 — `tests/test_utils.py`

- **Rule:**
  ```text
  Tests for Click's program name detection must verify that _detect_program_name returns the basename for plain paths, python -m module for __main__.py, python -m package.module for module files, and strips ./ prefixes.
  ```
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:**
  ```text
  When adding or modifying tests for _detect_program_name in tests/test_utils.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-187db22e0085cc37d12dc7e3.md)

## Rule 024 — `src/click/_compat.py`

- **Rule:**
  ```text
  _is_binary_reader must determine binary-ness by calling stream.read(0) and checking for bytes, swallowing any exception and returning the caller-supplied default, so detection tolerates streams that raise on zero-length reads.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  When modifying _is_binary_reader or stream capability detection that must tolerate streams raising on zero-length reads.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-19250a4bee3b097540e5d0dc.md)

## Rule 025 — `src/click/types.py`

- **Rule:**
  ```text
  File.to_info_dict must add 'mode' and 'encoding' to the base info dict, defining the serialization contract for file parameters.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  Modifying File.to_info_dict or the serialized info dict for file parameters.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1a609469c6e2cc90984c7ebe.md)

## Rule 026 — `tests/**`

- **Rule:**
  ```text
  Pytest test discovery is restricted to the tests directory via testpaths = ["tests"].
  ```
- **Applies to:**
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1b785ed9d7ed7aca893f06bb.md)

## Rule 027 — `src/click/types.py`

- **Rule:**
  ```text
  When modifying Choice._normalized_mapping, it must remain an internal/unsupported surface: callers should use normalize_choice instead, and the wrapper's documented role is a simple wrapper around normalize_choice.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When changing Choice._normalized_mapping or its callers.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1f2dc689b06bb3dce755f015.md)

## Rule 028 — `examples/repo/repo.py`

- **Rule:** The commit command in the repo example, when no message is given, must open an editor with a hint template and abort if the edited message is None or empty after stripping the marker section.
- **Applies to:**
  - `examples/repo/repo.py`
- **Condition:** When modifying the commit command's message handling in the repo example
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1f3d319dc2ddd1d6848bcb79.md)

## Rule 029 — `tests/test_commands.py`

- **Rule:**
  ```text
  Tests for command forwarding must assert that invoking the group with 'dist' produces output 'Count: 1\nCount: 42\n' with no exception.
  ```
- **Applies to:**
  - `tests/test_commands.py`
- **Condition:** When modifying or adding tests that check command forwarding behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1fd93cf68832eeed081cc701.md)

## Rule 030 — `src/click/testing.py`

- **Rule:** Result.output must remain an independent stream that interleaves stdout and stderr in write order, decoded with the runner charset and with CRLF normalized to LF; it must not be redefined as a stdout-only proxy.
- **Applies to:**
  - `src/click/testing.py`
- **Condition:** When modifying Result.output or the CliRunner stream capture that feeds it, preserve the mixed stdout/stderr write-order stream and charset/CRLF normalization rather than reverting to a stdout-only view.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-2089272fd40280a5c0da167a.md)

## Rule 031 — `src/click/_compat.py`

- **Rule:**
  ```text
  When modifying get_binary_stdin, it must continue to raise RuntimeError when no binary reader can be determined for sys.stdin, making binary stdin availability a hard precondition rather than returning None.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  When changing get_binary_stdin or binary stdin detection.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-22986b8bb9fcdcd7cb9b3e65.md)

## Rule 032 — `src/click/_compat.py`

- **Rule:**
  ```text
  _AtomicFile.__getattr__ must delegate attribute access to the wrapped file object, making the wrapper transparent for arbitrary attributes.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  Modifying _AtomicFile.__getattr__ or the wrapper's attribute delegation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-23f76373bee29ac46482a549.md)

## Rule 033 — `src/click/types.py`

- **Rule:**
  ```text
  UnprocessedParamType.__repr__ must return the literal string 'UNPROCESSED'.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When modifying UnprocessedParamType or its repr, keep __repr__ returning the literal 'UNPROCESSED'.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-291eb946e178ce537032e572.md)

## Rule 034 — `.github/workflows/publish.yaml`

- **Rule:** The publish-pypi job publishes packages from the artifact/ directory using pypa/gh-action-pypi-publish.
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-29862d795941e7b171ce185e.md)
