# Rule details

- **Rule:**
  ```text
  Encoding.encode_ordinary_batch must encode a list of strings in parallel with default num_threads=8, ignoring special tokens, and remain equivalent to encode_batch(text, disallowed_special=()) but slightly faster.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  When modifying Encoding.encode_ordinary_batch's parallel encoding behavior or special-token handling.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
encode_ordinary_batch encodes a list of strings in parallel via ThreadPoolExecutor with default num_threads=8 and ignores special tokens, matching the documented behavior.
```

- **Sources:**
  - `tiktoken/core.py:161-173`
