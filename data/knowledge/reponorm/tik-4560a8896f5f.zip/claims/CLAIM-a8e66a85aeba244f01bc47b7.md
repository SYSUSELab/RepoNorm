# Rule details

- **Rule:**
  ```text
  Encoding.encode_single_token must encode text or bytes corresponding to a single token, encode all special tokens, and raise KeyError when the token is not in the vocabulary.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  when modifying Encoding.encode_single_token or its vocabulary lookup
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
Encoding.encode_single_token encodes str to utf-8 bytes and delegates to self._core_bpe.encode_single_token, matching the rule that it encodes single-token text/bytes and encodes all special tokens; the KeyError path is documented in the docstring.
```

- **Sources:**
  - `tiktoken/core.py:242-256`
