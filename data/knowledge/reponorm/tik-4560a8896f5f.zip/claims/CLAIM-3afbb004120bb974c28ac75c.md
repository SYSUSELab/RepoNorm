# Rule details

- **Rule:** Encoding must produce exact token IDs for specific strings under each encoding, including byte-fallback cases and regex-split-dependent token boundaries.
- **Applies to:**
  - `tests/test_encoding.py`
- **Condition:** When modifying or adding exact tokenization tests or the encoding implementation.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_simple asserts exact token IDs such as enc.encode('hello world') == [31373, 995] and [15339, 1917], conforming to the exact tokenization rule.
```

- **Sources:**
  - `tests/test_encoding.py:14-28`

### Evidence 2 — current_observation

```text
test_simple_repeated asserts exact token ID lists for specific strings under gpt2, e.g. encode('0') == [15] and encode('000000000') == [10535, 830], matching the exact-tokenization contract.
```

- **Sources:**
  - `tests/test_encoding.py:31-49`

### Evidence 3 — current_observation

```text
test_simple_regex asserts exact token ID lists for specific strings under cl100k_base, conforming to the exact tokenization contract.
```

- **Sources:**
  - `tests/test_encoding.py:52-58`

### Evidence 4 — current_observation

```text
test_encode_surrogate_pairs asserts exact token IDs for specific strings, e.g. enc.encode("👍") == [9468, 239, 235].
```

- **Sources:**
  - `tests/test_encoding.py:94-102`
