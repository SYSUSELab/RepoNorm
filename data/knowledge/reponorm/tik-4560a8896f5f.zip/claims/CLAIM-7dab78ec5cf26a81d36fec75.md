# Rule details

- **Rule:**
  ```text
  The `python` feature enables the `pyo3` dependency.
  ```
- **Applies to:**
  - `Cargo.toml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
python = [
    "pyo3",
]

```

- **Sources:**
  - `Cargo.toml:13-15`
