# Rule details

- **Rule:** The public package surface must be validated through subprocess execution, and importing tiktoken must not eagerly import optional dependencies such as blobfile into sys.modules.
- **Applies to:**
  - `tests/test_simple_public.py`
- **Condition:** When modifying package import-time behavior or adding optional dependencies to the tiktoken package.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
tests/test_simple_public.py uses subprocess to import tiktoken and assert that optional dependencies like blobfile are absent from sys.modules.
```

- **Sources:**
  - `tests/test_simple_public.py`
