# Rule details

- **Rule:**
  ```text
  encoding_for_model must delegate to encoding_name_for_model and must raise KeyError for an unrecognized model name rather than returning a default encoding.
  ```
- **Applies to:**
  - `tiktoken/model.py`
- **Condition:**
  ```text
  When modifying encoding_for_model's model-name resolution or error behavior for unrecognized models.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
encoding_for_model delegates to encoding_name_for_model and returns get_encoding(...), so an unrecognized model name raises KeyError from the helper rather than returning a default encoding.
```

- **Sources:**
  - `tiktoken/model.py:105-110`
