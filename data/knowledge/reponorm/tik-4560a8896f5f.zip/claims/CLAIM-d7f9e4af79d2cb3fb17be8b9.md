# Rule details

- **Rule:**
  ```text
  read_file_cached must write via a uuid-suffixed temp file then os.rename; if writing to the cache fails with OSError it must only re-raise when the cache dir was user-specified, otherwise silently return the contents (referencing issue #75).
  ```
- **Applies to:**
  - `tiktoken/load.py`
- **Condition:**
  ```text
  When modifying read_file_cached's cache write error handling or temp-file write strategy.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
read_file_cached writes via a uuid-suffixed temp file then os.rename, and on OSError only re-raises when the cache dir was user-specified, otherwise silently returns the contents.
```

- **Sources:**
  - `tiktoken/load.py:32-83`
