# Rule details

- **Rule:**
  ```text
  Encoding.encode_to_numpy must return a numpy uint32 array built via np.frombuffer over the core BPE buffer, avoiding a copy into a Python list, with numpy imported lazily inside the method.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  When modifying Encoding.encode_to_numpy's return type or numpy import strategy.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The method imports numpy lazily inside the body and returns np.frombuffer(buffer, dtype=np.uint32) over the core BPE buffer, matching the zero-copy uint32 contract.
```

- **Sources:**
  - `tiktoken/core.py:135-159`
