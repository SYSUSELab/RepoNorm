# Rule details

- **Rule:**
  ```text
  Test helpers must define MAX_EXAMPLES from the TIKTOKEN_MAX_EXAMPLES environment variable (default 100) and provide ENCODINGS/SOME_ENCODINGS lists and pytest.param factories for supported encodings.
  ```
- **Applies to:**
  - `tests/test_helpers.py`
- **Condition:** When modifying or adding test helper configuration for encoding parametrization.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
tests/test_helpers.py defines MAX_EXAMPLES from TIKTOKEN_MAX_EXAMPLES with default 100, ENCODINGS/SOME_ENCODINGS lists, and pytest.param factories for encodings, matching the test-helper configuration rule.
```

- **Sources:**
  - `tests/test_helpers.py`
