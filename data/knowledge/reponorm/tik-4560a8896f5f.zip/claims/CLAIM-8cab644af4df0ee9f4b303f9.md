# Rule details

- **Rule:**
  ```text
  Encoding.encode_to_numpy must normalize allowed_special="all" to the encoding's special_tokens_set and disallowed_special="all" to special_tokens_set minus allowed_special, raising via raise_disallowed_special_token when a disallowed special token appears in the text.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  when modifying Encoding.encode_to_numpy or its special-token normalization
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
Encoding.encode_to_numpy normalizes allowed_special="all" to special_tokens_set and disallowed_special="all" to special_tokens_set minus allowed_special, and raises via raise_disallowed_special_token when a disallowed special token matches.
```

- **Sources:**
  - `tiktoken/core.py:135-159`
