# Rule details

- **Rule:**
  ```text
  Keep the tiktoken._tiktoken Rust extension built through setuptools_rust with Binding.PyO3 and debug=False; the build must always use the release profile because editable installs and performance-sensitive Rust code depend on it.
  ```
- **Applies to:**
  - `setup.py`
- **Condition:**
  ```text
  When modifying the Rust extension build configuration in setup.py, such as changing the setuptools_rust binding, debug flag, or release-profile behavior.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
setup.py configures the tiktoken._tiktoken Rust extension via setuptools_rust with Binding.PyO3 and debug=False, with a comment that --release is always used.
```

- **Sources:**
  - `setup.py`
