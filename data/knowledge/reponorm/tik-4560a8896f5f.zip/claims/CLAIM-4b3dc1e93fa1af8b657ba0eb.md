# Rule details

- **Rule:**
  ```text
  SimpleBytePairEncoding.__init__ must store pat_str and mergeable_ranks, build a reverse _decoder mapping token bytes to token id, and compile the pattern with regex.compile.
  ```
- **Applies to:**
  - `tiktoken/_educational.py`
- **Condition:**
  ```text
  when modifying SimpleBytePairEncoding.__init__ or its decoder/pattern setup
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
SimpleBytePairEncoding.__init__ stores pat_str and mergeable_ranks, builds the reverse _decoder mapping, and compiles the pattern with regex.compile.
```

- **Sources:**
  - `tiktoken/_educational.py:13-21`
