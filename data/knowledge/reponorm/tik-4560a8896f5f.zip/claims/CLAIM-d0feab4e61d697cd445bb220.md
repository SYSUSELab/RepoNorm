# Rule details

- **Rule:**
  ```text
  SimpleBytePairEncoding.train must be a staticmethod that runs bpe_train on the given data/vocab_size/pat_str and returns a new SimpleBytePairEncoding, providing a training entry point distinct from the production encodings.
  ```
- **Applies to:**
  - `tiktoken/_educational.py`
- **Condition:** When modifying SimpleBytePairEncoding.train's training entry point or return value.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
SimpleBytePairEncoding.train is a staticmethod that runs bpe_train on the given data/vocab_size/pat_str and returns a new SimpleBytePairEncoding.
```

- **Sources:**
  - `tiktoken/_educational.py:69-72`
