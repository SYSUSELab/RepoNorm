# Rule details

- **Rule:**
  ```text
  Tests that assert equivalence between encode_ordinary(text) and encode(text, disallowed_special=()) must preserve that equivalence for arbitrary text, since ordinary encoding is defined as the special-token-disallowed path.
  ```
- **Applies to:**
  - `tests/test_encoding.py`
- **Condition:**
  ```text
  When modifying or adding property tests that compare encode_ordinary output with encode(..., disallowed_special=()) output.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_hyp_special_ordinary asserts enc.encode_ordinary(text) == enc.encode(text, disallowed_special=()) over arbitrary hypothesis text, exactly the encode_ordinary/disallowed_special equivalence contract.
```

- **Sources:**
  - `tests/test_encoding.py:221-223`
