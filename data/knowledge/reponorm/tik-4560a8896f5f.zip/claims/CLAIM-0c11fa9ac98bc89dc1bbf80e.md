# Rule details

- **Rule:**
  ```text
  encoding_name_for_model must first check exact MODEL_TO_ENCODING membership, then fall back to prefix matching against MODEL_PREFIX_TO_ENCODING, accepting that prefix matching can match non-existent models to avoid library updates per model release.
  ```
- **Applies to:**
  - `tiktoken/model.py`
- **Condition:**
  ```text
  when modifying encoding_name_for_model or the model-to-encoding lookup tables
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
encoding_name_for_model checks exact MODEL_TO_ENCODING membership first, then falls back to prefix matching against MODEL_PREFIX_TO_ENCODING.
```

- **Sources:**
  - `tiktoken/model.py:80-102`
