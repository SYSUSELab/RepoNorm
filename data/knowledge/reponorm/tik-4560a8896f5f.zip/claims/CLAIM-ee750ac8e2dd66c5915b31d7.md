# Rule details

- **Rule:**
  ```text
  decode_with_offsets must return character offsets into the decoded text that match the canonical reference offset implementation, including repeated offsets when a token spans partial characters.
  ```
- **Applies to:**
  - `tests/test_offsets.py`
- **Condition:**
  ```text
  When modifying or adding offset decoding tests or the decode_with_offsets implementation.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_hyp_offsets asserts that decode_with_offsets(tokens)[1] equals the canonical _token_offsets_reference(enc, tokens), exercising offset semantics against the reference implementation.
```

- **Sources:**
  - `tests/test_offsets.py:31-46`

### Evidence 2 — current_observation

```text
test_basic_offsets asserts exact decode_with_offsets character offset lists, including repeated offsets for partial-character tokens.
```

- **Sources:**
  - `tests/test_offsets.py:49-79`
