# Rule details

- **Rule:**
  ```text
  get_encoding must validate the name is a string, return cached ENCODINGS entries, and under a lock lazily call _find_constructors; unknown names must raise ValueError including available plugin modules and tiktoken version.
  ```
- **Applies to:**
  - `tiktoken/registry.py`
- **Condition:**
  ```text
  When modifying get_encoding's name validation, caching, lazy constructor lookup, or unknown-name error message.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
get_encoding validates the name is a string, returns cached ENCODINGS entries, lazily calls _find_constructors under a lock, and raises ValueError including available plugin modules and tiktoken version for unknown names.
```

- **Sources:**
  - `tiktoken/registry.py:63-88`
