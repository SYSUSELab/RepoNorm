# Rule details

- **Rule:**
  ```text
  scripts/benchmark.py must keep benchmark_batch comparing tiktoken against HuggingFace GPT2TokenizerFast on the same documents, setting hf_enc.model_max_length = 1e30 to silence length warnings before timing.
  ```
- **Applies to:**
  - `scripts/benchmark.py`
- **Condition:**
  ```text
  When modifying benchmark_batch's tokenizer comparison or timing setup in scripts/benchmark.py, preserve the tiktoken-vs-HuggingFace comparison and the hf_enc.model_max_length = 1e30 warning suppression.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
benchmark_batch compares tiktoken's encoder against HuggingFace GPT2TokenizerFast on the same documents and sets hf_enc.model_max_length = 1e30 before timing.
```

- **Sources:**
  - `scripts/benchmark.py:15-37`
