# Rules for `scripts/benchmark.py`

## Rule 033 — `scripts/benchmark.py`

- **Rule:**
  ```text
  scripts/benchmark.py must keep benchmark_batch's thread count driven by the RAYON_NUM_THREADS environment variable and passed as num_threads to encode_ordinary_batch, so benchmark timing reflects the configured Rust rayon pool.
  ```
- **Applies to:**
  - `scripts/benchmark.py`
- **Condition:**
  ```text
  When modifying benchmark_batch or its batch-encoding call in scripts/benchmark.py, preserve the RAYON_NUM_THREADS-derived num_threads argument.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-6bf4fb257099036059d0a589.md)

## Rule 060 — `scripts/benchmark.py`

- **Rule:**
  ```text
  scripts/benchmark.py must keep benchmark_batch comparing tiktoken against HuggingFace GPT2TokenizerFast on the same documents, setting hf_enc.model_max_length = 1e30 to silence length warnings before timing.
  ```
- **Applies to:**
  - `scripts/benchmark.py`
- **Condition:**
  ```text
  When modifying benchmark_batch's tokenizer comparison or timing setup in scripts/benchmark.py, preserve the tiktoken-vs-HuggingFace comparison and the hf_enc.model_max_length = 1e30 warning suppression.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-c4436d5f4c0c03e207ddff98.md)

## Rule 062 — `scripts/benchmark.py`

- **Rule:** scripts/benchmark.py must keep its dependency on the optional blobfile package alongside tiktoken, so the benchmark harness continues to import blobfile for its blob-file handling.
- **Applies to:**
  - `scripts/benchmark.py`
- **Condition:** When modifying scripts/benchmark.py imports or dependency handling, preserve the blobfile import alongside tiktoken.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-d23b86a8bdf368d1a2217ec4.md)
