# Rules for `scripts/redact.py`

## Rule 007 — `scripts/redact.py`

- **Rule:** scripts/redact.py main() must keep --dry-run defaulting to True and printing a message instructing use of --dry-run=false to actually redact files, so redaction is opt-in.
- **Applies to:**
  - `scripts/redact.py`
- **Condition:** When modifying main()'s argument parsing or user messaging in scripts/redact.py, preserve the --dry-run default of True and the instruction to pass --dry-run=false to actually redact.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-11bc840573a51af46c99b0bd.md)

## Rule 039 — `scripts/redact.py`

- **Rule:**
  ```text
  scripts/redact.py must keep redact_file deleting any file whose first line contains 'redact' and otherwise stripping content between redact-beg/redact-end markers (both '#' and HTML comment forms) by splitting on the marker regex and keeping even-indexed segments, with dry_run suppressing all writes/deletes.
  ```
- **Applies to:**
  - `scripts/redact.py`
- **Condition:**
  ```text
  When modifying redact_file's file-selection or marker-stripping logic in scripts/redact.py, preserve the first-line 'redact' deletion rule, the redact-beg/redact-end marker stripping for both comment forms, and dry_run write suppression.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-7f58ee2b89815cb85dbe0e0f.md)
