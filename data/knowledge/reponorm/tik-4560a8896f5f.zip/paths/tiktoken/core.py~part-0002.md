# Rules for `tiktoken/core.py`

## Rule 059 — `tiktoken/core.py`

- **Rule:**
  ```text
  Encoding.decode_with_offsets must return (text, offsets) where each offset is the index into text of the first character containing bytes from that token, clamping to the first character containing the token's bytes when UTF-8 character boundaries do not align with token boundaries.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  When modifying decode_with_offsets or its offset computation, preserve the first-character-containing-token-bytes semantics and clamping behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-c1f21a1fe9440dc52e817e35.md)

## Rule 063 — `tiktoken/core.py`

- **Rule:**
  ```text
  Encoding.decode_single_token_bytes must decode all special tokens and raise KeyError when the token is not in the vocabulary.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  When modifying decode_single_token_bytes or the underlying token-to-bytes mapping, preserve special-token decoding and KeyError on unknown tokens.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-d32a0494279c44fb86e89444.md)

## Rule 064 — `tiktoken/core.py`

- **Rule:**
  ```text
  Encoding.__init__ must compute max_token_value as the max over mergeable_ranks and special_tokens values, and when explicit_n_vocab is provided assert len(mergeable_ranks)+len(special_tokens)==explicit_n_vocab and max_token_value==explicit_n_vocab-1.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  When modifying Encoding.__init__ or vocabulary composition, preserve the explicit_n_vocab consistency assertions and max_token_value computation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-d542bf54b9d106fa7b49a03d.md)

## Rule 065 — `tiktoken/core.py`

- **Rule:**
  ```text
  Encoding._encode_single_piece must encode text corresponding to bytes without a regex split and must not encode any special tokens.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  When modifying Encoding._encode_single_piece's encoding behavior or special-token handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-d7859b1197a20afefc155b71.md)

## Rule 069 — `tiktoken/core.py`

- **Rule:**
  ```text
  Encoding._encode_only_native_bpe must perform regex splitting in Python by compiling self._pat_str and using regex.findall, then call the core BPE encode_single_piece per piece, serving as the pure-Python reference path distinct from the native encode.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  when modifying Encoding._encode_only_native_bpe or the pure-Python reference path
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-de390bbc9b207624c7d977a0.md)

## Rule 082 — `tiktoken/core.py`

- **Rule:**
  ```text
  Encoding.encode must default to disallowed_special='all' and raise on text matching a disallowed special token; allowed_special='all' treats all special-token text as special tokens, disallowed_special=() encodes them as natural text, and UnicodeEncodeError triggers a utf-16 surrogatepass/replace fallback.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  When modifying Encoding.encode or its special-token handling, preserve the default disallowed_special='all' behavior, allowed_special='all' semantics, disallowed_special=() behavior, and UnicodeEncodeError fallback.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-f65d28f284675416a3202eb1.md)
