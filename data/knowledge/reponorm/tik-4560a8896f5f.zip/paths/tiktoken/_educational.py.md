# Rules for `tiktoken/_educational.py`

## Rule 004 — `tiktoken/_educational.py`

- **Rule:**
  ```text
  SimpleBytePairEncoding.from_tiktoken must accept either an encoding name string or an Encoding instance and construct the educational BPE from the encoding's _pat_str and _mergeable_ranks, bridging production and educational implementations.
  ```
- **Applies to:**
  - `tiktoken/_educational.py`
- **Condition:**
  ```text
  when modifying SimpleBytePairEncoding.from_tiktoken or its input handling
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-0afe16422e534a9c40d801b8.md)

## Rule 025 — `tiktoken/_educational.py`

- **Rule:**
  ```text
  SimpleBytePairEncoding.__init__ must store pat_str and mergeable_ranks, build a reverse _decoder mapping token bytes to token id, and compile the pattern with regex.compile.
  ```
- **Applies to:**
  - `tiktoken/_educational.py`
- **Condition:**
  ```text
  when modifying SimpleBytePairEncoding.__init__ or its decoder/pattern setup
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-4b3dc1e93fa1af8b657ba0eb.md)

## Rule 035 — `tiktoken/_educational.py`

- **Rule:**
  ```text
  bpe_train must repeatedly find the most common adjacent byte pair via collections.Counter, assign it the next token id (len(ranks)), merge it across all words, and loop until len(ranks) reaches vocab_size, with the visualise parameter controlling optional debug printing.
  ```
- **Applies to:**
  - `tiktoken/_educational.py`
- **Condition:**
  ```text
  when modifying bpe_train or its merge loop and vocab_size termination
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-6ded60e59e6d3953335f0b32.md)

## Rule 045 — `tiktoken/_educational.py`

- **Rule:**
  ```text
  tiktoken/_educational.py must remain an explicitly documented educational implementation of the byte pair encoding algorithm, distinct from the production Rust-backed core.
  ```
- **Applies to:**
  - `tiktoken/_educational.py`
- **Condition:**
  ```text
  when modifying tiktoken/_educational.py or its documented purpose
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-8a2786ec2879aadababcbdd3.md)

## Rule 061 — `tiktoken/_educational.py`

- **Rule:**
  ```text
  SimpleBytePairEncoding.train must be a staticmethod that runs bpe_train on the given data/vocab_size/pat_str and returns a new SimpleBytePairEncoding, providing a training entry point distinct from the production encodings.
  ```
- **Applies to:**
  - `tiktoken/_educational.py`
- **Condition:** When modifying SimpleBytePairEncoding.train's training entry point or return value.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-d0feab4e61d697cd445bb220.md)

## Rule 080 — `tiktoken/_educational.py`

- **Rule:**
  ```text
  SimpleBytePairEncoding.decode_bytes must concatenate per-token byte values from the decoder table and return bytes, preserving the byte-level decoding contract (e.g., decode_bytes([388, 372]) == b'hello world').
  ```
- **Applies to:**
  - `tiktoken/_educational.py`
- **Condition:**
  ```text
  when modifying SimpleBytePairEncoding.decode_bytes or the decoder table
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-f31a3f2c133c1e27040eae98.md)

## Rule 083 — `tiktoken/_educational.py`

- **Rule:**
  ```text
  SimpleBytePairEncoding.encode must split text with the pattern regex, encode each word's UTF-8 bytes via bpe_encode, and accept a visualise parameter defaulting to 'colour' for the educational BPE path.
  ```
- **Applies to:**
  - `tiktoken/_educational.py`
- **Condition:** When modifying SimpleBytePairEncoding.encode's encoding behavior or visualise parameter.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-fc0d02326b76d23ca4015bc9.md)
