# Rules for `tiktoken/core.py`

## Rule 010 — `tiktoken/core.py`

- **Rule:**
  ```text
  Encoding.decode_bytes_batch must decode a batch of token sequences using a ThreadPoolExecutor with a default num_threads of 8.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  When modifying Encoding.decode_bytes_batch's concurrency or default thread count.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-19ce06784434281a6ece20ed.md)

## Rule 013 — `tiktoken/core.py`

- **Rule:**
  ```text
  Encoding.encode_batch must resolve allowed_special='all' to the encoding's special_tokens_set and disallowed_special='all' to special_tokens_set minus allowed_special, coerce disallowed_special to a frozenset, and encode in parallel with default num_threads=8.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  When modifying Encoding.encode_batch's special-token resolution or parallel encoding defaults.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-2286ecfbdcf0fb215794bc5e.md)

## Rule 023 — `tiktoken/core.py`

- **Rule:**
  ```text
  Encoding.decode_batch must decode a list of token lists in parallel using a ThreadPoolExecutor with default num_threads=8 and pass the configurable errors policy through to decode.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  when modifying Encoding.decode_batch or its threading/error-policy parameters
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-3cb0e6afd15009c806938f15.md)

## Rule 024 — `tiktoken/core.py`

- **Rule:** Encoding.decode must keep errors='replace' as the default lossy behavior; callers needing exact byte roundtrips must pass errors='strict', so any change to the default or to the documented lossiness contract is a compatibility break.
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:** When modifying Encoding.decode's error-handling default or its documented roundtrip guarantees.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-474f5b1881dcb8a3c64dd939.md)

## Rule 027 — `tiktoken/core.py`

- **Rule:**
  ```text
  Encoding.encode_ordinary_batch must encode a list of strings in parallel with default num_threads=8, ignoring special tokens, and remain equivalent to encode_batch(text, disallowed_special=()) but slightly faster.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  When modifying Encoding.encode_ordinary_batch's parallel encoding behavior or special-token handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-54cfaa149af1b8155fbbe39f.md)

## Rule 029 — `tiktoken/core.py`

- **Rule:**
  ```text
  Encoding.encode_to_numpy must return a numpy uint32 array built via np.frombuffer over the core BPE buffer, avoiding a copy into a Python list, with numpy imported lazily inside the method.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  When modifying Encoding.encode_to_numpy's return type or numpy import strategy.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-57b45a1fbdb8b1a6537caebc.md)

## Rule 031 — `tiktoken/core.py`

- **Rule:**
  ```text
  Encoding.decode_with_offsets must currently raise on tokens that decode to invalid UTF-8 because it decodes with errors='strict'; this behavior may change to be more permissive in the future.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  When modifying Encoding.decode_with_offsets's error handling for invalid UTF-8 tokens.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-672dde761fdfd689aa894583.md)

## Rule 032 — `tiktoken/core.py`

- **Rule:**
  ```text
  Encoding.__repr__ must return '<Encoding {name!r}>'.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  when modifying Encoding.__repr__ or the Encoding name attribute
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-69150f7e371c6eb0e16e8ca7.md)

## Rule 042 — `tiktoken/core.py`

- **Rule:**
  ```text
  Encoding.n_vocab must remain a backwards-compatibility alias equal to max_token_value + 1; new code should use enc.max_token_value + 1 instead of relying on n_vocab.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  When modifying Encoding vocabulary-size or max-token-value computation, preserve n_vocab as max_token_value + 1 for backwards compatibility.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-84559a4933f8f9a5c03cebb8.md)

## Rule 046 — `tiktoken/core.py`

- **Rule:**
  ```text
  Encoding.encode_to_numpy must normalize allowed_special="all" to the encoding's special_tokens_set and disallowed_special="all" to special_tokens_set minus allowed_special, raising via raise_disallowed_special_token when a disallowed special token appears in the text.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  when modifying Encoding.encode_to_numpy or its special-token normalization
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-8cab644af4df0ee9f4b303f9.md)

## Rule 047 — `tiktoken/core.py`

- **Rule:**
  ```text
  Encoding.__setstate__ must restore a registered encoding by name via tiktoken.registry.get_encoding (copying its __dict__) when the pickled value is a string, otherwise re-initialize from the dict form, matching the __getstate__ optimization.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  When modifying Encoding.__setstate__ or pickle handling, preserve the string-name registry lookup and dict-form re-initialization paths.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-9b02c70edaa1cc87d2a08ece.md)

## Rule 049 — `tiktoken/core.py`

- **Rule:**
  ```text
  raise_disallowed_special_token must raise ValueError with remediation guidance: pass allowed_special, set disallowed_special to special_tokens_set minus the token, or use disallowed_special=() to disable checks.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  When modifying raise_disallowed_special_token or its error message, preserve ValueError and the documented remediation options.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-a7d421321383b8fa05a43d33.md)

## Rule 051 — `tiktoken/core.py`

- **Rule:**
  ```text
  Encoding.encode_single_token must encode text or bytes corresponding to a single token, encode all special tokens, and raise KeyError when the token is not in the vocabulary.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  when modifying Encoding.encode_single_token or its vocabulary lookup
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-a8e66a85aeba244f01bc47b7.md)

## Rule 054 — `tiktoken/core.py`

- **Rule:**
  ```text
  Encoding.is_special_token must assert the token is an int and return membership in _special_token_values, so special-token detection is based on the set of special token values rather than token text.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  When modifying is_special_token or special-token membership, preserve the int assertion and value-set-based detection.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-b9c827766f050461a5090c10.md)
