# Rules for `tiktoken/load.py`

## Rule 006 — `tiktoken/load.py`

- **Rule:**
  ```text
  read_file_cached must key its cache by sha1 of the blobpath, validate cached data against expected_hash, delete and re-fetch on mismatch, and raise ValueError on a hash mismatch of freshly downloaded contents.
  ```
- **Applies to:**
  - `tiktoken/load.py`
- **Condition:**
  ```text
  When modifying read_file_cached or changing its cache key, hash validation, or mismatch handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-105b05dde407ac10943c2ba7.md)

## Rule 016 — `tiktoken/load.py`

- **Rule:**
  ```text
  read_file must use blobfile for non-http(s) paths (raising ImportError with install guidance if blobfile is missing) but deliberately use requests for http(s) URLs to avoid auth issues such as MFA prompts.
  ```
- **Applies to:**
  - `tiktoken/load.py`
- **Condition:**
  ```text
  When modifying read_file or its path handling, preserve blobfile for non-http(s) paths and requests for http(s) URLs.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-2c4a743e6db808d53410974a.md)

## Rule 017 — `tiktoken/load.py`

- **Rule:**
  ```text
  dump_tiktoken_bpe must require the optional blobfile dependency (raising ImportError with an install hint otherwise) and write tokens sorted by rank as base64-encoded token plus rank per line, matching the load_tiktoken_bpe format.
  ```
- **Applies to:**
  - `tiktoken/load.py`
- **Condition:**
  ```text
  When modifying dump_tiktoken_bpe or its serialization format, preserve the blobfile dependency check and the rank-sorted base64 token+rank line format.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-3029846aff864f7d6bc754e8.md)

## Rule 019 — `tiktoken/load.py`

- **Rule:**
  ```text
  data_gym_to_mergeable_bpe_ranks must build a printable-byte rank table and assert the reconstructed bpe_ranks exactly equals the encoder_json mapping after dropping <|endoftext|> and <|startoftext|>, because tiktoken assumes ranks are ordered the same as merge priority.
  ```
- **Applies to:**
  - `tiktoken/load.py`
- **Condition:**
  ```text
  When modifying data_gym_to_mergeable_bpe_ranks or its rank reconstruction, preserve the exact-equality sanity check and the rank/merge-priority ordering assumption.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-31ebd8af51867f629d28ac10.md)

## Rule 020 — `tiktoken/load.py`

- **Rule:**
  ```text
  read_file_cached must select the cache directory from TIKTOKEN_CACHE_DIR, then DATA_GYM_CACHE_DIR, else a tempdir/data-gym-cache default; an empty cache_dir string disables caching entirely and falls back to read_file.
  ```
- **Applies to:**
  - `tiktoken/load.py`
- **Condition:**
  ```text
  When modifying read_file_cached's cache directory selection or empty-string caching disable behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-3a4d9330776056236e125e6a.md)

## Rule 021 — `tiktoken/load.py`

- **Rule:**
  ```text
  load_tiktoken_bpe must not add caching, must read via read_file_cached with optional expected_hash, must skip blank lines, and must wrap any per-line parse failure in a ValueError naming the offending line and file.
  ```
- **Applies to:**
  - `tiktoken/load.py`
- **Condition:**
  ```text
  when modifying load_tiktoken_bpe or its line parsing and error reporting
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-3a865982795e1f2bf627c7cf.md)

## Rule 043 — `tiktoken/load.py`

- **Rule:**
  ```text
  decode_data_gym must map each character of a data-gym encoded string back to its byte via data_gym_byte_to_byte.
  ```
- **Applies to:**
  - `tiktoken/load.py`
- **Condition:**
  ```text
  when modifying decode_data_gym or the data-gym byte mapping
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-84eefc0898f3815f9796e72c.md)

## Rule 057 — `tiktoken/load.py`

- **Rule:** tiktoken/load.py must import base64, hashlib, and os, covering hashing and base64 decoding of downloaded encoding data.
- **Applies to:**
  - `tiktoken/load.py`
- **Condition:** When modifying tiktoken/load.py's imports or responsibilities for hashing and base64 decoding.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-c0103c5367aa0be07d2e2713.md)

## Rule 066 — `tiktoken/load.py`

- **Rule:**
  ```text
  read_file_cached must write via a uuid-suffixed temp file then os.rename; if writing to the cache fails with OSError it must only re-raise when the cache dir was user-specified, otherwise silently return the contents (referencing issue #75).
  ```
- **Applies to:**
  - `tiktoken/load.py`
- **Condition:**
  ```text
  When modifying read_file_cached's cache write error handling or temp-file write strategy.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-d7f9e4af79d2cb3fb17be8b9.md)

## Rule 070 — `tiktoken/load.py`

- **Rule:**
  ```text
  check_hash must compare the sha256 hexdigest of the given bytes against expected_hash and return a bool, providing the integrity check used by load_tiktoken_bpe.
  ```
- **Applies to:**
  - `tiktoken/load.py`
- **Condition:**
  ```text
  When modifying check_hash or its integrity check, preserve sha256 hexdigest comparison and boolean return.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-de71b8f38b189568b65f4dc4.md)
