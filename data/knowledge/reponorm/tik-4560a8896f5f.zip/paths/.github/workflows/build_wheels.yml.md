# Rules for `.github/workflows/build_wheels.yml`

## Rule 003 — `.github/workflows/build_wheels.yml`

- **Rule:**
  ```text
  The build_wheels job uses pypa/cibuildwheel@v2.22.0 with CIBW_BUILD set to cp${{ matrix.python-version}}-*.
  ```
- **Applies to:**
  - `.github/workflows/build_wheels.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0909c12d17ebaca110754617.md)

## Rule 012 — `.github/workflows/build_wheels.yml`

- **Rule:**
  ```text
  The build_sdist job runs check-manifest -v after installing check-manifest.
  ```
- **Applies to:**
  - `.github/workflows/build_wheels.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-21fd53bcccfb02fecb49c606.md)

## Rule 030 — `.github/workflows/build_wheels.yml`

- **Rule:**
  ```text
  The build_wheels_aarch64 job uses pypa/cibuildwheel@v2.22.0 with CIBW_ARCHS set to aarch64.
  ```
- **Applies to:**
  - `.github/workflows/build_wheels.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-57b7a144dbee0ca3bd21e3c1.md)

## Rule 036 — `.github/workflows/build_wheels.yml`

- **Rule:**
  ```text
  The join_artifacts job merges artifacts matching pattern cibw-wheels-* into an artifact named cibw-wheels and deletes the merged artifacts.
  ```
- **Applies to:**
  - `.github/workflows/build_wheels.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6f237f9ae682e85c96609612.md)

## Rule 048 — `.github/workflows/build_wheels.yml`

- **Rule:**
  ```text
  The build_sdist job builds the sdist with python -m build --sdist after upgrading the build package.
  ```
- **Applies to:**
  - `.github/workflows/build_wheels.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a227d660302e23009b143c38.md)
