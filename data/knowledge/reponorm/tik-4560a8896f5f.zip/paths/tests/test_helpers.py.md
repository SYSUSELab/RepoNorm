# Rules for `tests/test_helpers.py`

## Rule 034 — `tests/test_helpers.py`

- **Rule:**
  ```text
  Test helpers must define MAX_EXAMPLES from the TIKTOKEN_MAX_EXAMPLES environment variable (default 100) and provide ENCODINGS/SOME_ENCODINGS lists and pytest.param factories for supported encodings.
  ```
- **Applies to:**
  - `tests/test_helpers.py`
- **Condition:** When modifying or adding test helper configuration for encoding parametrization.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-6dd8e2ae29bf99c44eba75f4.md)
