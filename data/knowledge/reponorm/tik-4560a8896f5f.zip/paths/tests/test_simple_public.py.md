# Rules for `tests/test_simple_public.py`

## Rule 073 — `tests/test_simple_public.py`

- **Rule:** The public package surface must be validated through subprocess execution, and importing tiktoken must not eagerly import optional dependencies such as blobfile into sys.modules.
- **Applies to:**
  - `tests/test_simple_public.py`
- **Condition:** When modifying package import-time behavior or adding optional dependencies to the tiktoken package.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-e03e59afbb7a1e99795e3dde.md)
