# Rules for `tests/test_misc.py`

## Rule 014 — `tests/test_misc.py`

- **Rule:**
  ```text
  The model-to-encoding mapping must be pinned in tests: gpt2->gpt2, text-davinci-003->p50k_base, text-davinci-edit-001->p50k_edit, gpt-3.5-turbo-0301 and gpt-4->cl100k_base, gpt-4o->o200k_base.
  ```
- **Applies to:**
  - `tests/test_misc.py`
- **Condition:**
  ```text
  When modifying the encoding_for_model mapping or adding new model names.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-234307d0a931c39b78a7c874.md)

## Rule 058 — `tests/test_misc.py`

- **Rule:** Importing tiktoken must not eagerly import the optional blobfile dependency into sys.modules.
- **Applies to:**
  - `tests/test_misc.py`
- **Condition:** When modifying or adding tests that check optional dependency isolation or the package import behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-c09f8ffa8abab9a9a9856267.md)
