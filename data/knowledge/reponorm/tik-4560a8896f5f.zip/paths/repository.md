# Rules for `repository root`

## Rule 011 — `**/*.rs`

- **Rule:** The crate declares a minimum supported Rust version of 1.57.0.
- **Applies to:**
  - `**/*.rs`
  - `Cargo.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1fed6dca8794f8d1da59e65c.md)

## Rule 026 — `**/*.rs`

- **Rule:** The crate is built with Rust edition 2021.
- **Applies to:**
  - `**/*.rs`
  - `Cargo.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-509109c529bf9054b771db1a.md)

## Rule 041 — `**/*.py`

- **Rule:**
  ```text
  The project declares a minimum supported Python version of 3.9 via requires-python = ">=3.9".
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8412e9d3f9b891eb7918bb10.md)
