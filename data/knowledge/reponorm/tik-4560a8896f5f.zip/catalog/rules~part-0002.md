# Full rule catalog

## Rule 017 — `tiktoken/load.py`

- **Rule:**
  ```text
  dump_tiktoken_bpe must require the optional blobfile dependency (raising ImportError with an install hint otherwise) and write tokens sorted by rank as base64-encoded token plus rank per line, matching the load_tiktoken_bpe format.
  ```
- **Applies to:**
  - `tiktoken/load.py`
- **Condition:**
  ```text
  When modifying dump_tiktoken_bpe or its serialization format, preserve the blobfile dependency check and the rank-sorted base64 token+rank line format.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3029846aff864f7d6bc754e8.md)

## Rule 018 — `tests/test_encoding.py`

- **Rule:** Encoding must handle surrogate pairs and lone surrogates consistently: surrogate-pair form encodes identically to the emoji, and a lone surrogate encodes the same as the replacement character.
- **Applies to:**
  - `tests/test_encoding.py`
- **Condition:** When modifying or adding surrogate handling tests or the encoding implementation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-30d17432315ee9909f221a91.md)

## Rule 019 — `tiktoken/load.py`

- **Rule:**
  ```text
  data_gym_to_mergeable_bpe_ranks must build a printable-byte rank table and assert the reconstructed bpe_ranks exactly equals the encoder_json mapping after dropping <|endoftext|> and <|startoftext|>, because tiktoken assumes ranks are ordered the same as merge priority.
  ```
- **Applies to:**
  - `tiktoken/load.py`
- **Condition:**
  ```text
  When modifying data_gym_to_mergeable_bpe_ranks or its rank reconstruction, preserve the exact-equality sanity check and the rank/merge-priority ordering assumption.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-31ebd8af51867f629d28ac10.md)

## Rule 020 — `tiktoken/load.py`

- **Rule:**
  ```text
  read_file_cached must select the cache directory from TIKTOKEN_CACHE_DIR, then DATA_GYM_CACHE_DIR, else a tempdir/data-gym-cache default; an empty cache_dir string disables caching entirely and falls back to read_file.
  ```
- **Applies to:**
  - `tiktoken/load.py`
- **Condition:**
  ```text
  When modifying read_file_cached's cache directory selection or empty-string caching disable behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3a4d9330776056236e125e6a.md)

## Rule 021 — `tiktoken/load.py`

- **Rule:**
  ```text
  load_tiktoken_bpe must not add caching, must read via read_file_cached with optional expected_hash, must skip blank lines, and must wrap any per-line parse failure in a ValueError naming the offending line and file.
  ```
- **Applies to:**
  - `tiktoken/load.py`
- **Condition:**
  ```text
  when modifying load_tiktoken_bpe or its line parsing and error reporting
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3a865982795e1f2bf627c7cf.md)

## Rule 022 — `tests/test_encoding.py`

- **Rule:** Encoding must produce exact token IDs for specific strings under each encoding, including byte-fallback cases and regex-split-dependent token boundaries.
- **Applies to:**
  - `tests/test_encoding.py`
- **Condition:** When modifying or adding exact tokenization tests or the encoding implementation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3afbb004120bb974c28ac75c.md)

## Rule 023 — `tiktoken/core.py`

- **Rule:**
  ```text
  Encoding.decode_batch must decode a list of token lists in parallel using a ThreadPoolExecutor with default num_threads=8 and pass the configurable errors policy through to decode.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  when modifying Encoding.decode_batch or its threading/error-policy parameters
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3cb0e6afd15009c806938f15.md)

## Rule 024 — `tiktoken/core.py`

- **Rule:** Encoding.decode must keep errors='replace' as the default lossy behavior; callers needing exact byte roundtrips must pass errors='strict', so any change to the default or to the documented lossiness contract is a compatibility break.
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:** When modifying Encoding.decode's error-handling default or its documented roundtrip guarantees.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-474f5b1881dcb8a3c64dd939.md)

## Rule 025 — `tiktoken/_educational.py`

- **Rule:**
  ```text
  SimpleBytePairEncoding.__init__ must store pat_str and mergeable_ranks, build a reverse _decoder mapping token bytes to token id, and compile the pattern with regex.compile.
  ```
- **Applies to:**
  - `tiktoken/_educational.py`
- **Condition:**
  ```text
  when modifying SimpleBytePairEncoding.__init__ or its decoder/pattern setup
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-4b3dc1e93fa1af8b657ba0eb.md)

## Rule 026 — `**/*.rs`

- **Rule:** The crate is built with Rust edition 2021.
- **Applies to:**
  - `**/*.rs`
  - `Cargo.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-509109c529bf9054b771db1a.md)

## Rule 027 — `tiktoken/core.py`

- **Rule:**
  ```text
  Encoding.encode_ordinary_batch must encode a list of strings in parallel with default num_threads=8, ignoring special tokens, and remain equivalent to encode_batch(text, disallowed_special=()) but slightly faster.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  When modifying Encoding.encode_ordinary_batch's parallel encoding behavior or special-token handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-54cfaa149af1b8155fbbe39f.md)

## Rule 028 — `tiktoken/registry.py`

- **Rule:**
  ```text
  _find_constructors must import each available plugin module, require an ENCODING_CONSTRUCTORS attribute (raising ValueError if missing), reject duplicate encoding names across plugins, and reset ENCODING_CONSTRUCTORS to None on any exception so errors are raised idempotently.
  ```
- **Applies to:**
  - `tiktoken/registry.py`
- **Condition:**
  ```text
  When modifying _find_constructors or changing plugin module validation, duplicate-name handling, or error reset behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-571b6c473cf1e795e600b0a4.md)

## Rule 029 — `tiktoken/core.py`

- **Rule:**
  ```text
  Encoding.encode_to_numpy must return a numpy uint32 array built via np.frombuffer over the core BPE buffer, avoiding a copy into a Python list, with numpy imported lazily inside the method.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  When modifying Encoding.encode_to_numpy's return type or numpy import strategy.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-57b45a1fbdb8b1a6537caebc.md)

## Rule 030 — `.github/workflows/build_wheels.yml`

- **Rule:**
  ```text
  The build_wheels_aarch64 job uses pypa/cibuildwheel@v2.22.0 with CIBW_ARCHS set to aarch64.
  ```
- **Applies to:**
  - `.github/workflows/build_wheels.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-57b7a144dbee0ca3bd21e3c1.md)

## Rule 031 — `tiktoken/core.py`

- **Rule:**
  ```text
  Encoding.decode_with_offsets must currently raise on tokens that decode to invalid UTF-8 because it decodes with errors='strict'; this behavior may change to be more permissive in the future.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  When modifying Encoding.decode_with_offsets's error handling for invalid UTF-8 tokens.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-672dde761fdfd689aa894583.md)
