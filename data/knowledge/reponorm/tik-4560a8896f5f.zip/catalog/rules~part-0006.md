# Full rule catalog

## Rule 079 — `tiktoken/registry.py`

- **Rule:**
  ```text
  list_encoding_names must acquire the module _lock, lazily call _find_constructors() when ENCODING_CONSTRUCTORS is None, and return list(ENCODING_CONSTRUCTORS), so constructor discovery is guarded by the registry lock.
  ```
- **Applies to:**
  - `tiktoken/registry.py`
- **Condition:**
  ```text
  when modifying list_encoding_names or the lazy constructor discovery path
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f0b703686317425669af3e8d.md)

## Rule 080 — `tiktoken/_educational.py`

- **Rule:**
  ```text
  SimpleBytePairEncoding.decode_bytes must concatenate per-token byte values from the decoder table and return bytes, preserving the byte-level decoding contract (e.g., decode_bytes([388, 372]) == b'hello world').
  ```
- **Applies to:**
  - `tiktoken/_educational.py`
- **Condition:**
  ```text
  when modifying SimpleBytePairEncoding.decode_bytes or the decoder table
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f31a3f2c133c1e27040eae98.md)

## Rule 081 — `tests/test_encoding.py`

- **Rule:**
  ```text
  Batch encoding methods must remain element-wise equivalent to repeated single-item encoding: encode_batch([t]) == [encode(t)] and encode_ordinary_batch([t]) == [encode_ordinary(t)], with no cross-item state or padding effects.
  ```
- **Applies to:**
  - `tests/test_encoding.py`
- **Condition:** When modifying or adding batch encoding methods or their tests in the encoding test module.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f3d298fda0eb4a044607480d.md)

## Rule 082 — `tiktoken/core.py`

- **Rule:**
  ```text
  Encoding.encode must default to disallowed_special='all' and raise on text matching a disallowed special token; allowed_special='all' treats all special-token text as special tokens, disallowed_special=() encodes them as natural text, and UnicodeEncodeError triggers a utf-16 surrogatepass/replace fallback.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  When modifying Encoding.encode or its special-token handling, preserve the default disallowed_special='all' behavior, allowed_special='all' semantics, disallowed_special=() behavior, and UnicodeEncodeError fallback.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f65d28f284675416a3202eb1.md)

## Rule 083 — `tiktoken/_educational.py`

- **Rule:**
  ```text
  SimpleBytePairEncoding.encode must split text with the pattern regex, encode each word's UTF-8 bytes via bpe_encode, and accept a visualise parameter defaulting to 'colour' for the educational BPE path.
  ```
- **Applies to:**
  - `tiktoken/_educational.py`
- **Condition:** When modifying SimpleBytePairEncoding.encode's encoding behavior or visualise parameter.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-fc0d02326b76d23ca4015bc9.md)

## Rule 084 — `setup.py`

- **Rule:**
  ```text
  Keep the tiktoken._tiktoken Rust extension built through setuptools_rust with Binding.PyO3 and debug=False; the build must always use the release profile because editable installs and performance-sensitive Rust code depend on it.
  ```
- **Applies to:**
  - `setup.py`
- **Condition:**
  ```text
  When modifying the Rust extension build configuration in setup.py, such as changing the setuptools_rust binding, debug flag, or release-profile behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-fc4234460155bebf343aac4e.md)
