# Full rule catalog

## Rule 001 — `tests/test_encoding.py`

- **Rule:**
  ```text
  Special-token handling must respect disallowed_special and allowed_special parameters: disallowed special tokens raise ValueError, and allowed_special='all' combined with disallowed_special='all' still encodes special tokens.
  ```
- **Applies to:**
  - `tests/test_encoding.py`
- **Condition:** When modifying or adding special-token handling tests or the encode special-token policy.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0167fedd67af4c132e249430.md)

## Rule 002 — `tiktoken/__init__.py`

- **Rule:**
  ```text
  tiktoken/__init__.py must declare the public API surface (Encoding, encoding_for_model, encoding_name_for_model, get_encoding, list_encoding_names) and set __version__ = '0.9.0'.
  ```
- **Applies to:**
  - `tiktoken/__init__.py`
- **Condition:**
  ```text
  When modifying the public API exports or version in tiktoken/__init__.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-02582c2c63b6bf15c6237df7.md)

## Rule 003 — `.github/workflows/build_wheels.yml`

- **Rule:**
  ```text
  The build_wheels job uses pypa/cibuildwheel@v2.22.0 with CIBW_BUILD set to cp${{ matrix.python-version}}-*.
  ```
- **Applies to:**
  - `.github/workflows/build_wheels.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0909c12d17ebaca110754617.md)

## Rule 004 — `tiktoken/_educational.py`

- **Rule:**
  ```text
  SimpleBytePairEncoding.from_tiktoken must accept either an encoding name string or an Encoding instance and construct the educational BPE from the encoding's _pat_str and _mergeable_ranks, bridging production and educational implementations.
  ```
- **Applies to:**
  - `tiktoken/_educational.py`
- **Condition:**
  ```text
  when modifying SimpleBytePairEncoding.from_tiktoken or its input handling
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0afe16422e534a9c40d801b8.md)

## Rule 005 — `tiktoken/model.py`

- **Rule:**
  ```text
  encoding_name_for_model must first check exact MODEL_TO_ENCODING membership, then fall back to prefix matching against MODEL_PREFIX_TO_ENCODING, accepting that prefix matching can match non-existent models to avoid library updates per model release.
  ```
- **Applies to:**
  - `tiktoken/model.py`
- **Condition:**
  ```text
  when modifying encoding_name_for_model or the model-to-encoding lookup tables
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0c11fa9ac98bc89dc1bbf80e.md)

## Rule 006 — `tiktoken/load.py`

- **Rule:**
  ```text
  read_file_cached must key its cache by sha1 of the blobpath, validate cached data against expected_hash, delete and re-fetch on mismatch, and raise ValueError on a hash mismatch of freshly downloaded contents.
  ```
- **Applies to:**
  - `tiktoken/load.py`
- **Condition:**
  ```text
  When modifying read_file_cached or changing its cache key, hash validation, or mismatch handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-105b05dde407ac10943c2ba7.md)

## Rule 007 — `scripts/redact.py`

- **Rule:** scripts/redact.py main() must keep --dry-run defaulting to True and printing a message instructing use of --dry-run=false to actually redact files, so redaction is opt-in.
- **Applies to:**
  - `scripts/redact.py`
- **Condition:** When modifying main()'s argument parsing or user messaging in scripts/redact.py, preserve the --dry-run default of True and the instruction to pass --dry-run=false to actually redact.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-11bc840573a51af46c99b0bd.md)

## Rule 008 — `Cargo.toml`

- **Rule:** The bstr dependency is pinned to version 1.5.0.
- **Applies to:**
  - `Cargo.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-12b692f674d8ea7f6eff2167.md)

## Rule 009 — `tests/test_encoding.py`

- **Rule:**
  ```text
  Tests that assert equivalence between encode_ordinary(text) and encode(text, disallowed_special=()) must preserve that equivalence for arbitrary text, since ordinary encoding is defined as the special-token-disallowed path.
  ```
- **Applies to:**
  - `tests/test_encoding.py`
- **Condition:**
  ```text
  When modifying or adding property tests that compare encode_ordinary output with encode(..., disallowed_special=()) output.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-14c31ecbebaca5d9a2fd1e59.md)

## Rule 010 — `tiktoken/core.py`

- **Rule:**
  ```text
  Encoding.decode_bytes_batch must decode a batch of token sequences using a ThreadPoolExecutor with a default num_threads of 8.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  When modifying Encoding.decode_bytes_batch's concurrency or default thread count.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-19ce06784434281a6ece20ed.md)

## Rule 011 — `**/*.rs`

- **Rule:** The crate declares a minimum supported Rust version of 1.57.0.
- **Applies to:**
  - `**/*.rs`
  - `Cargo.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1fed6dca8794f8d1da59e65c.md)

## Rule 012 — `.github/workflows/build_wheels.yml`

- **Rule:**
  ```text
  The build_sdist job runs check-manifest -v after installing check-manifest.
  ```
- **Applies to:**
  - `.github/workflows/build_wheels.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-21fd53bcccfb02fecb49c606.md)

## Rule 013 — `tiktoken/core.py`

- **Rule:**
  ```text
  Encoding.encode_batch must resolve allowed_special='all' to the encoding's special_tokens_set and disallowed_special='all' to special_tokens_set minus allowed_special, coerce disallowed_special to a frozenset, and encode in parallel with default num_threads=8.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  When modifying Encoding.encode_batch's special-token resolution or parallel encoding defaults.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-2286ecfbdcf0fb215794bc5e.md)

## Rule 014 — `tests/test_misc.py`

- **Rule:**
  ```text
  The model-to-encoding mapping must be pinned in tests: gpt2->gpt2, text-davinci-003->p50k_base, text-davinci-edit-001->p50k_edit, gpt-3.5-turbo-0301 and gpt-4->cl100k_base, gpt-4o->o200k_base.
  ```
- **Applies to:**
  - `tests/test_misc.py`
- **Condition:**
  ```text
  When modifying the encoding_for_model mapping or adding new model names.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-234307d0a931c39b78a7c874.md)

## Rule 015 — `tests/test_encoding.py`

- **Rule:**
  ```text
  Encoding tests must assert exact token ids for known inputs (e.g., 'hello world' for gpt2 and cl100k_base, repeated digit runs for gpt2) and verify per-token round-trip encode_single_token(decode_single_token_bytes(token)) == token across the encoding's vocabulary.
  ```
- **Applies to:**
  - `tests/test_encoding.py`
- **Condition:** When adding or modifying encoding correctness tests for token id stability or per-token round-trip.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-29446dfb5d3d24fd8629fb13.md)

## Rule 016 — `tiktoken/load.py`

- **Rule:**
  ```text
  read_file must use blobfile for non-http(s) paths (raising ImportError with install guidance if blobfile is missing) but deliberately use requests for http(s) URLs to avoid auth issues such as MFA prompts.
  ```
- **Applies to:**
  - `tiktoken/load.py`
- **Condition:**
  ```text
  When modifying read_file or its path handling, preserve blobfile for non-http(s) paths and requests for http(s) URLs.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-2c4a743e6db808d53410974a.md)
