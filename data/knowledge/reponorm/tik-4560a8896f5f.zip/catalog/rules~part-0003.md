# Full rule catalog

## Rule 032 — `tiktoken/core.py`

- **Rule:**
  ```text
  Encoding.__repr__ must return '<Encoding {name!r}>'.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  when modifying Encoding.__repr__ or the Encoding name attribute
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-69150f7e371c6eb0e16e8ca7.md)

## Rule 033 — `scripts/benchmark.py`

- **Rule:**
  ```text
  scripts/benchmark.py must keep benchmark_batch's thread count driven by the RAYON_NUM_THREADS environment variable and passed as num_threads to encode_ordinary_batch, so benchmark timing reflects the configured Rust rayon pool.
  ```
- **Applies to:**
  - `scripts/benchmark.py`
- **Condition:**
  ```text
  When modifying benchmark_batch or its batch-encoding call in scripts/benchmark.py, preserve the RAYON_NUM_THREADS-derived num_threads argument.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6bf4fb257099036059d0a589.md)

## Rule 034 — `tests/test_helpers.py`

- **Rule:**
  ```text
  Test helpers must define MAX_EXAMPLES from the TIKTOKEN_MAX_EXAMPLES environment variable (default 100) and provide ENCODINGS/SOME_ENCODINGS lists and pytest.param factories for supported encodings.
  ```
- **Applies to:**
  - `tests/test_helpers.py`
- **Condition:** When modifying or adding test helper configuration for encoding parametrization.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6dd8e2ae29bf99c44eba75f4.md)

## Rule 035 — `tiktoken/_educational.py`

- **Rule:**
  ```text
  bpe_train must repeatedly find the most common adjacent byte pair via collections.Counter, assign it the next token id (len(ranks)), merge it across all words, and loop until len(ranks) reaches vocab_size, with the visualise parameter controlling optional debug printing.
  ```
- **Applies to:**
  - `tiktoken/_educational.py`
- **Condition:**
  ```text
  when modifying bpe_train or its merge loop and vocab_size termination
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6ded60e59e6d3953335f0b32.md)

## Rule 036 — `.github/workflows/build_wheels.yml`

- **Rule:**
  ```text
  The join_artifacts job merges artifacts matching pattern cibw-wheels-* into an artifact named cibw-wheels and deletes the merged artifacts.
  ```
- **Applies to:**
  - `.github/workflows/build_wheels.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6f237f9ae682e85c96609612.md)

## Rule 037 — `Cargo.toml`

- **Rule:**
  ```text
  The `python` feature enables the `pyo3` dependency.
  ```
- **Applies to:**
  - `Cargo.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7dab78ec5cf26a81d36fec75.md)

## Rule 038 — `tiktoken/registry.py`

- **Rule:**
  ```text
  get_encoding must validate the name is a string, return cached ENCODINGS entries, and under a lock lazily call _find_constructors; unknown names must raise ValueError including available plugin modules and tiktoken version.
  ```
- **Applies to:**
  - `tiktoken/registry.py`
- **Condition:**
  ```text
  When modifying get_encoding's name validation, caching, lazy constructor lookup, or unknown-name error message.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7ef1fb6de1e77a1dc07b80c3.md)

## Rule 039 — `scripts/redact.py`

- **Rule:**
  ```text
  scripts/redact.py must keep redact_file deleting any file whose first line contains 'redact' and otherwise stripping content between redact-beg/redact-end markers (both '#' and HTML comment forms) by splitting on the marker regex and keeping even-indexed segments, with dry_run suppressing all writes/deletes.
  ```
- **Applies to:**
  - `scripts/redact.py`
- **Condition:**
  ```text
  When modifying redact_file's file-selection or marker-stripping logic in scripts/redact.py, preserve the first-line 'redact' deletion rule, the redact-beg/redact-end marker stripping for both comment forms, and dry_run write suppression.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7f58ee2b89815cb85dbe0e0f.md)

## Rule 040 — `Cargo.toml`

- **Rule:** The rustc-hash dependency is pinned to version 1.1.0.
- **Applies to:**
  - `Cargo.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-806ea9516cf2b424f984efde.md)

## Rule 041 — `**/*.py`

- **Rule:**
  ```text
  The project declares a minimum supported Python version of 3.9 via requires-python = ">=3.9".
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8412e9d3f9b891eb7918bb10.md)

## Rule 042 — `tiktoken/core.py`

- **Rule:**
  ```text
  Encoding.n_vocab must remain a backwards-compatibility alias equal to max_token_value + 1; new code should use enc.max_token_value + 1 instead of relying on n_vocab.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  When modifying Encoding vocabulary-size or max-token-value computation, preserve n_vocab as max_token_value + 1 for backwards compatibility.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-84559a4933f8f9a5c03cebb8.md)

## Rule 043 — `tiktoken/load.py`

- **Rule:**
  ```text
  decode_data_gym must map each character of a data-gym encoded string back to its byte via data_gym_byte_to_byte.
  ```
- **Applies to:**
  - `tiktoken/load.py`
- **Condition:**
  ```text
  when modifying decode_data_gym or the data-gym byte mapping
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-84eefc0898f3815f9796e72c.md)

## Rule 044 — `tiktoken/registry.py`

- **Rule:**
  ```text
  tiktoken/registry.py must guard the ENCODINGS dict and ENCODING_CONSTRUCTORS with a module-level threading.RLock, ensuring registry access is thread-safe.
  ```
- **Applies to:**
  - `tiktoken/registry.py`
- **Condition:**
  ```text
  When modifying registry access to ENCODINGS or ENCODING_CONSTRUCTORS.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-87ed6381e4743ed4d629fb6b.md)

## Rule 045 — `tiktoken/_educational.py`

- **Rule:**
  ```text
  tiktoken/_educational.py must remain an explicitly documented educational implementation of the byte pair encoding algorithm, distinct from the production Rust-backed core.
  ```
- **Applies to:**
  - `tiktoken/_educational.py`
- **Condition:**
  ```text
  when modifying tiktoken/_educational.py or its documented purpose
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8a2786ec2879aadababcbdd3.md)

## Rule 046 — `tiktoken/core.py`

- **Rule:**
  ```text
  Encoding.encode_to_numpy must normalize allowed_special="all" to the encoding's special_tokens_set and disallowed_special="all" to special_tokens_set minus allowed_special, raising via raise_disallowed_special_token when a disallowed special token appears in the text.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  when modifying Encoding.encode_to_numpy or its special-token normalization
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8cab644af4df0ee9f4b303f9.md)

## Rule 047 — `tiktoken/core.py`

- **Rule:**
  ```text
  Encoding.__setstate__ must restore a registered encoding by name via tiktoken.registry.get_encoding (copying its __dict__) when the pickled value is a string, otherwise re-initialize from the dict form, matching the __getstate__ optimization.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  When modifying Encoding.__setstate__ or pickle handling, preserve the string-name registry lookup and dict-form re-initialization paths.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9b02c70edaa1cc87d2a08ece.md)
