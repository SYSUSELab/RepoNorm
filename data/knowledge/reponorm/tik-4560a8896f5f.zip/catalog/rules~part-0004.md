# Full rule catalog

## Rule 048 — `.github/workflows/build_wheels.yml`

- **Rule:**
  ```text
  The build_sdist job builds the sdist with python -m build --sdist after upgrading the build package.
  ```
- **Applies to:**
  - `.github/workflows/build_wheels.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a227d660302e23009b143c38.md)

## Rule 049 — `tiktoken/core.py`

- **Rule:**
  ```text
  raise_disallowed_special_token must raise ValueError with remediation guidance: pass allowed_special, set disallowed_special to special_tokens_set minus the token, or use disallowed_special=() to disable checks.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  When modifying raise_disallowed_special_token or its error message, preserve ValueError and the documented remediation options.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a7d421321383b8fa05a43d33.md)

## Rule 050 — `Cargo.toml`

- **Rule:** The regex dependency is pinned to version 1.10.3.
- **Applies to:**
  - `Cargo.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a846797a20628dc3e110c81a.md)

## Rule 051 — `tiktoken/core.py`

- **Rule:**
  ```text
  Encoding.encode_single_token must encode text or bytes corresponding to a single token, encode all special tokens, and raise KeyError when the token is not in the vocabulary.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  when modifying Encoding.encode_single_token or its vocabulary lookup
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a8e66a85aeba244f01bc47b7.md)

## Rule 052 — `tiktoken/model.py`

- **Rule:**
  ```text
  encoding_for_model must delegate to encoding_name_for_model and must raise KeyError for an unrecognized model name rather than returning a default encoding.
  ```
- **Applies to:**
  - `tiktoken/model.py`
- **Condition:**
  ```text
  When modifying encoding_for_model's model-name resolution or error behavior for unrecognized models.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ab9a6e5292d9c49599a7cddc.md)

## Rule 053 — `tests/test_offsets.py`

- **Rule:**
  ```text
  Token offset tests must compute reference offsets by decoding the full token list with errors='strict' and measuring common prefix length against each prefix decoded with errors='ignore', using the shared _common_prefix_len helper.
  ```
- **Applies to:**
  - `tests/test_offsets.py`
- **Condition:** When adding or modifying token offset assertions in the test suite.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b3f716df4118e53e7b643ac9.md)

## Rule 054 — `tiktoken/core.py`

- **Rule:**
  ```text
  Encoding.is_special_token must assert the token is an int and return membership in _special_token_values, so special-token detection is based on the set of special token values rather than token text.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  When modifying is_special_token or special-token membership, preserve the int assertion and value-set-based detection.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b9c827766f050461a5090c10.md)

## Rule 055 — `tiktoken_ext/openai_public.py`

- **Rule:**
  ```text
  ENCODING_CONSTRUCTORS in tiktoken_ext/openai_public.py maps encoding names (gpt2, r50k_base, p50k_base, p50k_edit, cl100k_base, o200k_base) to their constructor functions; adding or renaming an encoding requires updating this mapping consistently with the constructor definitions.
  ```
- **Applies to:**
  - `tiktoken_ext/openai_public.py`
- **Condition:**
  ```text
  When adding, removing, or renaming an encoding constructor or its entry in ENCODING_CONSTRUCTORS in tiktoken_ext/openai_public.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-be772b9f99118f437541aed2.md)

## Rule 056 — `tiktoken/model.py`

- **Rule:**
  ```text
  MODEL_PREFIX_TO_ENCODING and MODEL_TO_ENCODING must define the model-name-to-encoding mapping, including o1/o3 and gpt-4o prefixes to o200k_base, gpt-4/gpt-3.5-turbo to cl100k_base, deprecated text/code models to p50k_base or r50k_base, edit models to p50k_edit, and gpt2/gpt-2 to gpt2.
  ```
- **Applies to:**
  - `tiktoken/model.py`
- **Condition:**
  ```text
  When modifying the model-name-to-encoding mapping in MODEL_PREFIX_TO_ENCODING or MODEL_TO_ENCODING.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-bf9677ca063882a022040a2a.md)

## Rule 057 — `tiktoken/load.py`

- **Rule:** tiktoken/load.py must import base64, hashlib, and os, covering hashing and base64 decoding of downloaded encoding data.
- **Applies to:**
  - `tiktoken/load.py`
- **Condition:** When modifying tiktoken/load.py's imports or responsibilities for hashing and base64 decoding.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c0103c5367aa0be07d2e2713.md)

## Rule 058 — `tests/test_misc.py`

- **Rule:** Importing tiktoken must not eagerly import the optional blobfile dependency into sys.modules.
- **Applies to:**
  - `tests/test_misc.py`
- **Condition:** When modifying or adding tests that check optional dependency isolation or the package import behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c09f8ffa8abab9a9a9856267.md)

## Rule 059 — `tiktoken/core.py`

- **Rule:**
  ```text
  Encoding.decode_with_offsets must return (text, offsets) where each offset is the index into text of the first character containing bytes from that token, clamping to the first character containing the token's bytes when UTF-8 character boundaries do not align with token boundaries.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  When modifying decode_with_offsets or its offset computation, preserve the first-character-containing-token-bytes semantics and clamping behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c1f21a1fe9440dc52e817e35.md)

## Rule 060 — `scripts/benchmark.py`

- **Rule:**
  ```text
  scripts/benchmark.py must keep benchmark_batch comparing tiktoken against HuggingFace GPT2TokenizerFast on the same documents, setting hf_enc.model_max_length = 1e30 to silence length warnings before timing.
  ```
- **Applies to:**
  - `scripts/benchmark.py`
- **Condition:**
  ```text
  When modifying benchmark_batch's tokenizer comparison or timing setup in scripts/benchmark.py, preserve the tiktoken-vs-HuggingFace comparison and the hf_enc.model_max_length = 1e30 warning suppression.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c4436d5f4c0c03e207ddff98.md)

## Rule 061 — `tiktoken/_educational.py`

- **Rule:**
  ```text
  SimpleBytePairEncoding.train must be a staticmethod that runs bpe_train on the given data/vocab_size/pat_str and returns a new SimpleBytePairEncoding, providing a training entry point distinct from the production encodings.
  ```
- **Applies to:**
  - `tiktoken/_educational.py`
- **Condition:** When modifying SimpleBytePairEncoding.train's training entry point or return value.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d0feab4e61d697cd445bb220.md)

## Rule 062 — `scripts/benchmark.py`

- **Rule:** scripts/benchmark.py must keep its dependency on the optional blobfile package alongside tiktoken, so the benchmark harness continues to import blobfile for its blob-file handling.
- **Applies to:**
  - `scripts/benchmark.py`
- **Condition:** When modifying scripts/benchmark.py imports or dependency handling, preserve the blobfile import alongside tiktoken.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d23b86a8bdf368d1a2217ec4.md)
