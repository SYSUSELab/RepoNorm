# Full rule catalog

## Rule 063 — `tiktoken/core.py`

- **Rule:**
  ```text
  Encoding.decode_single_token_bytes must decode all special tokens and raise KeyError when the token is not in the vocabulary.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  When modifying decode_single_token_bytes or the underlying token-to-bytes mapping, preserve special-token decoding and KeyError on unknown tokens.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d32a0494279c44fb86e89444.md)

## Rule 064 — `tiktoken/core.py`

- **Rule:**
  ```text
  Encoding.__init__ must compute max_token_value as the max over mergeable_ranks and special_tokens values, and when explicit_n_vocab is provided assert len(mergeable_ranks)+len(special_tokens)==explicit_n_vocab and max_token_value==explicit_n_vocab-1.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  When modifying Encoding.__init__ or vocabulary composition, preserve the explicit_n_vocab consistency assertions and max_token_value computation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d542bf54b9d106fa7b49a03d.md)

## Rule 065 — `tiktoken/core.py`

- **Rule:**
  ```text
  Encoding._encode_single_piece must encode text corresponding to bytes without a regex split and must not encode any special tokens.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  When modifying Encoding._encode_single_piece's encoding behavior or special-token handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d7859b1197a20afefc155b71.md)

## Rule 066 — `tiktoken/load.py`

- **Rule:**
  ```text
  read_file_cached must write via a uuid-suffixed temp file then os.rename; if writing to the cache fails with OSError it must only re-raise when the cache dir was user-specified, otherwise silently return the contents (referencing issue #75).
  ```
- **Applies to:**
  - `tiktoken/load.py`
- **Condition:**
  ```text
  When modifying read_file_cached's cache write error handling or temp-file write strategy.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d7f9e4af79d2cb3fb17be8b9.md)

## Rule 067 — `Cargo.toml`

- **Rule:** The pyo3 dependency is declared at version 0.22.2 with default features disabled and the "extension-module" and "macros" features enabled, and is optional.
- **Applies to:**
  - `Cargo.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-dba260c306c47f64207f2772.md)

## Rule 068 — `tests/test_encoding.py`

- **Rule:**
  ```text
  Byte-level encoding tests must verify that decode_bytes(_encode_bytes(bytestring)) round-trips arbitrary bytes, including invalid-UTF-8 sequences, using hypothesis property tests with deadline disabled.
  ```
- **Applies to:**
  - `tests/test_encoding.py`
- **Condition:** When adding or modifying byte-level encoding round-trip tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ddfaf6d8b5cd6956175aa66d.md)

## Rule 069 — `tiktoken/core.py`

- **Rule:**
  ```text
  Encoding._encode_only_native_bpe must perform regex splitting in Python by compiling self._pat_str and using regex.findall, then call the core BPE encode_single_piece per piece, serving as the pure-Python reference path distinct from the native encode.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  when modifying Encoding._encode_only_native_bpe or the pure-Python reference path
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-de390bbc9b207624c7d977a0.md)

## Rule 070 — `tiktoken/load.py`

- **Rule:**
  ```text
  check_hash must compare the sha256 hexdigest of the given bytes against expected_hash and return a bool, providing the integrity check used by load_tiktoken_bpe.
  ```
- **Applies to:**
  - `tiktoken/load.py`
- **Condition:**
  ```text
  When modifying check_hash or its integrity check, preserve sha256 hexdigest comparison and boolean return.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-de71b8f38b189568b65f4dc4.md)

## Rule 071 — `tests/test_encoding.py`

- **Rule:** Encoding an empty string must return an empty token list.
- **Applies to:**
  - `tests/test_encoding.py`
- **Condition:** When modifying or adding empty-string encoding tests or the encoding implementation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-df5417f35e451d643a9335a5.md)

## Rule 072 — `tests/test_pickle.py`

- **Rule:**
  ```text
  Encoding objects must round-trip through pickle: both registry encodings and custom Encoding instances constructed from name/pat_str/mergeable_ranks/special_tokens must encode identically after pickle.loads(pickle.dumps(...)), including special tokens mapping to their assigned ids.
  ```
- **Applies to:**
  - `tests/test_pickle.py`
- **Condition:** When modifying the Encoding class, its constructor, or its serialization-relevant attributes.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-dfdd9ecad73c2686293adbcc.md)

## Rule 073 — `tests/test_simple_public.py`

- **Rule:** The public package surface must be validated through subprocess execution, and importing tiktoken must not eagerly import optional dependencies such as blobfile into sys.modules.
- **Applies to:**
  - `tests/test_simple_public.py`
- **Condition:** When modifying package import-time behavior or adding optional dependencies to the tiktoken package.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e03e59afbb7a1e99795e3dde.md)

## Rule 074 — `Cargo.toml`

- **Rule:**
  ```text
  The `default` feature set is empty, so no features are enabled by default.
  ```
- **Applies to:**
  - `Cargo.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e5fdd6a782e0695378222537.md)

## Rule 075 — `setup.py`

- **Rule:**
  ```text
  Keep the declared packages as ["tiktoken", "tiktoken_ext"], include py.typed as package_data for tiktoken, and set zip_safe=False in setup.py.
  ```
- **Applies to:**
  - `setup.py`
- **Condition:**
  ```text
  When modifying package declarations, package_data, or zip_safe settings in setup.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e8d8b56a25af5e5fbe1a9aaf.md)

## Rule 076 — `Cargo.toml`

- **Rule:** The fancy-regex dependency is pinned to version 0.13.0.
- **Applies to:**
  - `Cargo.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ec244b63b8868f56d332a259.md)

## Rule 077 — `tests/test_offsets.py`

- **Rule:**
  ```text
  decode_with_offsets must return character offsets into the decoded text that match the canonical reference offset implementation, including repeated offsets when a token spans partial characters.
  ```
- **Applies to:**
  - `tests/test_offsets.py`
- **Condition:**
  ```text
  When modifying or adding offset decoding tests or the decode_with_offsets implementation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ee750ac8e2dd66c5915b31d7.md)

## Rule 078 — `tiktoken/registry.py`

- **Rule:**
  ```text
  _available_plugin_modules must be lru_cached and discover encoding constructors by iterating pkgutil.iter_modules over the tiktoken_ext namespace package, relying on the namespace-package pattern for fast iteration and correct editable-install behavior.
  ```
- **Applies to:**
  - `tiktoken/registry.py`
- **Condition:**
  ```text
  When modifying _available_plugin_modules or changing how plugin modules are discovered or cached.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-effdbd640718146f435df7e6.md)
