# Repository knowledge

Apply rules within their stated scope and when their conditions hold, respecting
exceptions. `required`, `recommended`, and `observed` have different strength:
an observed convention does not by itself prohibit a change requested by the task.
`reference_only` is context, not a default action.
Evidence locations identify sources, not the rule's scope.
Commands in rules do not authorize unrelated changes or external side effects.
Use relevant rules alongside the task and repository code; keep edits focused.

## Find rules

Path links and the [full catalog](catalog.md) are alternative routes. Search or
open relevant files directly; open claim details when evidence or a conflict matters.
Paths are navigation anchors, not a replacement for each rule's complete scope.

- `repository root`: [Read rules](paths/repository.md)
- `.github/workflows/build_wheels.yml`: [Read rules](paths/.github/workflows/build_wheels.yml.md)
- `Cargo.toml`: [Read rules](paths/Cargo.toml.md)
- `scripts/benchmark.py`: [Read rules](paths/scripts/benchmark.py.md)
- `scripts/redact.py`: [Read rules](paths/scripts/redact.py.md)
- `setup.py`: [Read rules](paths/setup.py.md)
- `tests/test_encoding.py`: [Read rules](paths/tests/test_encoding.py.md)
- `tests/test_helpers.py`: [Read rules](paths/tests/test_helpers.py.md)
- `tests/test_misc.py`: [Read rules](paths/tests/test_misc.py.md)
- `tests/test_offsets.py`: [Read rules](paths/tests/test_offsets.py.md)
- `tests/test_pickle.py`: [Read rules](paths/tests/test_pickle.py.md)
- `tests/test_simple_public.py`: [Read rules](paths/tests/test_simple_public.py.md)
- `tiktoken/__init__.py`: [Read rules](paths/tiktoken/__init__.py.md)
- `tiktoken/_educational.py`: [Read rules](paths/tiktoken/_educational.py.md)
- `tiktoken/core.py`: [Read rules (part 1)](paths/tiktoken/core.py~part-0001.md)
- `tiktoken/core.py`: [Read rules (part 2)](paths/tiktoken/core.py~part-0002.md)
- `tiktoken/load.py`: [Read rules](paths/tiktoken/load.py.md)
- `tiktoken/model.py`: [Read rules](paths/tiktoken/model.py.md)
- `tiktoken/registry.py`: [Read rules](paths/tiktoken/registry.py.md)
- `tiktoken_ext/openai_public.py`: [Read rules](paths/tiktoken_ext/openai_public.py.md)
