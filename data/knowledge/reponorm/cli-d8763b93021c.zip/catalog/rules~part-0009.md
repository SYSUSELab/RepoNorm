# Full rule catalog

## Rule 140 — `tests/test_context.py`

- **Rule:**
  ```text
  Tests that exercise the pass-object decorator pattern must keep the injected-object contract; changing pass_* decorator behavior requires updating these tests.
  ```
- **Applies to:**
  - `tests/test_context.py`
- **Condition:**
  ```text
  When modifying pass_* decorator injection behavior, the pass-object test in the context test file must be updated.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ecf004ec8506df35db2646e0.md)

## Rule 141 — `requirements/tests.in`

- **Rule:** The update-requirements tox environment runs pip-compile on tests.in with -q and posargs defaulting to -U.
- **Applies to:**
  - `requirements/tests.in`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ed87fd0567591ad47129bd4e.md)

## Rule 142 — `examples/aliases/aliases.py`

- **Rule:** Example commands that add an alias must update the aliases mapping with a single alias-to-command entry.
- **Applies to:**
  - `examples/aliases/aliases.py`
- **Condition:** when modifying alias addition in the aliases example
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ed93e1c4fac31bffd7a89af9.md)

## Rule 143 — `src/click/types.py`

- **Rule:**
  ```text
  When modifying _NumberParamTypeBase, preserve the extension protocol: _number_class is declared as a class variable so numeric ParamType subclasses supply their concrete number type.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  Modifying _NumberParamTypeBase or adding numeric ParamType subclasses.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-edf9d403232bc6929259159f.md)

## Rule 144 — `src/click/exceptions.py`

- **Rule:**
  ```text
  ClickException.__init__ must initialize the base Exception with the message and also store the message on self.message so it remains available as an attribute.
  ```
- **Applies to:**
  - `src/click/exceptions.py`
- **Condition:** when modifying ClickException initialization or message storage
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-eff81114648d6ff513cf1127.md)

## Rule 145 — `src/click/core.py`

- **Rule:**
  ```text
  When modifying Option.__init__ flag/prompt derivation, preserve that prompt=True requires a name and derives prompt text from it, _flag_needs_value is set when prompt is enabled but not required, is_flag is inferred from flag_value, _flag_needs_value, or secondary_opts, count options default to IntRange(min=0) with default 0, and the __debug__-guarded TypeErrors remain enforced.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When changing Option.__init__ flag, prompt, count, or secondary-option derivation logic.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f032f04fa6dffe0aeb3caf1a.md)

## Rule 146 — `src/click/core.py`

- **Rule:**
  ```text
  When modifying Context.to_info_dict in core.py, preserve the returned dict keys (command info, info_name, allow_extra_args, allow_interspersed_args, ignore_unknown_options, auto_envvar_prefix) and the traversal of the CLI structure for documentation tools.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  Changing Context.to_info_dict output keys or CLI structure traversal
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f0efefeb66946b2ebbe57fbe.md)

## Rule 147 — `src/click/testing.py`

- **Rule:**
  ```text
  When modifying EchoingStdin.__getattr__, preserve the delegation behavior that forwards attribute access to self._input, the underlying input stream.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:**
  ```text
  When changing EchoingStdin.__getattr__ or its attribute delegation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f1095d78bff71c81bbb61f00.md)

## Rule 148 — `examples/complex/complex/cli.py`

- **Rule:**
  ```text
  Example commands that need custom context state must define a custom command class (e.g. ComplexCLI) with context_settings and a pass_environment decorator, storing values such as verbose and home on the context for subcommands rather than using module-level globals.
  ```
- **Applies to:**
  - `examples/complex/complex/cli.py`
- **Condition:** when adding or modifying an example command group that needs custom context state shared with subcommands
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f2a61203ca795819bedf4a10.md)

## Rule 149 — `tests/test_utils.py`

- **Rule:**
  ```text
  Tests for confirm prompts must assert exact prompt/response output: default-True prompts render 'Foo [Y/n]: ' and empty input yields 'yes!', while default-False prompts render 'Foo [y/N]: ' and empty input yields 'no :('.
  ```
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:** When modifying or adding tests for confirm prompt formatting and default-echo behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f393c7bd373918c59cb3cd5c.md)

## Rule 150 — `examples/aliases/aliases.py`

- **Rule:**
  ```text
  The aliases example's status command must use @pass_config to receive a config object and echo a status message including config.path.
  ```
- **Applies to:**
  - `examples/aliases/aliases.py`
- **Condition:** When modifying the aliases example's status command.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f60743620d9dfa49619e0e74.md)

## Rule 151 — `examples/colors/colors.py`

- **Rule:**
  ```text
  Example commands that output colors must use the canonical 16-name all_colors tuple covering normal and bright ANSI color names.
  ```
- **Applies to:**
  - `examples/colors/colors.py`
- **Condition:** when modifying color output or the color name set in the colors example
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-faaa420056bfdf227ac29d33.md)

## Rule 152 — `tox.ini`

- **Rule:** The tox default environment list includes py3{13,12,11,10,9,8}, pypy310, style, typing, and docs.
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-fb74b20d2eeff9ef01c71ea9.md)

## Rule 153 — `src/click/**`

- **Rule:** Pyright type checking is scoped to the src/click and tests/typing directories.
- **Applies to:**
  - `src/click/**`
  - `tests/typing/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-fcc25a308a6e9f3469bc4ff3.md)

## Rule 154 — `**`

- **Rule:** Include tests that cover any code changes made, and ensure the test fails without the patch.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-fd4a5decede8dd15f7dc8cc4.md)

## Rule 155 — `**`

- **Rule:**
  ```text
  The tox 'style' test environment sets skip_install to true, so the package is not installed into that environment.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-fdd22ff404286fe9af9aa43a.md)

## Rule 156 — `src/click/_compat.py`

- **Rule:**
  ```text
  When modifying _force_correct_text_stream in _compat.py, preserve that it returns a compatible text stream as-is unless encoding is None and the stream is misconfigured; otherwise it wraps the underlying binary reader, defaulting errors to 'replace' to avoid exceptions.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  Changing _force_correct_text_stream wrapping or error defaulting
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ff9005e0654d31ca3665e931.md)
