# Full rule catalog

## Rule 035 — `src/click/core.py`

- **Rule:**
  ```text
  When modifying Group.__init__, preserve the invariant that chain mode cannot be combined with optional arguments; the constructor must raise RuntimeError for that combination, and no_args_is_help must default to the negation of invoke_without_command.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  Modifying Group.__init__ command normalization, no_args_is_help defaulting, or chain-mode validation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3355a6d227398129e47c546f.md)

## Rule 036 — `tox.ini`

- **Rule:**
  ```text
  The tox testenv `update-actions` runs the command `gha-update`.
  ```
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-359ee7be8c6e4a6d21e4be67.md)

## Rule 037 — `src/click/types.py`

- **Rule:** UnprocessedParamType must keep name 'text' and pass values through without conversion, serving as the default unprocessed parameter type.
- **Applies to:**
  - `src/click/types.py`
- **Condition:** when modifying UnprocessedParamType's name or conversion behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-35c9830ea1362b906fa21434.md)

## Rule 038 — `src/click/core.py`

- **Rule:**
  ```text
  When modifying Context.find_object in core.py, preserve the behavior that it walks up the parent chain and returns the first node whose obj is an instance of the requested type, returning None if no ancestor matches.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  Changing Context.find_object parent-chain traversal or type matching
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3baf6d37641226d2eaf2b057.md)

## Rule 039 — `examples/complex/complex/cli.py`

- **Rule:**
  ```text
  Example groups that discover subcommands from a folder must scan for files matching cmd_*.py, strip the 'cmd_' prefix and '.py' suffix, and sort the resulting names.
  ```
- **Applies to:**
  - `examples/complex/complex/cli.py`
- **Condition:** when modifying subcommand discovery in the complex example group
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3d190c82f484de72ae70a6ff.md)

## Rule 040 — `examples/validation/validation.py`

- **Rule:** Example commands that accept a URL argument must validate it through the example's URL parameter type, which rejects any scheme other than http/https via self.fail and skips scheme validation for already-parsed tuple values.
- **Applies to:**
  - `examples/validation/validation.py`
- **Condition:** when adding or modifying an example command that accepts a URL argument
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3f60578fc717355a5baffca4.md)

## Rule 041 — `tox.ini`

- **Rule:** Tox skips environments whose interpreter is missing.
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-43abaec219b67a12fc38d131.md)

## Rule 042 — `src/click/core.py`

- **Rule:**
  ```text
  When modifying Command.format_epilog, preserve the behavior that the epilog is written only when self.epilog is set, applying inspect.cleandoc and writing it as an indented paragraph in the help formatter.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  Modifying Command.format_epilog epilog rendering.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-44fb2aa39bc65a52e9a260b5.md)

## Rule 043 — `requirements/dev.in`

- **Rule:** The update-requirements tox environment runs pip-compile on dev.in with -q and posargs defaulting to -U.
- **Applies to:**
  - `requirements/dev.in`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-4528af874a9016aecae36687.md)

## Rule 044 — `tox.ini`

- **Rule:** The tox testenv installs dependencies from requirements/tests.txt.
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Use:** `reference_only`
- **Execution risk:** `external_side_effect`
- **Detail:** [Open claim details](../claims/CLAIM-482940998603b05f87cf9939.md)

## Rule 045 — `src/click/formatting.py`

- **Rule:**
  ```text
  When modifying HelpFormatter.write_dl in formatting.py, preserve that it raises TypeError if rows do not have exactly two columns and wraps the second column text with a minimum width of 10.
  ```
- **Applies to:**
  - `src/click/formatting.py`
- **Condition:**
  ```text
  Changing HelpFormatter.write_dl row validation or column wrapping
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-49b2655b7fec122d313448f6.md)

## Rule 046 — `**`

- **Rule:**
  ```text
  Files matching the [*] section are configured to trim trailing whitespace.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-4ca339d95bafd99842f4ee26.md)

## Rule 047 — `tests/test_formatting.py`

- **Rule:** Tests that assert exact help/usage text must keep the expected output in sync with the formatter's wrapping, paragraph, and indentation behavior; changing help rendering requires updating these exact-output assertions.
- **Applies to:**
  - `tests/test_formatting.py`
  - `tests/test_options.py`
- **Condition:**
  ```text
  When modifying help-text rendering (wrapping, \b paragraph preservation, indentation, or envvar/option help display), the exact-output assertions in the formatting and options tests must be updated to match.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-4ce25edb65b8ee3cf39e5d0e.md)

## Rule 048 — `src/click/shell_completion.py`

- **Rule:**
  ```text
  When modifying ShellComplete.func_name, preserve the shell function name contract: sanitize prog_name by replacing '-' with '_' and stripping non-word characters with re.sub(r"\W*", "", ..., flags=re.ASCII), then wrap it as _{safe_name}_completion.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:**
  ```text
  Modifying ShellComplete.func_name sanitization or completion function naming.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-4da1587fc03f64a10ac7cf1e.md)

## Rule 049 — `.github/workflows/publish.yaml`

- **Rule:** The publish-pypi job downloads artifacts and publishes packages from artifact/ to the TestPyPI repository URL https://test.pypi.org/legacy/.
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-4edd6ed3a0eab345d0a23a71.md)

## Rule 050 — `src/click/formatting.py`

- **Rule:**
  ```text
  When modifying help formatting defaults, preserve that HelpFormatter width defaults to terminal width minus 2, clamped between 50 and max_width (default 80), with FORCED_WIDTH overriding terminal detection.
  ```
- **Applies to:**
  - `src/click/formatting.py`
- **Condition:** when changing HelpFormatter width calculation or terminal detection
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-4f21eee4b00ba5c6892d48ca.md)

## Rule 051 — `examples/aliases/aliases.py`

- **Rule:**
  ```text
  Example commands that need configuration must load it in a group-level callback (e.g. read_config) so the config is available even when the group never executes, defaulting to a file next to the module (e.g. aliases.ini) rather than requiring the subcommand to load it.
  ```
- **Applies to:**
  - `examples/aliases/aliases.py`
- **Condition:** when adding or modifying an example command group that needs configuration available to all subcommands
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-519123bb9a9a7db3d0cd3319.md)
