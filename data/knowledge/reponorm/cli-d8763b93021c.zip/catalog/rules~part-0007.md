# Full rule catalog

## Rule 106 — `src/click/_compat.py`

- **Rule:**
  ```text
  When modifying _is_compat_stream_attr, preserve the compatibility rule: a stream attribute is compatible when it equals the desired value, or when the desired value is None and the attribute has any non-None value.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  Modifying _is_compat_stream_attr compatibility checks.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-aaf5bf08651a5024b87b79e5.md)

## Rule 107 — `tox.ini`

- **Rule:** The tox testenv builds the package as a wheel.
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ab9b4b51243fd64d0fca3c16.md)

## Rule 108 — `src/click/core.py`

- **Rule:**
  ```text
  When modifying Context.command_path, preserve the usage-path computation: join the parent's command_path with each parent parameter's get_usage_pieces, then append the current info_name and strip leading whitespace, so usage strings include parent parameter placeholders.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  Modifying Context.command_path usage-path construction.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ac7d4998ab75fa0c05ca6741.md)

## Rule 109 — `src/click/core.py`

- **Rule:**
  ```text
  When modifying Context.call_on_close, preserve the teardown contract: callbacks are registered on the context's exit stack and run when the context tears down; resources supporting the context manager protocol should instead be registered via with_resource.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  Modifying Context.call_on_close teardown registration or resource lifecycle handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ad241b0f11637121f8fe6276.md)

## Rule 110 — `src/click/core.py`

- **Rule:**
  ```text
  Group.add_command must raise TypeError when neither an explicit name nor cmd.name is available, and must call _check_nested_chain before storing the command in self.commands.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  when modifying Group.add_command or command registration logic
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-aedbc6836f2ac3ecf8ca5999.md)

## Rule 111 — `tox.ini`

- **Rule:** The update-requirements tox environment skips installing the project package.
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b110fc1e81365487e099c518.md)

## Rule 112 — `tests/test_shell_completion.py`

- **Rule:** Tests that exercise custom shell-completion callbacks must preserve the (ctx, param, incomplete) signature and list-of-strings return contract; changing the callback protocol requires updating these tests.
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:** When modifying the shell-completion callback protocol (signature or return type), the custom-callback test must be updated.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b2189d7f57909e8753c19042.md)

## Rule 113 — `src/click/_compat.py`

- **Rule:**
  ```text
  When modifying _compat module import-time behavior, preserve the platform gating: CYGWIN and WIN are derived from sys.platform prefixes, and _winconsole import plus ANSI stream wrapper installation occur only when sys.platform starts with 'win' and WIN is true.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  Modifying _compat platform detection or Windows-specific import-time wrapping.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b23bf23874b6e39271bca83c.md)

## Rule 114 — `tests/typing/typing_aliased_group.py`

- **Rule:** The typing example must keep asserting that a command alias group instance is typed as AliasedGroup, preserving the documented command-alias pattern's static typing compatibility.
- **Applies to:**
  - `tests/typing/typing_aliased_group.py`
- **Condition:** When modifying the typing example for command alias groups.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b2e0b86cfff1f3726e219f36.md)

## Rule 115 — `tests/test_shell_completion.py`

- **Rule:** Shell completion for a Choice type must filter candidates by the incomplete prefix: an empty prefix returns all choices, a partial prefix returns only matching choices, and an exact match returns only that choice.
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:** When modifying or extending shell completion tests for Choice-typed parameters, preserve prefix-based candidate filtering semantics.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b2ed3f06145a311c82518d3f.md)

## Rule 116 — `tests/test_custom_classes.py`

- **Rule:** Tests that exercise custom Group subclasses must preserve the subclassing contract; changing Group subclass behavior requires updating these tests.
- **Applies to:**
  - `tests/test_custom_classes.py`
- **Condition:** When modifying click.Group subclassing behavior, the custom-subgroup test must be updated.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b66b79f06f2b84fa86658b8b.md)

## Rule 117 — `.github/workflows/publish.yaml`

- **Rule:** The publish-pypi job publishes packages from artifact/ using pypa/gh-action-pypi-publish.
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b768428a74f02b35d2031408.md)

## Rule 118 — `src/click/core.py`

- **Rule:**
  ```text
  When modifying Option.prompt_for_value in core.py, preserve the flow: compute the default before prompting, route boolean flags through confirm, and forward show_default to prompt only when it is a bool.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  Changing Option.prompt_for_value default computation, boolean routing, or show_default forwarding
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b8143993c6e6c7408b357adc.md)

## Rule 119 — `src/click/_textwrap.py`

- **Rule:** TextWrapper must subclass textwrap.TextWrapper, indicating click customizes standard library wrapping behavior for its formatting needs.
- **Applies to:**
  - `src/click/_textwrap.py`
- **Condition:** When modifying click's text wrapping behavior or the TextWrapper class.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b8d26c4a7d8440c8d4aeb698.md)

## Rule 120 — `**`

- **Rule:** The pre-commit workflow runs the pre-commit-ci/lite-action step when the job has not been cancelled.
- **Applies to:**
  - `**`
- **Condition:** workflow predicate: ${{ !cancelled() }}
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b972c4959abd3a9140e2717b.md)

## Rule 121 — `tests/test_formatting.py`

- **Rule:**
  ```text
  Help text truncation must occur at a form feed (\f) in a command docstring, and tests must define a command whose docstring contains \f followed by text.
  ```
- **Applies to:**
  - `tests/test_formatting.py`
- **Condition:** When modifying help text truncation behavior or its tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-bc334eec2efb349dd0ba19f0.md)

## Rule 122 — `src/click/core.py`

- **Rule:**
  ```text
  Parameter must preserve the documented deprecation of the autocompletion parameter renamed to shell_complete in 8.0, with the old name wrapped until 8.1.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  when modifying Parameter's autocompletion or shell_complete parameter handling
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-bcfe42e07769e7fc5fc4318a.md)
