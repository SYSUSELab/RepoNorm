# Full rule catalog

## Rule 018 — `src/click/exceptions.py`

- **Rule:**
  ```text
  When modifying ClickException, preserve the invariant that it is the base exception Click handles and shows to the user, with a class-level exit_code default of 1.
  ```
- **Applies to:**
  - `src/click/exceptions.py`
- **Condition:**
  ```text
  When changing ClickException or its exit_code default.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1a46542ca6bbacc97f6aaf7a.md)

## Rule 019 — `src/click/shell_completion.py`

- **Rule:**
  ```text
  When modifying CompletionItem.__init__, preserve the shell completion item data contract: store value, type (default 'plain'), help, and capture remaining kwargs in _info.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:**
  ```text
  Modifying CompletionItem.__init__ field storage or default type handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1a51b9ed536418268107fee4.md)

## Rule 020 — `**/*.css`

- **Rule:** Files with the extensions css, html, js, json, jsx, scss, ts, tsx, yaml, or yml use an indent size of 2.
- **Applies to:**
  - `**/*.css`
  - `**/*.html`
  - `**/*.js`
  - `**/*.json`
  - `**/*.jsx`
  - `**/*.scss`
  - `**/*.ts`
  - `**/*.tsx`
  - `**/*.yaml`
  - `**/*.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1b7248c8e04eeab906db3ab2.md)

## Rule 021 — `.github/workflows/publish.yaml`

- **Rule:**
  ```text
  The create-release job creates a draft GitHub release via gh release create --draft with the repository and ref name, attaching *.intoto.jsonl and artifact/* files, using GH_TOKEN from github.token.
  ```
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-2335ae7c83ea7b156c0db030.md)

## Rule 022 — `src/click/core.py`

- **Rule:**
  ```text
  When modifying Command.format_help in core.py, preserve the documented low-level help composition order: format_usage, then format_help_text, then format_options, then format_epilog.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  Changing Command.format_help composition or ordering of help sections
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-23a0e64cf20e22202f22d294.md)

## Rule 023 — `src/click/testing.py`

- **Rule:**
  ```text
  CliRunner.invoke must preserve the documented versioned result attributes: output_bytes mixes stdout_bytes and stderr_bytes as seen in a terminal since 8.2, stderr_bytes is always returned, return_value holds the invoked command's return value since 8.0, and exc_info holds the traceback when available since 3.0.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:** when modifying CliRunner.invoke or its result attributes
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-23ee5919777fae0dfbb931db.md)

## Rule 024 — `src/click/termui.py`

- **Rule:** secho must style the message only when it is not bytes/bytearray, passing bytes through to echo unstyled, and must convert non-string messages to str.
- **Applies to:**
  - `src/click/termui.py`
- **Condition:** when modifying secho's message handling or styling path
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-24724711f08edd488417e7e1.md)

## Rule 025 — `examples/aliases/aliases.py`

- **Rule:**
  ```text
  The aliases example's get_command must resolve commands in order: builtin commands, explicit config alias, then automatic abbreviation; abbreviation only succeeds when exactly one command matches, otherwise ctx.fail reports 'Too many matches'.
  ```
- **Applies to:**
  - `examples/aliases/aliases.py`
- **Condition:** When modifying command resolution logic in the aliases example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-253229a7a0c5e9207e3faa19.md)

## Rule 026 — `**`

- **Rule:** The typing test environment runs mypy as a command.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-26a90b8c29b9deac223ff6c6.md)

## Rule 027 — `tox.ini`

- **Rule:** The tox testenv uses frozen constraints.
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-281e78ab17e9b6b9bbf5def6.md)

## Rule 028 — `click/**`

- **Rule:** Coverage measurement is configured to restrict its source to the click package and the tests directory.
- **Applies to:**
  - `click/**`
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-28cd2030c9bb34be433ba7f3.md)

## Rule 029 — `examples/**`

- **Rule:** Ruff excludes the examples/ directory from linting via extend-exclude.
- **Applies to:**
  - `examples/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-2b683e197feea26882b7bf8a.md)

## Rule 030 — `src/click/core.py`

- **Rule:** When modifying Group.group or Command.group, preserve the overloaded decorator behavior: a bare callable is accepted and returns a Group, and the decorator form produces a Group, so both direct and parenthesized decorator usage remain supported.
- **Applies to:**
  - `src/click/core.py`
- **Condition:** When changing Group.group or Command.group overloads or decorator-based group creation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-2bc00fdf0eb2120764dcc8ce.md)

## Rule 031 — `tests/test_shell_completion.py`

- **Rule:**
  ```text
  Shell completion tests must keep exercising the public shell_completion API surface (add_completion_class, CompletionItem, ShellComplete) together with core Command/Group/Option/Argument and Choice/File/Path types, because these are the stable entry points the completion tests depend on.
  ```
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:** When modifying shell completion tests or the completion API surface they import.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-2c40f40da6af63474aa830fd.md)

## Rule 032 — `examples/inout/inout.py`

- **Rule:** The inout example must use click.File('rb') with nargs=-1 for input and click.File('wb') for output, document that '-' denotes stdin/stdout, and copy chunks of 1024 bytes flushing after each write.
- **Applies to:**
  - `examples/inout/inout.py`
- **Condition:** When modifying the inout example's file input/output handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-2c7519b02b7d473eccdcbf7e.md)

## Rule 033 — `src/click/globals.py`

- **Rule:**
  ```text
  When modifying pop_context, preserve that it removes the top level from the context stack via _local.stack.pop(), requiring a prior push and raising IndexError on empty stack.
  ```
- **Applies to:**
  - `src/click/globals.py`
- **Condition:**
  ```text
  When changing pop_context or context stack management.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-2eaa8b7939681aafa3ea27af.md)

## Rule 034 — `src/click/types.py`

- **Rule:**
  ```text
  When modifying _NumberRangeBase.__repr__, preserve the representation that includes the range description and appends ' clamped' when clamping is enabled.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When changing _NumberRangeBase.__repr__ or its clamped representation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3218c1ce2dc8f0557203c0a6.md)
