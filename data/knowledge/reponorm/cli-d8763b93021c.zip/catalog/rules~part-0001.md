# Full rule catalog

## Rule 001 — `tests/test_utils.py`

- **Rule:** Tests that assert exact stdout/stderr routing for echo/prompt/confirm/pause must be updated when output routing changes; the routing contract (including leading-space and prompt-text placement) is pinned.
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:** When modifying echo/prompt/confirm/pause output routing between stdout and stderr, the exact-routing assertions in the utils test must be updated.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-002fb5be1203be478035a58d.md)

## Rule 002 — `tests/test_utils.py`

- **Rule:** LazyFile iteration must yield the file's lines, and tests must compare each expected line to the stripped actual line.
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:** When modifying LazyFile iteration behavior or its tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-006d570907d25a374b4385c8.md)

## Rule 003 — `docs/_build/**`

- **Rule:**
  ```text
  The flit sdist build excludes docs/_build/ from the source distribution.
  ```
- **Applies to:**
  - `docs/_build/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-03dd292af8afd81e9e1936f0.md)

## Rule 004 — `**/*.py`

- **Rule:** Ruff linting is configured with the rule set B, E, F, I, UP, and W selected.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-04e007ad3a4be09c578ef325.md)

## Rule 005 — `src/click/_compat.py`

- **Rule:**
  ```text
  _FixupStream.readable must return True when _force_readable is set, otherwise delegate to the wrapped stream's readable() if present, and fall back to attempting a zero-byte read, returning False on any exception.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  when modifying _FixupStream.readable or stream compatibility behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-08bd3af902df845e64f4d01a.md)

## Rule 006 — `examples/repo/repo.py`

- **Rule:**
  ```text
  Example commands that maintain mutable state must initialize it in the context object's __init__ (e.g. home, empty config dict, verbose=False) so commands share consistent state.
  ```
- **Applies to:**
  - `examples/repo/repo.py`
- **Condition:** when modifying the shared context object's initialization in the repo example
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-094504a10eca535e1a8c34a6.md)

## Rule 007 — `src/click/testing.py`

- **Rule:**
  ```text
  BytesIOCopy.flush must delegate to super().flush() and then copy_to.flush() to keep the mirrored buffer synchronized.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:** when modifying BytesIOCopy.flush or testing stream mirroring behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0c8973f8c185ca1bbf3c3669.md)

## Rule 008 — `tests/**`

- **Rule:**
  ```text
  Pytest test discovery is restricted to the tests directory via testpaths = ["tests"].
  ```
- **Applies to:**
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0d62a1719df3b1583e69c95d.md)

## Rule 009 — `src/click/core.py`

- **Rule:**
  ```text
  value_from_envvar must split the resolved envvar value via the parameter type's split_envvar_value only when the value is not None and nargs is not 1, so single-value parameters receive the raw string.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  when modifying value_from_envvar's envvar resolution or splitting behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-103da921e689ab75d789f49a.md)

## Rule 010 — `examples/complex/complex/cli.py`

- **Rule:** The complex example must define an Environment class in its CLI module serving as the shared state object passed through the example's command group.
- **Applies to:**
  - `examples/complex/complex/cli.py`
- **Condition:** When modifying the complex example's shared state handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-11f3d955bedad39add2a8dc5.md)

## Rule 011 — `src/click/core.py`

- **Rule:**
  ```text
  When modifying Group.resolve_command, preserve the resolution protocol: apply ctx.token_normalize_func when the initial lookup fails, and when still unresolved and not resilient_parsing, re-parse args if the first token looks like an option before failing with 'No such command', preserving --help routing.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  Modifying Group.resolve_command lookup, token normalization, or option-like fallback handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-126659bab1003f893a580746.md)

## Rule 012 — `src/click/utils.py`

- **Rule:** The wrapper constructor must store the wrapped IO object as self.wrapped, which is the delegation target for attribute access.
- **Applies to:**
  - `src/click/utils.py`
- **Condition:** when modifying the wrapper constructor or its delegation target
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-12880dc83cffda715b83102f.md)

## Rule 013 — `tests/test_utils.py`

- **Rule:** Tests for click.echo must verify it does not fail when sys.stdout and sys.stderr are None, as occurs with pythonw on Windows.
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:** When modifying or adding tests for click.echo behavior under missing standard streams.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-12fb35428b53a2624410a2db.md)

## Rule 014 — `examples/repo/repo.py`

- **Rule:** Example commands that copy files must accept variadic source paths and a single destination path, support a --force flag, and echo each copy operation.
- **Applies to:**
  - `examples/repo/repo.py`
- **Condition:** When adding or modifying a copy command in the repo example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-13324d8c153b06abde4a4992.md)

## Rule 015 — `src/click/core.py`

- **Rule:**
  ```text
  When modifying Context.find_root, preserve the traversal behavior that walks parent links to the outermost context so nested contexts can locate the root for shared state.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When changing Context.find_root or its parent-link traversal.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-136a95690b8438f70967b0a1.md)

## Rule 016 — `src/click/types.py`

- **Rule:**
  ```text
  When modifying Path.coerce_path_result, preserve the conversion behavior: values are converted to str via os.fsdecode, to bytes via os.fsencode, or to the configured PathLike type, and returned unchanged when they already match the type.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When changing Path.coerce_path_result or its path type conversion logic.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-18c75754ded5ac8d63701ca6.md)

## Rule 017 — `examples/repo/repo.py`

- **Rule:** The repo example's commit command must use multiple=True for --message/-m, build an editor hint with the marker "# Files to be committed:" when no message is provided, abort on None or empty message, and otherwise join multiple messages with newlines.
- **Applies to:**
  - `examples/repo/repo.py`
- **Condition:** When modifying the commit command's message handling in the repo example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1a180052db401e7935fa727b.md)
