# Full rule catalog

## Rule 123 — `requirements/docs.txt`

- **Rule:** Read the Docs documentation builds install requirements from requirements/docs.txt.
- **Applies to:**
  - `requirements/docs.txt`
- **Normative strength:** `observed`
- **Use:** `reference_only`
- **Execution risk:** `external_side_effect`
- **Detail:** [Open claim details](../claims/CLAIM-bddfd448afc743a8f031af5a.md)

## Rule 124 — `tests/test_options.py`

- **Rule:**
  ```text
  Tests that verify custom option/argument classes must keep using the get_help_record override and default/hidden display behavior as the extension points under test.
  ```
- **Applies to:**
  - `tests/test_options.py`
- **Condition:** When modifying tests for custom option or argument classes and their help/default rendering.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-be5083cea9c5f4a83ba76f71.md)

## Rule 125 — `**`

- **Rule:**
  ```text
  Files matching the [*] section use UTF-8 charset.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c1cd8e94713700a0cfeff4f6.md)

## Rule 126 — `examples/repo/repo.py`

- **Rule:**
  ```text
  Example click groups that manage shared state must store a state object on ctx.obj in the group callback and provide it to subcommands via a pass_repo-style decorator.
  ```
- **Applies to:**
  - `examples/repo/repo.py`
- **Condition:** When adding or modifying a click group in the repo example that manages shared state.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c4bd4da67be47708f88ea848.md)

## Rule 127 — `tests/test_termui.py`

- **Rule:**
  ```text
  Windows-specific getchar behavior must keep mapping Ctrl-C (\x03) to KeyboardInterrupt and Ctrl-Z (\x1a) to EOFError, tested by monkeypatching msvcrt.getwch and disabling _getchar.
  ```
- **Applies to:**
  - `tests/test_termui.py`
- **Condition:** When modifying Windows getchar exception handling or its tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-cd14cbcf283b740a008dd881.md)

## Rule 128 — `.github/workflows/publish.yaml`

- **Rule:**
  ```text
  The build job sets SOURCE_DATE_EPOCH from the last commit date via git log -1 --pretty=%ct written to $GITHUB_ENV.
  ```
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-cf491f5deb1fe222e12b18f4.md)

## Rule 129 — `src/click/formatting.py`

- **Rule:** When modifying HelpFormatter in formatting.py, preserve the documented contract that it always writes into memory and that width defaults to terminal width clamped to a maximum of 78.
- **Applies to:**
  - `src/click/formatting.py`
- **Condition:** Changing HelpFormatter width defaulting or output buffering behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d22826a5dc3954b487c62134.md)

## Rule 130 — `.github/workflows/publish.yaml`

- **Rule:** The build job installs build requirements with pip install -r requirements/build.txt.
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d26e322f0dac5bf4ccb00716.md)

## Rule 131 — `tox.ini`

- **Rule:** The update-requirements tox environment changes to the requirements directory before running its commands.
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d6619864fbdeea5df2184e30.md)

## Rule 132 — `src/click/utils.py`

- **Rule:** echo must preserve its output compatibility guarantees: flush output, strip ANSI codes when the output stream is not an interactive terminal, write bytes to a discovered binary writer, and return early when no standard streams are attached.
- **Applies to:**
  - `src/click/utils.py`
- **Condition:** when modifying echo's stream selection, ANSI stripping, byte writing, or flush behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-db6f72e4bb5b822f797a8be6.md)

## Rule 133 — `tests/test_shell_completion.py`

- **Rule:**
  ```text
  Shell completion tests must parametrize over Path type configurations and assert that File() or Path() yields completion item type "file" while Path(file_okay=False) yields "dir".
  ```
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:** When modifying path-type completion item type mapping or its tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-db9cc52e525e1266f803e586.md)

## Rule 134 — `examples/completion/completion.py`

- **Rule:** Example shell completion callbacks must return CompletionItem objects with help strings and match the incomplete value against both the value and the help text.
- **Applies to:**
  - `examples/completion/completion.py`
- **Condition:** When adding or modifying a shell completion callback in the completion example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-dfec9d11a6b78a5a48d14b0f.md)

## Rule 135 — `tests/typing/typing_aliased_group.py`

- **Rule:**
  ```text
  Typing tests that override resolve_command must return cmd.name from the super() result and assert cmd is not None, pinning the aliased-group command resolution contract.
  ```
- **Applies to:**
  - `tests/typing/typing_aliased_group.py`
- **Condition:**
  ```text
  when adding or modifying typing tests that override resolve_command in tests/typing/typing_aliased_group.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e10a6caa2d8d922bfea2ed81.md)

## Rule 136 — `src/click/utils.py`

- **Rule:** The stream flush wrapper must suppress only OSError with errno EPIPE and re-raise all other OSErrors, preserving the broken-pipe compatibility boundary.
- **Applies to:**
  - `src/click/utils.py`
- **Condition:** when modifying the flush wrapper's exception handling for output streams
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e1cfc6baaf689469d5dcfa55.md)

## Rule 137 — `tox.ini`

- **Rule:**
  ```text
  The tox testenv `update-actions` declares dependency `gha-update`.
  ```
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e31ea0dd02ff58560af48414.md)

## Rule 138 — `src/click/utils.py`

- **Rule:**
  ```text
  When modifying KeepOpenFile.__exit__ in utils.py, preserve that it is a no-op accepting exception type, value, and traceback and returning None, so exceptions are not suppressed.
  ```
- **Applies to:**
  - `src/click/utils.py`
- **Condition:**
  ```text
  Changing KeepOpenFile.__exit__ exception handling or return value
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e818e5c80cadd76dd471cafb.md)

## Rule 139 — `src/click/termui.py`

- **Rule:**
  ```text
  When modifying prompt() in termui.py, preserve the re-prompt loop: value_proc rejections (UsageError) must re-prompt with the error message, and when confirmation_prompt is set the second entry must match the first or the prompt repeats; confirmation_prompt=True must be replaced by the translated 'Repeat for confirmation' string.
  ```
- **Applies to:**
  - `src/click/termui.py`
- **Condition:** Changing prompt() input validation, confirmation, or error re-prompt behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-eaca096f29ba139f0b5ee4fc.md)
