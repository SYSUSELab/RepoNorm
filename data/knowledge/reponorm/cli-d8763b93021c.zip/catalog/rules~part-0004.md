# Full rule catalog

## Rule 052 — `src/click/testing.py`

- **Rule:**
  ```text
  EchoingStdin.read1 must delegate to self._echo(self._input.read1(n)) so bytes read through read1 are echoed to the captured output stream.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:** when modifying EchoingStdin.read1 or testing stream echo behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-52553c5aed48c83d957a0051.md)

## Rule 053 — `src/click/types.py`

- **Rule:**
  ```text
  When modifying FloatRange.__init__, preserve the validation that raises TypeError when clamp is True together with min_open or max_open, since clamping is not supported for open bounds.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When changing FloatRange.__init__ clamp or open-bound validation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-52909e6e71029dcf3d5c3a21.md)

## Rule 054 — `.github/workflows/publish.yaml`

- **Rule:** The build job builds the package with python -m build.
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5381c66612f017140f32e820.md)

## Rule 055 — `src/click/_compat.py`

- **Rule:** The seekable check must prefer the wrapped stream's own seekable attribute when present and only fall back to a seek/tell probe when that attribute is absent, treating probe exceptions as non-seekable.
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  when modifying _FixupStream.seekable or its fallback probe behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-555df78c4ec415aafc3910e0.md)

## Rule 056 — `src/click/core.py`

- **Rule:**
  ```text
  When modifying _MultiCommand, preserve the deprecation boundary: _MultiCommand is deprecated as of 8.2 and scheduled for removal in Click 9.0, with Group as the replacement; do not remove or change this compatibility boundary without updating the deprecation schedule.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When changing _MultiCommand or its deprecation metadata.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-55cc8ccfe8e75967bf6ae086.md)

## Rule 057 — `src/click/core.py`

- **Rule:**
  ```text
  Command.get_help must build a formatter via ctx.make_formatter, call format_help, and return the value with trailing newlines stripped.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  when modifying Command.get_help or help formatting logic
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-55e2cdca8e4bef3ae1c627ee.md)

## Rule 058 — `**/*.py`

- **Rule:**
  ```text
  The project declares a minimum supported Python version of 3.8 via requires-python = ">=3.8".
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5776411247f55833132b6580.md)

## Rule 059 — `tests/typing/typing_group_kw_options.py`

- **Rule:**
  ```text
  Tests that exercise Click's typing must use typing_extensions.assert_type to assert that a decorated command object is statically typed as click.Group.
  ```
- **Applies to:**
  - `tests/typing/typing_group_kw_options.py`
- **Condition:** when modifying or adding typing tests that assert on decorated command object types
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5797206233b173118f1de8f6.md)

## Rule 060 — `src/click/core.py`

- **Rule:** When modifying Context.invoke, preserve both invocation modes: passing a callback directly, or passing a Command whose callback is invoked with a new sub-context; in command mode, missing exposed params are filled from defaults and all kwargs are tracked in ctx.params so forward() can pass them at multiple levels.
- **Applies to:**
  - `src/click/core.py`
- **Condition:** When changing Context.invoke or its callback/command invocation modes.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-58dc6193a72b68b559c019c3.md)

## Rule 061 — `src/click/core.py`

- **Rule:**
  ```text
  When modifying Context.protected_args, preserve the deprecation boundary: protected_args is deprecated and will be removed in Click 9.0, with args containing remaining unparsed tokens; do not remove or change this compatibility boundary without updating the deprecation schedule.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When changing Context.protected_args or its deprecation metadata.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-590e4a8a65b694e2cd5c583a.md)

## Rule 062 — `tox.ini`

- **Rule:** The tox testenv runs pytest with verbose output, short tracebacks, and a basetemp under the environment temp directory, forwarding posargs.
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-59305d56b31ddf224831700f.md)

## Rule 063 — `src/click/_winconsole.py`

- **Rule:**
  ```text
  The Py_buffer ctypes Structure must preserve its exact field layout used for Windows console buffer access.
  ```
- **Applies to:**
  - `src/click/_winconsole.py`
- **Condition:**
  ```text
  when modifying Windows console buffer handling or the Py_buffer structure
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-59dd1e444744020367dafff9.md)

## Rule 064 — `src/click/formatting.py`

- **Rule:**
  ```text
  wrap_text with preserve_paragraphs=True treats a paragraph prefixed by a line containing the \b (\x08) character as raw: it is emitted via wrapper.indent_only without rewrapping, while normal paragraphs are filled.
  ```
- **Applies to:**
  - `src/click/formatting.py`
- **Condition:**
  ```text
  When modifying wrap_text paragraph handling or the \b raw-paragraph extension.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5a3b73b5170e0f265d60433b.md)

## Rule 065 — `examples/repo/repo.py`

- **Rule:**
  ```text
  The repo example must create a pass decorator via click.make_pass_decorator(Repo) to pass a Repo object through the context to commands.
  ```
- **Applies to:**
  - `examples/repo/repo.py`
- **Condition:** When modifying the repo example's context object passing mechanism.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5d1c28d18cf3430c6f87ae9f.md)

## Rule 066 — `src/click/core.py`

- **Rule:**
  ```text
  Parameter.get_help_record must return None by default, defining the no-help-record contract that subclasses override.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  when modifying Parameter.get_help_record or help-record generation
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5d92f7da89f106cff5a97394.md)

## Rule 067 — `**/*.py`

- **Rule:** Ruff isort linting enforces single-line import formatting (force-single-line = true).
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-621b35d9e44b2380761db6f7.md)

## Rule 068 — `src/click/types.py`

- **Rule:**
  ```text
  IntRange._clamp must return the bound unchanged when the range is closed, and bound + dir when open, so open bounds are adjusted by the direction to exclude the endpoint.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  when modifying IntRange._clamp or range bound handling
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6914271c151a7441e627d03f.md)
