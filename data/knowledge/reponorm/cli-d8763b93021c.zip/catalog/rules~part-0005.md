# Full rule catalog

## Rule 069 — `tests/test_parser.py`

- **Rule:**
  ```text
  Tests for split_arg_string must verify that quoted strings and backslash escapes are handled, including that an unterminated quote still yields the quoted content and a trailing backslash is dropped.
  ```
- **Applies to:**
  - `tests/test_parser.py`
- **Condition:**
  ```text
  when adding or modifying tests for split_arg_string in tests/test_parser.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-69a37ef2022ee510bd1610af.md)

## Rule 070 — `src/click/parser.py`

- **Rule:**
  ```text
  When modifying _ParsingState.__init__, preserve the initialization of opts, largs, rargs, and order parsing state so contributors extending the parser account for this mutable state.
  ```
- **Applies to:**
  - `src/click/parser.py`
- **Condition:**
  ```text
  When changing _ParsingState.__init__ or extending the option parser's mutable state.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6b3a3ccfd761237ced0516c8.md)

## Rule 071 — `examples/completion/completion.py`

- **Rule:** Example click groups must be defined with no subcommands, relying on later registration of commands via decorators.
- **Applies to:**
  - `examples/completion/completion.py`
- **Condition:** When defining a click group in an example that will have commands registered later.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6dc632f501d4d843cc38ba8e.md)

## Rule 072 — `tests/test_shell_completion.py`

- **Rule:** Absolute-path completion for a Path option must yield exactly one completion whose value is the absolute prefix, documenting absolute-path completion behavior.
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:** When modifying absolute-path completion behavior or its tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-71826de416388f8e429886c0.md)

## Rule 073 — `src/click/core.py`

- **Rule:**
  ```text
  Group.get_command must return the Command from self.commands by name or None if absent, defining the base command lookup contract.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  when modifying Group.get_command or its lookup behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-719cdf89f61dc315219f7dd1.md)

## Rule 074 — `tox.ini`

- **Rule:**
  ```text
  The tox testenv `update-pre_commit` runs `pre-commit autoupdate -j4` as its command.
  ```
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7332e2df73098c231095bb45.md)

## Rule 075 — `src/click/shell_completion.py`

- **Rule:**
  ```text
  When modifying ShellComplete.format_completion in shell_completion.py, preserve its abstract-style contract: it must raise NotImplementedError so each shell-specific subclass implements completion item formatting.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:**
  ```text
  Changing ShellComplete.format_completion or adding shell-specific completion subclasses
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7425cc3f2a20e0986454c0fa.md)

## Rule 076 — `requirements/typing.in`

- **Rule:** The update-requirements tox environment runs pip-compile on typing.in with -q and posargs defaulting to -U.
- **Applies to:**
  - `requirements/typing.in`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-77d18b60690bcd6ed0e57e65.md)

## Rule 077 — `src/click/formatting.py`

- **Rule:**
  ```text
  measure_table must compute the maximum width of each column across rows using term_len, returning a tuple of widths sorted by column index.
  ```
- **Applies to:**
  - `src/click/formatting.py`
- **Condition:** When modifying table width measurement or column width computation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-787798dea1155c7cf7dcb10a.md)

## Rule 078 — `examples/colors/colors.py`

- **Rule:** Example commands that emit styled output must apply click.style with the documented style attributes (fg, bold, reverse, blink, underline) and must rely on Click's automatic removal of ANSI styles when output is piped to a file rather than stripping them manually.
- **Applies to:**
  - `examples/colors/colors.py`
- **Condition:** when adding or modifying an example command that emits styled or colored output
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-78b1025258391d72d2d1360a.md)

## Rule 079 — `src/click/types.py`

- **Rule:**
  ```text
  When modifying CompositeParamType in types.py, preserve that it subclasses ParamType and sets is_composite = True, marking it as a type that consumes multiple values.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  Changing CompositeParamType inheritance or is_composite flag
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7aba3ca3eb26673ace67782b.md)

## Rule 080 — `docs/conf.py`

- **Rule:**
  ```text
  Sphinx autodoc options in docs/conf.py must keep autodoc_member_order='bysource', autodoc_typehints='description', and autodoc_preserve_defaults=True so generated API documentation preserves source member order, renders type hints in the description, and shows original default values.
  ```
- **Applies to:**
  - `docs/conf.py`
- **Condition:**
  ```text
  When modifying Sphinx configuration in docs/conf.py, preserve the autodoc_member_order, autodoc_typehints, and autodoc_preserve_defaults settings.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7e3e28ef71e1ed30a9a60c2b.md)

## Rule 081 — `src/click/types.py`

- **Rule:**
  ```text
  When modifying DateTime.__repr__, preserve the stable literal representation "DateTime" used for type display.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When changing DateTime.__repr__ or its type display representation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7f1a498446bfa9bbaf9ae5e1.md)

## Rule 082 — `**/*.py`

- **Rule:** Code must be formatted using Black; Black and other tools run automatically when pre-commit is installed.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-82947f5c208ef24bc1467008.md)

## Rule 083 — `tests/test_options.py`

- **Rule:** Tests that exercise option suggestion and bool-flag-with-type behavior must be updated when option parsing or suggestion logic changes.
- **Applies to:**
  - `tests/test_options.py`
- **Condition:** When modifying unknown-option suggestion logic or bool-flag-with-type acceptance, the corresponding assertions in the options test file must be updated.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-846a5a2fe071e6546465b39c.md)

## Rule 084 — `tests/typing/**`

- **Rule:** The typing test environment runs pyright against the tests/typing directory.
- **Applies to:**
  - `tests/typing/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-85cdb12a75cc387fa86dd6a6.md)

## Rule 085 — `src/click/_textwrap.py`

- **Rule:**
  ```text
  TextWrapper._handle_long_word must compute space_left as max(width - cur_len, 1) and ensure progress even with zero remaining width.
  ```
- **Applies to:**
  - `src/click/_textwrap.py`
- **Condition:**
  ```text
  when modifying TextWrapper._handle_long_word or long-word wrapping logic
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-866551078d67a816746f5d23.md)

## Rule 086 — `tox.ini`

- **Rule:** The tox testenv uses .pkg as the wheel build environment.
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-86bf1caf6fd6806cdb3c5dd3.md)
