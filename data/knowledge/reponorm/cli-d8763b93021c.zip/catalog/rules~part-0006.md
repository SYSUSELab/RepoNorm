# Full rule catalog

## Rule 087 — `src/click/_compat.py`

- **Rule:**
  ```text
  When modifying get_text_stdout, preserve the Windows-console special-casing: first attempt _get_windows_console_stream and otherwise fall back to _force_correct_text_writer with force_writable=True.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  Modifying get_text_stdout text stream resolution.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8aef9983bd2b235615e4e66b.md)

## Rule 088 — `tests/test_options.py`

- **Rule:**
  ```text
  Multiple=True options must split envvar values on os.path.pathsep, and auto_envvar_prefix must map TEST_ARG to the option, producing pathsep-joined output.
  ```
- **Applies to:**
  - `tests/test_options.py`
- **Condition:**
  ```text
  When modifying multiple-option envvar splitting or auto_envvar_prefix behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8ec73a637be26b7ea9381afc.md)

## Rule 089 — `src/click/formatting.py`

- **Rule:**
  ```text
  When modifying help formatting indentation, preserve that HelpFormatter.indent increases current_indent by indent_increment, defining the indentation step used in help formatting.
  ```
- **Applies to:**
  - `src/click/formatting.py`
- **Condition:** when changing HelpFormatter indentation logic
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8ece5ed01d4ef7ed0cf56b63.md)

## Rule 090 — `src/click/core.py`

- **Rule:**
  ```text
  CommandCollection.list_commands must merge super().list_commands with each source's list_commands into a set and return sorted results, deduplicating duplicate command names and producing deterministic order.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  when modifying CommandCollection.list_commands or its merge behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-963c98112a1082dfa845f0f6.md)

## Rule 091 — `src/click/formatting.py`

- **Rule:** When modifying help formatting, preserve that HelpFormatter.write appends to an internal buffer rather than emitting immediately, so output is only produced when the buffer is flushed.
- **Applies to:**
  - `src/click/formatting.py`
- **Condition:** when changing how HelpFormatter produces output
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9781a7c7f7c05af8fc77ced0.md)

## Rule 092 — `tests/typing/typing_aliased_group.py`

- **Rule:**
  ```text
  Typing example modules under tests/typing must remain static typing compatibility checks: typing_aliased_group defines a command 'pop' returning None to exercise aliased group typing, and typing_confirmation_option asserts a confirmation-option command is typed as click.Command for the documented yes-parameter pattern.
  ```
- **Applies to:**
  - `tests/typing/typing_aliased_group.py`
  - `tests/typing/typing_confirmation_option.py`
- **Condition:** When modifying or adding typing example modules under tests/typing.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-986d645fda9f79e856caed5c.md)

## Rule 093 — `examples/aliases/aliases.py`

- **Rule:** The aliases example must initialize path to the current working directory and an empty aliases dict, demonstrating a simple alias storage pattern.
- **Applies to:**
  - `examples/aliases/aliases.py`
- **Condition:** When modifying the aliases example's alias storage initialization.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-98a564216e78e31faa3c1e09.md)

## Rule 094 — `**`

- **Rule:**
  ```text
  The tox 'style' test environment runs pre-commit across all files via the command `pre-commit run --all-files`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Use:** `reference_only`
- **Execution risk:** `repository_wide_mutation`
- **Detail:** [Open claim details](../claims/CLAIM-997d318fc54eb07e709a239e.md)

## Rule 095 — `src/click/core.py`

- **Rule:** When modifying Option in core.py, preserve the Click 8.1 behavior that a single option boolean flag's default is not shown if its value is False.
- **Applies to:**
  - `src/click/core.py`
- **Condition:** Changing Option boolean flag default display behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9e536641c9cd93927dfbedfb.md)

## Rule 096 — `src/click/types.py`

- **Rule:**
  ```text
  When modifying ParamType.get_metavar in types.py, preserve the behavior that it returns the metavar default for a parameter if the type provides one, allowing custom types to control help metavar display.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  Changing ParamType.get_metavar or custom type metavar handling
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9ee6cd070ad61a10213f013d.md)

## Rule 097 — `tox.ini`

- **Rule:** The update-requirements tox environment installs pip-tools as its dependency.
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9fc201a4c2b494524bbeb3ff.md)

## Rule 098 — `src/click/_compat.py`

- **Rule:**
  ```text
  When modifying _find_binary_reader, preserve the detection behavior: return the stream itself when _is_binary_reader(stream, False) is true, otherwise check stream.buffer with _is_binary_reader(buf, True) and return it, else None, explicitly handling detached and closed-buffer stream cases.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  When changing _find_binary_reader or its binary stream detection logic.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a25c2dc9f2f428f674070d7c.md)

## Rule 099 — `requirements/docs.in`

- **Rule:** The update-requirements tox environment runs pip-compile on docs.in with -q and posargs defaulting to -U.
- **Applies to:**
  - `requirements/docs.in`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a333ae298a7c54123c0862f2.md)

## Rule 100 — `.github/workflows/publish.yaml`

- **Rule:** The build job uploads the ./dist directory as an artifact.
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a3c07ab6fda2802e2cd7d987.md)

## Rule 101 — `src/click/**`

- **Rule:** mypy is configured to check the files under src/click and tests/typing.
- **Applies to:**
  - `src/click/**`
  - `tests/typing/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a5a60396cc4b56cc56b3d72a.md)

## Rule 102 — `.github/workflows/publish.yaml`

- **Rule:**
  ```text
  The build job generates a hash by running sha256sum over dist contents and base64-encoding the result into $GITHUB_OUTPUT.
  ```
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a799f6ad1ae35bad163a4ebc.md)

## Rule 103 — `tox.ini`

- **Rule:** The tox testenv constrains package dependencies.
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a8c3447d315a6027c8b65e22.md)

## Rule 104 — `.github/workflows/lock.yaml`

- **Rule:** The lock workflow uses the dessant/lock-threads action pinned to commit 1bf7ec25051fe7c00bdd17e6a7cf3d7bfb7dc771 (v5.0.1).
- **Applies to:**
  - `.github/workflows/lock.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a8d1deffb940ff6223e7090d.md)

## Rule 105 — `requirements/build.in`

- **Rule:** The update-requirements tox environment runs pip-compile on build.in with -q and posargs defaulting to -U.
- **Applies to:**
  - `requirements/build.in`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-aa40ab6ac15aefec362b96b3.md)
