# Rule details

- **Rule:**
  ```text
  When modifying prompt() in termui.py, preserve the re-prompt loop: value_proc rejections (UsageError) must re-prompt with the error message, and when confirmation_prompt is set the second entry must match the first or the prompt repeats; confirmation_prompt=True must be replaced by the translated 'Repeat for confirmation' string.
  ```
- **Applies to:**
  - `src/click/termui.py`
- **Condition:** Changing prompt() input validation, confirmation, or error re-prompt behavior
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The prompt() body preserves the re-prompt loop on UsageError and the confirmation_prompt second-entry match requirement.
```

- **Sources:**
  - `src/click/termui.py:83-191`
