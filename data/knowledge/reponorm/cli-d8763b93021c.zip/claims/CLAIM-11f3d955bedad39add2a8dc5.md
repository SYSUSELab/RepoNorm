# Rule details

- **Rule:** The complex example must define an Environment class in its CLI module serving as the shared state object passed through the example's command group.
- **Applies to:**
  - `examples/complex/complex/cli.py`
- **Condition:** When modifying the complex example's shared state handling.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The complex example's CLI module defines the Environment class as the shared state object passed through the command group, matching the shared-state rule.
```

- **Sources:**
  - `examples/complex/complex/cli.py:10-24`
