# Rule details

- **Rule:**
  ```text
  When modifying EchoingStdin.__getattr__, preserve the delegation behavior that forwards attribute access to self._input, the underlying input stream.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:**
  ```text
  When changing EchoingStdin.__getattr__ or its attribute delegation.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
EchoingStdin.__getattr__ delegates attribute access to self._input via getattr(self._input, x), preserving the required delegation behavior.
```

- **Sources:**
  - `src/click/testing.py:32-33`
