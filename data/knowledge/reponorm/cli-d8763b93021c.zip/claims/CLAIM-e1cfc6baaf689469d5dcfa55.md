# Rule details

- **Rule:** The stream flush wrapper must suppress only OSError with errno EPIPE and re-raise all other OSErrors, preserving the broken-pipe compatibility boundary.
- **Applies to:**
  - `src/click/utils.py`
- **Condition:** when modifying the flush wrapper's exception handling for output streams
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
PacifyFlushWrapper.flush suppresses only OSError with errno EPIPE and re-raises all other OSErrors, preserving the broken-pipe boundary.
```

- **Sources:**
  - `src/click/utils.py:510-517`
