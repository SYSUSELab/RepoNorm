# Rule details

- **Rule:**
  ```text
  When modifying Option.__init__ flag/prompt derivation, preserve that prompt=True requires a name and derives prompt text from it, _flag_needs_value is set when prompt is enabled but not required, is_flag is inferred from flag_value, _flag_needs_value, or secondary_opts, count options default to IntRange(min=0) with default 0, and the __debug__-guarded TypeErrors remain enforced.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When changing Option.__init__ flag, prompt, count, or secondary-option derivation logic.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
Option.__init__ implements prompt-name derivation, _flag_needs_value, is_flag inference, count defaults, and the __debug__-guarded TypeErrors described by the rule.
```

- **Sources:**
  - `src/click/core.py:2454-2570`
