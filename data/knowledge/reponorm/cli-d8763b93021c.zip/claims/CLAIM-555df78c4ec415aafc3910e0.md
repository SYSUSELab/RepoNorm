# Rule details

- **Rule:** The seekable check must prefer the wrapped stream's own seekable attribute when present and only fall back to a seek/tell probe when that attribute is absent, treating probe exceptions as non-seekable.
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  when modifying _FixupStream.seekable or its fallback probe behavior
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
_FixupStream.seekable prefers the wrapped stream's seekable attribute when present and falls back to a seek/tell probe, treating probe exceptions as non-seekable.
```

- **Sources:**
  - `src/click/_compat.py:140-148`
