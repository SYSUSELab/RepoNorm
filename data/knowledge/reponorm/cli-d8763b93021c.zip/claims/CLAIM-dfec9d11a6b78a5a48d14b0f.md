# Rule details

- **Rule:** Example shell completion callbacks must return CompletionItem objects with help strings and match the incomplete value against both the value and the help text.
- **Applies to:**
  - `examples/completion/completion.py`
- **Condition:** When adding or modifying a shell completion callback in the completion example.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
list_users returns CompletionItem objects with help strings and matches the incomplete value against both value and help text.
```

- **Sources:**
  - `examples/completion/completion.py:36-47`
