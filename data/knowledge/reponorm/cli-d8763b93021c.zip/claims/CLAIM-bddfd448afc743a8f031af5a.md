# Rule details

- **Rule:** Read the Docs documentation builds install requirements from requirements/docs.txt.
- **Applies to:**
  - `requirements/docs.txt`
- **Normative strength:** `observed`
- **Use:** `reference_only`
- **Execution risk:** `external_side_effect`

## Supporting evidence

### Evidence 1 — explicit

```text
    - requirements: requirements/docs.txt

```

- **Sources:**
  - `.readthedocs.yaml:8`
