# Rule details

- **Rule:** The publish-pypi job downloads artifacts and publishes packages from artifact/ to the TestPyPI repository URL https://test.pypi.org/legacy/.
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
      - uses: actions/download-artifact@fa0a91b85d4f404e444e00e005971372dc801d16 # v4.1.8
      - uses: pypa/gh-action-pypi-publish@f7600683efdcb7656dec5b29656edb7bc586e597 # v1.10.3
        with:
          repository-url: https://test.pypi.org/legacy/
          packages-dir: artifact/

```

- **Sources:**
  - `.github/workflows/publish.yaml:66-70`
