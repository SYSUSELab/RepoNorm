# Rule details

- **Rule:**
  ```text
  The tox 'style' test environment sets skip_install to true, so the package is not installed into that environment.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
skip_install = true

```

- **Sources:**
  - `tox.ini:20`
