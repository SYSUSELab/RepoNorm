# Rule details

- **Rule:** The typing test environment runs mypy as a command.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
commands =
    mypy
    pyright tests/typing
    pyright --verifytypes click --ignoreexternal

```

- **Sources:**
  - `tox.ini:25-28`
