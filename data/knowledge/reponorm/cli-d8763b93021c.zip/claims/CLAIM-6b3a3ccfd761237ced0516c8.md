# Rule details

- **Rule:**
  ```text
  When modifying _ParsingState.__init__, preserve the initialization of opts, largs, rargs, and order parsing state so contributors extending the parser account for this mutable state.
  ```
- **Applies to:**
  - `src/click/parser.py`
- **Condition:**
  ```text
  When changing _ParsingState.__init__ or extending the option parser's mutable state.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
_ParsingState.__init__ initializes opts, largs, rargs, and order, preserving the mutable parsing state described by the rule.
```

- **Sources:**
  - `src/click/parser.py:215-219`
