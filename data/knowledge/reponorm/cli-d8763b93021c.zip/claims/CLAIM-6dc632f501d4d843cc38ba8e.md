# Rule details

- **Rule:** Example click groups must be defined with no subcommands, relying on later registration of commands via decorators.
- **Applies to:**
  - `examples/completion/completion.py`
- **Condition:** When defining a click group in an example that will have commands registered later.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The completion module defines the click group with no inline subcommands; commands are registered later via cli.add_command(group), matching the empty-group/later-registration convention.
```

- **Sources:**
  - `examples/completion/completion.py`

### Evidence 2 — current_observation

```text
The cli group in the completion example is defined with an empty body, relying on later command registration via decorators.
```

- **Sources:**
  - `examples/completion/completion.py:8-9`

### Evidence 3 — current_observation

```text
The group function is decorated with @cli.group and has an empty body (pass), defining no subcommands inline and relying on later registration, matching the empty-group convention.
```

- **Sources:**
  - `examples/completion/completion.py:32-33`
