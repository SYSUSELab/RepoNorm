# Rule details

- **Rule:** The tox default environment list includes py3{13,12,11,10,9,8}, pypy310, style, typing, and docs.
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
envlist =
    py3{13,12,11,10,9,8}
    pypy310
    style
    typing
    docs

```

- **Sources:**
  - `tox.ini:2-7`
