# Rule details

- **Rule:**
  ```text
  Tests for confirm prompts must assert exact prompt/response output: default-True prompts render 'Foo [Y/n]: ' and empty input yields 'yes!', while default-False prompts render 'Foo [y/N]: ' and empty input yields 'no :('.
  ```
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:** When modifying or adding tests for confirm prompt formatting and default-echo behavior.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_prompts asserts exact confirm prompt formatting and default-echo behavior: 'Foo [y/N]: ' with empty input yielding 'no :(' and 'Foo [Y/n]: ' with empty input yielding 'yes!'.
```

- **Sources:**
  - `tests/test_utils.py:113-150`
