# Rule details

- **Rule:**
  ```text
  When modifying KeepOpenFile.__exit__ in utils.py, preserve that it is a no-op accepting exception type, value, and traceback and returning None, so exceptions are not suppressed.
  ```
- **Applies to:**
  - `src/click/utils.py`
- **Condition:**
  ```text
  Changing KeepOpenFile.__exit__ exception handling or return value
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
KeepOpenFile.__exit__ accepts exception type, value, and traceback and is a no-op returning None, so exceptions are not suppressed.
```

- **Sources:**
  - `src/click/utils.py:207-213`
