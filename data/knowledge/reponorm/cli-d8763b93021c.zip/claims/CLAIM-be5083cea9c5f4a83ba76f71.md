# Rule details

- **Rule:**
  ```text
  Tests that verify custom option/argument classes must keep using the get_help_record override and default/hidden display behavior as the extension points under test.
  ```
- **Applies to:**
  - `tests/test_options.py`
- **Condition:** When modifying tests for custom option or argument classes and their help/default rendering.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The test file defines custom option classes overriding get_help_record and exercises custom argument default display, matching the custom-class extension-point convention.
```

- **Sources:**
  - `tests/test_options.py`
