# Rule details

- **Rule:** The inout example must use click.File('rb') with nargs=-1 for input and click.File('wb') for output, document that '-' denotes stdin/stdout, and copy chunks of 1024 bytes flushing after each write.
- **Applies to:**
  - `examples/inout/inout.py`
- **Condition:** When modifying the inout example's file input/output handling.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The inout cli function uses click.File('rb') with nargs=-1 for input and click.File('wb') for output, documents '-' as stdin/stdout, and copies 1024-byte chunks flushing after each write.
```

- **Sources:**
  - `examples/inout/inout.py:7-30`
