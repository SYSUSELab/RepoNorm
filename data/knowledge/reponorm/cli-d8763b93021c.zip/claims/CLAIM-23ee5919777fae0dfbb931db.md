# Rule details

- **Rule:**
  ```text
  CliRunner.invoke must preserve the documented versioned result attributes: output_bytes mixes stdout_bytes and stderr_bytes as seen in a terminal since 8.2, stderr_bytes is always returned, return_value holds the invoked command's return value since 8.0, and exc_info holds the traceback when available since 3.0.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:** when modifying CliRunner.invoke or its result attributes
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
CliRunner.invoke's docstring documents output_bytes mixing stdout and stderr as seen in a terminal since 8.2, stderr_bytes always returned, return_value since 8.0, and exc_info since 3.0, and the code sets these attributes, preserving the documented versioned result attribute contract.
```

- **Sources:**
  - `src/click/testing.py:407-513`
