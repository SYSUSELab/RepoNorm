# Rule details

- **Rule:**
  ```text
  The repo example must create a pass decorator via click.make_pass_decorator(Repo) to pass a Repo object through the context to commands.
  ```
- **Applies to:**
  - `examples/repo/repo.py`
- **Condition:** When modifying the repo example's context object passing mechanism.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The repo module creates the pass decorator via click.make_pass_decorator(Repo), matching the required context-passing pattern.
```

- **Sources:**
  - `examples/repo/repo.py`
