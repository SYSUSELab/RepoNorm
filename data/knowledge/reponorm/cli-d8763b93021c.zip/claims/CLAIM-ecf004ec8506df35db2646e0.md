# Rule details

- **Rule:**
  ```text
  Tests that exercise the pass-object decorator pattern must keep the injected-object contract; changing pass_* decorator behavior requires updating these tests.
  ```
- **Applies to:**
  - `tests/test_context.py`
- **Condition:**
  ```text
  When modifying pass_* decorator injection behavior, the pass-object test in the context test file must be updated.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
tests/test_context.py exercises pass-object decorator injection and context metadata behavior, preserving the injected-object contract.
```

- **Sources:**
  - `tests/test_context.py`
