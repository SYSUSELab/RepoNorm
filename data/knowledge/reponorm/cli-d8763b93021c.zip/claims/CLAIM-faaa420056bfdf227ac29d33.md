# Rule details

- **Rule:**
  ```text
  Example commands that output colors must use the canonical 16-name all_colors tuple covering normal and bright ANSI color names.
  ```
- **Applies to:**
  - `examples/colors/colors.py`
- **Condition:** when modifying color output or the color name set in the colors example
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The colors example module defines all_colors as a fixed 16-name tuple covering normal and bright ANSI color names, matching the canonical color-name set rule.
```

- **Sources:**
  - `examples/colors/colors.py`
