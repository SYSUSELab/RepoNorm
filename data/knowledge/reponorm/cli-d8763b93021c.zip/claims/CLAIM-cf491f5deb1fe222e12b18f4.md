# Rule details

- **Rule:**
  ```text
  The build job sets SOURCE_DATE_EPOCH from the last commit date via git log -1 --pretty=%ct written to $GITHUB_ENV.
  ```
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
      - run: echo "SOURCE_DATE_EPOCH=$(git log -1 --pretty=%ct)" >> $GITHUB_ENV

```

- **Sources:**
  - `.github/workflows/publish.yaml:20`
