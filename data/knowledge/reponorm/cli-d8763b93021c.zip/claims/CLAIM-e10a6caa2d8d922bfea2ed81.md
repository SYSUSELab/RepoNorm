# Rule details

- **Rule:**
  ```text
  Typing tests that override resolve_command must return cmd.name from the super() result and assert cmd is not None, pinning the aliased-group command resolution contract.
  ```
- **Applies to:**
  - `tests/typing/typing_aliased_group.py`
- **Condition:**
  ```text
  when adding or modifying typing tests that override resolve_command in tests/typing/typing_aliased_group.py
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The typing test override returns cmd.name from the super() result and asserts cmd is not None, pinning the aliased-group resolve_command contract.
```

- **Sources:**
  - `tests/typing/typing_aliased_group.py:22-28`
