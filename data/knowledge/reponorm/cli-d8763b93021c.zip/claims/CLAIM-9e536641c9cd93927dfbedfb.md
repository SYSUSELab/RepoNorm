# Rule details

- **Rule:** When modifying Option in core.py, preserve the Click 8.1 behavior that a single option boolean flag's default is not shown if its value is False.
- **Applies to:**
  - `src/click/core.py`
- **Condition:** Changing Option boolean flag default display behavior
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The Option class docstring documents that for single option boolean flags the default remains hidden if its value is False, preserving the Click 8.1 behavior the rule requires.
```

- **Sources:**
  - `src/click/core.py:2387-2938`
