# Rule details

- **Rule:** The typing example must keep asserting that a command alias group instance is typed as AliasedGroup, preserving the documented command-alias pattern's static typing compatibility.
- **Applies to:**
  - `tests/typing/typing_aliased_group.py`
- **Condition:** When modifying the typing example for command alias groups.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
typing_aliased_group.py asserts that the aliased group command instance is typed as AliasedGroup, preserving the documented command-alias typing pattern.
```

- **Sources:**
  - `tests/typing/typing_aliased_group.py`
