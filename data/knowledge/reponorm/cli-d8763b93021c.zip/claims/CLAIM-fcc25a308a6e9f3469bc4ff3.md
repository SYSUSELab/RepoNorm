# Rule details

- **Rule:** Pyright type checking is scoped to the src/click and tests/typing directories.
- **Applies to:**
  - `src/click/**`
  - `tests/typing/**`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
include = ["src/click", "tests/typing"]

```

- **Sources:**
  - `pyproject.toml:75`
