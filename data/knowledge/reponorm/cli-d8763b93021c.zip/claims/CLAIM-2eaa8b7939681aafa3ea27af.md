# Rule details

- **Rule:**
  ```text
  When modifying pop_context, preserve that it removes the top level from the context stack via _local.stack.pop(), requiring a prior push and raising IndexError on empty stack.
  ```
- **Applies to:**
  - `src/click/globals.py`
- **Condition:**
  ```text
  When changing pop_context or context stack management.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
pop_context is implemented as _local.stack.pop(), preserving the stack-pop behavior and prior-push requirement described by the rule.
```

- **Sources:**
  - `src/click/globals.py:49-51`
