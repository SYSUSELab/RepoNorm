# Rule details

- **Rule:**
  ```text
  measure_table must compute the maximum width of each column across rows using term_len, returning a tuple of widths sorted by column index.
  ```
- **Applies to:**
  - `src/click/formatting.py`
- **Condition:** When modifying table width measurement or column width computation.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
measure_table computes per-column maximum widths using term_len and returns a tuple of widths sorted by column index, matching the rule.
```

- **Sources:**
  - `src/click/formatting.py:14-21`
