# Rule details

- **Rule:** Example commands that add an alias must update the aliases mapping with a single alias-to-command entry.
- **Applies to:**
  - `examples/aliases/aliases.py`
- **Condition:** when modifying alias addition in the aliases example
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
Config.add_alias updates the aliases mapping with a single alias-to-command entry via self.aliases.update({alias: cmd}), conforming to the single-alias-entry rule.
```

- **Sources:**
  - `examples/aliases/aliases.py:14-15`
