# Rule details

- **Rule:** When modifying Group.group or Command.group, preserve the overloaded decorator behavior: a bare callable is accepted and returns a Group, and the decorator form produces a Group, so both direct and parenthesized decorator usage remain supported.
- **Applies to:**
  - `src/click/core.py`
- **Condition:** When changing Group.group or Command.group overloads or decorator-based group creation.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
Group.group overload signature accepts a bare callable and returns Group, preserving the overloaded decorator behavior.
```

- **Sources:**
  - `src/click/core.py:1605`

### Evidence 2 — current_observation

```text
Group.group is an overloaded decorator method, preserving the bare-callable and decorator-returning behavior.
```

- **Sources:**
  - `src/click/core.py:1608-1610`

### Evidence 3 — current_observation

```text
Group.group accepts a bare callable and returns a Group, and otherwise returns a decorator producing a Group, preserving the overloaded decorator behavior.
```

- **Sources:**
  - `src/click/core.py:1612-1654`
