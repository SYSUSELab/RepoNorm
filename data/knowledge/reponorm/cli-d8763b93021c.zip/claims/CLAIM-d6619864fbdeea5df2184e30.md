# Rule details

- **Rule:** The update-requirements tox environment changes to the requirements directory before running its commands.
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
change_dir = requirements

```

- **Sources:**
  - `tox.ini:49`
