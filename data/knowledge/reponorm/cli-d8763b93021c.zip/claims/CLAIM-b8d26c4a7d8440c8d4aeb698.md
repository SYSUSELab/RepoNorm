# Rule details

- **Rule:** TextWrapper must subclass textwrap.TextWrapper, indicating click customizes standard library wrapping behavior for its formatting needs.
- **Applies to:**
  - `src/click/_textwrap.py`
- **Condition:** When modifying click's text wrapping behavior or the TextWrapper class.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
TextWrapper is defined as class TextWrapper(textwrap.TextWrapper), directly subclassing the standard library TextWrapper as the rule requires.
```

- **Sources:**
  - `src/click/_textwrap.py:8-51`
