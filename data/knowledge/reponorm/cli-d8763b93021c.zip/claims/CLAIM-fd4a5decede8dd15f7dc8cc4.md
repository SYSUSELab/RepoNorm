# Rule details

- **Rule:** Include tests that cover any code changes made, and ensure the test fails without the patch.
- **Applies to:**
  - `**`
- **Normative strength:** `required`

## Supporting evidence

### Evidence 1 — explicit

```text
-   Include tests that cover any code changes you make. Make sure the
    test fails without your patch. Run the tests as described below.

```

- **Sources:**
  - `CONTRIBUTING.rst:153-154`
