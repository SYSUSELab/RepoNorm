# Rule details

- **Rule:**
  ```text
  _FixupStream.readable must return True when _force_readable is set, otherwise delegate to the wrapped stream's readable() if present, and fall back to attempting a zero-byte read, returning False on any exception.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  when modifying _FixupStream.readable or stream compatibility behavior
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
_FixupStream.readable returns True when _force_readable is set, delegates to the wrapped stream's readable() when present, and falls back to a zero-byte read returning False on exception.
```

- **Sources:**
  - `src/click/_compat.py:113-123`
