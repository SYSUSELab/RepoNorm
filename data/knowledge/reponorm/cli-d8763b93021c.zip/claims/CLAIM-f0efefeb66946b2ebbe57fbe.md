# Rule details

- **Rule:**
  ```text
  When modifying Context.to_info_dict in core.py, preserve the returned dict keys (command info, info_name, allow_extra_args, allow_interspersed_args, ignore_unknown_options, auto_envvar_prefix) and the traversal of the CLI structure for documentation tools.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  Changing Context.to_info_dict output keys or CLI structure traversal
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
Context.to_info_dict returns the documented keys (command info, info_name, allow_extra_args, allow_interspersed_args, ignore_unknown_options, auto_envvar_prefix) and traverses the CLI structure via self.command.to_info_dict(self).
```

- **Sources:**
  - `src/click/core.py:447-466`
