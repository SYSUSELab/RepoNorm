# Rule details

- **Rule:**
  ```text
  Windows-specific getchar behavior must keep mapping Ctrl-C (\x03) to KeyboardInterrupt and Ctrl-Z (\x1a) to EOFError, tested by monkeypatching msvcrt.getwch and disabling _getchar.
  ```
- **Applies to:**
  - `tests/test_termui.py`
- **Condition:** When modifying Windows getchar exception handling or its tests.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
tests/test_termui.py contains test_getchar_windows_exceptions monkeypatching msvcrt.getwch and asserting KeyboardInterrupt for \x03 and EOFError for \x1a.
```

- **Sources:**
  - `tests/test_termui.py`
