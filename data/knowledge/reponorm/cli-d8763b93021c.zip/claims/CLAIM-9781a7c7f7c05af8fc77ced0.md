# Rule details

- **Rule:** When modifying help formatting, preserve that HelpFormatter.write appends to an internal buffer rather than emitting immediately, so output is only produced when the buffer is flushed.
- **Applies to:**
  - `src/click/formatting.py`
- **Condition:** when changing how HelpFormatter produces output
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
HelpFormatter.write appends the string to self.buffer rather than emitting immediately, matching the buffering rule.
```

- **Sources:**
  - `src/click/formatting.py:135-137`
