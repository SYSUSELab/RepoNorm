# Rule details

- **Rule:** Tests that assert exact help/usage text must keep the expected output in sync with the formatter's wrapping, paragraph, and indentation behavior; changing help rendering requires updating these exact-output assertions.
- **Applies to:**
  - `tests/test_formatting.py`
  - `tests/test_options.py`
- **Condition:**
  ```text
  When modifying help-text rendering (wrapping, \b paragraph preservation, indentation, or envvar/option help display), the exact-output assertions in the formatting and options tests must be updated to match.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
tests/test_formatting.py asserts exact rendered help/usage output strings across many tests (wrapping, \b paragraph preservation, indentation, option help display), matching the exact-help-output assertion rule.
```

- **Sources:**
  - `tests/test_formatting.py`

### Evidence 2 — current_observation

```text
tests/test_options.py asserts exact rendered help/usage output (e.g. test_option_help_preserve_paragraphs, test_show_default_boolean_flag_name, test_usage_show_choices), matching the exact-help-output-assertion predicate.
```

- **Sources:**
  - `tests/test_options.py`
