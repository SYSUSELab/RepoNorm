# Rule details

- **Rule:**
  ```text
  When modifying ClickException, preserve the invariant that it is the base exception Click handles and shows to the user, with a class-level exit_code default of 1.
  ```
- **Applies to:**
  - `src/click/exceptions.py`
- **Condition:**
  ```text
  When changing ClickException or its exit_code default.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
ClickException in src/click/exceptions.py is the base exception Click handles and shows to the user, with a class-level exit_code default of 1, preserving the invariant.
```

- **Sources:**
  - `src/click/exceptions.py:25-45`
