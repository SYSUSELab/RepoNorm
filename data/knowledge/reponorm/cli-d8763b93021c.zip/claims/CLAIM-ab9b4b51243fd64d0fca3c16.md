# Rule details

- **Rule:** The tox testenv builds the package as a wheel.
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
package = wheel

```

- **Sources:**
  - `tox.ini:11`
