# Rule details

- **Rule:** echo must preserve its output compatibility guarantees: flush output, strip ANSI codes when the output stream is not an interactive terminal, write bytes to a discovered binary writer, and return early when no standard streams are attached.
- **Applies to:**
  - `src/click/utils.py`
- **Condition:** when modifying echo's stream selection, ANSI stripping, byte writing, or flush behavior
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
echo preserves its output compatibility guarantees: it flushes output, strips ANSI codes when the stream is not interactive, writes bytes to a discovered binary writer, and returns early when no standard streams are attached.
```

- **Sources:**
  - `src/click/utils.py:222-322`
