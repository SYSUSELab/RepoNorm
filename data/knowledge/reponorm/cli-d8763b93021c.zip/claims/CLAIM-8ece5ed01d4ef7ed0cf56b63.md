# Rule details

- **Rule:**
  ```text
  When modifying help formatting indentation, preserve that HelpFormatter.indent increases current_indent by indent_increment, defining the indentation step used in help formatting.
  ```
- **Applies to:**
  - `src/click/formatting.py`
- **Condition:** when changing HelpFormatter indentation logic
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
HelpFormatter.indent increases current_indent by indent_increment, matching the indentation rule.
```

- **Sources:**
  - `src/click/formatting.py:139-141`
