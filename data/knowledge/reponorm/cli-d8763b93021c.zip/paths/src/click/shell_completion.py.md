# Rules for `src/click/shell_completion.py`

## Rule 019 — `src/click/shell_completion.py`

- **Rule:**
  ```text
  When modifying CompletionItem.__init__, preserve the shell completion item data contract: store value, type (default 'plain'), help, and capture remaining kwargs in _info.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:**
  ```text
  Modifying CompletionItem.__init__ field storage or default type handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1a51b9ed536418268107fee4.md)

## Rule 048 — `src/click/shell_completion.py`

- **Rule:**
  ```text
  When modifying ShellComplete.func_name, preserve the shell function name contract: sanitize prog_name by replacing '-' with '_' and stripping non-word characters with re.sub(r"\W*", "", ..., flags=re.ASCII), then wrap it as _{safe_name}_completion.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:**
  ```text
  Modifying ShellComplete.func_name sanitization or completion function naming.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4da1587fc03f64a10ac7cf1e.md)

## Rule 075 — `src/click/shell_completion.py`

- **Rule:**
  ```text
  When modifying ShellComplete.format_completion in shell_completion.py, preserve its abstract-style contract: it must raise NotImplementedError so each shell-specific subclass implements completion item formatting.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:**
  ```text
  Changing ShellComplete.format_completion or adding shell-specific completion subclasses
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-7425cc3f2a20e0986454c0fa.md)
