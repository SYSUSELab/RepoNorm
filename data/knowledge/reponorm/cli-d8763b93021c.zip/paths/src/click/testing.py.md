# Rules for `src/click/testing.py`

## Rule 007 — `src/click/testing.py`

- **Rule:**
  ```text
  BytesIOCopy.flush must delegate to super().flush() and then copy_to.flush() to keep the mirrored buffer synchronized.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:** when modifying BytesIOCopy.flush or testing stream mirroring behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0c8973f8c185ca1bbf3c3669.md)

## Rule 023 — `src/click/testing.py`

- **Rule:**
  ```text
  CliRunner.invoke must preserve the documented versioned result attributes: output_bytes mixes stdout_bytes and stderr_bytes as seen in a terminal since 8.2, stderr_bytes is always returned, return_value holds the invoked command's return value since 8.0, and exc_info holds the traceback when available since 3.0.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:** when modifying CliRunner.invoke or its result attributes
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-23ee5919777fae0dfbb931db.md)

## Rule 052 — `src/click/testing.py`

- **Rule:**
  ```text
  EchoingStdin.read1 must delegate to self._echo(self._input.read1(n)) so bytes read through read1 are echoed to the captured output stream.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:** when modifying EchoingStdin.read1 or testing stream echo behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-52553c5aed48c83d957a0051.md)

## Rule 147 — `src/click/testing.py`

- **Rule:**
  ```text
  When modifying EchoingStdin.__getattr__, preserve the delegation behavior that forwards attribute access to self._input, the underlying input stream.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:**
  ```text
  When changing EchoingStdin.__getattr__ or its attribute delegation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f1095d78bff71c81bbb61f00.md)
