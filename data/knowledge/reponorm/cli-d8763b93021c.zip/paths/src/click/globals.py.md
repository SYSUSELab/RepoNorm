# Rules for `src/click/globals.py`

## Rule 033 — `src/click/globals.py`

- **Rule:**
  ```text
  When modifying pop_context, preserve that it removes the top level from the context stack via _local.stack.pop(), requiring a prior push and raising IndexError on empty stack.
  ```
- **Applies to:**
  - `src/click/globals.py`
- **Condition:**
  ```text
  When changing pop_context or context stack management.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2eaa8b7939681aafa3ea27af.md)
