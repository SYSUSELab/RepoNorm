# Rules for `src/click/parser.py`

## Rule 070 — `src/click/parser.py`

- **Rule:**
  ```text
  When modifying _ParsingState.__init__, preserve the initialization of opts, largs, rargs, and order parsing state so contributors extending the parser account for this mutable state.
  ```
- **Applies to:**
  - `src/click/parser.py`
- **Condition:**
  ```text
  When changing _ParsingState.__init__ or extending the option parser's mutable state.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6b3a3ccfd761237ced0516c8.md)
