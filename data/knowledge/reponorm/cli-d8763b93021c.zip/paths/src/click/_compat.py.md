# Rules for `src/click/_compat.py`

## Rule 005 — `src/click/_compat.py`

- **Rule:**
  ```text
  _FixupStream.readable must return True when _force_readable is set, otherwise delegate to the wrapped stream's readable() if present, and fall back to attempting a zero-byte read, returning False on any exception.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  when modifying _FixupStream.readable or stream compatibility behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-08bd3af902df845e64f4d01a.md)

## Rule 055 — `src/click/_compat.py`

- **Rule:** The seekable check must prefer the wrapped stream's own seekable attribute when present and only fall back to a seek/tell probe when that attribute is absent, treating probe exceptions as non-seekable.
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  when modifying _FixupStream.seekable or its fallback probe behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-555df78c4ec415aafc3910e0.md)

## Rule 087 — `src/click/_compat.py`

- **Rule:**
  ```text
  When modifying get_text_stdout, preserve the Windows-console special-casing: first attempt _get_windows_console_stream and otherwise fall back to _force_correct_text_writer with force_writable=True.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  Modifying get_text_stdout text stream resolution.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8aef9983bd2b235615e4e66b.md)

## Rule 098 — `src/click/_compat.py`

- **Rule:**
  ```text
  When modifying _find_binary_reader, preserve the detection behavior: return the stream itself when _is_binary_reader(stream, False) is true, otherwise check stream.buffer with _is_binary_reader(buf, True) and return it, else None, explicitly handling detached and closed-buffer stream cases.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  When changing _find_binary_reader or its binary stream detection logic.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a25c2dc9f2f428f674070d7c.md)

## Rule 106 — `src/click/_compat.py`

- **Rule:**
  ```text
  When modifying _is_compat_stream_attr, preserve the compatibility rule: a stream attribute is compatible when it equals the desired value, or when the desired value is None and the attribute has any non-None value.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  Modifying _is_compat_stream_attr compatibility checks.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-aaf5bf08651a5024b87b79e5.md)

## Rule 113 — `src/click/_compat.py`

- **Rule:**
  ```text
  When modifying _compat module import-time behavior, preserve the platform gating: CYGWIN and WIN are derived from sys.platform prefixes, and _winconsole import plus ANSI stream wrapper installation occur only when sys.platform starts with 'win' and WIN is true.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  Modifying _compat platform detection or Windows-specific import-time wrapping.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b23bf23874b6e39271bca83c.md)

## Rule 156 — `src/click/_compat.py`

- **Rule:**
  ```text
  When modifying _force_correct_text_stream in _compat.py, preserve that it returns a compatible text stream as-is unless encoding is None and the stream is misconfigured; otherwise it wraps the underlying binary reader, defaulting errors to 'replace' to avoid exceptions.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  Changing _force_correct_text_stream wrapping or error defaulting
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ff9005e0654d31ca3665e931.md)
