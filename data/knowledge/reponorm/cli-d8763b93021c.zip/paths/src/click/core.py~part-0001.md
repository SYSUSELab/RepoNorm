# Rules for `src/click/core.py`

## Rule 009 — `src/click/core.py`

- **Rule:**
  ```text
  value_from_envvar must split the resolved envvar value via the parameter type's split_envvar_value only when the value is not None and nargs is not 1, so single-value parameters receive the raw string.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  when modifying value_from_envvar's envvar resolution or splitting behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-103da921e689ab75d789f49a.md)

## Rule 011 — `src/click/core.py`

- **Rule:**
  ```text
  When modifying Group.resolve_command, preserve the resolution protocol: apply ctx.token_normalize_func when the initial lookup fails, and when still unresolved and not resilient_parsing, re-parse args if the first token looks like an option before failing with 'No such command', preserving --help routing.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  Modifying Group.resolve_command lookup, token normalization, or option-like fallback handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-126659bab1003f893a580746.md)

## Rule 015 — `src/click/core.py`

- **Rule:**
  ```text
  When modifying Context.find_root, preserve the traversal behavior that walks parent links to the outermost context so nested contexts can locate the root for shared state.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When changing Context.find_root or its parent-link traversal.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-136a95690b8438f70967b0a1.md)

## Rule 022 — `src/click/core.py`

- **Rule:**
  ```text
  When modifying Command.format_help in core.py, preserve the documented low-level help composition order: format_usage, then format_help_text, then format_options, then format_epilog.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  Changing Command.format_help composition or ordering of help sections
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-23a0e64cf20e22202f22d294.md)

## Rule 030 — `src/click/core.py`

- **Rule:** When modifying Group.group or Command.group, preserve the overloaded decorator behavior: a bare callable is accepted and returns a Group, and the decorator form produces a Group, so both direct and parenthesized decorator usage remain supported.
- **Applies to:**
  - `src/click/core.py`
- **Condition:** When changing Group.group or Command.group overloads or decorator-based group creation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2bc00fdf0eb2120764dcc8ce.md)

## Rule 035 — `src/click/core.py`

- **Rule:**
  ```text
  When modifying Group.__init__, preserve the invariant that chain mode cannot be combined with optional arguments; the constructor must raise RuntimeError for that combination, and no_args_is_help must default to the negation of invoke_without_command.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  Modifying Group.__init__ command normalization, no_args_is_help defaulting, or chain-mode validation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3355a6d227398129e47c546f.md)

## Rule 038 — `src/click/core.py`

- **Rule:**
  ```text
  When modifying Context.find_object in core.py, preserve the behavior that it walks up the parent chain and returns the first node whose obj is an instance of the requested type, returning None if no ancestor matches.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  Changing Context.find_object parent-chain traversal or type matching
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3baf6d37641226d2eaf2b057.md)

## Rule 042 — `src/click/core.py`

- **Rule:**
  ```text
  When modifying Command.format_epilog, preserve the behavior that the epilog is written only when self.epilog is set, applying inspect.cleandoc and writing it as an indented paragraph in the help formatter.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  Modifying Command.format_epilog epilog rendering.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-44fb2aa39bc65a52e9a260b5.md)

## Rule 056 — `src/click/core.py`

- **Rule:**
  ```text
  When modifying _MultiCommand, preserve the deprecation boundary: _MultiCommand is deprecated as of 8.2 and scheduled for removal in Click 9.0, with Group as the replacement; do not remove or change this compatibility boundary without updating the deprecation schedule.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When changing _MultiCommand or its deprecation metadata.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-55cc8ccfe8e75967bf6ae086.md)

## Rule 057 — `src/click/core.py`

- **Rule:**
  ```text
  Command.get_help must build a formatter via ctx.make_formatter, call format_help, and return the value with trailing newlines stripped.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  when modifying Command.get_help or help formatting logic
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-55e2cdca8e4bef3ae1c627ee.md)

## Rule 060 — `src/click/core.py`

- **Rule:** When modifying Context.invoke, preserve both invocation modes: passing a callback directly, or passing a Command whose callback is invoked with a new sub-context; in command mode, missing exposed params are filled from defaults and all kwargs are tracked in ctx.params so forward() can pass them at multiple levels.
- **Applies to:**
  - `src/click/core.py`
- **Condition:** When changing Context.invoke or its callback/command invocation modes.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-58dc6193a72b68b559c019c3.md)

## Rule 061 — `src/click/core.py`

- **Rule:**
  ```text
  When modifying Context.protected_args, preserve the deprecation boundary: protected_args is deprecated and will be removed in Click 9.0, with args containing remaining unparsed tokens; do not remove or change this compatibility boundary without updating the deprecation schedule.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When changing Context.protected_args or its deprecation metadata.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-590e4a8a65b694e2cd5c583a.md)

## Rule 066 — `src/click/core.py`

- **Rule:**
  ```text
  Parameter.get_help_record must return None by default, defining the no-help-record contract that subclasses override.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  when modifying Parameter.get_help_record or help-record generation
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5d92f7da89f106cff5a97394.md)

## Rule 073 — `src/click/core.py`

- **Rule:**
  ```text
  Group.get_command must return the Command from self.commands by name or None if absent, defining the base command lookup contract.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  when modifying Group.get_command or its lookup behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-719cdf89f61dc315219f7dd1.md)
