# Rules for `src/click/exceptions.py`

## Rule 018 — `src/click/exceptions.py`

- **Rule:**
  ```text
  When modifying ClickException, preserve the invariant that it is the base exception Click handles and shows to the user, with a class-level exit_code default of 1.
  ```
- **Applies to:**
  - `src/click/exceptions.py`
- **Condition:**
  ```text
  When changing ClickException or its exit_code default.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1a46542ca6bbacc97f6aaf7a.md)

## Rule 144 — `src/click/exceptions.py`

- **Rule:**
  ```text
  ClickException.__init__ must initialize the base Exception with the message and also store the message on self.message so it remains available as an attribute.
  ```
- **Applies to:**
  - `src/click/exceptions.py`
- **Condition:** when modifying ClickException initialization or message storage
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-eff81114648d6ff513cf1127.md)
