# Rules for `src/click/_textwrap.py`

## Rule 085 — `src/click/_textwrap.py`

- **Rule:**
  ```text
  TextWrapper._handle_long_word must compute space_left as max(width - cur_len, 1) and ensure progress even with zero remaining width.
  ```
- **Applies to:**
  - `src/click/_textwrap.py`
- **Condition:**
  ```text
  when modifying TextWrapper._handle_long_word or long-word wrapping logic
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-866551078d67a816746f5d23.md)

## Rule 119 — `src/click/_textwrap.py`

- **Rule:** TextWrapper must subclass textwrap.TextWrapper, indicating click customizes standard library wrapping behavior for its formatting needs.
- **Applies to:**
  - `src/click/_textwrap.py`
- **Condition:** When modifying click's text wrapping behavior or the TextWrapper class.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b8d26c4a7d8440c8d4aeb698.md)
