# Rules for `src/click/utils.py`

## Rule 012 — `src/click/utils.py`

- **Rule:** The wrapper constructor must store the wrapped IO object as self.wrapped, which is the delegation target for attribute access.
- **Applies to:**
  - `src/click/utils.py`
- **Condition:** when modifying the wrapper constructor or its delegation target
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-12880dc83cffda715b83102f.md)

## Rule 132 — `src/click/utils.py`

- **Rule:** echo must preserve its output compatibility guarantees: flush output, strip ANSI codes when the output stream is not an interactive terminal, write bytes to a discovered binary writer, and return early when no standard streams are attached.
- **Applies to:**
  - `src/click/utils.py`
- **Condition:** when modifying echo's stream selection, ANSI stripping, byte writing, or flush behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-db6f72e4bb5b822f797a8be6.md)

## Rule 136 — `src/click/utils.py`

- **Rule:** The stream flush wrapper must suppress only OSError with errno EPIPE and re-raise all other OSErrors, preserving the broken-pipe compatibility boundary.
- **Applies to:**
  - `src/click/utils.py`
- **Condition:** when modifying the flush wrapper's exception handling for output streams
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e1cfc6baaf689469d5dcfa55.md)

## Rule 138 — `src/click/utils.py`

- **Rule:**
  ```text
  When modifying KeepOpenFile.__exit__ in utils.py, preserve that it is a no-op accepting exception type, value, and traceback and returning None, so exceptions are not suppressed.
  ```
- **Applies to:**
  - `src/click/utils.py`
- **Condition:**
  ```text
  Changing KeepOpenFile.__exit__ exception handling or return value
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e818e5c80cadd76dd471cafb.md)
