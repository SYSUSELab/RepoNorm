# Rules for `src/click/termui.py`

## Rule 024 — `src/click/termui.py`

- **Rule:** secho must style the message only when it is not bytes/bytearray, passing bytes through to echo unstyled, and must convert non-string messages to str.
- **Applies to:**
  - `src/click/termui.py`
- **Condition:** when modifying secho's message handling or styling path
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-24724711f08edd488417e7e1.md)

## Rule 139 — `src/click/termui.py`

- **Rule:**
  ```text
  When modifying prompt() in termui.py, preserve the re-prompt loop: value_proc rejections (UsageError) must re-prompt with the error message, and when confirmation_prompt is set the second entry must match the first or the prompt repeats; confirmation_prompt=True must be replaced by the translated 'Repeat for confirmation' string.
  ```
- **Applies to:**
  - `src/click/termui.py`
- **Condition:** Changing prompt() input validation, confirmation, or error re-prompt behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-eaca096f29ba139f0b5ee4fc.md)
