# Rules for `src/click/_winconsole.py`

## Rule 063 — `src/click/_winconsole.py`

- **Rule:**
  ```text
  The Py_buffer ctypes Structure must preserve its exact field layout used for Windows console buffer access.
  ```
- **Applies to:**
  - `src/click/_winconsole.py`
- **Condition:**
  ```text
  when modifying Windows console buffer handling or the Py_buffer structure
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-59dd1e444744020367dafff9.md)
