# Rules for `src/click/types.py`

## Rule 016 — `src/click/types.py`

- **Rule:**
  ```text
  When modifying Path.coerce_path_result, preserve the conversion behavior: values are converted to str via os.fsdecode, to bytes via os.fsencode, or to the configured PathLike type, and returned unchanged when they already match the type.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When changing Path.coerce_path_result or its path type conversion logic.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-18c75754ded5ac8d63701ca6.md)

## Rule 034 — `src/click/types.py`

- **Rule:**
  ```text
  When modifying _NumberRangeBase.__repr__, preserve the representation that includes the range description and appends ' clamped' when clamping is enabled.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When changing _NumberRangeBase.__repr__ or its clamped representation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3218c1ce2dc8f0557203c0a6.md)

## Rule 037 — `src/click/types.py`

- **Rule:** UnprocessedParamType must keep name 'text' and pass values through without conversion, serving as the default unprocessed parameter type.
- **Applies to:**
  - `src/click/types.py`
- **Condition:** when modifying UnprocessedParamType's name or conversion behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-35c9830ea1362b906fa21434.md)

## Rule 053 — `src/click/types.py`

- **Rule:**
  ```text
  When modifying FloatRange.__init__, preserve the validation that raises TypeError when clamp is True together with min_open or max_open, since clamping is not supported for open bounds.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When changing FloatRange.__init__ clamp or open-bound validation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-52909e6e71029dcf3d5c3a21.md)

## Rule 068 — `src/click/types.py`

- **Rule:**
  ```text
  IntRange._clamp must return the bound unchanged when the range is closed, and bound + dir when open, so open bounds are adjusted by the direction to exclude the endpoint.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  when modifying IntRange._clamp or range bound handling
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6914271c151a7441e627d03f.md)

## Rule 079 — `src/click/types.py`

- **Rule:**
  ```text
  When modifying CompositeParamType in types.py, preserve that it subclasses ParamType and sets is_composite = True, marking it as a type that consumes multiple values.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  Changing CompositeParamType inheritance or is_composite flag
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-7aba3ca3eb26673ace67782b.md)

## Rule 081 — `src/click/types.py`

- **Rule:**
  ```text
  When modifying DateTime.__repr__, preserve the stable literal representation "DateTime" used for type display.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When changing DateTime.__repr__ or its type display representation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-7f1a498446bfa9bbaf9ae5e1.md)

## Rule 096 — `src/click/types.py`

- **Rule:**
  ```text
  When modifying ParamType.get_metavar in types.py, preserve the behavior that it returns the metavar default for a parameter if the type provides one, allowing custom types to control help metavar display.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  Changing ParamType.get_metavar or custom type metavar handling
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9ee6cd070ad61a10213f013d.md)

## Rule 143 — `src/click/types.py`

- **Rule:**
  ```text
  When modifying _NumberParamTypeBase, preserve the extension protocol: _number_class is declared as a class variable so numeric ParamType subclasses supply their concrete number type.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  Modifying _NumberParamTypeBase or adding numeric ParamType subclasses.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-edf9d403232bc6929259159f.md)
