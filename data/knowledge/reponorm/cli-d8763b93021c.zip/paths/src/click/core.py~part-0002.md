# Rules for `src/click/core.py`

## Rule 090 — `src/click/core.py`

- **Rule:**
  ```text
  CommandCollection.list_commands must merge super().list_commands with each source's list_commands into a set and return sorted results, deduplicating duplicate command names and producing deterministic order.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  when modifying CommandCollection.list_commands or its merge behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-963c98112a1082dfa845f0f6.md)

## Rule 095 — `src/click/core.py`

- **Rule:** When modifying Option in core.py, preserve the Click 8.1 behavior that a single option boolean flag's default is not shown if its value is False.
- **Applies to:**
  - `src/click/core.py`
- **Condition:** Changing Option boolean flag default display behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9e536641c9cd93927dfbedfb.md)

## Rule 108 — `src/click/core.py`

- **Rule:**
  ```text
  When modifying Context.command_path, preserve the usage-path computation: join the parent's command_path with each parent parameter's get_usage_pieces, then append the current info_name and strip leading whitespace, so usage strings include parent parameter placeholders.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  Modifying Context.command_path usage-path construction.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ac7d4998ab75fa0c05ca6741.md)

## Rule 109 — `src/click/core.py`

- **Rule:**
  ```text
  When modifying Context.call_on_close, preserve the teardown contract: callbacks are registered on the context's exit stack and run when the context tears down; resources supporting the context manager protocol should instead be registered via with_resource.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  Modifying Context.call_on_close teardown registration or resource lifecycle handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ad241b0f11637121f8fe6276.md)

## Rule 110 — `src/click/core.py`

- **Rule:**
  ```text
  Group.add_command must raise TypeError when neither an explicit name nor cmd.name is available, and must call _check_nested_chain before storing the command in self.commands.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  when modifying Group.add_command or command registration logic
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-aedbc6836f2ac3ecf8ca5999.md)

## Rule 118 — `src/click/core.py`

- **Rule:**
  ```text
  When modifying Option.prompt_for_value in core.py, preserve the flow: compute the default before prompting, route boolean flags through confirm, and forward show_default to prompt only when it is a bool.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  Changing Option.prompt_for_value default computation, boolean routing, or show_default forwarding
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b8143993c6e6c7408b357adc.md)

## Rule 122 — `src/click/core.py`

- **Rule:**
  ```text
  Parameter must preserve the documented deprecation of the autocompletion parameter renamed to shell_complete in 8.0, with the old name wrapped until 8.1.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  when modifying Parameter's autocompletion or shell_complete parameter handling
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-bcfe42e07769e7fc5fc4318a.md)

## Rule 145 — `src/click/core.py`

- **Rule:**
  ```text
  When modifying Option.__init__ flag/prompt derivation, preserve that prompt=True requires a name and derives prompt text from it, _flag_needs_value is set when prompt is enabled but not required, is_flag is inferred from flag_value, _flag_needs_value, or secondary_opts, count options default to IntRange(min=0) with default 0, and the __debug__-guarded TypeErrors remain enforced.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When changing Option.__init__ flag, prompt, count, or secondary-option derivation logic.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f032f04fa6dffe0aeb3caf1a.md)

## Rule 146 — `src/click/core.py`

- **Rule:**
  ```text
  When modifying Context.to_info_dict in core.py, preserve the returned dict keys (command info, info_name, allow_extra_args, allow_interspersed_args, ignore_unknown_options, auto_envvar_prefix) and the traversal of the CLI structure for documentation tools.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  Changing Context.to_info_dict output keys or CLI structure traversal
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f0efefeb66946b2ebbe57fbe.md)
