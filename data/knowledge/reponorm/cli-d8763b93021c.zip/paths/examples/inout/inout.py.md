# Rules for `examples/inout/inout.py`

## Rule 032 — `examples/inout/inout.py`

- **Rule:** The inout example must use click.File('rb') with nargs=-1 for input and click.File('wb') for output, document that '-' denotes stdin/stdout, and copy chunks of 1024 bytes flushing after each write.
- **Applies to:**
  - `examples/inout/inout.py`
- **Condition:** When modifying the inout example's file input/output handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2c7519b02b7d473eccdcbf7e.md)
