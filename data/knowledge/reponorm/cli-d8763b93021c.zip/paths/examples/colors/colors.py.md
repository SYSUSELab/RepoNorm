# Rules for `examples/colors/colors.py`

## Rule 078 — `examples/colors/colors.py`

- **Rule:** Example commands that emit styled output must apply click.style with the documented style attributes (fg, bold, reverse, blink, underline) and must rely on Click's automatic removal of ANSI styles when output is piped to a file rather than stripping them manually.
- **Applies to:**
  - `examples/colors/colors.py`
- **Condition:** when adding or modifying an example command that emits styled or colored output
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-78b1025258391d72d2d1360a.md)

## Rule 151 — `examples/colors/colors.py`

- **Rule:**
  ```text
  Example commands that output colors must use the canonical 16-name all_colors tuple covering normal and bright ANSI color names.
  ```
- **Applies to:**
  - `examples/colors/colors.py`
- **Condition:** when modifying color output or the color name set in the colors example
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-faaa420056bfdf227ac29d33.md)
