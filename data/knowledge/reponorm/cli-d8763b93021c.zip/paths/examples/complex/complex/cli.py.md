# Rules for `examples/complex/complex/cli.py`

## Rule 010 — `examples/complex/complex/cli.py`

- **Rule:** The complex example must define an Environment class in its CLI module serving as the shared state object passed through the example's command group.
- **Applies to:**
  - `examples/complex/complex/cli.py`
- **Condition:** When modifying the complex example's shared state handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-11f3d955bedad39add2a8dc5.md)

## Rule 039 — `examples/complex/complex/cli.py`

- **Rule:**
  ```text
  Example groups that discover subcommands from a folder must scan for files matching cmd_*.py, strip the 'cmd_' prefix and '.py' suffix, and sort the resulting names.
  ```
- **Applies to:**
  - `examples/complex/complex/cli.py`
- **Condition:** when modifying subcommand discovery in the complex example group
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3d190c82f484de72ae70a6ff.md)

## Rule 148 — `examples/complex/complex/cli.py`

- **Rule:**
  ```text
  Example commands that need custom context state must define a custom command class (e.g. ComplexCLI) with context_settings and a pass_environment decorator, storing values such as verbose and home on the context for subcommands rather than using module-level globals.
  ```
- **Applies to:**
  - `examples/complex/complex/cli.py`
- **Condition:** when adding or modifying an example command group that needs custom context state shared with subcommands
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f2a61203ca795819bedf4a10.md)
