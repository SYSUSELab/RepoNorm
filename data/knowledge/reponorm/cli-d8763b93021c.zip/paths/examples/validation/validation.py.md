# Rules for `examples/validation/validation.py`

## Rule 040 — `examples/validation/validation.py`

- **Rule:** Example commands that accept a URL argument must validate it through the example's URL parameter type, which rejects any scheme other than http/https via self.fail and skips scheme validation for already-parsed tuple values.
- **Applies to:**
  - `examples/validation/validation.py`
- **Condition:** when adding or modifying an example command that accepts a URL argument
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3f60578fc717355a5baffca4.md)
