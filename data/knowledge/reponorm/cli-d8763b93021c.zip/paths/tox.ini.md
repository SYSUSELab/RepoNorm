# Rules for `tox.ini`

## Rule 027 — `tox.ini`

- **Rule:** The tox testenv uses frozen constraints.
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-281e78ab17e9b6b9bbf5def6.md)

## Rule 036 — `tox.ini`

- **Rule:**
  ```text
  The tox testenv `update-actions` runs the command `gha-update`.
  ```
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-359ee7be8c6e4a6d21e4be67.md)

## Rule 041 — `tox.ini`

- **Rule:** Tox skips environments whose interpreter is missing.
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-43abaec219b67a12fc38d131.md)

## Rule 062 — `tox.ini`

- **Rule:** The tox testenv runs pytest with verbose output, short tracebacks, and a basetemp under the environment temp directory, forwarding posargs.
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-59305d56b31ddf224831700f.md)

## Rule 074 — `tox.ini`

- **Rule:**
  ```text
  The tox testenv `update-pre_commit` runs `pre-commit autoupdate -j4` as its command.
  ```
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7332e2df73098c231095bb45.md)

## Rule 086 — `tox.ini`

- **Rule:** The tox testenv uses .pkg as the wheel build environment.
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-86bf1caf6fd6806cdb3c5dd3.md)

## Rule 097 — `tox.ini`

- **Rule:** The update-requirements tox environment installs pip-tools as its dependency.
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9fc201a4c2b494524bbeb3ff.md)

## Rule 103 — `tox.ini`

- **Rule:** The tox testenv constrains package dependencies.
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a8c3447d315a6027c8b65e22.md)

## Rule 107 — `tox.ini`

- **Rule:** The tox testenv builds the package as a wheel.
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ab9b4b51243fd64d0fca3c16.md)

## Rule 111 — `tox.ini`

- **Rule:** The update-requirements tox environment skips installing the project package.
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b110fc1e81365487e099c518.md)

## Rule 131 — `tox.ini`

- **Rule:** The update-requirements tox environment changes to the requirements directory before running its commands.
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d6619864fbdeea5df2184e30.md)

## Rule 137 — `tox.ini`

- **Rule:**
  ```text
  The tox testenv `update-actions` declares dependency `gha-update`.
  ```
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e31ea0dd02ff58560af48414.md)

## Rule 152 — `tox.ini`

- **Rule:** The tox default environment list includes py3{13,12,11,10,9,8}, pypy310, style, typing, and docs.
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-fb74b20d2eeff9ef01c71ea9.md)
