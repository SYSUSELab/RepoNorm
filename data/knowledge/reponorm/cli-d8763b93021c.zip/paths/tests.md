# Rules for `tests`

## Rule 008 — `tests/**`

- **Rule:**
  ```text
  Pytest test discovery is restricted to the tests directory via testpaths = ["tests"].
  ```
- **Applies to:**
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0d62a1719df3b1583e69c95d.md)

## Rule 028 — `click/**`

- **Rule:** Coverage measurement is configured to restrict its source to the click package and the tests directory.
- **Applies to:**
  - `click/**`
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-28cd2030c9bb34be433ba7f3.md)
