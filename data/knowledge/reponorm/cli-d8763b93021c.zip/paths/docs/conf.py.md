# Rules for `docs/conf.py`

## Rule 080 — `docs/conf.py`

- **Rule:**
  ```text
  Sphinx autodoc options in docs/conf.py must keep autodoc_member_order='bysource', autodoc_typehints='description', and autodoc_preserve_defaults=True so generated API documentation preserves source member order, renders type hints in the description, and shows original default values.
  ```
- **Applies to:**
  - `docs/conf.py`
- **Condition:**
  ```text
  When modifying Sphinx configuration in docs/conf.py, preserve the autodoc_member_order, autodoc_typehints, and autodoc_preserve_defaults settings.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-7e3e28ef71e1ed30a9a60c2b.md)
