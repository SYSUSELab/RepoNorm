# Rules for `repository root`

## Rule 004 — `**/*.py`

- **Rule:** Ruff linting is configured with the rule set B, E, F, I, UP, and W selected.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-04e007ad3a4be09c578ef325.md)

## Rule 020 — `**/*.css`

- **Rule:** Files with the extensions css, html, js, json, jsx, scss, ts, tsx, yaml, or yml use an indent size of 2.
- **Applies to:**
  - `**/*.css`
  - `**/*.html`
  - `**/*.js`
  - `**/*.json`
  - `**/*.jsx`
  - `**/*.scss`
  - `**/*.ts`
  - `**/*.tsx`
  - `**/*.yaml`
  - `**/*.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1b7248c8e04eeab906db3ab2.md)

## Rule 026 — `**`

- **Rule:** The typing test environment runs mypy as a command.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-26a90b8c29b9deac223ff6c6.md)

## Rule 046 — `**`

- **Rule:**
  ```text
  Files matching the [*] section are configured to trim trailing whitespace.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-4ca339d95bafd99842f4ee26.md)

## Rule 058 — `**/*.py`

- **Rule:**
  ```text
  The project declares a minimum supported Python version of 3.8 via requires-python = ">=3.8".
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5776411247f55833132b6580.md)

## Rule 067 — `**/*.py`

- **Rule:** Ruff isort linting enforces single-line import formatting (force-single-line = true).
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-621b35d9e44b2380761db6f7.md)

## Rule 082 — `**/*.py`

- **Rule:** Code must be formatted using Black; Black and other tools run automatically when pre-commit is installed.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-82947f5c208ef24bc1467008.md)

## Rule 120 — `**`

- **Rule:** The pre-commit workflow runs the pre-commit-ci/lite-action step when the job has not been cancelled.
- **Applies to:**
  - `**`
- **Condition:** workflow predicate: ${{ !cancelled() }}
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b972c4959abd3a9140e2717b.md)

## Rule 125 — `**`

- **Rule:**
  ```text
  Files matching the [*] section use UTF-8 charset.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c1cd8e94713700a0cfeff4f6.md)

## Rule 154 — `**`

- **Rule:** Include tests that cover any code changes made, and ensure the test fails without the patch.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-fd4a5decede8dd15f7dc8cc4.md)

## Rule 155 — `**`

- **Rule:**
  ```text
  The tox 'style' test environment sets skip_install to true, so the package is not installed into that environment.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-fdd22ff404286fe9af9aa43a.md)
