# Rules for `examples`

## Rule 029 — `examples/**`

- **Rule:** Ruff excludes the examples/ directory from linting via extend-exclude.
- **Applies to:**
  - `examples/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-2b683e197feea26882b7bf8a.md)
