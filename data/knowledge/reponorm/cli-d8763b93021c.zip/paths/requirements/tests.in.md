# Rules for `requirements/tests.in`

## Rule 141 — `requirements/tests.in`

- **Rule:** The update-requirements tox environment runs pip-compile on tests.in with -q and posargs defaulting to -U.
- **Applies to:**
  - `requirements/tests.in`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-ed87fd0567591ad47129bd4e.md)
