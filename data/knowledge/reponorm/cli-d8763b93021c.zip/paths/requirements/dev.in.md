# Rules for `requirements/dev.in`

## Rule 043 — `requirements/dev.in`

- **Rule:** The update-requirements tox environment runs pip-compile on dev.in with -q and posargs defaulting to -U.
- **Applies to:**
  - `requirements/dev.in`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-4528af874a9016aecae36687.md)
