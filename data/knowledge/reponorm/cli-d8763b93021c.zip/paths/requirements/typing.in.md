# Rules for `requirements/typing.in`

## Rule 076 — `requirements/typing.in`

- **Rule:** The update-requirements tox environment runs pip-compile on typing.in with -q and posargs defaulting to -U.
- **Applies to:**
  - `requirements/typing.in`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-77d18b60690bcd6ed0e57e65.md)
