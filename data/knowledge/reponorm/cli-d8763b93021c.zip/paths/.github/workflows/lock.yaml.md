# Rules for `.github/workflows/lock.yaml`

## Rule 104 — `.github/workflows/lock.yaml`

- **Rule:** The lock workflow uses the dessant/lock-threads action pinned to commit 1bf7ec25051fe7c00bdd17e6a7cf3d7bfb7dc771 (v5.0.1).
- **Applies to:**
  - `.github/workflows/lock.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a8d1deffb940ff6223e7090d.md)
