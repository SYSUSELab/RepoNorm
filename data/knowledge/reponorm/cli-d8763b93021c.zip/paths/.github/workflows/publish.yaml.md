# Rules for `.github/workflows/publish.yaml`

## Rule 021 — `.github/workflows/publish.yaml`

- **Rule:**
  ```text
  The create-release job creates a draft GitHub release via gh release create --draft with the repository and ref name, attaching *.intoto.jsonl and artifact/* files, using GH_TOKEN from github.token.
  ```
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2335ae7c83ea7b156c0db030.md)

## Rule 049 — `.github/workflows/publish.yaml`

- **Rule:** The publish-pypi job downloads artifacts and publishes packages from artifact/ to the TestPyPI repository URL https://test.pypi.org/legacy/.
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4edd6ed3a0eab345d0a23a71.md)

## Rule 054 — `.github/workflows/publish.yaml`

- **Rule:** The build job builds the package with python -m build.
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5381c66612f017140f32e820.md)

## Rule 100 — `.github/workflows/publish.yaml`

- **Rule:** The build job uploads the ./dist directory as an artifact.
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a3c07ab6fda2802e2cd7d987.md)

## Rule 102 — `.github/workflows/publish.yaml`

- **Rule:**
  ```text
  The build job generates a hash by running sha256sum over dist contents and base64-encoding the result into $GITHUB_OUTPUT.
  ```
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a799f6ad1ae35bad163a4ebc.md)

## Rule 117 — `.github/workflows/publish.yaml`

- **Rule:** The publish-pypi job publishes packages from artifact/ using pypa/gh-action-pypi-publish.
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b768428a74f02b35d2031408.md)

## Rule 128 — `.github/workflows/publish.yaml`

- **Rule:**
  ```text
  The build job sets SOURCE_DATE_EPOCH from the last commit date via git log -1 --pretty=%ct written to $GITHUB_ENV.
  ```
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-cf491f5deb1fe222e12b18f4.md)

## Rule 130 — `.github/workflows/publish.yaml`

- **Rule:** The build job installs build requirements with pip install -r requirements/build.txt.
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d26e322f0dac5bf4ccb00716.md)
