# Rules for `tests/test_custom_classes.py`

## Rule 116 — `tests/test_custom_classes.py`

- **Rule:** Tests that exercise custom Group subclasses must preserve the subclassing contract; changing Group subclass behavior requires updating these tests.
- **Applies to:**
  - `tests/test_custom_classes.py`
- **Condition:** When modifying click.Group subclassing behavior, the custom-subgroup test must be updated.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-b66b79f06f2b84fa86658b8b.md)
