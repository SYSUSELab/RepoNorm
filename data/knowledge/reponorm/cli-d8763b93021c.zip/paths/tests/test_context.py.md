# Rules for `tests/test_context.py`

## Rule 140 — `tests/test_context.py`

- **Rule:**
  ```text
  Tests that exercise the pass-object decorator pattern must keep the injected-object contract; changing pass_* decorator behavior requires updating these tests.
  ```
- **Applies to:**
  - `tests/test_context.py`
- **Condition:**
  ```text
  When modifying pass_* decorator injection behavior, the pass-object test in the context test file must be updated.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-ecf004ec8506df35db2646e0.md)
