# Rules for `tests/test_utils.py`

## Rule 001 — `tests/test_utils.py`

- **Rule:** Tests that assert exact stdout/stderr routing for echo/prompt/confirm/pause must be updated when output routing changes; the routing contract (including leading-space and prompt-text placement) is pinned.
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:** When modifying echo/prompt/confirm/pause output routing between stdout and stderr, the exact-routing assertions in the utils test must be updated.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-002fb5be1203be478035a58d.md)

## Rule 002 — `tests/test_utils.py`

- **Rule:** LazyFile iteration must yield the file's lines, and tests must compare each expected line to the stripped actual line.
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:** When modifying LazyFile iteration behavior or its tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-006d570907d25a374b4385c8.md)

## Rule 013 — `tests/test_utils.py`

- **Rule:** Tests for click.echo must verify it does not fail when sys.stdout and sys.stderr are None, as occurs with pythonw on Windows.
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:** When modifying or adding tests for click.echo behavior under missing standard streams.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-12fb35428b53a2624410a2db.md)

## Rule 149 — `tests/test_utils.py`

- **Rule:**
  ```text
  Tests for confirm prompts must assert exact prompt/response output: default-True prompts render 'Foo [Y/n]: ' and empty input yields 'yes!', while default-False prompts render 'Foo [y/N]: ' and empty input yields 'no :('.
  ```
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:** When modifying or adding tests for confirm prompt formatting and default-echo behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-f393c7bd373918c59cb3cd5c.md)
