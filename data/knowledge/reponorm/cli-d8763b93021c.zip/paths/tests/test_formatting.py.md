# Rules for `tests/test_formatting.py`

## Rule 047 — `tests/test_formatting.py`

- **Rule:** Tests that assert exact help/usage text must keep the expected output in sync with the formatter's wrapping, paragraph, and indentation behavior; changing help rendering requires updating these exact-output assertions.
- **Applies to:**
  - `tests/test_formatting.py`
  - `tests/test_options.py`
- **Condition:**
  ```text
  When modifying help-text rendering (wrapping, \b paragraph preservation, indentation, or envvar/option help display), the exact-output assertions in the formatting and options tests must be updated to match.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-4ce25edb65b8ee3cf39e5d0e.md)

## Rule 121 — `tests/test_formatting.py`

- **Rule:**
  ```text
  Help text truncation must occur at a form feed (\f) in a command docstring, and tests must define a command whose docstring contains \f followed by text.
  ```
- **Applies to:**
  - `tests/test_formatting.py`
- **Condition:** When modifying help text truncation behavior or its tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-bc334eec2efb349dd0ba19f0.md)
