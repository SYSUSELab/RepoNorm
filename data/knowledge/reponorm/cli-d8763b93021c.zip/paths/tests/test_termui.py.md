# Rules for `tests/test_termui.py`

## Rule 127 — `tests/test_termui.py`

- **Rule:**
  ```text
  Windows-specific getchar behavior must keep mapping Ctrl-C (\x03) to KeyboardInterrupt and Ctrl-Z (\x1a) to EOFError, tested by monkeypatching msvcrt.getwch and disabling _getchar.
  ```
- **Applies to:**
  - `tests/test_termui.py`
- **Condition:** When modifying Windows getchar exception handling or its tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-cd14cbcf283b740a008dd881.md)
