# Rules for `tests/typing`

## Rule 084 — `tests/typing/**`

- **Rule:** The typing test environment runs pyright against the tests/typing directory.
- **Applies to:**
  - `tests/typing/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-85cdb12a75cc387fa86dd6a6.md)

## Rule 101 — `src/click/**`

- **Rule:** mypy is configured to check the files under src/click and tests/typing.
- **Applies to:**
  - `src/click/**`
  - `tests/typing/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-a5a60396cc4b56cc56b3d72a.md)

## Rule 153 — `src/click/**`

- **Rule:** Pyright type checking is scoped to the src/click and tests/typing directories.
- **Applies to:**
  - `src/click/**`
  - `tests/typing/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-fcc25a308a6e9f3469bc4ff3.md)
