# Rules for `tests/typing/typing_aliased_group.py`

## Rule 092 — `tests/typing/typing_aliased_group.py`

- **Rule:**
  ```text
  Typing example modules under tests/typing must remain static typing compatibility checks: typing_aliased_group defines a command 'pop' returning None to exercise aliased group typing, and typing_confirmation_option asserts a confirmation-option command is typed as click.Command for the documented yes-parameter pattern.
  ```
- **Applies to:**
  - `tests/typing/typing_aliased_group.py`
  - `tests/typing/typing_confirmation_option.py`
- **Condition:** When modifying or adding typing example modules under tests/typing.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-986d645fda9f79e856caed5c.md)

## Rule 114 — `tests/typing/typing_aliased_group.py`

- **Rule:** The typing example must keep asserting that a command alias group instance is typed as AliasedGroup, preserving the documented command-alias pattern's static typing compatibility.
- **Applies to:**
  - `tests/typing/typing_aliased_group.py`
- **Condition:** When modifying the typing example for command alias groups.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b2e0b86cfff1f3726e219f36.md)

## Rule 135 — `tests/typing/typing_aliased_group.py`

- **Rule:**
  ```text
  Typing tests that override resolve_command must return cmd.name from the super() result and assert cmd is not None, pinning the aliased-group command resolution contract.
  ```
- **Applies to:**
  - `tests/typing/typing_aliased_group.py`
- **Condition:**
  ```text
  when adding or modifying typing tests that override resolve_command in tests/typing/typing_aliased_group.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e10a6caa2d8d922bfea2ed81.md)
