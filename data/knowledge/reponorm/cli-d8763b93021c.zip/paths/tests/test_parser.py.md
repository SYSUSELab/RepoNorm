# Rules for `tests/test_parser.py`

## Rule 069 — `tests/test_parser.py`

- **Rule:**
  ```text
  Tests for split_arg_string must verify that quoted strings and backslash escapes are handled, including that an unterminated quote still yields the quoted content and a trailing backslash is dropped.
  ```
- **Applies to:**
  - `tests/test_parser.py`
- **Condition:**
  ```text
  when adding or modifying tests for split_arg_string in tests/test_parser.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-69a37ef2022ee510bd1610af.md)
