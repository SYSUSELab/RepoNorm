# Rules for `tests/test_shell_completion.py`

## Rule 031 — `tests/test_shell_completion.py`

- **Rule:**
  ```text
  Shell completion tests must keep exercising the public shell_completion API surface (add_completion_class, CompletionItem, ShellComplete) together with core Command/Group/Option/Argument and Choice/File/Path types, because these are the stable entry points the completion tests depend on.
  ```
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:** When modifying shell completion tests or the completion API surface they import.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-2c40f40da6af63474aa830fd.md)

## Rule 072 — `tests/test_shell_completion.py`

- **Rule:** Absolute-path completion for a Path option must yield exactly one completion whose value is the absolute prefix, documenting absolute-path completion behavior.
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:** When modifying absolute-path completion behavior or its tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-71826de416388f8e429886c0.md)

## Rule 112 — `tests/test_shell_completion.py`

- **Rule:** Tests that exercise custom shell-completion callbacks must preserve the (ctx, param, incomplete) signature and list-of-strings return contract; changing the callback protocol requires updating these tests.
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:** When modifying the shell-completion callback protocol (signature or return type), the custom-callback test must be updated.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-b2189d7f57909e8753c19042.md)

## Rule 115 — `tests/test_shell_completion.py`

- **Rule:** Shell completion for a Choice type must filter candidates by the incomplete prefix: an empty prefix returns all choices, a partial prefix returns only matching choices, and an exact match returns only that choice.
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:** When modifying or extending shell completion tests for Choice-typed parameters, preserve prefix-based candidate filtering semantics.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-b2ed3f06145a311c82518d3f.md)

## Rule 133 — `tests/test_shell_completion.py`

- **Rule:**
  ```text
  Shell completion tests must parametrize over Path type configurations and assert that File() or Path() yields completion item type "file" while Path(file_okay=False) yields "dir".
  ```
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:** When modifying path-type completion item type mapping or its tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-db9cc52e525e1266f803e586.md)
