# Rules for `tests/test_options.py`

## Rule 047 — `tests/test_formatting.py`

- **Rule:** Tests that assert exact help/usage text must keep the expected output in sync with the formatter's wrapping, paragraph, and indentation behavior; changing help rendering requires updating these exact-output assertions.
- **Applies to:**
  - `tests/test_formatting.py`
  - `tests/test_options.py`
- **Condition:**
  ```text
  When modifying help-text rendering (wrapping, \b paragraph preservation, indentation, or envvar/option help display), the exact-output assertions in the formatting and options tests must be updated to match.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-4ce25edb65b8ee3cf39e5d0e.md)

## Rule 083 — `tests/test_options.py`

- **Rule:** Tests that exercise option suggestion and bool-flag-with-type behavior must be updated when option parsing or suggestion logic changes.
- **Applies to:**
  - `tests/test_options.py`
- **Condition:** When modifying unknown-option suggestion logic or bool-flag-with-type acceptance, the corresponding assertions in the options test file must be updated.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-846a5a2fe071e6546465b39c.md)

## Rule 088 — `tests/test_options.py`

- **Rule:**
  ```text
  Multiple=True options must split envvar values on os.path.pathsep, and auto_envvar_prefix must map TEST_ARG to the option, producing pathsep-joined output.
  ```
- **Applies to:**
  - `tests/test_options.py`
- **Condition:**
  ```text
  When modifying multiple-option envvar splitting or auto_envvar_prefix behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-8ec73a637be26b7ea9381afc.md)

## Rule 124 — `tests/test_options.py`

- **Rule:**
  ```text
  Tests that verify custom option/argument classes must keep using the get_help_record override and default/hidden display behavior as the extension points under test.
  ```
- **Applies to:**
  - `tests/test_options.py`
- **Condition:** When modifying tests for custom option or argument classes and their help/default rendering.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-be5083cea9c5f4a83ba76f71.md)
