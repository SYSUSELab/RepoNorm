# Full rule catalog

## Rule 117 — `outlines/models/gemini.py`

- **Rule:**
  ```text
  Model factory functions (from_llamacpp, from_gemini, from_transformers) must accept the native client/tokenizer object and return the corresponding Outlines model wrapper, preserving the public conversion entry point contract.
  ```
- **Applies to:**
  - `outlines/models/gemini.py`
  - `outlines/models/llamacpp.py`
  - `outlines/models/transformers.py`
- **Condition:** when adding or modifying a model factory conversion function that wraps a native client or tokenizer into an Outlines model
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-bb5f58827bc6ded49bf08e2a.md)

## Rule 118 — `outlines/models/transformers.py`

- **Rule:**
  ```text
  convert_token_to_string prepends a space for Llama tokenizers when the token starts with SPIECE_UNDERLINE or equals <0x20>, a hack to compensate for missing spaces in HF Llama tokenizers.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:**
  ```text
  When modifying convert_token_to_string or adding tokenizer-specific string conversion workarounds.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-bb87b1fc0ad9be832eebd69e.md)

## Rule 119 — `tests/models/test_openai_type_adapter.py`

- **Rule:**
  ```text
  The OpenAI adapter must reject str, int, Literal[1, 2], list[Foo], regex, and CFG output types with specific TypeError messages, documenting the set of unsupported output types for the OpenAI backend.
  ```
- **Applies to:**
  - `tests/models/test_openai_type_adapter.py`
- **Condition:** when changing OpenAI type adapter output-type validation or its unsupported-type error messages
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-bcbe5961c7cd8886891c70b0.md)

## Rule 120 — `scripts/gen_ref_pages.py`

- **Rule:**
  ```text
  The gen-files plugin runs the script scripts/gen_ref_pages.py.
  ```
- **Applies to:**
  - `scripts/gen_ref_pages.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-bd98bfefa2b7d4b61cd07ba3.md)

## Rule 121 — `outlines/inputs.py`

- **Rule:** Chat message inputs must be dicts carrying 'role' and 'content' keys, where role is one of user/assistant/system and content is a string or a list containing a string plus multimodal assets; string prompts are passed through unchanged rather than being wrapped into chat messages.
- **Applies to:**
  - `outlines/inputs.py`
  - `outlines/models/tgi.py`
- **Condition:** When changing how chat messages are validated or how string prompts are converted into model inputs.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-bf8adc836ae38de3cbc3e594.md)

## Rule 122 — `outlines/types/dsl.py`

- **Rule:**
  ```text
  JsonSchema.from_file must read a .json file and construct a JsonSchema from the parsed schema, defining the file-based schema construction API.
  ```
- **Applies to:**
  - `outlines/types/dsl.py`
- **Condition:**
  ```text
  when modifying JsonSchema.from_file's file reading or schema construction behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c01b3120d19394ad7ada6218.md)

## Rule 123 — `tests/models/test_openai.py`

- **Rule:** Tests that exercise a model backend requiring an API key must use a session-scoped fixture that constructs the client once and shares it across the session.
- **Applies to:**
  - `tests/models/test_openai.py`
- **Condition:** When adding or modifying a model fixture for a backend that requires an API key.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c02c37d9a9aa9c8163f15f2b.md)

## Rule 124 — `tests/models/test_openai_type_adapter.py`

- **Rule:**
  ```text
  OpenAI type adapter JSON mode must map dict output types to the request payload {"response_format": {"type": "json_object"}}.
  ```
- **Applies to:**
  - `tests/models/test_openai_type_adapter.py`
- **Condition:** when changing how the OpenAI type adapter maps output types to request payloads
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c3e51ef54833f0f2e73d45d9.md)

## Rule 125 — `examples/cerebrium/main.py`

- **Rule:** Examples that accept JSON Schema documents with nested $ref definitions must demonstrate that Outlines accepts such documents for structured generation, preserving support for definitions and $ref references.
- **Applies to:**
  - `examples/cerebrium/main.py`
- **Condition:** When adding or modifying an example that passes a JSON Schema document containing definitions and $ref references to Outlines.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c8af076f3bd4ab8b9038a6fe.md)

## Rule 126 — `tests/models/test_gemini.py`

- **Rule:** Tests for choice-constrained generation must assert that generating with a list of choices returns a string equal to one of the choice values, and that list choices are intentionally unsupported (xfail) where semantically incorrect.
- **Applies to:**
  - `tests/models/test_gemini.py`
- **Condition:** when adding or modifying tests for choice-constrained generation with list choices
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ca456058eb760cdef88a2022.md)

## Rule 127 — `outlines/processors/tensor_adapters/torch.py`

- **Rule:**
  ```text
  Torch tensor adapter __init__ imports torch and stores it on self, indicating lazy framework import as the adapter initialization convention.
  ```
- **Applies to:**
  - `outlines/processors/tensor_adapters/torch.py`
- **Condition:** When adding or modifying tensor adapter initialization that must lazily import a framework.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ce2f2baf8283bfa3a4f9ed0b.md)

## Rule 128 — `examples/react.py`

- **Rule:**
  ```text
  The react example's search_wikipedia helper must build a MediaWiki API URL with format=json and return only the first two sentences of the page extract joined by periods; contributors changing the helper should preserve this truncation behavior.
  ```
- **Applies to:**
  - `examples/react.py`
- **Condition:** When modifying the react example's Wikipedia search helper or its result formatting.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ced30761d39485316350a34b.md)

## Rule 129 — `tests/backends/test_xgrammar.py`

- **Rule:** Tests for a backend's logits processors must assert both the processor class identity and that generated output conforms to each constraint kind (JSON schema, regex, CFG).
- **Applies to:**
  - `tests/backends/test_xgrammar.py`
- **Condition:** When adding or modifying backend logits-processor tests that cover multiple constraint kinds.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-cf5fdac21f2d235d9cf67143.md)

## Rule 130 — `outlines/models/base.py`

- **Rule:**
  ```text
  The base Model ABC declares type_adapter: ModelTypeAdapter and tensor_library_name: str as class-level attributes; subclasses must define type_adapter, and steerable models must additionally define tensor_library_name.
  ```
- **Applies to:**
  - `outlines/models/base.py`
- **Condition:** When adding a new Model subclass or modifying the base Model ABC's required attributes.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d175cfdd66e6cdeea189be42.md)
