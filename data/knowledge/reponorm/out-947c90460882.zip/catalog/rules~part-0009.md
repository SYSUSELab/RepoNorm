# Full rule catalog

## Rule 131 — `examples/dating_profile.py`

- **Rule:** Example schemas that model a question-answer pair must keep the question typed as the repository's QuestionChoice type and the answer as a plain string, so the example stays coupled to the shared choice type rather than introducing a parallel representation.
- **Applies to:**
  - `examples/dating_profile.py`
- **Condition:**
  ```text
  When modifying the dating_profile example's question-answer dataclass or its field types.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d4c6ff20d48ab7e9cbc762e7.md)

## Rule 132 — `outlines/models/mlxlm.py`

- **Rule:**
  ```text
  MLXLM must set tensor_library_name = "mlx", matching the tensor adapter registry key required by the base Model contract for steerable models.
  ```
- **Applies to:**
  - `outlines/models/mlxlm.py`
- **Condition:**
  ```text
  when adding or modifying a model class that declares a tensor_library_name for steerable model support
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d5269976f155b843043e94b6.md)

## Rule 133 — `examples/beam-cloud/app.py`

- **Rule:**
  ```text
  Serverless examples must load the model once in the endpoint's on_start hook and retrieve it via context.on_start_value, constructing the Generator per request rather than reloading the model on each invocation.
  ```
- **Applies to:**
  - `examples/beam-cloud/app.py`
- **Condition:** When modifying the Beam Cloud example's model loading or request handler.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d8b2d12d22ea8465ef9f99b0.md)

## Rule 134 — `**`

- **Rule:** EditorConfig is rooted at this file (root = true), so this file is the top-most EditorConfig file.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d91b8e9a7a01b5241969d7fd.md)

## Rule 135 — `outlines/types/utils.py`

- **Rule:**
  ```text
  outlines/types/utils.py must import _TypedDictMeta from typing on Python 3.12+ and from typing_extensions otherwise, preserving this compatibility boundary when touching TypedDict handling.
  ```
- **Applies to:**
  - `outlines/types/utils.py`
- **Condition:** when modifying TypedDict handling or imports in outlines/types/utils.py
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d929f0056fed1774f43cdb85.md)

## Rule 136 — `tests/**`

- **Rule:**
  ```text
  Pytest test discovery is restricted to the tests directory via testpaths = ["tests"].
  ```
- **Applies to:**
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-dc0a48620c39e0c0691d12bd.md)

## Rule 137 — `outlines/models/gemini.py`

- **Rule:**
  ```text
  Gemini.generate must format input and output type through the type adapter, call client.models.generate_content with model name defaulting to self.model_name, and merge generation_config with inference kwargs.
  ```
- **Applies to:**
  - `outlines/models/gemini.py`
- **Condition:**
  ```text
  when modifying Gemini.generate's request construction or generation_config merging
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-dc34e8743fe4d10e2da4faff.md)

## Rule 138 — `.github/workflows/release_pypi.yaml`

- **Rule:**
  ```text
  The release workflow builds the SDist and wheel by running ./.github/scripts/build_sdist_and_wheel.sh.
  ```
- **Applies to:**
  - `.github/workflows/release_pypi.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-dd725eedbef4191dff50eb5d.md)

## Rule 139 — `outlines/templates.py`

- **Rule:**
  ```text
  The template `name` filter requires a callable and raises TypeError otherwise; for callables lacking `__name__` it falls back to the type name, so contributors must not assume every callable has `__name__`.
  ```
- **Applies to:**
  - `outlines/templates.py`
- **Condition:**
  ```text
  When modifying the template `name` filter or relying on `__name__` of callables passed to templates.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e0e24947b7ae9db76916b4fa.md)

## Rule 140 — `outlines/types/json_schema_utils.py`

- **Rule:**
  ```text
  When adding or modifying preprocess_schema_for_union_types, keep it as a temporary workaround for outlines-core lacking JSON schema type arrays by converting ["string","null"] to anyOf, and return invalid JSON strings unchanged to preserve error behavior.
  ```
- **Applies to:**
  - `outlines/types/json_schema_utils.py`
- **Condition:**
  ```text
  when adding or changing preprocess_schema_for_union_types or its handling of union-type schemas
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e25036a3586891723290c083.md)

## Rule 141 — `tests/models/test_gemini.py`

- **Rule:**
  ```text
  Tests that exercise Gemini list-of-pydantic generation must be marked @pytest.mark.api_call and assert the returned JSON list's first element is a dict containing the expected key.
  ```
- **Applies to:**
  - `tests/models/test_gemini.py`
- **Condition:** When adding or modifying Gemini tests that exercise list-of-pydantic generation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e2d46cc495155d08345577c1.md)

## Rule 142 — `SUMMARY.md`

- **Rule:** The literate-nav plugin uses SUMMARY.md as its navigation file.
- **Applies to:**
  - `SUMMARY.md`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e4d6c445cb6d1035add6bc66.md)

## Rule 143 — `**`

- **Rule:**
  ```text
  The tests job runs pytest under coverage with branch coverage and parallel mode, excluding tests marked api_call.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e595797e4dfa08412030d619.md)

## Rule 144 — `.github/workflows/release_pypi.yaml`

- **Rule:** The release workflow sets up Python version 3.10 via actions/setup-python.
- **Applies to:**
  - `.github/workflows/release_pypi.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e96125d8ab2429720fa0fea3.md)

## Rule 145 — `.github/workflows/build_documentation.yml`

- **Rule:** The documentation build workflow sets up Python version 3.10 via actions/setup-python.
- **Applies to:**
  - `.github/workflows/build_documentation.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-eab19b4a6b6f7d4638a6119e.md)

## Rule 146 — `mkdocs.yml`

- **Rule:** The git-committers plugin is configured for repository dottxt-ai/outlines on branch main.
- **Applies to:**
  - `mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-eb7582ab877914ced6741eb2.md)

## Rule 147 — `tests/types/test_types_utils.py`

- **Rule:**
  ```text
  Tests for type utilities must preserve the documented predicate behavior: is_typing_tuple returns true for tuple[int, str] and Tuple[int, str] and false for bare tuple, empty tuple literal, and list, and fixtures must include callables lacking type annotations.
  ```
- **Applies to:**
  - `tests/types/test_types_utils.py`
- **Condition:** when adding or modifying tests for type utility predicates or their fixtures
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ed301faa013033bc971cc118.md)

## Rule 148 — `examples/self_consistency.py`

- **Rule:** Examples that demonstrate self-consistency must generate multiple samples, extract the answer from each with a regex, and report the most frequent value as the consensus with its percentage.
- **Applies to:**
  - `examples/self_consistency.py`
- **Condition:** When adding or modifying an example that demonstrates self-consistency consensus.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ed738532ca09296fb49d3d66.md)
