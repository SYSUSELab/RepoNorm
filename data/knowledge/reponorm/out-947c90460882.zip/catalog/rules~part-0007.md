# Full rule catalog

## Rule 101 — `tests/models/test_ollama.py`

- **Rule:** The Ollama model's stream method must return a generator whose first yielded item is a str.
- **Applies to:**
  - `tests/models/test_ollama.py`
- **Condition:** when changing the Ollama model's stream method or its yielded item types
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a44c653fb75d49a984812862.md)

## Rule 102 — `outlines/templates.py`

- **Rule:** When adding or modifying the Template callable, render the underlying template with the supplied keyword arguments and return the rendered result as a Python string.
- **Applies to:**
  - `outlines/templates.py`
- **Condition:**
  ```text
  when adding or changing Template.__call__ or its rendering behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a5151f1f990e51b777a139c6.md)

## Rule 103 — `tests/models/test_vllm_offline.py`

- **Rule:** Passing an unknown inference keyword to the vLLM model must raise TypeError, enforcing strict inference-kwarg validation.
- **Applies to:**
  - `tests/models/test_vllm_offline.py`
- **Condition:** when changing vLLM model inference-kwarg handling or adding new accepted keywords
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a5583452c1b48705dcbf0585.md)

## Rule 104 — `tests/models/test_llamacpp_tokenizer.py`

- **Rule:**
  ```text
  Tests for model backends must preserve the documented external model pinning: the different_model fixture loads TheBloke/phi-2-GGUF phi-2.Q4_K_M.gguf via llama_cpp.Llama.from_pretrained for tokenizer tests.
  ```
- **Applies to:**
  - `tests/models/test_llamacpp_tokenizer.py`
- **Condition:** when adding or modifying tests for tokenizer behavior that require an external model fixture
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a8a2f3d3162b80ef0d3a56ec.md)

## Rule 105 — `outlines/_version.py`

- **Rule:**
  ```text
  setuptools_scm writes the generated version file to outlines/_version.py.
  ```
- **Applies to:**
  - `outlines/_version.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a8c7facf8c168b030b6fd32e.md)

## Rule 106 — `outlines/applications.py`

- **Rule:**
  ```text
  Application.__init__ must store the template and output type and initialize generator and model to None, deferring generator/model binding to a later step.
  ```
- **Applies to:**
  - `outlines/applications.py`
- **Condition:**
  ```text
  when modifying or extending Application.__init__ or the application initialization lifecycle
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ab31b8006a3760e9610315af.md)

## Rule 107 — `tests/models/test_sglang_type_adapter.py`

- **Rule:** The SGLang type adapter image fixture must build a 1x1 white RGB PNG in memory via BytesIO and reopen it.
- **Applies to:**
  - `tests/models/test_sglang_type_adapter.py`
- **Condition:** when adding or modifying image-input tests for the SGLang type adapter
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-af4203b4357190ce95210997.md)

## Rule 108 — `tests/models/test_transformers.py`

- **Rule:**
  ```text
  The transformers multiple-samples test must assert that a single call returns a string, while passing num_return_sequences=2 with do_sample=True returns a list of length 2, documenting the sampling-dependent return shape.
  ```
- **Applies to:**
  - `tests/models/test_transformers.py`
- **Condition:** when changing the transformers multiple-samples test or its sampling-dependent return-shape assertions
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b1987e14e4cc90a8a466a3ba.md)

## Rule 109 — `tests/models/test_sglang.py`

- **Rule:** Tests that exercise a real SGLang server must select the llguidance grammar backend (--grammar-backend llguidance); the outlines backend cannot handle EBNF grammars and the xgrammar backend is slow and buggy.
- **Applies to:**
  - `tests/models/test_sglang.py`
- **Condition:** when adding or modifying SGLang tests that run against a live SGLang server
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b38295464265a57a00785c30.md)

## Rule 110 — `examples/bentoml/service.py`

- **Rule:**
  ```text
  Examples that constrain generation with a JSON schema must pass the schema through outlines.json_schema(...) when constructing the generator or processor, rather than embedding schema constraints in the prompt alone.
  ```
- **Applies to:**
  - `examples/bentoml/service.py`
  - `examples/cerebrium/main.py`
  - `examples/pick_odd_one_out.py`
- **Condition:** When adding or modifying an example that constrains model output to a JSON schema.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b386c81ae0bda0895ba434d7.md)

## Rule 111 — `**/__init__.py`

- **Rule:**
  ```text
  Flake8 ignores F401 and F403 in __init__.py files.
  ```
- **Applies to:**
  - `**/__init__.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b3c1f3cfe60f36feaccd3054.md)

## Rule 112 — `examples/**/*.py`

- **Rule:** Example scripts under examples/ that chain multiple generation steps must pass the output of one constrained generation call as input to the next, preserving the structured intermediate value rather than discarding it.
- **Applies to:**
  - `examples/**/*.py`
- **Condition:** When adding or modifying an example that chains multiple generation steps, thread the structured output of each step into the next step's input.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b505839f059ed912228c6bb7.md)

## Rule 113 — `outlines/models/mlxlm.py`

- **Rule:**
  ```text
  MLX LM generate_batch always raises NotImplementedError because the mlx_lm library does not support batch inference.
  ```
- **Applies to:**
  - `outlines/models/mlxlm.py`
- **Condition:**
  ```text
  When modifying MLXLM.generate_batch or adding batch inference support to the MLX LM backend.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b5ea40cc0d4e664bdc155e0c.md)

## Rule 114 — `examples/babyagi.py`

- **Rule:**
  ```text
  Examples that load prompt or template files via relative paths (e.g. Template.from_file("prompts/...")) must be run from their own example directory; contributors changing such examples should preserve or document the working-directory requirement rather than silently switching to absolute paths.
  ```
- **Applies to:**
  - `examples/babyagi.py`
- **Condition:** When modifying an example that loads prompt/template files through relative paths.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b721db90a9dc7d3cdc4d6803.md)

## Rule 115 — `tests/types/test_json_schema_union_types.py`

- **Rule:** The TestJsonSchemaUnionTypes class must group test cases for JSON schemas with union types, treating union-type schema handling as a distinct tested concern.
- **Applies to:**
  - `tests/types/test_json_schema_union_types.py`
- **Condition:** When adding or modifying tests for JSON schema union-type handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b7f2a2b27e480e96fbedb873.md)

## Rule 116 — `tests/models/test_anthropic.py`

- **Rule:** The Anthropic wrong-output-type test asserts that model.generate with a Foo(1) output type raises NotImplementedError matching 'is not available', documenting rejection of unsupported output types.
- **Applies to:**
  - `tests/models/test_anthropic.py`
- **Condition:** when modifying or extending Anthropic model.generate output type handling or its tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b890b378ffd1c2e81f8eace3.md)
