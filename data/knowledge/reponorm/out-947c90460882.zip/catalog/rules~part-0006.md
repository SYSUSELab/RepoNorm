# Full rule catalog

## Rule 085 — `tests/models/test_transformers_tokenizer.py`

- **Rule:** Tests for tokenizer wrappers must assert hash/equality semantics: hash returns an int, equivalent tokenizers hash equal, and tokenizers with different configurations hash differently.
- **Applies to:**
  - `tests/models/test_transformers_tokenizer.py`
- **Condition:** when adding or modifying tests for tokenizer wrapper hash or equality behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-90ee256ccbc1f923cdaf85e9.md)

## Rule 086 — `outlines/models/base.py`

- **Rule:**
  ```text
  Model.__call__ must construct a Generator with the given output_type and backend and invoke it, so model(prompt, Foo) is equivalent to Generator(model, Foo)(prompt); the backend argument is only used for steerable models when output_type is provided.
  ```
- **Applies to:**
  - `outlines/models/base.py`
- **Condition:**
  ```text
  When modifying Model.__call__ or adding a new model subclass that overrides call semantics.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-920e48042b244a8fa01c6111.md)

## Rule 087 — `**`

- **Rule:** For all files, line endings use LF.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-942f40350ad8cdf0581148fb.md)

## Rule 088 — `outlines/models/tgi.py`

- **Rule:**
  ```text
  When adding or modifying the TGI integration module, export AsyncTGI, TGI, and from_tgi and import python_types_to_terms, to_regex, JsonSchema, and CFG from the DSL, preserving this public integration surface.
  ```
- **Applies to:**
  - `outlines/models/tgi.py`
- **Condition:** when adding or changing the TGI module's exports or DSL imports
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-95944e7e39be94566b434309.md)

## Rule 089 — `.devcontainer/devcontainer.json`

- **Rule:** The dev container runs with the --device=nvidia.com/gpu=all argument.
- **Applies to:**
  - `.devcontainer/devcontainer.json`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-95bd0ff7409e475a0547cb43.md)

## Rule 090 — `outlines/inputs.py`

- **Rule:** Chat.extend must append a list of message dicts to self.messages, defining the mutation semantics for extending a chat conversation.
- **Applies to:**
  - `outlines/inputs.py`
- **Condition:** when modifying Chat.extend's message mutation behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-97ea33a189f84b0db1c1cdde.md)

## Rule 091 — `tests/backends/test_llguidance.py`

- **Rule:**
  ```text
  The llguidance backend test fixture cfg_lark must supply a Lark grammar string using %import common.NUMBER, %import common.WS_INLINE, and %ignore WS_INLINE.
  ```
- **Applies to:**
  - `tests/backends/test_llguidance.py`
- **Condition:** when adding or modifying llguidance backend grammar fixtures
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-986209988773c71e3570f202.md)

## Rule 092 — `outlines/models/openai.py`

- **Rule:**
  ```text
  Each model backend's type adapter must define format_output_type with an explicit supported-output-type boundary: unsupported output types must raise TypeError (or NotImplementedError for CFG-based structured outputs) rather than silently degrading, and supported types must be routed to the backend's native mechanism (e.g. grammar.type=json for JsonSchema, grammar.type=regex via to_regex for other terms).
  ```
- **Applies to:**
  - `outlines/models/openai.py`
  - `outlines/models/tgi.py`
- **Condition:**
  ```text
  When adding or modifying a model backend's format_output_type to accept a new output type or change how an existing output type is serialized.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-998f7439eaa78261c7606840.md)

## Rule 093 — `**/*.py`

- **Rule:** Coverage is collected with branch coverage enabled.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9c65cf00dd0a411094570a2a.md)

## Rule 094 — `**/*.py`

- **Rule:**
  ```text
  The project declares a supported Python version range of >=3.9,<3.13.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9d2bac2c0121dbd4480af549.md)

## Rule 095 — `tests/models/test_mlxlm.py`

- **Rule:** The MLX model wrapper's generate must return a str, establishing the basic return-type contract for the MLX model wrapper.
- **Applies to:**
  - `tests/models/test_mlxlm.py`
- **Condition:** when changing the MLX model wrapper generate return type
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9f1c7008df65e8433c7317b1.md)

## Rule 096 — `tests/models/test_vllm_offline.py`

- **Rule:** Tests that exercise the offline vLLM model's generate must assert the return type (plain string for a simple prompt) as the basic generation contract.
- **Applies to:**
  - `tests/models/test_vllm_offline.py`
- **Condition:** When adding or modifying tests for the offline vLLM model's generate method.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9f65684e0b8aeea88b00e0b3.md)

## Rule 097 — `outlines/models/sglang.py`

- **Rule:**
  ```text
  from_sglang must dispatch on client type: openai.OpenAI yields SGLang, openai.AsyncOpenAI yields AsyncSGLang, and any other client type raises ValueError.
  ```
- **Applies to:**
  - `outlines/models/sglang.py`
- **Condition:**
  ```text
  when modifying from_sglang's client-type dispatch or adding new client types
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a009306d2a2df261614dee58.md)

## Rule 098 — `tests/types/test_json_schema_union_types.py`

- **Rule:**
  ```text
  `preprocess_schema_for_union_types` must convert type arrays into anyOf at every nesting level, including inside array items and nested object properties, and preserve the number of union members as anyOf length.
  ```
- **Applies to:**
  - `tests/types/test_json_schema_union_types.py`
- **Condition:**
  ```text
  when changing preprocess_schema_for_union_types handling of nested type arrays
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a1675ff493fd07c772330b34.md)

## Rule 099 — `tests/processors/test_tensor_adapters.py`

- **Rule:**
  ```text
  Tensor adapter to_list must convert 1d, 2d, and 3d tensors into nested Python lists preserving each dimension's length across all supported frameworks.
  ```
- **Applies to:**
  - `tests/processors/test_tensor_adapters.py`
- **Condition:**
  ```text
  when modifying or extending tensor adapter to_list behavior or its tests
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a2fd31442487a6107c8433dd.md)

## Rule 100 — `outlines/_version.py`

- **Rule:**
  ```text
  Coverage measurement omits the listed files and directories: outlines/_version.py, outlines/models/anthropic.py, outlines/models/dottxt.py, outlines/models/gemini.py, outlines/models/mlxlm.py, outlines/models/openai.py, outlines/models/vllm_offline.py, outlines/processors/tensor_adapters/mlx.py, and tests/*.
  ```
- **Applies to:**
  - `outlines/_version.py`
  - `outlines/models/anthropic.py`
  - `outlines/models/dottxt.py`
  - `outlines/models/gemini.py`
  - `outlines/models/mlxlm.py`
  - `outlines/models/openai.py`
  - `outlines/models/vllm_offline.py`
  - `outlines/processors/tensor_adapters/mlx.py`
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a3d4630cf0aebda7015f40de.md)
