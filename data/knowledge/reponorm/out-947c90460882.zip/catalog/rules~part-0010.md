# Full rule catalog

## Rule 149 — `mkdocs.yml`

- **Rule:** The MkDocs site uses the material theme.
- **Applies to:**
  - `mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-edc13f5428258ac6970dfd5e.md)

## Rule 150 — `tests/models/test_ollama_type_adapter.py`

- **Rule:**
  ```text
  The Ollama type adapter's format_output_type must round-trip a JSON schema string back to the original schema object, defining the adapter's schema normalization contract.
  ```
- **Applies to:**
  - `tests/models/test_ollama_type_adapter.py`
- **Condition:**
  ```text
  when modifying or extending Ollama type adapter format_output_type or its tests
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ee5e08cd4df3004000fa4f97.md)

## Rule 151 — `examples/llamacpp_example.py`

- **Rule:**
  ```text
  The llamacpp example's end-to-end usage must wrap the Llama model with outlines.from_llamacpp, construct a Generator with a Pydantic output type, and call it with prompt, seed, and max_tokens; contributors changing the example should preserve this call signature.
  ```
- **Applies to:**
  - `examples/llamacpp_example.py`
- **Condition:** When modifying the llamacpp example's model wrapping or Generator invocation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f099c39846025250025adffc.md)

## Rule 152 — `examples/dating_profile.py`

- **Rule:** Examples that define enumerated prompt choices must model them as a str-valued Enum whose members map option letters to prompt fragments, so generation can be constrained to the enumerated set.
- **Applies to:**
  - `examples/dating_profile.py`
- **Condition:** When adding or modifying an example that constrains generation to a fixed set of prompt choices.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f0b6bef0716517f46f64b1cf.md)

## Rule 153 — `.github/workflows/publish_documentation.yml`

- **Rule:** When the event is a push, the workflow deploys the branch as the unstable alias using mike.
- **Applies to:**
  - `.github/workflows/publish_documentation.yml`
- **Condition:**
  ```text
  workflow predicate: github.event_name == 'push'
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f2080984b9d4d39c192bfb29.md)

## Rule 154 — `tests/models/test_gemini_type_adapter.py`

- **Rule:**
  ```text
  The Gemini type adapter test module must import TypedDict from typing on Python >= 3.12 and from typing_extensions otherwise, establishing a version-conditional import convention.
  ```
- **Applies to:**
  - `tests/models/test_gemini_type_adapter.py`
- **Condition:** when adding TypedDict imports to the Gemini type adapter test module
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f2f8cd5c857142dfb2d97b28.md)

## Rule 155 — `examples/bentoml/import_model.py`

- **Rule:** Examples that derive a Bento model tag from a model identifier must lowercase the identifier and replace '/' with '--', following the repository convention for Bento model tags.
- **Applies to:**
  - `examples/bentoml/import_model.py`
- **Condition:** When adding or modifying an example that derives a Bento model tag from a model identifier.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f5b6688c3490757d99662a93.md)

## Rule 156 — `tests/models/test_gemini.py`

- **Rule:**
  ```text
  Tests that exercise a backend's choice-constrained generation must be marked with @pytest.mark.api_call and assert the returned value is one of the provided choices.
  ```
- **Applies to:**
  - `tests/models/test_gemini.py`
- **Condition:** when adding or modifying tests that make real API calls for choice-constrained generation
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f6055ca30dfb0cb44d987854.md)

## Rule 157 — `**/*.py`

- **Rule:** Flake8 enforces a maximum line length of 88 characters.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f6b6436362339df387eae03e.md)

## Rule 158 — `outlines/models/transformers.py`

- **Rule:**
  ```text
  TransformerTokenizer.decode must use tokenizer.batch_decode with skip_special_tokens=True, stripping special tokens from decoded output.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:** when modifying the Transformers tokenizer decode method or relying on raw token text in decoded output
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f9e64f06dee1c01a3996f3be.md)

## Rule 159 — `.github/workflows/tests_nightly.yml`

- **Rule:** The test environment is set up by upgrading pip, installing uv, creating a uv venv, and installing the package editable with the test extra.
- **Applies to:**
  - `.github/workflows/tests_nightly.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-faf4114f05545a2094d54087.md)

## Rule 160 — `outlines/models/tokenizer.py`

- **Rule:**
  ```text
  The tokenizer module must not require numpy at runtime; numpy imports must remain guarded under TYPE_CHECKING.
  ```
- **Applies to:**
  - `outlines/models/tokenizer.py`
- **Condition:** When adding or modifying imports in the tokenizer module.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-fe78c59445e2c0ec20572efe.md)

## Rule 161 — `tests/models/test_openai.py`

- **Rule:** OpenAI simple pydantic generation must return a string whose JSON parse contains the model's field name, verifying structured output for pydantic types.
- **Applies to:**
  - `tests/models/test_openai.py`
- **Condition:** when changing OpenAI pydantic structured-output handling
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ff0a2747724292588d3ce367.md)
