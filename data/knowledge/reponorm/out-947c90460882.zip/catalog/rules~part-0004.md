# Full rule catalog

## Rule 052 — `.github/workflows/release_pypi.yaml`

- **Rule:**
  ```text
  The release workflow publishes to PyPI using pypa/gh-action-pypi-publish with user __token__ and password from the PYPI_TOKEN secret.
  ```
- **Applies to:**
  - `.github/workflows/release_pypi.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-56d2890b6a15613ebbbc1845.md)

## Rule 053 — `tests/models/test_llamacpp_tokenizer.py`

- **Rule:** Tests for tokenizer fixtures must define a fixture that constructs the tokenizer from a no-HF-tokenizer model fixture to exercise the no-HF-tokenizer code path.
- **Applies to:**
  - `tests/models/test_llamacpp_tokenizer.py`
- **Condition:** when adding or modifying tokenizer fixtures that need to exercise the no-HF-tokenizer code path
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-59cabc7698885cb7d1ef9eb5.md)

## Rule 054 — `tests/models/test_transformers.py`

- **Rule:** Tests for model instantiation must assert that invalid output types (e.g. plain Python types like int) raise ValueError at instantiation time.
- **Applies to:**
  - `tests/models/test_transformers.py`
- **Condition:** when adding or modifying tests for model instantiation with invalid output types
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5ca6f58ddf9285485ce8a9b2.md)

## Rule 055 — `outlines/models/gemini.py`

- **Rule:**
  ```text
  Gemini.format_input must accept only str, list, and Chat (prompt plus images); the base singledispatchmethod implementation raises TypeError stating these are the only available input types.
  ```
- **Applies to:**
  - `outlines/models/gemini.py`
- **Condition:**
  ```text
  when adding or modifying accepted input types for Gemini.format_input
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6280b608e784670ab9dbe868.md)

## Rule 056 — `outlines/models/transformers.py`

- **Rule:**
  ```text
  TransformerTokenizer.__eq__ compares model_name and kwargs when both attributes exist, otherwise falls back to comparing tokenizer; returns NotImplemented for unrelated types.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:**
  ```text
  When modifying TransformerTokenizer.__eq__ or adding equality semantics to tokenizer wrappers.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-629ddae584e1819d8e1d9d37.md)

## Rule 057 — `tests/types/test_types_utils.py`

- **Rule:**
  ```text
  `is_callable` must return True for functions and lambdas but False for `dict`, classes, dataclasses, TypedDicts, and pydantic models, defining the callable-detection boundary used by type dispatch.
  ```
- **Applies to:**
  - `tests/types/test_types_utils.py`
- **Condition:**
  ```text
  when modifying or extending is_callable type classification or its tests
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-648c421af81b729bee026cd2.md)

## Rule 058 — `.github/workflows/tests_nightly.yml`

- **Rule:** The workflow installs Ollama and pulls the tinyllama model.
- **Applies to:**
  - `.github/workflows/tests_nightly.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-657003d7e793ef8852ab6337.md)

## Rule 059 — `examples/bentoml/service.py`

- **Rule:**
  ```text
  The BentoML example service must keep its DEFAULT_SCHEMA JSON schema in sync with the Character model: required fields name, age, armor, weapon, strength and $ref-based Armor/Weapon enum definitions must match the schema the service expects.
  ```
- **Applies to:**
  - `examples/bentoml/service.py`
- **Condition:**
  ```text
  When modifying the BentoML example's Character schema or its DEFAULT_SCHEMA JSON definition.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-68bd9ce3d82c352f939b8ca0.md)

## Rule 060 — `tests/types/test_types_utils.py`

- **Rule:**
  ```text
  is_datetime must return true only for datetime.datetime, and false for datetime.date, datetime.time, and a datetime instance, defining the exact type-classification boundary.
  ```
- **Applies to:**
  - `tests/types/test_types_utils.py`
- **Condition:**
  ```text
  when modifying or extending is_datetime type classification or its tests
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6932079f93de062c96c3d82c.md)

## Rule 061 — `outlines/models/dottxt.py`

- **Rule:**
  ```text
  Dottxt format_input accepts only str inputs and raises TypeError for any other type, so contributors must not pass non-string model inputs to this adapter.
  ```
- **Applies to:**
  - `outlines/models/dottxt.py`
- **Condition:**
  ```text
  When modifying Dottxt format_input or adding input handling to the Dottxt adapter.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-69b0cd551945d2fb0da421ab.md)

## Rule 062 — `tests/test_utils/mock_tgi_client.py`

- **Rule:**
  ```text
  Mock TGI client _create must hash kwargs into a request key, raise ValueError when no mock response is registered, and return an iterator when stream=True.
  ```
- **Applies to:**
  - `tests/test_utils/mock_tgi_client.py`
- **Condition:** when adding or modifying the mock TGI client's request/response matching behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-69b2bae9b5cb6d5fff16a810.md)

## Rule 063 — `tests/models/test_gemini.py`

- **Rule:** Tests for dataclass-typed generation must assert that model.generate returns a str whose JSON content contains the expected field.
- **Applies to:**
  - `tests/models/test_gemini.py`
- **Condition:** when adding or modifying tests for dataclass-typed generation output
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6beaf1eb3722dd8a0c09714c.md)

## Rule 064 — `**`

- **Rule:** For all files, a final newline is inserted.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-734fbaef6626b932be86d820.md)

## Rule 065 — `tests/models/test_gemini_type_adapter.py`

- **Rule:**
  ```text
  Tests that exercise a backend's structured-output type adapter must assert the exact payload shape (e.g. response_mime_type and response_schema) returned by format_output_type for the given output type.
  ```
- **Applies to:**
  - `tests/models/test_gemini_type_adapter.py`
- **Condition:**
  ```text
  when adding or modifying tests for a backend type adapter's format_output_type behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-74893380f434f86c1a3de69e.md)

## Rule 066 — `examples/beam-cloud/app.py`

- **Rule:**
  ```text
  Examples that load a HuggingFace causal LM through outlines.models.from_transformers must pass matching AutoModelForCausalLM and AutoTokenizer instances for the same model identifier.
  ```
- **Applies to:**
  - `examples/beam-cloud/app.py`
  - `examples/modal_example.py`
- **Condition:**
  ```text
  When adding or modifying an example that constructs an Outlines model via from_transformers.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-749f751983e6ac300b005fbe.md)

## Rule 067 — `outlines/models/base.py`

- **Rule:**
  ```text
  `outlines/models/base.py` is the shared base-class module for all models and model type adapters, importing `ABC`, `abstractmethod`, and async/sync iterator types; new model or adapter base classes belong here.
  ```
- **Applies to:**
  - `outlines/models/base.py`
- **Condition:** When adding or modifying shared model or model-type-adapter base classes.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7784c72d98412a39836c7b08.md)
