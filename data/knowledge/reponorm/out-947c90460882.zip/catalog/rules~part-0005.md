# Full rule catalog

## Rule 068 — `tests/models/test_gemini_type_adapter.py`

- **Rule:**
  ```text
  Gemini type adapter format_input must map Chat roles to Gemini contents roles, translating 'assistant' to 'model' and embedding Image inputs as inline_data with mime_type and image_str data.
  ```
- **Applies to:**
  - `tests/models/test_gemini_type_adapter.py`
- **Condition:**
  ```text
  when changing Gemini type adapter format_input role mapping or image embedding
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-77f9a7ddafffa9d3dbd90607.md)

## Rule 069 — `outlines/__init__.py`

- **Rule:**
  ```text
  outlines/__init__.py must export a curated __all__ combining cache helpers, Application, Generator, type constructors (regex, json_schema, cfg), Template, grammars, and a model_list of from_* factory names; from_vllm_offline is imported but absent from model_list and must not be re-exported via __all__.
  ```
- **Applies to:**
  - `outlines/__init__.py`
- **Condition:**
  ```text
  When modifying the public API surface or __all__ in outlines/__init__.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-79e726af48006f71f56e67e3.md)

## Rule 070 — `.github/workflows/asv_benchmark_pr.yml`

- **Rule:** The workflow runs asv continuous comparing upstream/main to HEAD with --no-stats --interleave-rounds -a repeat=3, tolerating errors.
- **Applies to:**
  - `.github/workflows/asv_benchmark_pr.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7a78fa96a9339420d1eba6cf.md)

## Rule 071 — `tests/test_templates.py`

- **Rule:**
  ```text
  Template tests must define custom_filter as a plain callable taking a string and returning its uppercase form, establishing that custom filters are plain callables.
  ```
- **Applies to:**
  - `tests/test_templates.py`
- **Condition:** When modifying or adding template tests that define custom filters.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7ae3b9c256b5d2c6019efbdd.md)

## Rule 072 — `tests/models/test_mlxlm.py`

- **Rule:** MLXLM model calls must reject unknown inference keyword arguments by raising TypeError, so passing an unsupported kwarg such as foo='bar' is an error rather than being silently ignored.
- **Applies to:**
  - `tests/models/test_mlxlm.py`
- **Condition:** when changing MLXLM model call handling of inference keyword arguments
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7b2007fc9cc946dc827c1f60.md)

## Rule 073 — `tests/backends/test_backends.py`

- **Rule:**
  ```text
  Tests for backend utilities must preserve the documented stable regex fixture: the regex fixture returns the literal pattern r"[0-9]{3}" used across backend tests.
  ```
- **Applies to:**
  - `tests/backends/test_backends.py`
- **Condition:** when adding or modifying backend tests that use the shared regex fixture
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7bb3852723fec27d62f484bb.md)

## Rule 074 — `tests/models/test_gemini_type_adapter.py`

- **Rule:**
  ```text
  Gemini type adapter's format_output_type for a TypedDict must return a dict with response_mime_type 'application/json' and response_schema set to the type itself, defining the Gemini structured-output mapping.
  ```
- **Applies to:**
  - `tests/models/test_gemini_type_adapter.py`
- **Condition:**
  ```text
  when modifying or extending Gemini type adapter format_output_type or its tests
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7ddcaf5346642f48d9b752fb.md)

## Rule 075 — `tests/models/test_utils.py`

- **Rule:**
  ```text
  `set_additional_properties_false_json_schema` must add additionalProperties: False when absent, leave it unchanged when already False, and leave it unchanged when True, so the function only sets the flag when missing.
  ```
- **Applies to:**
  - `tests/models/test_utils.py`
- **Condition:**
  ```text
  when changing set_additional_properties_false_json_schema behavior for present or absent additionalProperties
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7fb352457c2f4ee9eb43ad77.md)

## Rule 076 — `environment.yml`

- **Rule:** The conda environment pins python==3.10.0.
- **Applies to:**
  - `environment.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7fb6a375de9ab9c4121babb4.md)

## Rule 077 — `.github/workflows/asv_benchmark_pr.yml`

- **Rule:** The workflow installs asv, virtualenv, and lf-asv-formatter as dependencies.
- **Applies to:**
  - `.github/workflows/asv_benchmark_pr.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-81b03cd8051cea8dc1d3cb33.md)

## Rule 078 — `outlines/models/sglang.py`

- **Rule:**
  ```text
  `SGLang` must remain a thin wrapper around the `openai.OpenAI` client, converting user-specified input/output types into OpenAI client arguments rather than implementing its own transport.
  ```
- **Applies to:**
  - `outlines/models/sglang.py`
- **Condition:** When modifying the SGLang model wrapper's request construction or client usage.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-81baf95f5232d79cc584c49e.md)

## Rule 079 — `examples/vllm_offline_integration.py`

- **Rule:** Examples that define a structured output schema must use a pydantic model with typed string fields as the schema passed to the generation pipeline.
- **Applies to:**
  - `examples/vllm_offline_integration.py`
- **Condition:** When adding or modifying an example that defines a structured output schema for generation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8376d86e5f2782c9e640164a.md)

## Rule 080 — `outlines/models/transformers.py`

- **Rule:**
  ```text
  `TransformersMultiModalTypeAdapter` must be declared as a `ModelTypeAdapter` for the `TransformersMultiModal` model, so multimodal adapter registration must target that model.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:** When adding or modifying the multimodal transformers type adapter registration.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8a9b5314fe420c0f73d94318.md)

## Rule 081 — `.devcontainer/devcontainer.json`

- **Rule:** The dev container enables the nvidia-cuda devcontainer feature with installCudnn set to true.
- **Applies to:**
  - `.devcontainer/devcontainer.json`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8b315652ab780d736f70c5e0.md)

## Rule 082 — `tests/models/test_tokenizer.py`

- **Rule:** The base Tokenizer class is abstract and must not be directly instantiable; instantiating Tokenizer() must raise TypeError matching "instantiate abstract".
- **Applies to:**
  - `tests/models/test_tokenizer.py`
- **Condition:** when modifying the base Tokenizer class or its abstract-method declarations
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8cc94982c99b94ee76bf3720.md)

## Rule 083 — `README.md`

- **Rule:** The project readme file is declared as README.md.
- **Applies to:**
  - `README.md`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8e6d902fc5184d02251b79f7.md)

## Rule 084 — `**/*.py`

- **Rule:** Flake8 ignores error codes E203, E231, E501, E741, W503, W504, C901, and E731.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8f57d3e8c4f7044df40cb759.md)
