# Full rule catalog

## Rule 001 — `outlines/models/transformers.py`

- **Rule:**
  ```text
  `get_llama_tokenizer_types` must tolerate missing Llama-family tokenizer classes by substituting dummy classes on ImportError and returning the tuple, preserving compatibility across transformers versions.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:** When modifying tokenizer type resolution or upgrading the transformers dependency for Llama-family tokenizers.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-013b124a52ad34e62b452f7f.md)

## Rule 002 — `**`

- **Rule:** For all files, charset is utf-8.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-03c96832a1aba6566d6dd59b.md)

## Rule 003 — `tests/models/test_ollama_type_adapter.py`

- **Rule:**
  ```text
  The Ollama type adapter's format_input must convert a plain text prompt into a single-element list containing a user-role message dict with the text as content.
  ```
- **Applies to:**
  - `tests/models/test_ollama_type_adapter.py`
- **Condition:**
  ```text
  when modifying or extending Ollama type adapter format_input or its tests
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-063d5804c48254a23951bd39.md)

## Rule 004 — `tests/models/test_ollama_type_adapter.py`

- **Rule:**
  ```text
  The Ollama type adapter must format a genson SchemaBuilder with mixed integer/string values into a JSON schema whose type is ["integer", "string"] and whose required list is ["hi"].
  ```
- **Applies to:**
  - `tests/models/test_ollama_type_adapter.py`
- **Condition:** when changing Ollama type adapter schema formatting for genson SchemaBuilder inputs
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-070f7d713939571af3173289.md)

## Rule 005 — `tests/models/test_vllm.py`

- **Rule:** The sync vLLM model's n sampling parameter must return a list of exactly n string samples.
- **Applies to:**
  - `tests/models/test_vllm.py`
- **Condition:** when changing sync vLLM sampling or its n-parameter handling
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0a6d67ce24f5ccf7d7a5b5d2.md)

## Rule 006 — `.devcontainer/devcontainer.json`

- **Rule:** The dev container enables the conda devcontainer feature.
- **Applies to:**
  - `.devcontainer/devcontainer.json`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0c58c4ebbf15949d2b12e3ae.md)

## Rule 007 — `**/*.py`

- **Rule:** mypy enables the incomplete feature "Unpack".
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0c6643355add2dda0a1e617b.md)

## Rule 008 — `outlines/inputs.py`

- **Rule:**
  ```text
  Audio must be a dataclass holding an audio: Any field, documented to be passed alongside a text prompt in a list as model_input for audio-capable multimodal models.
  ```
- **Applies to:**
  - `outlines/inputs.py`
- **Condition:** when modifying the Audio dataclass or its multimodal input usage
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0ccaf4ac8cf07fcff2e5c30c.md)

## Rule 009 — `examples/babyagi.py`

- **Rule:**
  ```text
  The BabyAGI example's one_cycle must not reuse the loop variable `task` for newly created tasks while also referencing the popped task via a different name (first_task); contributors fixing or extending this example should resolve the shadowing so the popped task's task_name is used consistently.
  ```
- **Applies to:**
  - `examples/babyagi.py`
- **Condition:**
  ```text
  When modifying the BabyAGI example's one_cycle task-creation loop or its variable naming.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0e3de5e758e71e8839e913e9.md)

## Rule 010 — `examples/modal_example.py`

- **Rule:** Examples that pin Outlines and its dependencies must pin outlines==1.0.0 together with compatible transformers, datasets, and accelerate versions in a Debian slim Python 3.11 image.
- **Applies to:**
  - `examples/modal_example.py`
- **Condition:** When adding or modifying an example that pins Outlines and its dependencies.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0e952a7629c9b77438fbdff1.md)

## Rule 011 — `.github/workflows/publish_documentation.yml`

- **Rule:** The workflow checks out the repository with fetch-depth 0 and sets up Python version 3.x.
- **Applies to:**
  - `.github/workflows/publish_documentation.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1522a03ff5493dd155bf9837.md)

## Rule 012 — `**/*.yaml`

- **Rule:** For YAML files, indent size is 2.
- **Applies to:**
  - `**/*.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-157977bc67a4b6df2f2f61b4.md)

## Rule 013 — `tests/models/test_vllm.py`

- **Rule:**
  ```text
  `test_vllm_sync_cfg` must assert that generating with CFG(YES_NO_GRAMMAR) yields a string restricted to ["yes", "no"], verifying CFG-constrained decoding on the vLLM backend.
  ```
- **Applies to:**
  - `tests/models/test_vllm.py`
- **Condition:** when changing the vLLM CFG-constrained decoding test
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1604e60297bcb27994ff5c8f.md)

## Rule 014 — `**`

- **Rule:** For all files, trailing whitespace is trimmed.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-19a630f6deb6dd56c8d1692d.md)

## Rule 015 — `outlines/backends/__init__.py`

- **Rule:**
  ```text
  The backends package must define CFG_DEFAULT_BACKEND as 'llguidance' while JSON_SCHEMA_DEFAULT_BACKEND and REGEX_DEFAULT_BACKEND are 'outlines_core'.
  ```
- **Applies to:**
  - `outlines/backends/__init__.py`
- **Condition:** when modifying default backend selection constants in the backends package
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-19bdbebee6e1391705d11cc7.md)

## Rule 016 — `.github/workflows/publish_documentation.yml`

- **Rule:** When the event is a release, the workflow deploys the tag as the latest alias and sets latest as the default version using mike.
- **Applies to:**
  - `.github/workflows/publish_documentation.yml`
- **Condition:**
  ```text
  workflow predicate: github.event_name == 'release'
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1ace280d84471390aacdaf90.md)

## Rule 017 — `outlines/models/dottxt.py`

- **Rule:**
  ```text
  from_dottxt constructs a Dottxt model by forwarding client, model_name, and model_revision positionally to the Dottxt constructor, so the constructor argument order is part of the factory contract.
  ```
- **Applies to:**
  - `outlines/models/dottxt.py`
- **Condition:**
  ```text
  When modifying from_dottxt or the Dottxt constructor's parameter order.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1c5479fb8fa93bd68ef414f7.md)

## Rule 018 — `examples/bentoml/import_model.py`

- **Rule:**
  ```text
  The BentoML import_model example must load tokenizer and model from MODEL_ID with torch.float16 and low_cpu_mem_usage, then save both into a bentoml.models.create context path; contributors changing the import flow should preserve this packaging contract.
  ```
- **Applies to:**
  - `examples/bentoml/import_model.py`
- **Condition:**
  ```text
  When modifying the BentoML import_model example's loading or saving flow.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1d708adf7afae5b12681f7cf.md)
