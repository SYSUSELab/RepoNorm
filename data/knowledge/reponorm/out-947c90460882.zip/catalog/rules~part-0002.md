# Full rule catalog

## Rule 019 — `outlines/models/base.py`

- **Rule:**
  ```text
  AsyncModel.__call__ must construct a Generator with the model, output type, and backend, then await it, making model(prompt, Foo) equivalent to awaiting Generator(model, Foo)(prompt).
  ```
- **Applies to:**
  - `outlines/models/base.py`
- **Condition:** when modifying the async model call path or the Generator construction contract
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1fcd5b6af02be9f9e08e8f1b.md)

## Rule 020 — `**/*.py`

- **Rule:** Pytest treats warnings as errors by default (filterwarnings includes "error"), except for the explicitly ignored warning categories.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-218eda82d8f12d1ecf586b5f.md)

## Rule 021 — `examples/babyagi.py`

- **Rule:** Examples that parse structured model output must implement the parsing convention explicitly (e.g. splitting lines and keeping only lines containing a period, taking text after the first period) rather than relying on the model to return clean structured text.
- **Applies to:**
  - `examples/babyagi.py`
- **Condition:** When adding or modifying an example that parses structured model output into discrete items.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-21980cad68b287fc13e014c0.md)

## Rule 022 — `tests/models/test_mlxlm.py`

- **Rule:**
  ```text
  MLX tests must be gated by pytest.mark.skipif(not HAS_MLX, reason='MLX tests require Apple Silicon') and choice tests must assert the model output is one of the allowed choices.
  ```
- **Applies to:**
  - `tests/models/test_mlxlm.py`
- **Condition:** when adding or modifying MLX model tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-226612617b6b5cc1a8c6007f.md)

## Rule 023 — `.devcontainer/devcontainer.json`

- **Rule:** The dev container declares GPU host requirements as optional.
- **Applies to:**
  - `.devcontainer/devcontainer.json`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-255e39c19ebcae6f0db6fbcb.md)

## Rule 024 — `.github/workflows/asv_benchmark_pr.yml`

- **Rule:** The workflow runs asv compare with --factor=1.1 --no-stats --split upstream/main HEAD and fails the step if the output contains 'Benchmarks that have got worse'.
- **Applies to:**
  - `.github/workflows/asv_benchmark_pr.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-28e64d1c488af19b18a89eae.md)

## Rule 025 — `outlines/processors/tensor_adapters/numpy.py`

- **Rule:**
  ```text
  NumpyTensorAdapter must declare library_name = "numpy", the key used to register and look up the adapter in the tensor_adapters mapping consumed by BaseLogitsProcessor.__init__.
  ```
- **Applies to:**
  - `outlines/processors/tensor_adapters/numpy.py`
- **Condition:**
  ```text
  when adding or modifying a tensor adapter's library_name registration key
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-2e8567480c144faac386073e.md)

## Rule 026 — `mkdocs.yml`

- **Rule:** The git-revision-date-localized plugin enables creation date and uses the timeago type.
- **Applies to:**
  - `mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-328724e12605a8d4ddc9742a.md)

## Rule 027 — `tests/models/test_anthropic.py`

- **Rule:**
  ```text
  Tests for model backends must preserve the documented client initialization contract: from_anthropic accepts an optional model name that sets model.model_name when provided and leaves it None when omitted, while model.client is always the passed client.
  ```
- **Applies to:**
  - `tests/models/test_anthropic.py`
- **Condition:** when adding or modifying tests for model backend client initialization
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-32f515af4f3c04ffb246d16b.md)

## Rule 028 — `pyproject.toml`

- **Rule:** The project version is declared as dynamic rather than a static value.
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-33bec29ab8660a2bb7013c8a.md)

## Rule 029 — `tests/models/test_sglang.py`

- **Rule:**
  ```text
  Tests for backend selection must use the SGLANG_SERVER_URL environment variable to choose between a real server and a mock client, warning and defaulting to the mock client when unset, and defaulting the model name via SGLANG_MODEL_NAME.
  ```
- **Applies to:**
  - `tests/models/test_sglang.py`
- **Condition:** when adding or modifying tests that need to select between a real SGLang server and a mock client
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3464fe52e7de5195a6e43c40.md)

## Rule 030 — `tests/models/test_transformers.py`

- **Rule:**
  ```text
  Tests that verify a model wrapper's tensor backend must assert the concrete adapter types and tensor_library_name (e.g. 'jax' for Flax models).
  ```
- **Applies to:**
  - `tests/models/test_transformers.py`
- **Condition:**
  ```text
  When adding or modifying tests that instantiate a model via from_transformers and verify its backend.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-35e8dc270733195de6a8c541.md)

## Rule 031 — `.devcontainer/devcontainer.json`

- **Rule:** The dev container enables the rust devcontainer feature.
- **Applies to:**
  - `.devcontainer/devcontainer.json`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-375e9e30eb98e17effb3e521.md)

## Rule 032 — `tests/processors/test_tensor_adapters.py`

- **Rule:** Tensor adapter shape() must return a sequence whose length and entries match the tensor rank and dimensions for 1d, 2d, and 3d tensors across all supported frameworks.
- **Applies to:**
  - `tests/processors/test_tensor_adapters.py`
- **Condition:** when modifying or extending tensor adapter shape behavior or its tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-38e227f75a2e7426221dfd05.md)

## Rule 033 — `outlines/types/utils.py`

- **Rule:**
  ```text
  is_pydantic_model must return False for generic types with a non-None origin, and otherwise True only for classes that subclass BaseModel; the origin check exists because generic types cannot be used with issubclass on Python versions below 3.11.
  ```
- **Applies to:**
  - `outlines/types/utils.py`
- **Condition:**
  ```text
  When modifying is_pydantic_model or adding type-detection utilities that must handle generic types across Python versions.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-39bbcbcb281a8f878e7b8091.md)

## Rule 034 — `.devcontainer/devcontainer.json`

- **Rule:** The dev container is based on the mcr.microsoft.com/devcontainers/python:3.12 image.
- **Applies to:**
  - `.devcontainer/devcontainer.json`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-39c48f9ed29386514b40f7fa.md)

## Rule 035 — `outlines/models/tgi.py`

- **Rule:**
  ```text
  `TGI.generate_stream` supports all output types except CFG when the server backend supports them, and its streaming loop is marked `pragma: no cover` so it is excluded from coverage.
  ```
- **Applies to:**
  - `outlines/models/tgi.py`
- **Condition:** When modifying TGI streaming generation or its coverage pragmas.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3c3c4351dc02fbd3665876d9.md)
