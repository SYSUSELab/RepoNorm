# Full rule catalog

## Rule 036 — `outlines/processors/tensor_adapters/tensorflow.py`

- **Rule:**
  ```text
  The tensorflow tensor adapter's `to_list` must convert via `tensor.numpy().tolist()`, requiring eager tensor semantics for the tensorflow backend.
  ```
- **Applies to:**
  - `outlines/processors/tensor_adapters/tensorflow.py`
- **Condition:** When modifying tensor-to-list conversion for the tensorflow backend.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3caf1f3f8250e0c29faa13d4.md)

## Rule 037 — `.github/workflows/publish_documentation.yml`

- **Rule:** The workflow installs documentation dependencies from requirements-doc.txt and builds the docs with mkdocs build.
- **Applies to:**
  - `.github/workflows/publish_documentation.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3d162945b42cbf7939a5dc92.md)

## Rule 038 — `examples/pick_odd_one_out.py`

- **Rule:** Examples that demonstrate constrained vs unconstrained generation must use two generators over the same model: an unconstrained Generator for chain-of-thought reasoning with stop sequences, and a Generator constrained by a JsonSchema whose result field is an enum of the options.
- **Applies to:**
  - `examples/pick_odd_one_out.py`
- **Condition:** When adding or modifying an example that contrasts constrained and unconstrained generation over the same model.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3d79fbf92e170f6334914b72.md)

## Rule 039 — `tests/test_generator.py`

- **Rule:**
  ```text
  The generator test module must build MockAsyncOpenAIClient/MockOpenAIClient from tests.test_utils.mock_openai_client and register paired mock responses (non-streaming and streaming with stream: True) keyed by request payload including extra_body.guided_regex, to test black-box generators without network calls.
  ```
- **Applies to:**
  - `tests/test_generator.py`
- **Condition:** When modifying or adding generator tests that use mock OpenAI clients.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3f0b4fe8539d7ddf0ef15fbe.md)

## Rule 040 — `examples/**`

- **Rule:** mypy excludes the "examples" directory from type checking.
- **Applies to:**
  - `examples/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-41aa774c58bda9f6bb65b95b.md)

## Rule 041 — `outlines/templates.py`

- **Rule:** The args template filter must require a callable and raise TypeError otherwise; it returns a comma-joined string of inspect.signature parameters including annotations and defaults.
- **Applies to:**
  - `outlines/templates.py`
- **Condition:** when modifying the args template filter's callable validation or signature formatting
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-4435020abe1075a26b15de89.md)

## Rule 042 — `examples/**/*.py`

- **Rule:** Example scripts under examples/ that define structured output types must declare them as explicit typed schemas (pydantic models or dataclasses) rather than ad-hoc dicts or untyped structures.
- **Applies to:**
  - `examples/**/*.py`
- **Condition:** When adding or modifying an example that defines a structured output type, declare it as a pydantic model or dataclass rather than an untyped dict.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-45f31f27b32efe01f757577e.md)

## Rule 043 — `outlines/backends/xgrammar.py`

- **Rule:**
  ```text
  XGrammarLogitsProcessor.reset() must set self.xgrammar_logits_processor to None, clearing the processor rather than reinitializing it.
  ```
- **Applies to:**
  - `outlines/backends/xgrammar.py`
- **Condition:** when modifying the reset behavior of a logits processor that holds a compiled grammar state
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-475d17dfa7265546f77ce5eb.md)

## Rule 044 — `tests/models/test_openai.py`

- **Rule:**
  ```text
  Tests for model backends must preserve the documented multi-sample generation contract: OpenAI generate with n=2 returns a list of length 2 containing two strings, and such tests must carry the api_call marker.
  ```
- **Applies to:**
  - `tests/models/test_openai.py`
- **Condition:** when adding or modifying tests for multi-sample generation in a model backend
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-4987ba5f682984de0d82bcb5.md)

## Rule 045 — `examples/llamacpp_example.py`

- **Rule:** Examples that constrain generation to a fixed vocabulary must define the choices as a str Enum (e.g. Armor, Weapon) and reference those enums from the Pydantic model, rather than using free-form strings.
- **Applies to:**
  - `examples/llamacpp_example.py`
- **Condition:** When editing the llamacpp example's constrained-choice fields or their enum definitions.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-4a2ecfbaea08569b1bd0d29b.md)

## Rule 046 — `tests/models/test_ollama_type_adapter.py`

- **Rule:**
  ```text
  Type adapter tests must assert that format_output_type passes the provided schema through unchanged for dataclass output types.
  ```
- **Applies to:**
  - `tests/models/test_ollama_type_adapter.py`
- **Condition:** When adding or modifying type adapter tests for dataclass output types.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-4ae00eeab0740c66ee5aaf9f.md)

## Rule 047 — `environment.yml`

- **Rule:**
  ```text
  The conda environment installs the project itself in editable mode with the test extra via pip (`-e ".[test]"`).
  ```
- **Applies to:**
  - `environment.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-4af24d73349813b80a5ee846.md)

## Rule 048 — `tests/models/test_sglang_type_adapter.py`

- **Rule:**
  ```text
  The SGLang type adapter's format_input for a plain string prompt must produce a single user-role message with the string as content, establishing the minimal text-input normalization contract.
  ```
- **Applies to:**
  - `tests/models/test_sglang_type_adapter.py`
- **Condition:**
  ```text
  when changing SGLang type adapter format_input handling of plain string prompts
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-4ba42f8bb0eda1645af9a842.md)

## Rule 049 — `outlines/processors/tensor_adapters/torch.py`

- **Rule:**
  ```text
  TorchTensorAdapter.to_device must be implemented as tensor.to(device), relying on torch's native device transfer rather than custom logic.
  ```
- **Applies to:**
  - `outlines/processors/tensor_adapters/torch.py`
- **Condition:** when modifying the torch tensor adapter's device transfer behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-4f1ad9fa406bd1b3071c69f7.md)

## Rule 050 — `.github/workflows/release_pypi.yaml`

- **Rule:**
  ```text
  The release workflow checks that the package version matches the release name by grepping for "^Version: ${GITHUB_REF:10}$" in outlines.egg-info/PKG-INFO.
  ```
- **Applies to:**
  - `.github/workflows/release_pypi.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-535917fda7b0f3950f1e29fa.md)

## Rule 051 — `tests/types/test_types_utils.py`

- **Rule:**
  ```text
  Tests that exercise the is_bool type utility must assert recognition of bool, Annotated[bool,...], and NewType over bool, while rejecting int, bool instances, Annotated[int,...], and NewType over int.
  ```
- **Applies to:**
  - `tests/types/test_types_utils.py`
- **Condition:**
  ```text
  When adding or modifying tests for the is_bool type utility.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-539b373ccd5c81ba5cf17164.md)
