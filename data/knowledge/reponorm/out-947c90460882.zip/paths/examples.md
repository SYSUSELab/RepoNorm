# Rules for `examples`

## Rule 040 — `examples/**`

- **Rule:** mypy excludes the "examples" directory from type checking.
- **Applies to:**
  - `examples/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-41aa774c58bda9f6bb65b95b.md)

## Rule 042 — `examples/**/*.py`

- **Rule:** Example scripts under examples/ that define structured output types must declare them as explicit typed schemas (pydantic models or dataclasses) rather than ad-hoc dicts or untyped structures.
- **Applies to:**
  - `examples/**/*.py`
- **Condition:** When adding or modifying an example that defines a structured output type, declare it as a pydantic model or dataclass rather than an untyped dict.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-45f31f27b32efe01f757577e.md)

## Rule 112 — `examples/**/*.py`

- **Rule:** Example scripts under examples/ that chain multiple generation steps must pass the output of one constrained generation call as input to the next, preserving the structured intermediate value rather than discarding it.
- **Applies to:**
  - `examples/**/*.py`
- **Condition:** When adding or modifying an example that chains multiple generation steps, thread the structured output of each step into the next step's input.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b505839f059ed912228c6bb7.md)
