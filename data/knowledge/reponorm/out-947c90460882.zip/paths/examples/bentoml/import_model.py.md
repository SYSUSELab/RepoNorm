# Rules for `examples/bentoml/import_model.py`

## Rule 018 — `examples/bentoml/import_model.py`

- **Rule:**
  ```text
  The BentoML import_model example must load tokenizer and model from MODEL_ID with torch.float16 and low_cpu_mem_usage, then save both into a bentoml.models.create context path; contributors changing the import flow should preserve this packaging contract.
  ```
- **Applies to:**
  - `examples/bentoml/import_model.py`
- **Condition:**
  ```text
  When modifying the BentoML import_model example's loading or saving flow.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1d708adf7afae5b12681f7cf.md)

## Rule 155 — `examples/bentoml/import_model.py`

- **Rule:** Examples that derive a Bento model tag from a model identifier must lowercase the identifier and replace '/' with '--', following the repository convention for Bento model tags.
- **Applies to:**
  - `examples/bentoml/import_model.py`
- **Condition:** When adding or modifying an example that derives a Bento model tag from a model identifier.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f5b6688c3490757d99662a93.md)
