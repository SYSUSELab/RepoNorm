# Rules for `examples/llamacpp_example.py`

## Rule 045 — `examples/llamacpp_example.py`

- **Rule:** Examples that constrain generation to a fixed vocabulary must define the choices as a str Enum (e.g. Armor, Weapon) and reference those enums from the Pydantic model, rather than using free-form strings.
- **Applies to:**
  - `examples/llamacpp_example.py`
- **Condition:** When editing the llamacpp example's constrained-choice fields or their enum definitions.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-4a2ecfbaea08569b1bd0d29b.md)

## Rule 151 — `examples/llamacpp_example.py`

- **Rule:**
  ```text
  The llamacpp example's end-to-end usage must wrap the Llama model with outlines.from_llamacpp, construct a Generator with a Pydantic output type, and call it with prompt, seed, and max_tokens; contributors changing the example should preserve this call signature.
  ```
- **Applies to:**
  - `examples/llamacpp_example.py`
- **Condition:** When modifying the llamacpp example's model wrapping or Generator invocation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-f099c39846025250025adffc.md)
