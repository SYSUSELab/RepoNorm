# Rules for `examples/modal_example.py`

## Rule 010 — `examples/modal_example.py`

- **Rule:** Examples that pin Outlines and its dependencies must pin outlines==1.0.0 together with compatible transformers, datasets, and accelerate versions in a Debian slim Python 3.11 image.
- **Applies to:**
  - `examples/modal_example.py`
- **Condition:** When adding or modifying an example that pins Outlines and its dependencies.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-0e952a7629c9b77438fbdff1.md)

## Rule 066 — `examples/beam-cloud/app.py`

- **Rule:**
  ```text
  Examples that load a HuggingFace causal LM through outlines.models.from_transformers must pass matching AutoModelForCausalLM and AutoTokenizer instances for the same model identifier.
  ```
- **Applies to:**
  - `examples/beam-cloud/app.py`
  - `examples/modal_example.py`
- **Condition:**
  ```text
  When adding or modifying an example that constructs an Outlines model via from_transformers.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-749f751983e6ac300b005fbe.md)
