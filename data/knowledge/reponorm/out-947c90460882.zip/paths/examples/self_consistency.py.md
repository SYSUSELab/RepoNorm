# Rules for `examples/self_consistency.py`

## Rule 148 — `examples/self_consistency.py`

- **Rule:** Examples that demonstrate self-consistency must generate multiple samples, extract the answer from each with a regex, and report the most frequent value as the consensus with its percentage.
- **Applies to:**
  - `examples/self_consistency.py`
- **Condition:** When adding or modifying an example that demonstrates self-consistency consensus.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-ed738532ca09296fb49d3d66.md)
