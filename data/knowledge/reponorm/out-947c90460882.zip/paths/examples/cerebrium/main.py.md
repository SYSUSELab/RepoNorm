# Rules for `examples/cerebrium/main.py`

## Rule 110 — `examples/bentoml/service.py`

- **Rule:**
  ```text
  Examples that constrain generation with a JSON schema must pass the schema through outlines.json_schema(...) when constructing the generator or processor, rather than embedding schema constraints in the prompt alone.
  ```
- **Applies to:**
  - `examples/bentoml/service.py`
  - `examples/cerebrium/main.py`
  - `examples/pick_odd_one_out.py`
- **Condition:** When adding or modifying an example that constrains model output to a JSON schema.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b386c81ae0bda0895ba434d7.md)

## Rule 125 — `examples/cerebrium/main.py`

- **Rule:** Examples that accept JSON Schema documents with nested $ref definitions must demonstrate that Outlines accepts such documents for structured generation, preserving support for definitions and $ref references.
- **Applies to:**
  - `examples/cerebrium/main.py`
- **Condition:** When adding or modifying an example that passes a JSON Schema document containing definitions and $ref references to Outlines.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c8af076f3bd4ab8b9038a6fe.md)
