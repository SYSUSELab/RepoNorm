# Rules for `examples/dating_profile.py`

## Rule 131 — `examples/dating_profile.py`

- **Rule:** Example schemas that model a question-answer pair must keep the question typed as the repository's QuestionChoice type and the answer as a plain string, so the example stays coupled to the shared choice type rather than introducing a parallel representation.
- **Applies to:**
  - `examples/dating_profile.py`
- **Condition:**
  ```text
  When modifying the dating_profile example's question-answer dataclass or its field types.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-d4c6ff20d48ab7e9cbc762e7.md)

## Rule 152 — `examples/dating_profile.py`

- **Rule:** Examples that define enumerated prompt choices must model them as a str-valued Enum whose members map option letters to prompt fragments, so generation can be constrained to the enumerated set.
- **Applies to:**
  - `examples/dating_profile.py`
- **Condition:** When adding or modifying an example that constrains generation to a fixed set of prompt choices.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-f0b6bef0716517f46f64b1cf.md)
