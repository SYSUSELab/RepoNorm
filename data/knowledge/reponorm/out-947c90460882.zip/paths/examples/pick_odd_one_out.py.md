# Rules for `examples/pick_odd_one_out.py`

## Rule 038 — `examples/pick_odd_one_out.py`

- **Rule:** Examples that demonstrate constrained vs unconstrained generation must use two generators over the same model: an unconstrained Generator for chain-of-thought reasoning with stop sequences, and a Generator constrained by a JsonSchema whose result field is an enum of the options.
- **Applies to:**
  - `examples/pick_odd_one_out.py`
- **Condition:** When adding or modifying an example that contrasts constrained and unconstrained generation over the same model.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-3d79fbf92e170f6334914b72.md)

## Rule 110 — `examples/bentoml/service.py`

- **Rule:**
  ```text
  Examples that constrain generation with a JSON schema must pass the schema through outlines.json_schema(...) when constructing the generator or processor, rather than embedding schema constraints in the prompt alone.
  ```
- **Applies to:**
  - `examples/bentoml/service.py`
  - `examples/cerebrium/main.py`
  - `examples/pick_odd_one_out.py`
- **Condition:** When adding or modifying an example that constrains model output to a JSON schema.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-b386c81ae0bda0895ba434d7.md)
