# Rules for `README.md`

## Rule 083 — `README.md`

- **Rule:** The project readme file is declared as README.md.
- **Applies to:**
  - `README.md`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8e6d902fc5184d02251b79f7.md)
