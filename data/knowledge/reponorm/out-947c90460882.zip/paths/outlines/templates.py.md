# Rules for `outlines/templates.py`

## Rule 041 — `outlines/templates.py`

- **Rule:** The args template filter must require a callable and raise TypeError otherwise; it returns a comma-joined string of inspect.signature parameters including annotations and defaults.
- **Applies to:**
  - `outlines/templates.py`
- **Condition:** when modifying the args template filter's callable validation or signature formatting
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-4435020abe1075a26b15de89.md)

## Rule 102 — `outlines/templates.py`

- **Rule:** When adding or modifying the Template callable, render the underlying template with the supplied keyword arguments and return the rendered result as a Python string.
- **Applies to:**
  - `outlines/templates.py`
- **Condition:**
  ```text
  when adding or changing Template.__call__ or its rendering behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-a5151f1f990e51b777a139c6.md)

## Rule 139 — `outlines/templates.py`

- **Rule:**
  ```text
  The template `name` filter requires a callable and raises TypeError otherwise; for callables lacking `__name__` it falls back to the type name, so contributors must not assume every callable has `__name__`.
  ```
- **Applies to:**
  - `outlines/templates.py`
- **Condition:**
  ```text
  When modifying the template `name` filter or relying on `__name__` of callables passed to templates.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-e0e24947b7ae9db76916b4fa.md)
