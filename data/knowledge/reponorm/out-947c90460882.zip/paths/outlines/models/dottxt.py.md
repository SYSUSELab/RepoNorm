# Rules for `outlines/models/dottxt.py`

## Rule 017 — `outlines/models/dottxt.py`

- **Rule:**
  ```text
  from_dottxt constructs a Dottxt model by forwarding client, model_name, and model_revision positionally to the Dottxt constructor, so the constructor argument order is part of the factory contract.
  ```
- **Applies to:**
  - `outlines/models/dottxt.py`
- **Condition:**
  ```text
  When modifying from_dottxt or the Dottxt constructor's parameter order.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1c5479fb8fa93bd68ef414f7.md)

## Rule 061 — `outlines/models/dottxt.py`

- **Rule:**
  ```text
  Dottxt format_input accepts only str inputs and raises TypeError for any other type, so contributors must not pass non-string model inputs to this adapter.
  ```
- **Applies to:**
  - `outlines/models/dottxt.py`
- **Condition:**
  ```text
  When modifying Dottxt format_input or adding input handling to the Dottxt adapter.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-69b0cd551945d2fb0da421ab.md)

## Rule 100 — `outlines/_version.py`

- **Rule:**
  ```text
  Coverage measurement omits the listed files and directories: outlines/_version.py, outlines/models/anthropic.py, outlines/models/dottxt.py, outlines/models/gemini.py, outlines/models/mlxlm.py, outlines/models/openai.py, outlines/models/vllm_offline.py, outlines/processors/tensor_adapters/mlx.py, and tests/*.
  ```
- **Applies to:**
  - `outlines/_version.py`
  - `outlines/models/anthropic.py`
  - `outlines/models/dottxt.py`
  - `outlines/models/gemini.py`
  - `outlines/models/mlxlm.py`
  - `outlines/models/openai.py`
  - `outlines/models/vllm_offline.py`
  - `outlines/processors/tensor_adapters/mlx.py`
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a3d4630cf0aebda7015f40de.md)
