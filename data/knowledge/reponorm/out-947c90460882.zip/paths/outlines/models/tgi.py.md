# Rules for `outlines/models/tgi.py`

## Rule 035 — `outlines/models/tgi.py`

- **Rule:**
  ```text
  `TGI.generate_stream` supports all output types except CFG when the server backend supports them, and its streaming loop is marked `pragma: no cover` so it is excluded from coverage.
  ```
- **Applies to:**
  - `outlines/models/tgi.py`
- **Condition:** When modifying TGI streaming generation or its coverage pragmas.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3c3c4351dc02fbd3665876d9.md)

## Rule 088 — `outlines/models/tgi.py`

- **Rule:**
  ```text
  When adding or modifying the TGI integration module, export AsyncTGI, TGI, and from_tgi and import python_types_to_terms, to_regex, JsonSchema, and CFG from the DSL, preserving this public integration surface.
  ```
- **Applies to:**
  - `outlines/models/tgi.py`
- **Condition:** when adding or changing the TGI module's exports or DSL imports
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-95944e7e39be94566b434309.md)

## Rule 092 — `outlines/models/openai.py`

- **Rule:**
  ```text
  Each model backend's type adapter must define format_output_type with an explicit supported-output-type boundary: unsupported output types must raise TypeError (or NotImplementedError for CFG-based structured outputs) rather than silently degrading, and supported types must be routed to the backend's native mechanism (e.g. grammar.type=json for JsonSchema, grammar.type=regex via to_regex for other terms).
  ```
- **Applies to:**
  - `outlines/models/openai.py`
  - `outlines/models/tgi.py`
- **Condition:**
  ```text
  When adding or modifying a model backend's format_output_type to accept a new output type or change how an existing output type is serialized.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-998f7439eaa78261c7606840.md)

## Rule 121 — `outlines/inputs.py`

- **Rule:** Chat message inputs must be dicts carrying 'role' and 'content' keys, where role is one of user/assistant/system and content is a string or a list containing a string plus multimodal assets; string prompts are passed through unchanged rather than being wrapped into chat messages.
- **Applies to:**
  - `outlines/inputs.py`
  - `outlines/models/tgi.py`
- **Condition:** When changing how chat messages are validated or how string prompts are converted into model inputs.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-bf8adc836ae38de3cbc3e594.md)
