# Rules for `outlines/models/tokenizer.py`

## Rule 160 — `outlines/models/tokenizer.py`

- **Rule:**
  ```text
  The tokenizer module must not require numpy at runtime; numpy imports must remain guarded under TYPE_CHECKING.
  ```
- **Applies to:**
  - `outlines/models/tokenizer.py`
- **Condition:** When adding or modifying imports in the tokenizer module.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-fe78c59445e2c0ec20572efe.md)
