# Rules for `outlines/models/mlxlm.py`

## Rule 100 — `outlines/_version.py`

- **Rule:**
  ```text
  Coverage measurement omits the listed files and directories: outlines/_version.py, outlines/models/anthropic.py, outlines/models/dottxt.py, outlines/models/gemini.py, outlines/models/mlxlm.py, outlines/models/openai.py, outlines/models/vllm_offline.py, outlines/processors/tensor_adapters/mlx.py, and tests/*.
  ```
- **Applies to:**
  - `outlines/_version.py`
  - `outlines/models/anthropic.py`
  - `outlines/models/dottxt.py`
  - `outlines/models/gemini.py`
  - `outlines/models/mlxlm.py`
  - `outlines/models/openai.py`
  - `outlines/models/vllm_offline.py`
  - `outlines/processors/tensor_adapters/mlx.py`
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a3d4630cf0aebda7015f40de.md)

## Rule 113 — `outlines/models/mlxlm.py`

- **Rule:**
  ```text
  MLX LM generate_batch always raises NotImplementedError because the mlx_lm library does not support batch inference.
  ```
- **Applies to:**
  - `outlines/models/mlxlm.py`
- **Condition:**
  ```text
  When modifying MLXLM.generate_batch or adding batch inference support to the MLX LM backend.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b5ea40cc0d4e664bdc155e0c.md)

## Rule 132 — `outlines/models/mlxlm.py`

- **Rule:**
  ```text
  MLXLM must set tensor_library_name = "mlx", matching the tensor adapter registry key required by the base Model contract for steerable models.
  ```
- **Applies to:**
  - `outlines/models/mlxlm.py`
- **Condition:**
  ```text
  when adding or modifying a model class that declares a tensor_library_name for steerable model support
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d5269976f155b843043e94b6.md)
