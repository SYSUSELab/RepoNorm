# Rules for `outlines/models/base.py`

## Rule 019 — `outlines/models/base.py`

- **Rule:**
  ```text
  AsyncModel.__call__ must construct a Generator with the model, output type, and backend, then await it, making model(prompt, Foo) equivalent to awaiting Generator(model, Foo)(prompt).
  ```
- **Applies to:**
  - `outlines/models/base.py`
- **Condition:** when modifying the async model call path or the Generator construction contract
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1fcd5b6af02be9f9e08e8f1b.md)

## Rule 067 — `outlines/models/base.py`

- **Rule:**
  ```text
  `outlines/models/base.py` is the shared base-class module for all models and model type adapters, importing `ABC`, `abstractmethod`, and async/sync iterator types; new model or adapter base classes belong here.
  ```
- **Applies to:**
  - `outlines/models/base.py`
- **Condition:** When adding or modifying shared model or model-type-adapter base classes.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-7784c72d98412a39836c7b08.md)

## Rule 086 — `outlines/models/base.py`

- **Rule:**
  ```text
  Model.__call__ must construct a Generator with the given output_type and backend and invoke it, so model(prompt, Foo) is equivalent to Generator(model, Foo)(prompt); the backend argument is only used for steerable models when output_type is provided.
  ```
- **Applies to:**
  - `outlines/models/base.py`
- **Condition:**
  ```text
  When modifying Model.__call__ or adding a new model subclass that overrides call semantics.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-920e48042b244a8fa01c6111.md)

## Rule 130 — `outlines/models/base.py`

- **Rule:**
  ```text
  The base Model ABC declares type_adapter: ModelTypeAdapter and tensor_library_name: str as class-level attributes; subclasses must define type_adapter, and steerable models must additionally define tensor_library_name.
  ```
- **Applies to:**
  - `outlines/models/base.py`
- **Condition:** When adding a new Model subclass or modifying the base Model ABC's required attributes.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d175cfdd66e6cdeea189be42.md)
