# Rules for `outlines/models/sglang.py`

## Rule 078 — `outlines/models/sglang.py`

- **Rule:**
  ```text
  `SGLang` must remain a thin wrapper around the `openai.OpenAI` client, converting user-specified input/output types into OpenAI client arguments rather than implementing its own transport.
  ```
- **Applies to:**
  - `outlines/models/sglang.py`
- **Condition:** When modifying the SGLang model wrapper's request construction or client usage.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-81baf95f5232d79cc584c49e.md)

## Rule 097 — `outlines/models/sglang.py`

- **Rule:**
  ```text
  from_sglang must dispatch on client type: openai.OpenAI yields SGLang, openai.AsyncOpenAI yields AsyncSGLang, and any other client type raises ValueError.
  ```
- **Applies to:**
  - `outlines/models/sglang.py`
- **Condition:**
  ```text
  when modifying from_sglang's client-type dispatch or adding new client types
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a009306d2a2df261614dee58.md)
