# Rules for `outlines/models/openai.py`

## Rule 092 — `outlines/models/openai.py`

- **Rule:**
  ```text
  Each model backend's type adapter must define format_output_type with an explicit supported-output-type boundary: unsupported output types must raise TypeError (or NotImplementedError for CFG-based structured outputs) rather than silently degrading, and supported types must be routed to the backend's native mechanism (e.g. grammar.type=json for JsonSchema, grammar.type=regex via to_regex for other terms).
  ```
- **Applies to:**
  - `outlines/models/openai.py`
  - `outlines/models/tgi.py`
- **Condition:**
  ```text
  When adding or modifying a model backend's format_output_type to accept a new output type or change how an existing output type is serialized.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-998f7439eaa78261c7606840.md)

## Rule 100 — `outlines/_version.py`

- **Rule:**
  ```text
  Coverage measurement omits the listed files and directories: outlines/_version.py, outlines/models/anthropic.py, outlines/models/dottxt.py, outlines/models/gemini.py, outlines/models/mlxlm.py, outlines/models/openai.py, outlines/models/vllm_offline.py, outlines/processors/tensor_adapters/mlx.py, and tests/*.
  ```
- **Applies to:**
  - `outlines/_version.py`
  - `outlines/models/anthropic.py`
  - `outlines/models/dottxt.py`
  - `outlines/models/gemini.py`
  - `outlines/models/mlxlm.py`
  - `outlines/models/openai.py`
  - `outlines/models/vllm_offline.py`
  - `outlines/processors/tensor_adapters/mlx.py`
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a3d4630cf0aebda7015f40de.md)
