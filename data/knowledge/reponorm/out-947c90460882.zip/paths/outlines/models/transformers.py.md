# Rules for `outlines/models/transformers.py`

## Rule 001 — `outlines/models/transformers.py`

- **Rule:**
  ```text
  `get_llama_tokenizer_types` must tolerate missing Llama-family tokenizer classes by substituting dummy classes on ImportError and returning the tuple, preserving compatibility across transformers versions.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:** When modifying tokenizer type resolution or upgrading the transformers dependency for Llama-family tokenizers.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-013b124a52ad34e62b452f7f.md)

## Rule 056 — `outlines/models/transformers.py`

- **Rule:**
  ```text
  TransformerTokenizer.__eq__ compares model_name and kwargs when both attributes exist, otherwise falls back to comparing tokenizer; returns NotImplemented for unrelated types.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:**
  ```text
  When modifying TransformerTokenizer.__eq__ or adding equality semantics to tokenizer wrappers.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-629ddae584e1819d8e1d9d37.md)

## Rule 080 — `outlines/models/transformers.py`

- **Rule:**
  ```text
  `TransformersMultiModalTypeAdapter` must be declared as a `ModelTypeAdapter` for the `TransformersMultiModal` model, so multimodal adapter registration must target that model.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:** When adding or modifying the multimodal transformers type adapter registration.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8a9b5314fe420c0f73d94318.md)

## Rule 117 — `outlines/models/gemini.py`

- **Rule:**
  ```text
  Model factory functions (from_llamacpp, from_gemini, from_transformers) must accept the native client/tokenizer object and return the corresponding Outlines model wrapper, preserving the public conversion entry point contract.
  ```
- **Applies to:**
  - `outlines/models/gemini.py`
  - `outlines/models/llamacpp.py`
  - `outlines/models/transformers.py`
- **Condition:** when adding or modifying a model factory conversion function that wraps a native client or tokenizer into an Outlines model
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-bb5f58827bc6ded49bf08e2a.md)

## Rule 118 — `outlines/models/transformers.py`

- **Rule:**
  ```text
  convert_token_to_string prepends a space for Llama tokenizers when the token starts with SPIECE_UNDERLINE or equals <0x20>, a hack to compensate for missing spaces in HF Llama tokenizers.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:**
  ```text
  When modifying convert_token_to_string or adding tokenizer-specific string conversion workarounds.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-bb87b1fc0ad9be832eebd69e.md)

## Rule 158 — `outlines/models/transformers.py`

- **Rule:**
  ```text
  TransformerTokenizer.decode must use tokenizer.batch_decode with skip_special_tokens=True, stripping special tokens from decoded output.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:** when modifying the Transformers tokenizer decode method or relying on raw token text in decoded output
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f9e64f06dee1c01a3996f3be.md)
