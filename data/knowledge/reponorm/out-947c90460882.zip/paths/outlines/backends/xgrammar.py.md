# Rules for `outlines/backends/xgrammar.py`

## Rule 043 — `outlines/backends/xgrammar.py`

- **Rule:**
  ```text
  XGrammarLogitsProcessor.reset() must set self.xgrammar_logits_processor to None, clearing the processor rather than reinitializing it.
  ```
- **Applies to:**
  - `outlines/backends/xgrammar.py`
- **Condition:** when modifying the reset behavior of a logits processor that holds a compiled grammar state
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-475d17dfa7265546f77ce5eb.md)
