# Rules for `outlines/types/dsl.py`

## Rule 122 — `outlines/types/dsl.py`

- **Rule:**
  ```text
  JsonSchema.from_file must read a .json file and construct a JsonSchema from the parsed schema, defining the file-based schema construction API.
  ```
- **Applies to:**
  - `outlines/types/dsl.py`
- **Condition:**
  ```text
  when modifying JsonSchema.from_file's file reading or schema construction behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c01b3120d19394ad7ada6218.md)
