# Rules for `outlines/types/utils.py`

## Rule 033 — `outlines/types/utils.py`

- **Rule:**
  ```text
  is_pydantic_model must return False for generic types with a non-None origin, and otherwise True only for classes that subclass BaseModel; the origin check exists because generic types cannot be used with issubclass on Python versions below 3.11.
  ```
- **Applies to:**
  - `outlines/types/utils.py`
- **Condition:**
  ```text
  When modifying is_pydantic_model or adding type-detection utilities that must handle generic types across Python versions.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-39bbcbcb281a8f878e7b8091.md)

## Rule 135 — `outlines/types/utils.py`

- **Rule:**
  ```text
  outlines/types/utils.py must import _TypedDictMeta from typing on Python 3.12+ and from typing_extensions otherwise, preserving this compatibility boundary when touching TypedDict handling.
  ```
- **Applies to:**
  - `outlines/types/utils.py`
- **Condition:** when modifying TypedDict handling or imports in outlines/types/utils.py
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d929f0056fed1774f43cdb85.md)
