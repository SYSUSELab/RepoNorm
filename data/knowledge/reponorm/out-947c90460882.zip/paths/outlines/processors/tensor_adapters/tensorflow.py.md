# Rules for `outlines/processors/tensor_adapters/tensorflow.py`

## Rule 036 — `outlines/processors/tensor_adapters/tensorflow.py`

- **Rule:**
  ```text
  The tensorflow tensor adapter's `to_list` must convert via `tensor.numpy().tolist()`, requiring eager tensor semantics for the tensorflow backend.
  ```
- **Applies to:**
  - `outlines/processors/tensor_adapters/tensorflow.py`
- **Condition:** When modifying tensor-to-list conversion for the tensorflow backend.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3caf1f3f8250e0c29faa13d4.md)
