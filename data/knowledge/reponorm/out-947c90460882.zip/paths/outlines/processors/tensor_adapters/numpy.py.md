# Rules for `outlines/processors/tensor_adapters/numpy.py`

## Rule 025 — `outlines/processors/tensor_adapters/numpy.py`

- **Rule:**
  ```text
  NumpyTensorAdapter must declare library_name = "numpy", the key used to register and look up the adapter in the tensor_adapters mapping consumed by BaseLogitsProcessor.__init__.
  ```
- **Applies to:**
  - `outlines/processors/tensor_adapters/numpy.py`
- **Condition:**
  ```text
  when adding or modifying a tensor adapter's library_name registration key
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2e8567480c144faac386073e.md)
