# Rules for `outlines/applications.py`

## Rule 106 — `outlines/applications.py`

- **Rule:**
  ```text
  Application.__init__ must store the template and output type and initialize generator and model to None, deferring generator/model binding to a later step.
  ```
- **Applies to:**
  - `outlines/applications.py`
- **Condition:**
  ```text
  when modifying or extending Application.__init__ or the application initialization lifecycle
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-ab31b8006a3760e9610315af.md)
