# Rules for `outlines/inputs.py`

## Rule 008 — `outlines/inputs.py`

- **Rule:**
  ```text
  Audio must be a dataclass holding an audio: Any field, documented to be passed alongside a text prompt in a list as model_input for audio-capable multimodal models.
  ```
- **Applies to:**
  - `outlines/inputs.py`
- **Condition:** when modifying the Audio dataclass or its multimodal input usage
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-0ccaf4ac8cf07fcff2e5c30c.md)

## Rule 090 — `outlines/inputs.py`

- **Rule:** Chat.extend must append a list of message dicts to self.messages, defining the mutation semantics for extending a chat conversation.
- **Applies to:**
  - `outlines/inputs.py`
- **Condition:** when modifying Chat.extend's message mutation behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-97ea33a189f84b0db1c1cdde.md)

## Rule 121 — `outlines/inputs.py`

- **Rule:** Chat message inputs must be dicts carrying 'role' and 'content' keys, where role is one of user/assistant/system and content is a string or a list containing a string plus multimodal assets; string prompts are passed through unchanged rather than being wrapped into chat messages.
- **Applies to:**
  - `outlines/inputs.py`
  - `outlines/models/tgi.py`
- **Condition:** When changing how chat messages are validated or how string prompts are converted into model inputs.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-bf8adc836ae38de3cbc3e594.md)
