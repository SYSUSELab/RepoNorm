# Rules for `environment.yml`

## Rule 047 — `environment.yml`

- **Rule:**
  ```text
  The conda environment installs the project itself in editable mode with the test extra via pip (`-e ".[test]"`).
  ```
- **Applies to:**
  - `environment.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-4af24d73349813b80a5ee846.md)

## Rule 076 — `environment.yml`

- **Rule:** The conda environment pins python==3.10.0.
- **Applies to:**
  - `environment.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7fb6a375de9ab9c4121babb4.md)
