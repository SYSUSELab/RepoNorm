# Rules for `scripts/gen_ref_pages.py`

## Rule 120 — `scripts/gen_ref_pages.py`

- **Rule:**
  ```text
  The gen-files plugin runs the script scripts/gen_ref_pages.py.
  ```
- **Applies to:**
  - `scripts/gen_ref_pages.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-bd98bfefa2b7d4b61cd07ba3.md)
