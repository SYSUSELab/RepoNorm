# Rules for `.devcontainer/devcontainer.json`

## Rule 006 — `.devcontainer/devcontainer.json`

- **Rule:** The dev container enables the conda devcontainer feature.
- **Applies to:**
  - `.devcontainer/devcontainer.json`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-0c58c4ebbf15949d2b12e3ae.md)

## Rule 023 — `.devcontainer/devcontainer.json`

- **Rule:** The dev container declares GPU host requirements as optional.
- **Applies to:**
  - `.devcontainer/devcontainer.json`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-255e39c19ebcae6f0db6fbcb.md)

## Rule 031 — `.devcontainer/devcontainer.json`

- **Rule:** The dev container enables the rust devcontainer feature.
- **Applies to:**
  - `.devcontainer/devcontainer.json`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-375e9e30eb98e17effb3e521.md)

## Rule 034 — `.devcontainer/devcontainer.json`

- **Rule:** The dev container is based on the mcr.microsoft.com/devcontainers/python:3.12 image.
- **Applies to:**
  - `.devcontainer/devcontainer.json`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-39c48f9ed29386514b40f7fa.md)

## Rule 081 — `.devcontainer/devcontainer.json`

- **Rule:** The dev container enables the nvidia-cuda devcontainer feature with installCudnn set to true.
- **Applies to:**
  - `.devcontainer/devcontainer.json`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-8b315652ab780d736f70c5e0.md)

## Rule 089 — `.devcontainer/devcontainer.json`

- **Rule:** The dev container runs with the --device=nvidia.com/gpu=all argument.
- **Applies to:**
  - `.devcontainer/devcontainer.json`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-95bd0ff7409e475a0547cb43.md)
