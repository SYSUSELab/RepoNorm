# Rules for `tests/test_utils/mock_tgi_client.py`

## Rule 062 — `tests/test_utils/mock_tgi_client.py`

- **Rule:**
  ```text
  Mock TGI client _create must hash kwargs into a request key, raise ValueError when no mock response is registered, and return an iterator when stream=True.
  ```
- **Applies to:**
  - `tests/test_utils/mock_tgi_client.py`
- **Condition:** when adding or modifying the mock TGI client's request/response matching behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-69b2bae9b5cb6d5fff16a810.md)
