# Rules for `tests/processors/test_tensor_adapters.py`

## Rule 032 — `tests/processors/test_tensor_adapters.py`

- **Rule:** Tensor adapter shape() must return a sequence whose length and entries match the tensor rank and dimensions for 1d, 2d, and 3d tensors across all supported frameworks.
- **Applies to:**
  - `tests/processors/test_tensor_adapters.py`
- **Condition:** when modifying or extending tensor adapter shape behavior or its tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-38e227f75a2e7426221dfd05.md)

## Rule 099 — `tests/processors/test_tensor_adapters.py`

- **Rule:**
  ```text
  Tensor adapter to_list must convert 1d, 2d, and 3d tensors into nested Python lists preserving each dimension's length across all supported frameworks.
  ```
- **Applies to:**
  - `tests/processors/test_tensor_adapters.py`
- **Condition:**
  ```text
  when modifying or extending tensor adapter to_list behavior or its tests
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a2fd31442487a6107c8433dd.md)
