# Rules for `tests/backends/test_backends.py`

## Rule 073 — `tests/backends/test_backends.py`

- **Rule:**
  ```text
  Tests for backend utilities must preserve the documented stable regex fixture: the regex fixture returns the literal pattern r"[0-9]{3}" used across backend tests.
  ```
- **Applies to:**
  - `tests/backends/test_backends.py`
- **Condition:** when adding or modifying backend tests that use the shared regex fixture
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-7bb3852723fec27d62f484bb.md)
