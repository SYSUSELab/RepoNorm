# Rules for `tests/backends/test_llguidance.py`

## Rule 091 — `tests/backends/test_llguidance.py`

- **Rule:**
  ```text
  The llguidance backend test fixture cfg_lark must supply a Lark grammar string using %import common.NUMBER, %import common.WS_INLINE, and %ignore WS_INLINE.
  ```
- **Applies to:**
  - `tests/backends/test_llguidance.py`
- **Condition:** when adding or modifying llguidance backend grammar fixtures
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-986209988773c71e3570f202.md)
