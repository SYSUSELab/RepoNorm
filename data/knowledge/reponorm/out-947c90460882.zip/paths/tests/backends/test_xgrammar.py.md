# Rules for `tests/backends/test_xgrammar.py`

## Rule 129 — `tests/backends/test_xgrammar.py`

- **Rule:** Tests for a backend's logits processors must assert both the processor class identity and that generated output conforms to each constraint kind (JSON schema, regex, CFG).
- **Applies to:**
  - `tests/backends/test_xgrammar.py`
- **Condition:** When adding or modifying backend logits-processor tests that cover multiple constraint kinds.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-cf5fdac21f2d235d9cf67143.md)
