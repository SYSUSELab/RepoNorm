# Rules for `tests/types/test_types_utils.py`

## Rule 051 — `tests/types/test_types_utils.py`

- **Rule:**
  ```text
  Tests that exercise the is_bool type utility must assert recognition of bool, Annotated[bool,...], and NewType over bool, while rejecting int, bool instances, Annotated[int,...], and NewType over int.
  ```
- **Applies to:**
  - `tests/types/test_types_utils.py`
- **Condition:**
  ```text
  When adding or modifying tests for the is_bool type utility.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-539b373ccd5c81ba5cf17164.md)

## Rule 057 — `tests/types/test_types_utils.py`

- **Rule:**
  ```text
  `is_callable` must return True for functions and lambdas but False for `dict`, classes, dataclasses, TypedDicts, and pydantic models, defining the callable-detection boundary used by type dispatch.
  ```
- **Applies to:**
  - `tests/types/test_types_utils.py`
- **Condition:**
  ```text
  when modifying or extending is_callable type classification or its tests
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-648c421af81b729bee026cd2.md)

## Rule 060 — `tests/types/test_types_utils.py`

- **Rule:**
  ```text
  is_datetime must return true only for datetime.datetime, and false for datetime.date, datetime.time, and a datetime instance, defining the exact type-classification boundary.
  ```
- **Applies to:**
  - `tests/types/test_types_utils.py`
- **Condition:**
  ```text
  when modifying or extending is_datetime type classification or its tests
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6932079f93de062c96c3d82c.md)

## Rule 147 — `tests/types/test_types_utils.py`

- **Rule:**
  ```text
  Tests for type utilities must preserve the documented predicate behavior: is_typing_tuple returns true for tuple[int, str] and Tuple[int, str] and false for bare tuple, empty tuple literal, and list, and fixtures must include callables lacking type annotations.
  ```
- **Applies to:**
  - `tests/types/test_types_utils.py`
- **Condition:** when adding or modifying tests for type utility predicates or their fixtures
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ed301faa013033bc971cc118.md)
