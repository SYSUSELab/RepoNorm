# Rules for `tests/types/test_json_schema_union_types.py`

## Rule 098 — `tests/types/test_json_schema_union_types.py`

- **Rule:**
  ```text
  `preprocess_schema_for_union_types` must convert type arrays into anyOf at every nesting level, including inside array items and nested object properties, and preserve the number of union members as anyOf length.
  ```
- **Applies to:**
  - `tests/types/test_json_schema_union_types.py`
- **Condition:**
  ```text
  when changing preprocess_schema_for_union_types handling of nested type arrays
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a1675ff493fd07c772330b34.md)

## Rule 115 — `tests/types/test_json_schema_union_types.py`

- **Rule:** The TestJsonSchemaUnionTypes class must group test cases for JSON schemas with union types, treating union-type schema handling as a distinct tested concern.
- **Applies to:**
  - `tests/types/test_json_schema_union_types.py`
- **Condition:** When adding or modifying tests for JSON schema union-type handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b7f2a2b27e480e96fbedb873.md)
