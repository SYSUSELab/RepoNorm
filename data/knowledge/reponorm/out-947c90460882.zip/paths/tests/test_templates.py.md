# Rules for `tests/test_templates.py`

## Rule 071 — `tests/test_templates.py`

- **Rule:**
  ```text
  Template tests must define custom_filter as a plain callable taking a string and returning its uppercase form, establishing that custom filters are plain callables.
  ```
- **Applies to:**
  - `tests/test_templates.py`
- **Condition:** When modifying or adding template tests that define custom filters.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-7ae3b9c256b5d2c6019efbdd.md)
