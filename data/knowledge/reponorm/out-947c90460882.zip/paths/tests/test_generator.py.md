# Rules for `tests/test_generator.py`

## Rule 039 — `tests/test_generator.py`

- **Rule:**
  ```text
  The generator test module must build MockAsyncOpenAIClient/MockOpenAIClient from tests.test_utils.mock_openai_client and register paired mock responses (non-streaming and streaming with stream: True) keyed by request payload including extra_body.guided_regex, to test black-box generators without network calls.
  ```
- **Applies to:**
  - `tests/test_generator.py`
- **Condition:** When modifying or adding generator tests that use mock OpenAI clients.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-3f0b4fe8539d7ddf0ef15fbe.md)
