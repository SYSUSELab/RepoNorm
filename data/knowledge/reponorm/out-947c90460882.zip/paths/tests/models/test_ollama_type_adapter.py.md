# Rules for `tests/models/test_ollama_type_adapter.py`

## Rule 003 — `tests/models/test_ollama_type_adapter.py`

- **Rule:**
  ```text
  The Ollama type adapter's format_input must convert a plain text prompt into a single-element list containing a user-role message dict with the text as content.
  ```
- **Applies to:**
  - `tests/models/test_ollama_type_adapter.py`
- **Condition:**
  ```text
  when modifying or extending Ollama type adapter format_input or its tests
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-063d5804c48254a23951bd39.md)

## Rule 004 — `tests/models/test_ollama_type_adapter.py`

- **Rule:**
  ```text
  The Ollama type adapter must format a genson SchemaBuilder with mixed integer/string values into a JSON schema whose type is ["integer", "string"] and whose required list is ["hi"].
  ```
- **Applies to:**
  - `tests/models/test_ollama_type_adapter.py`
- **Condition:** when changing Ollama type adapter schema formatting for genson SchemaBuilder inputs
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-070f7d713939571af3173289.md)

## Rule 046 — `tests/models/test_ollama_type_adapter.py`

- **Rule:**
  ```text
  Type adapter tests must assert that format_output_type passes the provided schema through unchanged for dataclass output types.
  ```
- **Applies to:**
  - `tests/models/test_ollama_type_adapter.py`
- **Condition:** When adding or modifying type adapter tests for dataclass output types.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4ae00eeab0740c66ee5aaf9f.md)

## Rule 150 — `tests/models/test_ollama_type_adapter.py`

- **Rule:**
  ```text
  The Ollama type adapter's format_output_type must round-trip a JSON schema string back to the original schema object, defining the adapter's schema normalization contract.
  ```
- **Applies to:**
  - `tests/models/test_ollama_type_adapter.py`
- **Condition:**
  ```text
  when modifying or extending Ollama type adapter format_output_type or its tests
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ee5e08cd4df3004000fa4f97.md)
