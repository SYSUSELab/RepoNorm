# Rules for `tests/models/test_anthropic.py`

## Rule 027 — `tests/models/test_anthropic.py`

- **Rule:**
  ```text
  Tests for model backends must preserve the documented client initialization contract: from_anthropic accepts an optional model name that sets model.model_name when provided and leaves it None when omitted, while model.client is always the passed client.
  ```
- **Applies to:**
  - `tests/models/test_anthropic.py`
- **Condition:** when adding or modifying tests for model backend client initialization
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-32f515af4f3c04ffb246d16b.md)

## Rule 116 — `tests/models/test_anthropic.py`

- **Rule:** The Anthropic wrong-output-type test asserts that model.generate with a Foo(1) output type raises NotImplementedError matching 'is not available', documenting rejection of unsupported output types.
- **Applies to:**
  - `tests/models/test_anthropic.py`
- **Condition:** when modifying or extending Anthropic model.generate output type handling or its tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b890b378ffd1c2e81f8eace3.md)
