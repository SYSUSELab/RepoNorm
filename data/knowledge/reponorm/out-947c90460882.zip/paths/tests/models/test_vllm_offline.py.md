# Rules for `tests/models/test_vllm_offline.py`

## Rule 096 — `tests/models/test_vllm_offline.py`

- **Rule:** Tests that exercise the offline vLLM model's generate must assert the return type (plain string for a simple prompt) as the basic generation contract.
- **Applies to:**
  - `tests/models/test_vllm_offline.py`
- **Condition:** When adding or modifying tests for the offline vLLM model's generate method.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9f65684e0b8aeea88b00e0b3.md)

## Rule 103 — `tests/models/test_vllm_offline.py`

- **Rule:** Passing an unknown inference keyword to the vLLM model must raise TypeError, enforcing strict inference-kwarg validation.
- **Applies to:**
  - `tests/models/test_vllm_offline.py`
- **Condition:** when changing vLLM model inference-kwarg handling or adding new accepted keywords
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a5583452c1b48705dcbf0585.md)
