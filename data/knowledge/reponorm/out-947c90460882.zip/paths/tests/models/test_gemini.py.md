# Rules for `tests/models/test_gemini.py`

## Rule 063 — `tests/models/test_gemini.py`

- **Rule:** Tests for dataclass-typed generation must assert that model.generate returns a str whose JSON content contains the expected field.
- **Applies to:**
  - `tests/models/test_gemini.py`
- **Condition:** when adding or modifying tests for dataclass-typed generation output
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6beaf1eb3722dd8a0c09714c.md)

## Rule 126 — `tests/models/test_gemini.py`

- **Rule:** Tests for choice-constrained generation must assert that generating with a list of choices returns a string equal to one of the choice values, and that list choices are intentionally unsupported (xfail) where semantically incorrect.
- **Applies to:**
  - `tests/models/test_gemini.py`
- **Condition:** when adding or modifying tests for choice-constrained generation with list choices
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ca456058eb760cdef88a2022.md)

## Rule 141 — `tests/models/test_gemini.py`

- **Rule:**
  ```text
  Tests that exercise Gemini list-of-pydantic generation must be marked @pytest.mark.api_call and assert the returned JSON list's first element is a dict containing the expected key.
  ```
- **Applies to:**
  - `tests/models/test_gemini.py`
- **Condition:** When adding or modifying Gemini tests that exercise list-of-pydantic generation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e2d46cc495155d08345577c1.md)

## Rule 156 — `tests/models/test_gemini.py`

- **Rule:**
  ```text
  Tests that exercise a backend's choice-constrained generation must be marked with @pytest.mark.api_call and assert the returned value is one of the provided choices.
  ```
- **Applies to:**
  - `tests/models/test_gemini.py`
- **Condition:** when adding or modifying tests that make real API calls for choice-constrained generation
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f6055ca30dfb0cb44d987854.md)
