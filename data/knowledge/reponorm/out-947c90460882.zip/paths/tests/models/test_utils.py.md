# Rules for `tests/models/test_utils.py`

## Rule 075 — `tests/models/test_utils.py`

- **Rule:**
  ```text
  `set_additional_properties_false_json_schema` must add additionalProperties: False when absent, leave it unchanged when already False, and leave it unchanged when True, so the function only sets the flag when missing.
  ```
- **Applies to:**
  - `tests/models/test_utils.py`
- **Condition:**
  ```text
  when changing set_additional_properties_false_json_schema behavior for present or absent additionalProperties
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-7fb352457c2f4ee9eb43ad77.md)
