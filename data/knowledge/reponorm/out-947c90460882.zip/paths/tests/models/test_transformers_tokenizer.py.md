# Rules for `tests/models/test_transformers_tokenizer.py`

## Rule 085 — `tests/models/test_transformers_tokenizer.py`

- **Rule:** Tests for tokenizer wrappers must assert hash/equality semantics: hash returns an int, equivalent tokenizers hash equal, and tokenizers with different configurations hash differently.
- **Applies to:**
  - `tests/models/test_transformers_tokenizer.py`
- **Condition:** when adding or modifying tests for tokenizer wrapper hash or equality behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-90ee256ccbc1f923cdaf85e9.md)
