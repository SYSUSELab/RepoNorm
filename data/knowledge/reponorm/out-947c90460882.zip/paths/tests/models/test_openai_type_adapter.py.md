# Rules for `tests/models/test_openai_type_adapter.py`

## Rule 119 — `tests/models/test_openai_type_adapter.py`

- **Rule:**
  ```text
  The OpenAI adapter must reject str, int, Literal[1, 2], list[Foo], regex, and CFG output types with specific TypeError messages, documenting the set of unsupported output types for the OpenAI backend.
  ```
- **Applies to:**
  - `tests/models/test_openai_type_adapter.py`
- **Condition:** when changing OpenAI type adapter output-type validation or its unsupported-type error messages
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-bcbe5961c7cd8886891c70b0.md)

## Rule 124 — `tests/models/test_openai_type_adapter.py`

- **Rule:**
  ```text
  OpenAI type adapter JSON mode must map dict output types to the request payload {"response_format": {"type": "json_object"}}.
  ```
- **Applies to:**
  - `tests/models/test_openai_type_adapter.py`
- **Condition:** when changing how the OpenAI type adapter maps output types to request payloads
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c3e51ef54833f0f2e73d45d9.md)
