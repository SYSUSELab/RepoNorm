# Rules for `tests/models/test_sglang_type_adapter.py`

## Rule 048 — `tests/models/test_sglang_type_adapter.py`

- **Rule:**
  ```text
  The SGLang type adapter's format_input for a plain string prompt must produce a single user-role message with the string as content, establishing the minimal text-input normalization contract.
  ```
- **Applies to:**
  - `tests/models/test_sglang_type_adapter.py`
- **Condition:**
  ```text
  when changing SGLang type adapter format_input handling of plain string prompts
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4ba42f8bb0eda1645af9a842.md)

## Rule 107 — `tests/models/test_sglang_type_adapter.py`

- **Rule:** The SGLang type adapter image fixture must build a 1x1 white RGB PNG in memory via BytesIO and reopen it.
- **Applies to:**
  - `tests/models/test_sglang_type_adapter.py`
- **Condition:** when adding or modifying image-input tests for the SGLang type adapter
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-af4203b4357190ce95210997.md)
