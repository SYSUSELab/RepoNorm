# Rules for `tests/models/test_openai.py`

## Rule 044 — `tests/models/test_openai.py`

- **Rule:**
  ```text
  Tests for model backends must preserve the documented multi-sample generation contract: OpenAI generate with n=2 returns a list of length 2 containing two strings, and such tests must carry the api_call marker.
  ```
- **Applies to:**
  - `tests/models/test_openai.py`
- **Condition:** when adding or modifying tests for multi-sample generation in a model backend
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4987ba5f682984de0d82bcb5.md)

## Rule 123 — `tests/models/test_openai.py`

- **Rule:** Tests that exercise a model backend requiring an API key must use a session-scoped fixture that constructs the client once and shares it across the session.
- **Applies to:**
  - `tests/models/test_openai.py`
- **Condition:** When adding or modifying a model fixture for a backend that requires an API key.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c02c37d9a9aa9c8163f15f2b.md)

## Rule 161 — `tests/models/test_openai.py`

- **Rule:** OpenAI simple pydantic generation must return a string whose JSON parse contains the model's field name, verifying structured output for pydantic types.
- **Applies to:**
  - `tests/models/test_openai.py`
- **Condition:** when changing OpenAI pydantic structured-output handling
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ff0a2747724292588d3ce367.md)
