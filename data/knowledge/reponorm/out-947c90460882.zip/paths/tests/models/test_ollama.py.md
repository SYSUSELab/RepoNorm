# Rules for `tests/models/test_ollama.py`

## Rule 101 — `tests/models/test_ollama.py`

- **Rule:** The Ollama model's stream method must return a generator whose first yielded item is a str.
- **Applies to:**
  - `tests/models/test_ollama.py`
- **Condition:** when changing the Ollama model's stream method or its yielded item types
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a44c653fb75d49a984812862.md)
