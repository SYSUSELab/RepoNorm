# Rules for `tests/models/test_gemini_type_adapter.py`

## Rule 065 — `tests/models/test_gemini_type_adapter.py`

- **Rule:**
  ```text
  Tests that exercise a backend's structured-output type adapter must assert the exact payload shape (e.g. response_mime_type and response_schema) returned by format_output_type for the given output type.
  ```
- **Applies to:**
  - `tests/models/test_gemini_type_adapter.py`
- **Condition:**
  ```text
  when adding or modifying tests for a backend type adapter's format_output_type behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-74893380f434f86c1a3de69e.md)

## Rule 068 — `tests/models/test_gemini_type_adapter.py`

- **Rule:**
  ```text
  Gemini type adapter format_input must map Chat roles to Gemini contents roles, translating 'assistant' to 'model' and embedding Image inputs as inline_data with mime_type and image_str data.
  ```
- **Applies to:**
  - `tests/models/test_gemini_type_adapter.py`
- **Condition:**
  ```text
  when changing Gemini type adapter format_input role mapping or image embedding
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-77f9a7ddafffa9d3dbd90607.md)

## Rule 074 — `tests/models/test_gemini_type_adapter.py`

- **Rule:**
  ```text
  Gemini type adapter's format_output_type for a TypedDict must return a dict with response_mime_type 'application/json' and response_schema set to the type itself, defining the Gemini structured-output mapping.
  ```
- **Applies to:**
  - `tests/models/test_gemini_type_adapter.py`
- **Condition:**
  ```text
  when modifying or extending Gemini type adapter format_output_type or its tests
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-7ddcaf5346642f48d9b752fb.md)

## Rule 154 — `tests/models/test_gemini_type_adapter.py`

- **Rule:**
  ```text
  The Gemini type adapter test module must import TypedDict from typing on Python >= 3.12 and from typing_extensions otherwise, establishing a version-conditional import convention.
  ```
- **Applies to:**
  - `tests/models/test_gemini_type_adapter.py`
- **Condition:** when adding TypedDict imports to the Gemini type adapter test module
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f2f8cd5c857142dfb2d97b28.md)
