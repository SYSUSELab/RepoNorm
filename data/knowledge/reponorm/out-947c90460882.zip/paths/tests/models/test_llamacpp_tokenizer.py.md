# Rules for `tests/models/test_llamacpp_tokenizer.py`

## Rule 053 — `tests/models/test_llamacpp_tokenizer.py`

- **Rule:** Tests for tokenizer fixtures must define a fixture that constructs the tokenizer from a no-HF-tokenizer model fixture to exercise the no-HF-tokenizer code path.
- **Applies to:**
  - `tests/models/test_llamacpp_tokenizer.py`
- **Condition:** when adding or modifying tokenizer fixtures that need to exercise the no-HF-tokenizer code path
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-59cabc7698885cb7d1ef9eb5.md)

## Rule 104 — `tests/models/test_llamacpp_tokenizer.py`

- **Rule:**
  ```text
  Tests for model backends must preserve the documented external model pinning: the different_model fixture loads TheBloke/phi-2-GGUF phi-2.Q4_K_M.gguf via llama_cpp.Llama.from_pretrained for tokenizer tests.
  ```
- **Applies to:**
  - `tests/models/test_llamacpp_tokenizer.py`
- **Condition:** when adding or modifying tests for tokenizer behavior that require an external model fixture
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a8a2f3d3162b80ef0d3a56ec.md)
