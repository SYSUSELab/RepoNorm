# Rules for `tests/models/test_vllm.py`

## Rule 005 — `tests/models/test_vllm.py`

- **Rule:** The sync vLLM model's n sampling parameter must return a list of exactly n string samples.
- **Applies to:**
  - `tests/models/test_vllm.py`
- **Condition:** when changing sync vLLM sampling or its n-parameter handling
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0a6d67ce24f5ccf7d7a5b5d2.md)

## Rule 013 — `tests/models/test_vllm.py`

- **Rule:**
  ```text
  `test_vllm_sync_cfg` must assert that generating with CFG(YES_NO_GRAMMAR) yields a string restricted to ["yes", "no"], verifying CFG-constrained decoding on the vLLM backend.
  ```
- **Applies to:**
  - `tests/models/test_vllm.py`
- **Condition:** when changing the vLLM CFG-constrained decoding test
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1604e60297bcb27994ff5c8f.md)
