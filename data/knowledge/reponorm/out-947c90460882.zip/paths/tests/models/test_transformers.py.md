# Rules for `tests/models/test_transformers.py`

## Rule 030 — `tests/models/test_transformers.py`

- **Rule:**
  ```text
  Tests that verify a model wrapper's tensor backend must assert the concrete adapter types and tensor_library_name (e.g. 'jax' for Flax models).
  ```
- **Applies to:**
  - `tests/models/test_transformers.py`
- **Condition:**
  ```text
  When adding or modifying tests that instantiate a model via from_transformers and verify its backend.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-35e8dc270733195de6a8c541.md)

## Rule 054 — `tests/models/test_transformers.py`

- **Rule:** Tests for model instantiation must assert that invalid output types (e.g. plain Python types like int) raise ValueError at instantiation time.
- **Applies to:**
  - `tests/models/test_transformers.py`
- **Condition:** when adding or modifying tests for model instantiation with invalid output types
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5ca6f58ddf9285485ce8a9b2.md)

## Rule 108 — `tests/models/test_transformers.py`

- **Rule:**
  ```text
  The transformers multiple-samples test must assert that a single call returns a string, while passing num_return_sequences=2 with do_sample=True returns a list of length 2, documenting the sampling-dependent return shape.
  ```
- **Applies to:**
  - `tests/models/test_transformers.py`
- **Condition:** when changing the transformers multiple-samples test or its sampling-dependent return-shape assertions
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b1987e14e4cc90a8a466a3ba.md)
