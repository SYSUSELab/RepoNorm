# Rules for `tests/models/test_mlxlm.py`

## Rule 022 — `tests/models/test_mlxlm.py`

- **Rule:**
  ```text
  MLX tests must be gated by pytest.mark.skipif(not HAS_MLX, reason='MLX tests require Apple Silicon') and choice tests must assert the model output is one of the allowed choices.
  ```
- **Applies to:**
  - `tests/models/test_mlxlm.py`
- **Condition:** when adding or modifying MLX model tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-226612617b6b5cc1a8c6007f.md)

## Rule 072 — `tests/models/test_mlxlm.py`

- **Rule:** MLXLM model calls must reject unknown inference keyword arguments by raising TypeError, so passing an unsupported kwarg such as foo='bar' is an error rather than being silently ignored.
- **Applies to:**
  - `tests/models/test_mlxlm.py`
- **Condition:** when changing MLXLM model call handling of inference keyword arguments
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-7b2007fc9cc946dc827c1f60.md)

## Rule 095 — `tests/models/test_mlxlm.py`

- **Rule:** The MLX model wrapper's generate must return a str, establishing the basic return-type contract for the MLX model wrapper.
- **Applies to:**
  - `tests/models/test_mlxlm.py`
- **Condition:** when changing the MLX model wrapper generate return type
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9f1c7008df65e8433c7317b1.md)
