# Rules for `tests/models/test_sglang.py`

## Rule 029 — `tests/models/test_sglang.py`

- **Rule:**
  ```text
  Tests for backend selection must use the SGLANG_SERVER_URL environment variable to choose between a real server and a mock client, warning and defaulting to the mock client when unset, and defaulting the model name via SGLANG_MODEL_NAME.
  ```
- **Applies to:**
  - `tests/models/test_sglang.py`
- **Condition:** when adding or modifying tests that need to select between a real SGLang server and a mock client
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3464fe52e7de5195a6e43c40.md)

## Rule 109 — `tests/models/test_sglang.py`

- **Rule:** Tests that exercise a real SGLang server must select the llguidance grammar backend (--grammar-backend llguidance); the outlines backend cannot handle EBNF grammars and the xgrammar backend is slow and buggy.
- **Applies to:**
  - `tests/models/test_sglang.py`
- **Condition:** when adding or modifying SGLang tests that run against a live SGLang server
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b38295464265a57a00785c30.md)
