# Rules for `tests/models/test_tokenizer.py`

## Rule 082 — `tests/models/test_tokenizer.py`

- **Rule:** The base Tokenizer class is abstract and must not be directly instantiable; instantiating Tokenizer() must raise TypeError matching "instantiate abstract".
- **Applies to:**
  - `tests/models/test_tokenizer.py`
- **Condition:** when modifying the base Tokenizer class or its abstract-method declarations
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8cc94982c99b94ee76bf3720.md)
