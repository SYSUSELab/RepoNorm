# Rules for `SUMMARY.md`

## Rule 142 — `SUMMARY.md`

- **Rule:** The literate-nav plugin uses SUMMARY.md as its navigation file.
- **Applies to:**
  - `SUMMARY.md`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e4d6c445cb6d1035add6bc66.md)
