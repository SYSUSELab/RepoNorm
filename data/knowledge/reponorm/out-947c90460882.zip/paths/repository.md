# Rules for `repository root`

## Rule 002 — `**`

- **Rule:** For all files, charset is utf-8.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-03c96832a1aba6566d6dd59b.md)

## Rule 007 — `**/*.py`

- **Rule:** mypy enables the incomplete feature "Unpack".
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0c6643355add2dda0a1e617b.md)

## Rule 012 — `**/*.yaml`

- **Rule:** For YAML files, indent size is 2.
- **Applies to:**
  - `**/*.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-157977bc67a4b6df2f2f61b4.md)

## Rule 014 — `**`

- **Rule:** For all files, trailing whitespace is trimmed.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-19a630f6deb6dd56c8d1692d.md)

## Rule 020 — `**/*.py`

- **Rule:** Pytest treats warnings as errors by default (filterwarnings includes "error"), except for the explicitly ignored warning categories.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-218eda82d8f12d1ecf586b5f.md)

## Rule 064 — `**`

- **Rule:** For all files, a final newline is inserted.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-734fbaef6626b932be86d820.md)

## Rule 084 — `**/*.py`

- **Rule:** Flake8 ignores error codes E203, E231, E501, E741, W503, W504, C901, and E731.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8f57d3e8c4f7044df40cb759.md)

## Rule 087 — `**`

- **Rule:** For all files, line endings use LF.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-942f40350ad8cdf0581148fb.md)

## Rule 093 — `**/*.py`

- **Rule:** Coverage is collected with branch coverage enabled.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9c65cf00dd0a411094570a2a.md)

## Rule 094 — `**/*.py`

- **Rule:**
  ```text
  The project declares a supported Python version range of >=3.9,<3.13.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9d2bac2c0121dbd4480af549.md)

## Rule 111 — `**/__init__.py`

- **Rule:**
  ```text
  Flake8 ignores F401 and F403 in __init__.py files.
  ```
- **Applies to:**
  - `**/__init__.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b3c1f3cfe60f36feaccd3054.md)

## Rule 134 — `**`

- **Rule:** EditorConfig is rooted at this file (root = true), so this file is the top-most EditorConfig file.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d91b8e9a7a01b5241969d7fd.md)

## Rule 143 — `**`

- **Rule:**
  ```text
  The tests job runs pytest under coverage with branch coverage and parallel mode, excluding tests marked api_call.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e595797e4dfa08412030d619.md)

## Rule 157 — `**/*.py`

- **Rule:** Flake8 enforces a maximum line length of 88 characters.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f6b6436362339df387eae03e.md)
