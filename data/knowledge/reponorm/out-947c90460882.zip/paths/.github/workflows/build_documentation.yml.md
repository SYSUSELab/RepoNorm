# Rules for `.github/workflows/build_documentation.yml`

## Rule 145 — `.github/workflows/build_documentation.yml`

- **Rule:** The documentation build workflow sets up Python version 3.10 via actions/setup-python.
- **Applies to:**
  - `.github/workflows/build_documentation.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-eab19b4a6b6f7d4638a6119e.md)
