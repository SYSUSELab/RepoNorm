# Rules for `.github/workflows/asv_benchmark_pr.yml`

## Rule 024 — `.github/workflows/asv_benchmark_pr.yml`

- **Rule:** The workflow runs asv compare with --factor=1.1 --no-stats --split upstream/main HEAD and fails the step if the output contains 'Benchmarks that have got worse'.
- **Applies to:**
  - `.github/workflows/asv_benchmark_pr.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-28e64d1c488af19b18a89eae.md)

## Rule 070 — `.github/workflows/asv_benchmark_pr.yml`

- **Rule:** The workflow runs asv continuous comparing upstream/main to HEAD with --no-stats --interleave-rounds -a repeat=3, tolerating errors.
- **Applies to:**
  - `.github/workflows/asv_benchmark_pr.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-7a78fa96a9339420d1eba6cf.md)

## Rule 077 — `.github/workflows/asv_benchmark_pr.yml`

- **Rule:** The workflow installs asv, virtualenv, and lf-asv-formatter as dependencies.
- **Applies to:**
  - `.github/workflows/asv_benchmark_pr.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-81b03cd8051cea8dc1d3cb33.md)
