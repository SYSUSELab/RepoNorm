# Rules for `.github/workflows/tests_nightly.yml`

## Rule 058 — `.github/workflows/tests_nightly.yml`

- **Rule:** The workflow installs Ollama and pulls the tinyllama model.
- **Applies to:**
  - `.github/workflows/tests_nightly.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-657003d7e793ef8852ab6337.md)

## Rule 159 — `.github/workflows/tests_nightly.yml`

- **Rule:** The test environment is set up by upgrading pip, installing uv, creating a uv venv, and installing the package editable with the test extra.
- **Applies to:**
  - `.github/workflows/tests_nightly.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-faf4114f05545a2094d54087.md)
