# Rules for `.github/workflows/publish_documentation.yml`

## Rule 011 — `.github/workflows/publish_documentation.yml`

- **Rule:** The workflow checks out the repository with fetch-depth 0 and sets up Python version 3.x.
- **Applies to:**
  - `.github/workflows/publish_documentation.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1522a03ff5493dd155bf9837.md)

## Rule 016 — `.github/workflows/publish_documentation.yml`

- **Rule:** When the event is a release, the workflow deploys the tag as the latest alias and sets latest as the default version using mike.
- **Applies to:**
  - `.github/workflows/publish_documentation.yml`
- **Condition:**
  ```text
  workflow predicate: github.event_name == 'release'
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1ace280d84471390aacdaf90.md)

## Rule 037 — `.github/workflows/publish_documentation.yml`

- **Rule:** The workflow installs documentation dependencies from requirements-doc.txt and builds the docs with mkdocs build.
- **Applies to:**
  - `.github/workflows/publish_documentation.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3d162945b42cbf7939a5dc92.md)

## Rule 153 — `.github/workflows/publish_documentation.yml`

- **Rule:** When the event is a push, the workflow deploys the branch as the unstable alias using mike.
- **Applies to:**
  - `.github/workflows/publish_documentation.yml`
- **Condition:**
  ```text
  workflow predicate: github.event_name == 'push'
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f2080984b9d4d39c192bfb29.md)
