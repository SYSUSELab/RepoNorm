# Rule details

- **Rule:** mypy enables the incomplete feature "Unpack".
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
enable_incomplete_feature = ["Unpack"]

```

- **Sources:**
  - `pyproject.toml:128`
