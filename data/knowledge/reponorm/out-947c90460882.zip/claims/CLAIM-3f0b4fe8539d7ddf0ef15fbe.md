# Rule details

- **Rule:**
  ```text
  The generator test module must build MockAsyncOpenAIClient/MockOpenAIClient from tests.test_utils.mock_openai_client and register paired mock responses (non-streaming and streaming with stream: True) keyed by request payload including extra_body.guided_regex, to test black-box generators without network calls.
  ```
- **Applies to:**
  - `tests/test_generator.py`
- **Condition:** When modifying or adding generator tests that use mock OpenAI clients.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
tests/test_generator.py imports MockAsyncOpenAIClient/MockOpenAIClient from tests.test_utils.mock_openai_client and registers paired non-streaming and streaming (stream: True) mock responses keyed by request payload including extra_body.guided_regex.
```

- **Sources:**
  - `tests/test_generator.py`
