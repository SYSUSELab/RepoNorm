# Rule details

- **Rule:**
  ```text
  Gemini type adapter format_input must map Chat roles to Gemini contents roles, translating 'assistant' to 'model' and embedding Image inputs as inline_data with mime_type and image_str data.
  ```
- **Applies to:**
  - `tests/models/test_gemini_type_adapter.py`
- **Condition:**
  ```text
  when changing Gemini type adapter format_input role mapping or image embedding
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The file asserts Gemini format_input role mapping ('assistant' to 'model') and Image embedding as inline_data with mime_type and image_str.
```

- **Sources:**
  - `tests/models/test_gemini_type_adapter.py`
