# Rule details

- **Rule:**
  ```text
  The tensorflow tensor adapter's `to_list` must convert via `tensor.numpy().tolist()`, requiring eager tensor semantics for the tensorflow backend.
  ```
- **Applies to:**
  - `outlines/processors/tensor_adapters/tensorflow.py`
- **Condition:** When modifying tensor-to-list conversion for the tensorflow backend.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
TensorFlowTensorAdapter.to_list converts via tensor.numpy().tolist(), matching the required eager tensor conversion.
```

- **Sources:**
  - `outlines/processors/tensor_adapters/tensorflow.py:23-24`
