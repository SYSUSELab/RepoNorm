# Rule details

- **Rule:**
  ```text
  Gemini.generate must format input and output type through the type adapter, call client.models.generate_content with model name defaulting to self.model_name, and merge generation_config with inference kwargs.
  ```
- **Applies to:**
  - `outlines/models/gemini.py`
- **Condition:**
  ```text
  when modifying Gemini.generate's request construction or generation_config merging
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
Gemini.generate formats input and output type through the type adapter, calls client.models.generate_content with model defaulting to self.model_name, and merges generation_config with inference kwargs.
```

- **Sources:**
  - `outlines/models/gemini.py:283-317`
