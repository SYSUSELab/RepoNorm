# Rule details

- **Rule:**
  ```text
  Serverless examples must load the model once in the endpoint's on_start hook and retrieve it via context.on_start_value, constructing the Generator per request rather than reloading the model on each invocation.
  ```
- **Applies to:**
  - `examples/beam-cloud/app.py`
- **Condition:** When modifying the Beam Cloud example's model loading or request handler.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The Beam Cloud example defines load_models as the endpoint's on_start hook and the handler reads context.on_start_value to reuse the cached model, constructing the Generator per request rather than reloading.
```

- **Sources:**
  - `examples/beam-cloud/app.py`
