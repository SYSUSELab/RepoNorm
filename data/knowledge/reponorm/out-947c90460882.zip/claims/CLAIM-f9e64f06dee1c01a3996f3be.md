# Rule details

- **Rule:**
  ```text
  TransformerTokenizer.decode must use tokenizer.batch_decode with skip_special_tokens=True, stripping special tokens from decoded output.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:** when modifying the Transformers tokenizer decode method or relying on raw token text in decoded output
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
TransformerTokenizer.decode calls batch_decode with skip_special_tokens=True, stripping special tokens as required.
```

- **Sources:**
  - `outlines/models/transformers.py:96-98`
