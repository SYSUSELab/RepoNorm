# Rule details

- **Rule:** Tests for model instantiation must assert that invalid output types (e.g. plain Python types like int) raise ValueError at instantiation time.
- **Applies to:**
  - `tests/models/test_transformers.py`
- **Condition:** when adding or modifying tests for model instantiation with invalid output types
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_transformers_instantiate_invalid wraps from_transformers with an invalid output type (int) in pytest.raises(ValueError), asserting the instantiation-time rejection.
```

- **Sources:**
  - `tests/models/test_transformers.py`
