# Rule details

- **Rule:** Tests for tokenizer wrappers must assert hash/equality semantics: hash returns an int, equivalent tokenizers hash equal, and tokenizers with different configurations hash differently.
- **Applies to:**
  - `tests/models/test_transformers_tokenizer.py`
- **Condition:** when adding or modifying tests for tokenizer wrapper hash or equality behavior
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The test file asserts hash returns an int, equivalent tokenizers hash equal, and differently configured tokenizers hash differently, conforming to the tokenizer wrapper hash/equality contract.
```

- **Sources:**
  - `tests/models/test_transformers_tokenizer.py`
