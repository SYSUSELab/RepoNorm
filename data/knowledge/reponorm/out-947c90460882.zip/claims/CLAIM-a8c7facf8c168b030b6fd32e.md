# Rule details

- **Rule:**
  ```text
  setuptools_scm writes the generated version file to outlines/_version.py.
  ```
- **Applies to:**
  - `outlines/_version.py`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
write_to = "outlines/_version.py"

```

- **Sources:**
  - `pyproject.toml:111`
