# Rule details

- **Rule:** Tests for dataclass-typed generation must assert that model.generate returns a str whose JSON content contains the expected field.
- **Applies to:**
  - `tests/models/test_gemini.py`
- **Condition:** when adding or modifying tests for dataclass-typed generation output
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The file includes test_gemini_simple_dataclass, which generates with a dataclass type and asserts the result is a str whose json.loads content contains the expected field 'bar', matching the dataclass-output rule.
```

- **Sources:**
  - `tests/models/test_gemini.py`
