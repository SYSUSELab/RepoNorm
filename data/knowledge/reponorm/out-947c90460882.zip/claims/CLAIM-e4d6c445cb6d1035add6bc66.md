# Rule details

- **Rule:** The literate-nav plugin uses SUMMARY.md as its navigation file.
- **Applies to:**
  - `SUMMARY.md`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
    - literate-nav:
        nav_file: SUMMARY.md

```

- **Sources:**
  - `mkdocs.yml:113-114`
