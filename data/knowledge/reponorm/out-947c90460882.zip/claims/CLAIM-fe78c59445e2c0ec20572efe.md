# Rule details

- **Rule:**
  ```text
  The tokenizer module must not require numpy at runtime; numpy imports must remain guarded under TYPE_CHECKING.
  ```
- **Applies to:**
  - `outlines/models/tokenizer.py`
- **Condition:** When adding or modifying imports in the tokenizer module.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The tokenizer module imports numpy only inside a TYPE_CHECKING block, so numpy is not required at runtime.
```

- **Sources:**
  - `outlines/models/tokenizer.py`
