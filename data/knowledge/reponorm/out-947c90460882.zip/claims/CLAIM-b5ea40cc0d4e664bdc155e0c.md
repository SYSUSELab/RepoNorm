# Rule details

- **Rule:**
  ```text
  MLX LM generate_batch always raises NotImplementedError because the mlx_lm library does not support batch inference.
  ```
- **Applies to:**
  - `outlines/models/mlxlm.py`
- **Condition:**
  ```text
  When modifying MLXLM.generate_batch or adding batch inference support to the MLX LM backend.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
MLXLM.generate_batch unconditionally raises NotImplementedError stating that mlx_lm does not support batch inference.
```

- **Sources:**
  - `outlines/models/mlxlm.py:131-139`
