# Rule details

- **Rule:**
  ```text
  The BentoML import_model example must load tokenizer and model from MODEL_ID with torch.float16 and low_cpu_mem_usage, then save both into a bentoml.models.create context path; contributors changing the import flow should preserve this packaging contract.
  ```
- **Applies to:**
  - `examples/bentoml/import_model.py`
- **Condition:**
  ```text
  When modifying the BentoML import_model example's loading or saving flow.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The example loads tokenizer and model from MODEL_ID with torch.float16 and low_cpu_mem_usage, then saves both into a bentoml.models.create context, matching the packaging contract.
```

- **Sources:**
  - `examples/bentoml/import_model.py`
