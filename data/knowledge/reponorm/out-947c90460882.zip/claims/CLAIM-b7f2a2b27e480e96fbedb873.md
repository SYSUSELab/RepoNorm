# Rule details

- **Rule:** The TestJsonSchemaUnionTypes class must group test cases for JSON schemas with union types, treating union-type schema handling as a distinct tested concern.
- **Applies to:**
  - `tests/types/test_json_schema_union_types.py`
- **Condition:** When adding or modifying tests for JSON schema union-type handling.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
TestJsonSchemaUnionTypes is a test class grouping cases for JSON schemas with union types, treating union-type handling as a distinct tested concern.
```

- **Sources:**
  - `tests/types/test_json_schema_union_types.py:8-158`
