# Rule details

- **Rule:** The MkDocs site uses the material theme.
- **Applies to:**
  - `mkdocs.yml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
theme:
    name: material

```

- **Sources:**
  - `mkdocs.yml:18-19`
