# Rule details

- **Rule:**
  ```text
  The base Model ABC declares type_adapter: ModelTypeAdapter and tensor_library_name: str as class-level attributes; subclasses must define type_adapter, and steerable models must additionally define tensor_library_name.
  ```
- **Applies to:**
  - `outlines/models/base.py`
- **Condition:** When adding a new Model subclass or modifying the base Model ABC's required attributes.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The base Model ABC class body declares type_adapter: ModelTypeAdapter and tensor_library_name: str as class-level attributes, matching the rule.
```

- **Sources:**
  - `outlines/models/base.py:62-305`
