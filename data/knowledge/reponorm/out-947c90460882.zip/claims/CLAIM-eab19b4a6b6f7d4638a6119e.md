# Rule details

- **Rule:** The documentation build workflow sets up Python version 3.10 via actions/setup-python.
- **Applies to:**
  - `.github/workflows/build_documentation.yml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
      - uses: actions/setup-python@v4
        with:
          python-version: "3.10"

```

- **Sources:**
  - `.github/workflows/build_documentation.yml:14-16`
