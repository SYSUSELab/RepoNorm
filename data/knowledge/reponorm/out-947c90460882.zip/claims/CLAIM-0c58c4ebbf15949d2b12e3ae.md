# Rule details

- **Rule:** The dev container enables the conda devcontainer feature.
- **Applies to:**
  - `.devcontainer/devcontainer.json`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
    "ghcr.io/devcontainers/features/conda:1": {},

```

- **Sources:**
  - `.devcontainer/devcontainer.json:11`
