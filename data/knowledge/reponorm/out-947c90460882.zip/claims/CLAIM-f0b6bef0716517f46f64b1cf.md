# Rule details

- **Rule:** Examples that define enumerated prompt choices must model them as a str-valued Enum whose members map option letters to prompt fragments, so generation can be constrained to the enumerated set.
- **Applies to:**
  - `examples/dating_profile.py`
- **Condition:** When adding or modifying an example that constrains generation to a fixed set of prompt choices.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
examples/dating_profile.py defines QuestionChoice as a str-valued Enum whose members map option letters A-F to prompt fragments, matching the enumerated-choice rule.
```

- **Sources:**
  - `examples/dating_profile.py`
