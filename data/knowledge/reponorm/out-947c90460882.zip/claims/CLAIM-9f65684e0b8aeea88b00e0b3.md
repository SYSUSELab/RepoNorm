# Rule details

- **Rule:** Tests that exercise the offline vLLM model's generate must assert the return type (plain string for a simple prompt) as the basic generation contract.
- **Applies to:**
  - `tests/models/test_vllm_offline.py`
- **Condition:** When adding or modifying tests for the offline vLLM model's generate method.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_vllm_simple calls generate with a simple prompt and asserts the result is a str, matching the offline vLLM return-type contract.
```

- **Sources:**
  - `tests/models/test_vllm_offline.py:60-62`
