# Rule details

- **Rule:**
  ```text
  The Gemini type adapter test module must import TypedDict from typing on Python >= 3.12 and from typing_extensions otherwise, establishing a version-conditional import convention.
  ```
- **Applies to:**
  - `tests/models/test_gemini_type_adapter.py`
- **Condition:** when adding TypedDict imports to the Gemini type adapter test module
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The file imports TypedDict from typing when sys.version_info >= (3, 12) and from typing_extensions otherwise, matching the version-conditional import convention.
```

- **Sources:**
  - `tests/models/test_gemini_type_adapter.py`
