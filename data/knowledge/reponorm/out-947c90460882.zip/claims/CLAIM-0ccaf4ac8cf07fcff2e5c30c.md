# Rule details

- **Rule:**
  ```text
  Audio must be a dataclass holding an audio: Any field, documented to be passed alongside a text prompt in a list as model_input for audio-capable multimodal models.
  ```
- **Applies to:**
  - `outlines/inputs.py`
- **Condition:** when modifying the Audio dataclass or its multimodal input usage
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
Audio is a @dataclass with an audio: Any field, documented to be passed with a text prompt in a list as model_input for audio-capable models.
```

- **Sources:**
  - `outlines/inputs.py:58-71`
