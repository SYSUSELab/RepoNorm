# Rule details

- **Rule:**
  ```text
  is_pydantic_model must return False for generic types with a non-None origin, and otherwise True only for classes that subclass BaseModel; the origin check exists because generic types cannot be used with issubclass on Python versions below 3.11.
  ```
- **Applies to:**
  - `outlines/types/utils.py`
- **Condition:**
  ```text
  When modifying is_pydantic_model or adding type-detection utilities that must handle generic types across Python versions.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
is_pydantic_model returns False when get_origin(value) is not None and otherwise checks isinstance(value, type) and issubclass(value, BaseModel), matching the origin-guard and issubclass contract.
```

- **Sources:**
  - `outlines/types/utils.py:131-136`
