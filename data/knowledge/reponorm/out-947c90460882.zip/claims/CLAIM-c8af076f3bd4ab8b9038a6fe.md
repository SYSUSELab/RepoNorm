# Rule details

- **Rule:** Examples that accept JSON Schema documents with nested $ref definitions must demonstrate that Outlines accepts such documents for structured generation, preserving support for definitions and $ref references.
- **Applies to:**
  - `examples/cerebrium/main.py`
- **Condition:** When adding or modifying an example that passes a JSON Schema document containing definitions and $ref references to Outlines.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The example passes a JSON Schema document containing definitions and $ref references to Outlines for structured generation, demonstrating acceptance of nested $ref schemas.
```

- **Sources:**
  - `examples/cerebrium/main.py`
