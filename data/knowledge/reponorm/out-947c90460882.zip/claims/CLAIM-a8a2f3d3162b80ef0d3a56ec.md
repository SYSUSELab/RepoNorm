# Rule details

- **Rule:**
  ```text
  Tests for model backends must preserve the documented external model pinning: the different_model fixture loads TheBloke/phi-2-GGUF phi-2.Q4_K_M.gguf via llama_cpp.Llama.from_pretrained for tokenizer tests.
  ```
- **Applies to:**
  - `tests/models/test_llamacpp_tokenizer.py`
- **Condition:** when adding or modifying tests for tokenizer behavior that require an external model fixture
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The different_model fixture loads the documented pinned model TheBloke/phi-2-GGUF phi-2.Q4_K_M.gguf via llama_cpp.Llama.from_pretrained.
```

- **Sources:**
  - `tests/models/test_llamacpp_tokenizer.py`
