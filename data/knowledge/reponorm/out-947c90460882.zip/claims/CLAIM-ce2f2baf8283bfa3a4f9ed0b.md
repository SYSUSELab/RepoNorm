# Rule details

- **Rule:**
  ```text
  Torch tensor adapter __init__ imports torch and stores it on self, indicating lazy framework import as the adapter initialization convention.
  ```
- **Applies to:**
  - `outlines/processors/tensor_adapters/torch.py`
- **Condition:** When adding or modifying tensor adapter initialization that must lazily import a framework.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
TorchTensorAdapter.__init__ imports torch inside the method body and stores it as self.torch, matching the lazy framework import convention.
```

- **Sources:**
  - `outlines/processors/tensor_adapters/torch.py:9-12`
