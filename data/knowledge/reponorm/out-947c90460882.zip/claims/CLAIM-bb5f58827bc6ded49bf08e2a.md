# Rule details

- **Rule:**
  ```text
  Model factory functions (from_llamacpp, from_gemini, from_transformers) must accept the native client/tokenizer object and return the corresponding Outlines model wrapper, preserving the public conversion entry point contract.
  ```
- **Applies to:**
  - `outlines/models/gemini.py`
  - `outlines/models/llamacpp.py`
  - `outlines/models/transformers.py`
- **Condition:** when adding or modifying a model factory conversion function that wraps a native client or tokenizer into an Outlines model
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
from_gemini accepts the native client and returns the Gemini Outlines wrapper, preserving the public conversion entry point contract.
```

- **Sources:**
  - `outlines/models/gemini.py:368-385`

### Evidence 2 — current_observation

```text
from_llamacpp accepts the native Llama model and returns the LlamaCpp Outlines wrapper, preserving the public conversion entry point contract.
```

- **Sources:**
  - `outlines/models/llamacpp.py:324-339`

### Evidence 3 — current_observation

```text
from_transformers accepts a native tokenizer/processor and returns the corresponding Outlines Transformers or TransformersMultiModal wrapper, preserving the factory conversion contract.
```

- **Sources:**
  - `outlines/models/transformers.py:589-631`
