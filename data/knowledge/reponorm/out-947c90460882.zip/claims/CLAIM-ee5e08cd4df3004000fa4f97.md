# Rule details

- **Rule:**
  ```text
  The Ollama type adapter's format_output_type must round-trip a JSON schema string back to the original schema object, defining the adapter's schema normalization contract.
  ```
- **Applies to:**
  - `tests/models/test_ollama_type_adapter.py`
- **Condition:**
  ```text
  when modifying or extending Ollama type adapter format_output_type or its tests
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_ollama_type_adapter_json_schema_str asserts a JSON schema string round-trips back to the original schema object, matching the adapter normalization contract.
```

- **Sources:**
  - `tests/models/test_ollama_type_adapter.py:162-165`
