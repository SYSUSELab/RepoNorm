# Rule details

- **Rule:**
  ```text
  Tests for model backends must preserve the documented client initialization contract: from_anthropic accepts an optional model name that sets model.model_name when provided and leaves it None when omitted, while model.client is always the passed client.
  ```
- **Applies to:**
  - `tests/models/test_anthropic.py`
- **Condition:** when adding or modifying tests for model backend client initialization
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_init_from_client asserts model.client equals the passed client and model.model_name is set when provided and None when omitted, matching the documented init contract.
```

- **Sources:**
  - `tests/models/test_anthropic.py`
