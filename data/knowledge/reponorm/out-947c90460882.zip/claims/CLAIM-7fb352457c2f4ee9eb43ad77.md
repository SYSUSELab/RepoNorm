# Rule details

- **Rule:**
  ```text
  `set_additional_properties_false_json_schema` must add additionalProperties: False when absent, leave it unchanged when already False, and leave it unchanged when True, so the function only sets the flag when missing.
  ```
- **Applies to:**
  - `tests/models/test_utils.py`
- **Condition:**
  ```text
  when changing set_additional_properties_false_json_schema behavior for present or absent additionalProperties
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The test asserts the flag is added when additionalProperties is absent and left unchanged when already False or True, matching the conditional-setting rule.
```

- **Sources:**
  - `tests/models/test_utils.py`
