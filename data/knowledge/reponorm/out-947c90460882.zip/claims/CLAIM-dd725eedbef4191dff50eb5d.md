# Rule details

- **Rule:**
  ```text
  The release workflow builds the SDist and wheel by running ./.github/scripts/build_sdist_and_wheel.sh.
  ```
- **Applies to:**
  - `.github/workflows/release_pypi.yaml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
      run: ./.github/scripts/build_sdist_and_wheel.sh

```

- **Sources:**
  - `.github/workflows/release_pypi.yaml:19`
