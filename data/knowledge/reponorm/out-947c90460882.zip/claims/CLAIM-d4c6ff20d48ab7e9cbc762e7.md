# Rule details

- **Rule:** Example schemas that model a question-answer pair must keep the question typed as the repository's QuestionChoice type and the answer as a plain string, so the example stays coupled to the shared choice type rather than introducing a parallel representation.
- **Applies to:**
  - `examples/dating_profile.py`
- **Condition:**
  ```text
  When modifying the dating_profile example's question-answer dataclass or its field types.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The QuestionAnswer dataclass types its question field as QuestionChoice and its answer field as str, keeping the question coupled to the shared choice type.
```

- **Sources:**
  - `examples/dating_profile.py`
