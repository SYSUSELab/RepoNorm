# Rule details

- **Rule:**
  ```text
  AsyncModel.__call__ must construct a Generator with the model, output type, and backend, then await it, making model(prompt, Foo) equivalent to awaiting Generator(model, Foo)(prompt).
  ```
- **Applies to:**
  - `outlines/models/base.py`
- **Condition:** when modifying the async model call path or the Generator construction contract
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
AsyncModel.__call__ constructs Generator(self, output_type, backend) and awaits it, preserving equivalence with awaiting Generator(model, Foo)(prompt).
```

- **Sources:**
  - `outlines/models/base.py:325-368`
