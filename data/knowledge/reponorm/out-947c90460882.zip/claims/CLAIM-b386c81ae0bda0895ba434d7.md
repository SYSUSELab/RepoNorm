# Rule details

- **Rule:**
  ```text
  Examples that constrain generation with a JSON schema must pass the schema through outlines.json_schema(...) when constructing the generator or processor, rather than embedding schema constraints in the prompt alone.
  ```
- **Applies to:**
  - `examples/bentoml/service.py`
  - `examples/cerebrium/main.py`
  - `examples/pick_odd_one_out.py`
- **Condition:** When adding or modifying an example that constrains model output to a JSON schema.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The example routes the schema through outlines.json_schema(json_schema) when constructing the Generator, satisfying the rule that JSON-schema-constrained examples use the json_schema helper.
```

- **Sources:**
  - `examples/bentoml/service.py`

### Evidence 2 — current_observation

```text
The example routes the schema through outlines.json_schema(schema) when invoking the model, rather than embedding schema constraints in the prompt alone.
```

- **Sources:**
  - `examples/cerebrium/main.py`
