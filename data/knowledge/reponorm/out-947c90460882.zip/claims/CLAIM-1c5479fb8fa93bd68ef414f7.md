# Rule details

- **Rule:**
  ```text
  from_dottxt constructs a Dottxt model by forwarding client, model_name, and model_revision positionally to the Dottxt constructor, so the constructor argument order is part of the factory contract.
  ```
- **Applies to:**
  - `outlines/models/dottxt.py`
- **Condition:**
  ```text
  When modifying from_dottxt or the Dottxt constructor's parameter order.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
from_dottxt returns Dottxt(client, model_name, model_revision), forwarding the three arguments positionally to the constructor.
```

- **Sources:**
  - `outlines/models/dottxt.py:202-225`
