# Rule details

- **Rule:** The project version is declared as dynamic rather than a static value.
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
dynamic = ["version"]

```

- **Sources:**
  - `pyproject.toml:42`
