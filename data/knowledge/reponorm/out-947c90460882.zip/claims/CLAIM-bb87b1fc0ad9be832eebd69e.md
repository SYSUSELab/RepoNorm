# Rule details

- **Rule:**
  ```text
  convert_token_to_string prepends a space for Llama tokenizers when the token starts with SPIECE_UNDERLINE or equals <0x20>, a hack to compensate for missing spaces in HF Llama tokenizers.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:**
  ```text
  When modifying convert_token_to_string or adding tokenizer-specific string conversion workarounds.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
`TransformerTokenizer.convert_token_to_string` implements the Llama workaround: when `self.is_llama` and the token starts with SPIECE_UNDERLINE or equals `<0x20>`, it prepends a space.
```

- **Sources:**
  - `outlines/models/transformers.py:100-110`
