# Rule details

- **Rule:** Tests for a backend's logits processors must assert both the processor class identity and that generated output conforms to each constraint kind (JSON schema, regex, CFG).
- **Applies to:**
  - `tests/backends/test_xgrammar.py`
- **Condition:** When adding or modifying backend logits-processor tests that cover multiple constraint kinds.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_xgrammar_backend asserts processor class identity via isinstance and checks output conformance for JSON schema, regex, and CFG constraint kinds.
```

- **Sources:**
  - `tests/backends/test_xgrammar.py:61-87`
