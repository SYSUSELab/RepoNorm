# Rule details

- **Rule:**
  ```text
  Flake8 ignores F401 and F403 in __init__.py files.
  ```
- **Applies to:**
  - `**/__init__.py`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
per-file-ignores =
    **/__init__.py:F401,F403

```

- **Sources:**
  - `setup.cfg:5-6`
