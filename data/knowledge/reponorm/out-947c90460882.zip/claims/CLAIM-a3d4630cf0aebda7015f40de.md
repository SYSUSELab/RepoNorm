# Rule details

- **Rule:**
  ```text
  Coverage measurement omits the listed files and directories: outlines/_version.py, outlines/models/anthropic.py, outlines/models/dottxt.py, outlines/models/gemini.py, outlines/models/mlxlm.py, outlines/models/openai.py, outlines/models/vllm_offline.py, outlines/processors/tensor_adapters/mlx.py, and tests/*.
  ```
- **Applies to:**
  - `outlines/_version.py`
  - `outlines/models/anthropic.py`
  - `outlines/models/dottxt.py`
  - `outlines/models/gemini.py`
  - `outlines/models/mlxlm.py`
  - `outlines/models/openai.py`
  - `outlines/models/vllm_offline.py`
  - `outlines/processors/tensor_adapters/mlx.py`
  - `tests/**`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
omit = [
    "outlines/_version.py",
    "outlines/models/anthropic.py",
    "outlines/models/dottxt.py",
    "outlines/models/gemini.py",
    "outlines/models/mlxlm.py",
    "outlines/models/openai.py",
    "outlines/models/vllm_offline.py",
    "outlines/processors/tensor_adapters/mlx.py",
    "tests/*",
]

```

- **Sources:**
  - `pyproject.toml:178-188`
