# Rule details

- **Rule:**
  ```text
  Mock TGI client _create must hash kwargs into a request key, raise ValueError when no mock response is registered, and return an iterator when stream=True.
  ```
- **Applies to:**
  - `tests/test_utils/mock_tgi_client.py`
- **Condition:** when adding or modifying the mock TGI client's request/response matching behavior
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The mock TGI client's _create hashes kwargs into a request key, raises ValueError when no response is registered, and returns an iterator when stream=True.
```

- **Sources:**
  - `tests/test_utils/mock_tgi_client.py`
