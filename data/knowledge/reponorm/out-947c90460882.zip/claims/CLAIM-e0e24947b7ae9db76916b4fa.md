# Rule details

- **Rule:**
  ```text
  The template `name` filter requires a callable and raises TypeError otherwise; for callables lacking `__name__` it falls back to the type name, so contributors must not assume every callable has `__name__`.
  ```
- **Applies to:**
  - `outlines/templates.py`
- **Condition:**
  ```text
  When modifying the template `name` filter or relying on `__name__` of callables passed to templates.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
get_fn_name raises TypeError for non-callables, matching the rule's requirement that the name filter requires a callable.
```

- **Sources:**
  - `outlines/templates.py:203-213`
