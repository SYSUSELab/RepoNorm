# Rule details

- **Rule:** When the event is a release, the workflow deploys the tag as the latest alias and sets latest as the default version using mike.
- **Applies to:**
  - `.github/workflows/publish_documentation.yml`
- **Condition:**
  ```text
  workflow predicate: github.event_name == 'release'
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
        if: github.event_name == 'release'

```

- **Sources:**
  - `.github/workflows/publish_documentation.yml:43`

### Evidence 2 — explicit

```text
        run: |
          mike deploy --push --update-aliases ${{ github.ref_name }} latest
          mike set-default --push latest

```

- **Sources:**
  - `.github/workflows/publish_documentation.yml:44-46`
