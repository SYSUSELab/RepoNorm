# Rule details

- **Rule:**
  ```text
  Template tests must define custom_filter as a plain callable taking a string and returning its uppercase form, establishing that custom filters are plain callables.
  ```
- **Applies to:**
  - `tests/test_templates.py`
- **Condition:** When modifying or adding template tests that define custom filters.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
custom_filter is defined as a plain callable taking a string and returning its uppercase form, matching the template filter convention.
```

- **Sources:**
  - `tests/test_templates.py:190-191`
