# Full rule catalog

## Rule 104 — `dirty_equals/_other.py`

- **Rule:**
  ```text
  Modules that import Literal from typing must fall back to typing_extensions on ImportError to preserve compatibility with older Python versions.
  ```
- **Applies to:**
  - `dirty_equals/_other.py`
  - `dirty_equals/_strings.py`
- **Condition:** when adding or modifying typing imports in dirty-equals modules
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-bd638db7317df2586d922dbe.md)

## Rule 105 — `dirty_equals/_other.py`

- **Rule:**
  ```text
  IsJson.__init__ must raise TypeError('IsJson requires either an argument or kwargs, not both') when both expected_value and expected_kwargs are supplied, and must use plain_repr('*') when no expected value is given.
  ```
- **Applies to:**
  - `dirty_equals/_other.py`
- **Condition:**
  ```text
  when modifying IsJson.__init__ or the wildcard vs parameterized JSON matching contract
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-be0777bc306416fe652486a9.md)

## Rule 106 — `dirty_equals/_base.py`

- **Rule:** DirtyEquals equals for a dirty tuple must return True only if all dirty values equal the other value, defining AND-composition semantics for tuple matchers.
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:** When modifying DirtyAnd.equals or the tuple-composition equality path.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-bffd302c0c06975da783b62a.md)

## Rule 107 — `tests/test_inspection.py`

- **Rule:**
  ```text
  Tests for `HasAttributes` must assert that attribute values are matched (including nested predicates like `IsInt()`/`IsStr()`), that negation is supported, and that extra expected attributes not present on the value cause a mismatch.
  ```
- **Applies to:**
  - `tests/test_inspection.py`
- **Condition:**
  ```text
  when adding or modifying tests that pin `HasAttributes` matching, negation, and extra-attribute mismatch behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c125cc8f676b2477fb18f2a7.md)

## Rule 108 — `dirty_equals/_base.py`

- **Rule:**
  ```text
  IsOneOf.__init__ must store expected_value plus more_expected_values as a tuple and pass them to super, so IsOneOf supports variadic expected values and can be combined with Contains via |.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:**
  ```text
  When modifying IsOneOf.__init__ or the variadic expected-value construction path.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c1650a9f39c8f129936efe9b.md)

## Rule 109 — `.github/workflows/upload-previews.yml`

- **Rule:**
  ```text
  The workflow runs `smokeshow upload docs` with SMOKESHOW_GITHUB_STATUS_DESCRIPTION set to 'Docs Preview', SMOKESHOW_GITHUB_CONTEXT set to 'docs', SMOKESHOW_GITHUB_TOKEN from secrets.github_token, SMOKESHOW_GITHUB_PR_HEAD_SHA from the triggering run's head SHA, and SMOKESHOW_AUTH_KEY from secrets.smokeshow_auth_key.
  ```
- **Applies to:**
  - `.github/workflows/upload-previews.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c4336e423f1f99837c9edc02.md)

## Rule 110 — `dirty_equals/__init__.py`

- **Rule:**
  ```text
  The package `__init__` must re-export the full public API and define `__all__` including `__version__`, with `__version__ = '0.0.dev0'`.
  ```
- **Applies to:**
  - `dirty_equals/__init__.py`
- **Condition:**
  ```text
  when modifying the package `__init__` re-exports, `__all__`, or `__version__`
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c4765e2ee7da9d5393940523.md)

## Rule 111 — `tests/**/*.py`

- **Rule:**
  ```text
  Matcher classes must raise AssertionError when compared with `==` against a non-matching value, and their `repr`/`str` must remain stable after a failed comparison.
  ```
- **Applies to:**
  - `tests/**/*.py`
- **Condition:** when adding or modifying matcher equality/repr assertions in the test suite
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c47f45683d4e522b4ff6f5f4.md)

## Rule 112 — `dirty_equals/_datetime.py`

- **Rule:**
  ```text
  When a datetime matcher compares with enforce_tz enabled, approx_equals must compare only UTC offsets rather than full tzinfo identity, and a naive approx must require the other value to be naive; do not tighten to full tzinfo equality.
  ```
- **Applies to:**
  - `dirty_equals/_datetime.py`
- **Condition:** Modifying timezone handling in datetime approximate comparison.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ca0d0fe49d35dabed6290582.md)

## Rule 113 — `dirty_equals/_numeric.py`

- **Rule:** When a numeric matcher restricts allowed types, booleans must be explicitly excluded even though they are int subclasses; do not allow bool to match an int matcher.
- **Applies to:**
  - `dirty_equals/_numeric.py`
- **Condition:** Modifying allowed-type constraints for numeric matchers.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-caae73890afbd218cdde88a1.md)

## Rule 114 — `**`

- **Rule:**
  ```text
  Running `make clean` removes the `.cache`, `.pytest_cache`, and `.mypy_cache` directories.
  ```
- **Applies to:**
  - `**`
- **Condition:** command target: clean
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-cb17ef3b1ca77d38f950d090.md)

## Rule 115 — `docs/plugins.py`

- **Rule:**
  ```text
  The mkdocs-simple-hooks plugin maps the on_page_markdown hook to docs.plugins:on_page_markdown.
  ```
- **Applies to:**
  - `docs/plugins.py`
  - `mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-cc020b16a58b337309373e2a.md)

## Rule 116 — `tests/test_strings.py`

- **Rule:**
  ```text
  IsBytes(regex=...) must match bytes patterns, including wildcard bytes regexes such as b'wh.*er'.
  ```
- **Applies to:**
  - `tests/test_strings.py`
- **Condition:** when adding or modifying tests for IsBytes regex matching
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-cc507b80d722c1a238b861b8.md)

## Rule 117 — `dirty_equals/_boolean.py`

- **Rule:** IsTrueLike.equals must return bool(other), so truthiness rather than identity with True is the comparison rule.
- **Applies to:**
  - `dirty_equals/_boolean.py`
- **Condition:** Modifying IsTrueLike.equals comparison logic.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-cd8eab0e635d3798d727bc22.md)

## Rule 118 — `dirty_equals/_inspection.py`

- **Rule:**
  ```text
  When a matcher class exposes a __class_getitem__ shorthand, it must return cls(expected) so that subscript syntax is exactly equivalent to the constructor call; do not change the shorthand to return a different type or defer construction.
  ```
- **Applies to:**
  - `dirty_equals/_inspection.py`
  - `dirty_equals/_other.py`
- **Condition:**
  ```text
  Modifying or adding a __class_getitem__ shorthand on a matcher class.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d305869d340f00e8c64f80cd.md)

## Rule 119 — `**/*.py`

- **Rule:** A local pre-commit hook with id 'mypy' runs 'make mypy' on Python-typed files using the system language.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d5a3d025170faf41bc3d01bf.md)
