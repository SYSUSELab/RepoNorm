# Full rule catalog

## Rule 019 — `tests/test_list_tuple.py`

- **Rule:**
  ```text
  IsList must reject check_order=False combined with positions by raising TypeError with the message 'check_order=False is not compatible with positions'.
  ```
- **Applies to:**
  - `tests/test_list_tuple.py`
- **Condition:**
  ```text
  when adding or modifying tests for IsList argument validation involving check_order and positions
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1fd2c5d9fa3304129030ef44.md)

## Rule 020 — `tests/test_other.py`

- **Rule:**
  ```text
  IsJson must compare equal to both IsJson(expected_value) and the subscript form IsJson[expected_value] for null, string, list, and object JSON values.
  ```
- **Applies to:**
  - `tests/test_other.py`
- **Condition:** when adding or modifying tests for IsJson equality across constructor and subscript forms
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-248d4ba17d8f4aed345ee6ec.md)

## Rule 021 — `tests/test_other.py`

- **Rule:**
  ```text
  Tests for `IsJson` must assert that a JSON array matcher does not equal a JSON object string and that its `str` is the matcher's repr.
  ```
- **Applies to:**
  - `tests/test_other.py`
- **Condition:**
  ```text
  when adding or modifying tests that pin `IsJson` inequality and repr behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-25a47df13a63df29145e0f32.md)

## Rule 022 — `tests/test_dict.py`

- **Rule:**
  ```text
  Tests for dict matcher reprs must parametrize `IsDict`, `IsPartialDict`, `IsIgnoreDict`, and `IsStrictDict` repr output, including settings such as partial, ignore, and strict reflected in bracket notation.
  ```
- **Applies to:**
  - `tests/test_dict.py`
- **Condition:** when adding or modifying tests that pin repr output for dict matchers
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-27929f8df7081718dfaf1750.md)

## Rule 023 — `dirty_equals/_base.py`

- **Rule:**
  ```text
  DirtyEquals.__init__ must store repr_args/repr_kwargs and initialize _other/_was_equal, establishing the shared repr and comparison-state protocol for subclasses.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:**
  ```text
  Modifying DirtyEquals.__init__ or the shared repr/comparison-state protocol used by subclasses.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-287333f88250b607da401ae8.md)

## Rule 024 — `dirty_equals/_base.py`

- **Rule:**
  ```text
  The base module must import Protocol from typing but fall back to Protocol = object on Python 3.7, and define InstanceOrType as Union[DirtyEquals[Any], DirtyEqualsMeta].
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:** when modifying typing imports or the InstanceOrType alias in the base module
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-28cdbc64df0bebc211d0c5f8.md)

## Rule 025 — `tests/test_datetime.py`

- **Rule:**
  ```text
  Tests for `IsNow` with `iso_string=True` must assert that the matcher equals the current datetime's ISO-formatted string.
  ```
- **Applies to:**
  - `tests/test_datetime.py`
- **Condition:**
  ```text
  when adding or modifying tests that cover `IsNow` ISO-string matching
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-2963cb23ab4e5cc70ef8ab74.md)

## Rule 026 — `dirty_equals/_other.py`

- **Rule:**
  ```text
  `IsUUID` must accept version values None, 1, 2, 3, 4, or 5; omitting version accepts all UUID versions, and hyphenated and non-hyphenated UUID strings are both accepted.
  ```
- **Applies to:**
  - `dirty_equals/_other.py`
- **Condition:**
  ```text
  when modifying `IsUUID.__init__` or the accepted version values and string formats
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-29cccda2d51b384a80eb52e3.md)

## Rule 027 — `tests/test_list_tuple.py`

- **Rule:**
  ```text
  Tests for list/tuple matchers must cover the documented mismatch boundaries: length ranges, check_order=False, positions, and Contains, asserting inequality for each mismatch case.
  ```
- **Applies to:**
  - `tests/test_list_tuple.py`
- **Condition:** when adding or modifying list/tuple matcher mismatch tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-2c94a5f39531ec147a96a37f.md)

## Rule 028 — `dirty_equals/_datetime.py`

- **Rule:**
  ```text
  Datetime prepare must accept datetime values, numeric timestamps only when unix_number is set, and strings only when iso_string or format_string is configured; otherwise it must raise TypeError or ValueError.
  ```
- **Applies to:**
  - `dirty_equals/_datetime.py`
- **Condition:** when modifying IsDatetime.prepare or its input-type acceptance rules
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-32bdad8133f81372ed777c9f.md)

## Rule 029 — `dirty_equals/_strings.py`

- **Rule:** When a string/bytes matcher is constructed, unset options must be passed to super as Omit so they do not appear in repr; do not pass None or default values that would surface in repr.
- **Applies to:**
  - `dirty_equals/_strings.py`
- **Condition:** Modifying construction of a string/bytes matcher.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-389073e647b7aa37b67bd771.md)

## Rule 030 — `**`

- **Rule:**
  ```text
  Running `make clean` removes editor backup files matching `*~` and `.*~`.
  ```
- **Applies to:**
  - `**`
- **Condition:** command target: clean
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3cb0e99d2675c574e3edbe97.md)

## Rule 031 — `dirty_equals/_numeric.py`

- **Rule:**
  ```text
  `IsNonPositive` must check values `<= 0` and accept `int`, `float`, `Decimal`, or any value implementing `__le__` for 0, including `Decimal('-0')` and `Decimal('0')`.
  ```
- **Applies to:**
  - `dirty_equals/_numeric.py`
- **Condition:**
  ```text
  when modifying `IsNonPositive` or its comparison semantics
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3e663f6d7c8e6262237902db.md)

## Rule 032 — `dirty_equals/_numeric.py`

- **Rule:**
  ```text
  IsNumber must restrict allowed_types to int, float, and Decimal, excluding date and datetime, so numeric comparisons reject date-like values even though IsNumeric accepts them.
  ```
- **Applies to:**
  - `dirty_equals/_numeric.py`
- **Condition:**
  ```text
  Modifying IsNumber allowed_types or its relationship to IsNumeric.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3e6ba705df711dd2b01c4a1b.md)

## Rule 033 — `dirty_equals/_other.py`

- **Rule:**
  ```text
  `IsUUID` must be a `DirtyEquals[UUID]` subclass documented to check for a valid UUID and optionally check UUID version.
  ```
- **Applies to:**
  - `dirty_equals/_other.py`
- **Condition:**
  ```text
  when modifying `IsUUID` or its base class relationship and documented contract
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-426cb7e21f670a2a0f8e3964.md)

## Rule 034 — `**`

- **Rule:**
  ```text
  Running `make format` executes `$(isort)` followed by `$(black)` to format the codebase.
  ```
- **Applies to:**
  - `**`
- **Condition:** command target: format
- **Normative strength:** `observed`
- **Use:** `reference_only`
- **Execution risk:** `repository_wide_mutation`
- **Detail:** [Open claim details](../claims/CLAIM-432752a152b32660c6e14a8f.md)
