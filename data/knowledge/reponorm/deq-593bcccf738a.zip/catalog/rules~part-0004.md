# Full rule catalog

## Rule 053 — `tests/test_datetime.py`

- **Rule:**
  ```text
  IsDate must support approx, iso_string, format_string, ge, gt, and delta matching, and must reject wrong types and datetime-vs-date mismatches.
  ```
- **Applies to:**
  - `tests/test_datetime.py`
- **Condition:** when adding or modifying tests for IsDate matching options and type mismatches
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6be59f414e5df35b6332f566.md)

## Rule 054 — `dirty_equals/_base.py`

- **Rule:** The base equals implementation must return True unconditionally, defining the default equality behavior that subclasses override.
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:** when modifying the base equals implementation or AnyThing equality behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6cf3b3713513e18c38b14051.md)

## Rule 055 — `**`

- **Rule:**
  ```text
  Running `make install` installs test, linting, and docs requirements via pip, installs project dependencies via poetry, and installs pre-commit hooks.
  ```
- **Applies to:**
  - `**`
- **Condition:** command target: install
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6efa68676f601767d0a18f8d.md)

## Rule 056 — `tests/test_datetime.py`

- **Rule:**
  ```text
  Datetime tests must import `IsDate`, `IsDatetime`, `IsNow`, and `IsToday` from dirty_equals and may use pytz and unittest.mock.Mock for timezone and mock-based behavior.
  ```
- **Applies to:**
  - `tests/test_datetime.py`
- **Condition:** when adding or modifying datetime tests that need timezone or mock-based coverage
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-715a672bfa1169d910008203.md)

## Rule 057 — `tests/mypy_checks.py`

- **Rule:**
  ```text
  The mypy_checks.py module must remain type-checkable by mypy and must document intentional type-error boundaries with explicit type: ignore comments rather than removing the offending expression.
  ```
- **Applies to:**
  - `tests/mypy_checks.py`
- **Condition:**
  ```text
  when modifying tests/mypy_checks.py to add or adjust type-checking assertions
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-77c4f8fae3a0e865ef81dfe8.md)

## Rule 058 — `dirty_equals/_base.py`

- **Rule:**
  ```text
  _repr_ne must dispatch to repr(v) for DirtyEqualsMeta instances and to v._repr_ne() otherwise, preserving class vs instance repr behavior under negation.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:**
  ```text
  when modifying _repr_ne or the negation repr dispatch logic
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-798394956447c4e31a00b331.md)

## Rule 059 — `docs/plugins.py`

- **Rule:**
  ```text
  The mkdocs-simple-hooks plugin maps the on_pre_build hook to docs.plugins:on_pre_build.
  ```
- **Applies to:**
  - `docs/plugins.py`
  - `mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-79a294cc94c1ce6a9cd8cb8a.md)

## Rule 060 — `dirty_equals/_boolean.py`

- **Rule:**
  ```text
  `IsFalseLike.equals` must return `not bool(other)` for non-string values, but when `allow_strings` is true and `other` is a `str` it must delegate to `make_string_check`.
  ```
- **Applies to:**
  - `dirty_equals/_boolean.py`
- **Condition:**
  ```text
  when modifying `IsFalseLike.equals` or the `allow_strings` behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7c8de7d51467aac8c92d2d84.md)

## Rule 061 — `dirty_equals/_sequence.py`

- **Rule:**
  ```text
  IsListOrTuple must keep allowed_type defaulting to (list, tuple), constraining which container types the predicate accepts; do not broaden the default to arbitrary iterables.
  ```
- **Applies to:**
  - `dirty_equals/_sequence.py`
- **Condition:**
  ```text
  when modifying IsListOrTuple or its allowed_type default
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7c9bfc68a78dfa412c076e2d.md)

## Rule 062 — `dirty_equals/_base.py`

- **Rule:**
  ```text
  When a matcher class is composed via & or |, the composed result must remain a DirtyEquals subclass so it can be used anywhere a DirtyEquals is accepted; do not change DirtyAnd/DirtyOr to non-DirtyEquals types.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:** Modifying or adding composition operators on matcher classes.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7db8b0c1966a8b2158081f5c.md)

## Rule 063 — `dirty_equals/_base.py`

- **Rule:**
  ```text
  DirtyEquals.__or__ must return a DirtyOr combining self and other, so the | operator is part of the public composition protocol for dirty equality objects.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:**
  ```text
  when modifying DirtyEquals.__or__ or the public composition protocol
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-81e44b1e290cad9446886799.md)

## Rule 064 — `tests/test_dict.py`

- **Rule:**
  ```text
  Tests for nested dirty-equals matchers inside `IsIgnoreDict` must assert that the nested matcher's `.value` property returns the matched value after a successful comparison.
  ```
- **Applies to:**
  - `tests/test_dict.py`
- **Condition:**
  ```text
  when adding or modifying tests that cover stateful nested matchers inside `IsIgnoreDict`
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-83ec8274618e8c8f39dc6f77.md)

## Rule 065 — `dirty_equals/_utils.py`

- **Rule:**
  ```text
  get_dict_arg must enforce dict-like initialization: kwargs and positional args cannot both be supplied, at most one positional dict is allowed, and a non-dict positional raises TypeError.
  ```
- **Applies to:**
  - `dirty_equals/_utils.py`
- **Condition:**
  ```text
  Modifying get_dict_arg argument validation or dict-like initialization enforcement.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-867835172502d44b9f4271c0.md)

## Rule 066 — `dirty_equals/_inspection.py`

- **Rule:**
  ```text
  `IsInstance` must be a `DirtyEquals` subclass parameterized by `ExpectedType`, so instance checks participate in the same dirty-equals comparison protocol as other matchers.
  ```
- **Applies to:**
  - `dirty_equals/_inspection.py`
- **Condition:**
  ```text
  when modifying `IsInstance` or its base class relationship
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-86b50df4c3887309fd6af16b.md)

## Rule 067 — `**/*.py`

- **Rule:**
  ```text
  Running `make lint` executes black in check mode.
  ```
- **Applies to:**
  - `**/*.py`
- **Condition:** command target: lint
- **Normative strength:** `observed`
- **Use:** `reference_only`
- **Execution risk:** `repository_wide_mutation`
- **Detail:** [Open claim details](../claims/CLAIM-8a959174949a7a9975da260e.md)

## Rule 068 — `**`

- **Rule:**
  ```text
  Running `make testcov` depends on the `test` target and then runs `coverage report --show-missing` and `coverage html`.
  ```
- **Applies to:**
  - `**`
- **Condition:** command target: testcov
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8b809f3a9447bc14c89e0bfe.md)

## Rule 069 — `dirty_equals/_dict.py`

- **Rule:**
  ```text
  When a matcher supports partial/subset matching, the enabling flag must be set in _post_init (e.g. partial=True) rather than at comparison time; do not move the flag assignment out of initialization.
  ```
- **Applies to:**
  - `dirty_equals/_dict.py`
- **Condition:** Modifying initialization of a partial/subset matcher.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8c6b00841730e3b9090f60c0.md)
