# Full rule catalog

## Rule 070 — `dirty_equals/_base.py`

- **Rule:** AnyThing must match any value and is intended for use inside other comparisons such as IsList and IsStrictDict.
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:** when modifying AnyThing or using it as a wildcard inside composite matchers
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8f417f7ca0c4a1894b74f0f2.md)

## Rule 071 — `dirty_equals/_base.py`

- **Rule:**
  ```text
  DirtyEquals.__invert__ must return DirtyNot(self) so ~dirty produces a negated matcher; do not change the negation result type or drop the inversion behavior.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:**
  ```text
  when modifying DirtyEquals.__invert__ or the negation operator behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8f888d8f686bdac375efdfcd.md)

## Rule 072 — `dirty_equals/_dict.py`

- **Rule:**
  ```text
  `_ignore_value` must use `type(v) in (DirtyEquals, DirtyEqualsMeta)` rather than `isinstance`, because `isinstance` reportedly always returns True on PyPy; contributors changing this check must preserve the exact-type semantics.
  ```
- **Applies to:**
  - `dirty_equals/_dict.py`
- **Condition:**
  ```text
  when modifying the type check inside `IsDict._ignore_value` or refactoring it to use `isinstance`
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8fbcfa37b3821b0c0f0e8a1b.md)

## Rule 073 — `dirty_equals/_inspection.py`

- **Rule:**
  ```text
  `IsInstanceOf` must provide an overloaded `__init__` accepting `**expected: Any`, indicating keyword-based expected attribute matching in addition to positional forms.
  ```
- **Applies to:**
  - `dirty_equals/_inspection.py`
- **Condition:**
  ```text
  when modifying `IsInstanceOf.__init__` or its overloaded signatures
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-911f68e5de1b1e1c2270de33.md)

## Rule 074 — `dirty_equals/_sequence.py`

- **Rule:**
  ```text
  _sequence.py must export HasLen, Contains, IsListOrTuple, IsList, and IsTuple, and define LengthType as Union[None, int, Tuple[int, Union[int, Any]]], establishing the accepted length argument shapes.
  ```
- **Applies to:**
  - `dirty_equals/_sequence.py`
- **Condition:**
  ```text
  Modifying _sequence.py exports or LengthType definition.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-922a266c4348e2cd1da65cce.md)

## Rule 075 — `dirty_equals/_inspection.py`

- **Rule:**
  ```text
  `HasName.equals` must first check the value's own `__name__`; only when `allow_instances` is true may it fall back to checking the value's `__class__.__name__`, so instance matching is opt-in.
  ```
- **Applies to:**
  - `dirty_equals/_inspection.py`
- **Condition:**
  ```text
  when modifying `HasName.equals` or the `allow_instances` behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9268f6032c6f5d359c4ad32f.md)

## Rule 076 — `dirty_equals/_other.py`

- **Rule:**
  ```text
  FunctionCheck is a DirtyEquals[Any] predicate that delegates equality checking to a user-supplied function; preserve this delegation contract when modifying function-based matchers.
  ```
- **Applies to:**
  - `dirty_equals/_other.py`
- **Condition:**
  ```text
  When modifying FunctionCheck or related function-delegating matchers in dirty_equals/_other.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-93a10e293e56dd6adc9ffe18.md)

## Rule 077 — `tests/**`

- **Rule:** Pytest test discovery is restricted to the "tests" directory via testpaths.
- **Applies to:**
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9417ac0939a0b7613196899c.md)

## Rule 078 — `**`

- **Rule:** Codecov project status checks are disabled.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-950d79871ac23d97e85c878c.md)

## Rule 079 — `dirty_equals/_base.py`

- **Rule:**
  ```text
  DirtyEquals.__eq__ must special-case self is DirtyEquals or other is Generic/Protocol to avoid recursive errors during generic creation, and must swallow TypeError to avoid disrupting pytest error reporting.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:**
  ```text
  when modifying DirtyEquals.__eq__ or the generic-creation comparison path
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-95e34caf1d3a7ef63bc2b283.md)

## Rule 080 — `dirty_equals/_numeric.py`

- **Rule:**
  ```text
  The positive-int predicate must initialize its bound via super().__init__(gt=0) and clear _repr_kwargs, so its repr omits the implicit bound.
  ```
- **Applies to:**
  - `dirty_equals/_numeric.py`
- **Condition:**
  ```text
  Modifying IsPositive.__init__ bound initialization or repr kwargs handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-96c1a14de9a7ed539b854129.md)

## Rule 081 — `dirty_equals/_sequence.py`

- **Rule:**
  ```text
  When a container matcher checks containment, it must verify the object contains one or more values as a DirtyEquals[Container[Any]] matcher; do not change it to a non-DirtyEquals or non-container matcher.
  ```
- **Applies to:**
  - `dirty_equals/_sequence.py`
- **Condition:** Modifying container containment matching.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-97d8262c342617d846ba03f7.md)

## Rule 082 — `dirty_equals/_base.py`

- **Rule:**
  ```text
  DirtyEquals.__eq__ must catch TypeError and ValueError raised by the subclass equals() implementation and return False instead of propagating the exception.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:**
  ```text
  When modifying DirtyEquals.__eq__ or adding a new DirtyEquals subclass whose equals() may raise TypeError or ValueError.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9896a5d47b4b4af7ba46ccaf.md)

## Rule 083 — `dirty_equals/_numeric.py`

- **Rule:**
  ```text
  IsPositive must accept any value implementing __gt__ against 0, not only int/float/Decimal, and must keep 0 != IsPositive and -1 != IsPositive.
  ```
- **Applies to:**
  - `dirty_equals/_numeric.py`
- **Condition:** when modifying IsPositive or its comparison acceptance rules
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9951ee905731b3bf97adb396.md)

## Rule 084 — `tests/test_base.py`

- **Rule:**
  ```text
  repr of dirty-equals matchers must preserve class vs instance distinction and operator composition forms, including ~, &, |, and parameterized instances like IsInt(lt=5).
  ```
- **Applies to:**
  - `tests/test_base.py`
- **Condition:** when adding or modifying tests for matcher repr of class/instance and operator composition forms
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9a1e838856dd024611daeb5f.md)

## Rule 085 — `dirty_equals/_base.py`

- **Rule:**
  ```text
  DirtyAnd requires at least two operands (a, b) plus optional extras, so `&` composition cannot produce a single-operand DirtyAnd.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:**
  ```text
  when modifying DirtyAnd.__init__ or the `&` composition operator
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9e25db71c81bdb683aa39975.md)

## Rule 086 — `.github/workflows/ci.yml`

- **Rule:** The deploy job publishes the built docs site to the gh-pages branch.
- **Applies to:**
  - `.github/workflows/ci.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a3d0ac8084f8c7a0b55cfec4.md)
