# Full rule catalog

## Rule 087 — `dirty_equals/_datetime.py`

- **Rule:**
  ```text
  _datetime.py must import IsNumeric from ._numeric and reuse it for numeric comparison behavior rather than reimplementing numeric matching.
  ```
- **Applies to:**
  - `dirty_equals/_datetime.py`
- **Condition:**
  ```text
  When modifying _datetime.py's numeric comparison behavior or refactoring numeric matcher reuse.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a5736fc8c5fd248418b914fd.md)

## Rule 088 — `dirty_equals/_dict.py`

- **Rule:**
  ```text
  IsStrictDict._post_init must set self.strict = True, making strict key-order checking the default for this dict type unless overridden.
  ```
- **Applies to:**
  - `dirty_equals/_dict.py`
- **Condition:**
  ```text
  when modifying IsStrictDict._post_init or its strict default
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ad775089bd6f5253d11e9cb1.md)

## Rule 089 — `.github/workflows/ci.yml`

- **Rule:** The lint job runs make lint and make mypy.
- **Applies to:**
  - `.github/workflows/ci.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ae7bda9d7d2687d337894ada.md)

## Rule 090 — `dirty_equals/_datetime.py`

- **Rule:**
  ```text
  IsDate must accept approx/delta/gt/lt/ge/le plus iso_string and format_string, and numeric delta must be interpreted as seconds and converted to timedelta.
  ```
- **Applies to:**
  - `dirty_equals/_datetime.py`
- **Condition:**
  ```text
  Modifying IsDate.__init__ parameter handling or delta conversion.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-aeeb0e785b8cded510890aeb.md)

## Rule 091 — `dirty_equals/_base.py`

- **Rule:**
  ```text
  DirtyEquals.__repr__ must return repr(self._other) after a successful equality and self._repr_ne() otherwise, so that failed comparisons show the expected value in diffs.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:**
  ```text
  when modifying DirtyEquals.__repr__ or the repr of a subclass that relies on the base repr
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b11510ddad5cd65e868dcc88.md)

## Rule 092 — `**/*.py`

- **Rule:** mypy does not warn when a function returns a value typed as Any.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b1b0dfb04139589d7b971e4a.md)

## Rule 093 — `dirty_equals/_numeric.py`

- **Rule:**
  ```text
  IsNumeric.equals must prepare the value and return bounds_checks(other) only when has_bounds_checks is set, otherwise return True, so an unconstrained numeric predicate accepts any prepared value.
  ```
- **Applies to:**
  - `dirty_equals/_numeric.py`
- **Condition:** Modifying IsNumeric.equals comparison dispatch or bounds-check gating.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b2df647aa015d17765ca87c0.md)

## Rule 094 — `dirty_equals/_inspection.py`

- **Rule:**
  ```text
  HasAttributes.__init__ must accept either positional dicts or keyword arguments via get_dict_arg and pass the resulting expected attributes to the superclass, so attribute expectations follow dict-style construction.
  ```
- **Applies to:**
  - `dirty_equals/_inspection.py`
- **Condition:**
  ```text
  when modifying HasAttributes.__init__ or the attribute-expectation construction path
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b33039425222088d2b666c9a.md)

## Rule 095 — `dirty_equals/_sequence.py`

- **Rule:**
  ```text
  IsListOrTuple.equals must enforce allowed_type and length before comparing, and for order-insensitive comparison must remove each expected item from a copy of the other sequence so duplicates are handled without set hashing.
  ```
- **Applies to:**
  - `dirty_equals/_sequence.py`
- **Condition:** When modifying IsListOrTuple.equals or adding new sequence comparison modes.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b4c023ecd74571ef6d80d19e.md)

## Rule 096 — `dirty_equals/_dict.py`

- **Rule:**
  ```text
  _repr_ne must emit partial/ignore/strict modifiers only when they differ from the subclass defaults (IsPartialDict, IsIgnoreDict, IsStrictDict), so reprs of subclasses omit redundant default settings.
  ```
- **Applies to:**
  - `dirty_equals/_dict.py`
- **Condition:**
  ```text
  when modifying IsDict._repr_ne or the repr modifier emission logic for dict subclasses
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b63c5266f2d7e695465cbf5f.md)

## Rule 097 — `dirty_equals/_strings.py`

- **Rule:**
  ```text
  When a regex is prepared for a string matcher, flex mode must strip flags other than re.UNICODE and extract the pattern, encoding string patterns to bytes, while non-flex mode extracts the pattern only when regex_flags is nonzero; do not change this flag-handling behavior.
  ```
- **Applies to:**
  - `dirty_equals/_strings.py`
- **Condition:** Modifying regex preparation for string matchers.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b6582437b0dccfdaa1db9143.md)

## Rule 098 — `dirty_equals/_other.py`

- **Rule:** IsJson must remain a DirtyEquals subclass specialized for JSON values, preserving JSON parsing/comparison as a first-class matcher category.
- **Applies to:**
  - `dirty_equals/_other.py`
- **Condition:** When modifying IsJson or adding new JSON matcher behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b746b735bac299327e60bf5a.md)

## Rule 099 — `dirty_equals/_sequence.py`

- **Rule:**
  ```text
  When a matcher accepts a length constraint, _length_repr must raise TypeError for non-int lengths that are not a 2-tuple and render a non-int upper bound as '...'; do not silently accept other length forms.
  ```
- **Applies to:**
  - `dirty_equals/_sequence.py`
- **Condition:** Modifying length-constraint validation or repr.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b94d2bdd82939c86efc52737.md)

## Rule 100 — `.github/workflows/upload-previews.yml`

- **Rule:** The workflow sets up Python version 3.10 via actions/setup-python.
- **Applies to:**
  - `.github/workflows/upload-previews.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-bb42c5ecb945233a4219a5f0.md)

## Rule 101 — `dirty_equals/_base.py`

- **Rule:**
  ```text
  _repr_ne must omit arguments and kwargs whose value is Omit, so sentinel values are excluded from generated reprs.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:**
  ```text
  when modifying _repr_ne or its argument/kwarg filtering
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-bb827b6369158f0fc3d3b1a3.md)

## Rule 102 — `dirty_equals/_sequence.py`

- **Rule:**
  ```text
  HasLen must be a DirtyEquals[Sized] predicate for checking a value's length or that its length falls within a range.
  ```
- **Applies to:**
  - `dirty_equals/_sequence.py`
- **Condition:** Modifying HasLen class definition or its length-checking semantics.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-bbbb4782bfa7b7e83b14f115.md)

## Rule 103 — `.github/workflows/upload-previews.yml`

- **Rule:** The workflow downloads artifacts from the ci.yml workflow at the triggering run's head SHA using dawidd6/action-download-artifact.
- **Applies to:**
  - `.github/workflows/upload-previews.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-bc0ac0e8e743aff65ef354c0.md)
