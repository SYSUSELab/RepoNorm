# Full rule catalog

## Rule 139 — `dirty_equals/**`

- **Rule:**
  ```text
  Running `make mypy` executes `mypy dirty_equals tests/mypy_checks.py`.
  ```
- **Applies to:**
  - `dirty_equals/**`
  - `tests/mypy_checks.py`
- **Condition:** command target: mypy
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f99ae9d77f3271fc33594a73.md)

## Rule 140 — `tests/test_inspection.py`

- **Rule:**
  ```text
  Tests for `IsInstance` must assert that `IsInstance(Foo)` and `IsInstance[Foo]` are equivalent forms and that non-matching values compare unequal.
  ```
- **Applies to:**
  - `tests/test_inspection.py`
- **Condition:**
  ```text
  when adding or modifying tests that pin `IsInstance` call and subscript equivalence
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-fe0b4bd691dd4e0b1b943826.md)

## Rule 141 — `tests/test_base.py`

- **Rule:** Tests that verify class-level sentinel matchers such as IsApprox must assert that the sentinel class itself is usable directly in comparisons without instantiation.
- **Applies to:**
  - `tests/test_base.py`
- **Condition:** when adding or modifying tests for class-level sentinel matchers
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-fe6041c7887e3d137b957772.md)
