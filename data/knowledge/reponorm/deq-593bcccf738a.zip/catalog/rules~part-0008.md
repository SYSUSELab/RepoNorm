# Full rule catalog

## Rule 120 — `dirty_equals/_inspection.py`

- **Rule:**
  ```text
  IsInstance must accept expected_type and only_direct_instance, support both IsInstance[Foo] and IsInstance(Foo), and only_direct_instance=True must reject subclass instances.
  ```
- **Applies to:**
  - `dirty_equals/_inspection.py`
- **Condition:**
  ```text
  Modifying IsInstance constructor signature or only_direct_instance behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d696e428136ffd44f916b66c.md)

## Rule 121 — `dirty_equals/_inspection.py`

- **Rule:** HasAttributes must remain a partial check: the attributes provided to check do not need to be exhaustive, so contributors must not assume it requires an exact attribute set.
- **Applies to:**
  - `dirty_equals/_inspection.py`
- **Condition:** when modifying HasAttributes or its attribute comparison behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-de7e13cda1d1970dd9c4bf7c.md)

## Rule 122 — `tests/test_docs.py`

- **Rule:** Documentation examples in .py and .md files are executed by the docs test suite, so docstring and markdown code chunks must remain runnable.
- **Applies to:**
  - `tests/test_docs.py`
- **Condition:** When changing documentation examples in .py or .md files, ensure the extracted docstring and markdown code chunks remain executable by the docs test suite.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-df279041896039ccd1f0256b.md)

## Rule 123 — `.github/workflows/ci.yml`

- **Rule:** The docs job builds the documentation site with mkdocs build --strict.
- **Applies to:**
  - `.github/workflows/ci.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-df5aed3f3dd419e7b8e6e3cc.md)

## Rule 124 — `**/*.py`

- **Rule:** A local pre-commit hook with id 'lint' runs 'make lint' on Python-typed files using the system language.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e03e1acad1bd7c3006631282.md)

## Rule 125 — `tests/test_inspection.py`

- **Rule:**
  ```text
  HasRepr must support subscript syntax HasRepr['...'], negation with ~HasRepr, regex matching, and class/object reprs, asserting equality for each case.
  ```
- **Applies to:**
  - `tests/test_inspection.py`
- **Condition:** when adding or modifying tests for HasRepr matching forms
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e171139e817bbc8a669754d9.md)

## Rule 126 — `dirty_equals/_dict.py`

- **Rule:**
  ```text
  `IsIgnoreDict._post_init` must set `ignore={None}`, so None keys are ignored by default in that dict matcher.
  ```
- **Applies to:**
  - `dirty_equals/_dict.py`
- **Condition:**
  ```text
  when modifying `IsIgnoreDict._post_init` or the default `ignore` set
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e33cf1bd2ec752e81591d37d.md)

## Rule 127 — `**/*.py`

- **Rule:**
  ```text
  isort is configured with include_trailing_comma = true.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e50dfb2ff33ee6293d57c356.md)

## Rule 128 — `dirty_equals/_base.py`

- **Rule:**
  ```text
  DirtyEquals subclasses that accept multiple instance-or-type arguments must store them as a tuple in self.dirties, as shown by __init__(self, a, b, *extra).
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:** when modifying a DirtyEquals subclass constructor that accepts multiple instance-or-type arguments
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e6bc03bac8c1d939b58752bc.md)

## Rule 129 — `**`

- **Rule:**
  ```text
  Running `make test` executes `coverage run -m pytest` followed by `python tests/mypy_checks.py`.
  ```
- **Applies to:**
  - `**`
- **Condition:** command target: test
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e7c55d3a01b0b0462f73b210.md)

## Rule 130 — `dirty_equals/_other.py`

- **Rule:** A matcher's equals can delegate directly to a stored callable via self.func(other), supporting function-based custom matchers.
- **Applies to:**
  - `dirty_equals/_other.py`
- **Condition:** when modifying FunctionCheck.equals or adding function-based custom matchers
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e9520b6558efcfe685212e7b.md)

## Rule 131 — `**/*.py`

- **Rule:**
  ```text
  isort is configured with force_grid_wrap = 0.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ea1ba70d0b0a07eac66d62cc.md)

## Rule 132 — `dirty_equals/_dict.py`

- **Rule:** IsDict.settings must return a new IsDict with copied state and must support strict, partial, and ignore; partial and ignore cannot be combined and must raise TypeError.
- **Applies to:**
  - `dirty_equals/_dict.py`
- **Condition:** when modifying IsDict.settings or the strict/partial/ignore configuration surface
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ebde4cba6f58b2dec5b71433.md)

## Rule 133 — `tests/test_docs.py`

- **Rule:**
  ```text
  The docs test must use `pytest_generate_tests` to parametrize `module_name` and `source_code` from `generate_code_chunks('dirty_equals', 'docs')` so every runnable docs code chunk becomes a test case.
  ```
- **Applies to:**
  - `tests/test_docs.py`
- **Condition:** when adding or modifying the docs test harness that parametrizes runnable documentation code chunks
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ec1576121832f7ea5ac56072.md)

## Rule 134 — `dirty_equals/_boolean.py`

- **Rule:**
  ```text
  Boolean matchers must depend on DirtyEquals from _base and Omit from _utils, using Omit as the shared sentinel for suppressing repr kwargs.
  ```
- **Applies to:**
  - `dirty_equals/_boolean.py`
- **Condition:** when modifying boolean matchers or their repr-kwarg suppression behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ec9c9ad5d30440047a323911.md)

## Rule 135 — `**/*.py`

- **Rule:**
  ```text
  Running `make lint` executes isort in check-only mode with `--df`.
  ```
- **Applies to:**
  - `**/*.py`
- **Condition:** command target: lint
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-eef518ed001eda1c2d365c08.md)

## Rule 136 — `tests/test_list_tuple.py`

- **Rule:**
  ```text
  Tests for `IsTuple` length repr must assert that open-ended length bounds normalize a tuple length like `(6, 'x')` to `(6, ...)` while concrete bounds like `(6, 10)` are preserved.
  ```
- **Applies to:**
  - `tests/test_list_tuple.py`
- **Condition:**
  ```text
  when adding or modifying tests that pin `IsTuple` length repr canonicalization
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f2a8d3faa4773ee8e1b38bb5.md)

## Rule 137 — `**/*.py`

- **Rule:**
  ```text
  Coverage excludes lines matching "pragma: no cover", "raise NotImplementedError", "raise NotImplemented", "if TYPE_CHECKING:", and "@overload" from coverage reporting.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f2ac77769ebae6b48111accf.md)

## Rule 138 — `tests/test_boolean.py`

- **Rule:**
  ```text
  Tests that pin the truthiness semantics of IsTrueLike and IsFalseLike must parametrize across bools, containers, None, and numeric zero/one, and must assert both the positive matcher and its negation (~IsTrueLike) where applicable.
  ```
- **Applies to:**
  - `tests/test_boolean.py`
- **Condition:** when adding or modifying tests for IsTrueLike or IsFalseLike truthiness behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f93e96bc743b5e6913e23b5c.md)
