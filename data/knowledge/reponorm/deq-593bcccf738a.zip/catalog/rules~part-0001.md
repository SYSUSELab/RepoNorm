# Full rule catalog

## Rule 001 — `dirty_equals/_numeric.py`

- **Rule:**
  ```text
  IsNumeric.prepare must reject booleans (True/False) with TypeError even though bool is a subclass of int, and must reject values outside allowed_types.
  ```
- **Applies to:**
  - `dirty_equals/_numeric.py`
- **Condition:** When modifying IsNumeric.prepare or extending numeric type acceptance in the numeric matcher.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-00770ed6c04e6a6a5c95b2c4.md)

## Rule 002 — `dirty_equals/_inspection.py`

- **Rule:**
  ```text
  IsInstance equality must use exact type comparison when only_direct_instance is set, otherwise fall back to isinstance checks.
  ```
- **Applies to:**
  - `dirty_equals/_inspection.py`
- **Condition:**
  ```text
  Modifying IsInstance.equals type-matching logic or only_direct_instance handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0180222f349ad47a29ecbf98.md)

## Rule 003 — `tests/test_list_tuple.py`

- **Rule:**
  ```text
  Sequence matchers IsList, IsTuple, IsListOrTuple, HasLen, and Contains must be tested across length ranges, check_order=False, positions, and AnyThing placeholders.
  ```
- **Applies to:**
  - `tests/test_list_tuple.py`
- **Condition:** When changing sequence matcher options or adding new sequence matcher parameters.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-033bf0b0028129a60c8e5344.md)

## Rule 004 — `dirty_equals/_numeric.py`

- **Rule:** IsApprox must remain a subclass of IsNumber that only permits approximate comparisons; contributors adding exact-comparison behavior to IsNumber must not assume IsApprox inherits it.
- **Applies to:**
  - `dirty_equals/_numeric.py`
- **Condition:** when adding or changing exact-comparison behavior on IsNumber or its subclasses
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0412eb77cbe0607c7f10b096.md)

## Rule 005 — `dirty_equals/_sequence.py`

- **Rule:**
  ```text
  HasLen.__init__ must store an int min_length as the exact length when max_length is None, otherwise store (min_length, max_length) and pass the length repr to super, with ellipsis meaning no maximum.
  ```
- **Applies to:**
  - `dirty_equals/_sequence.py`
- **Condition:**
  ```text
  when modifying HasLen.__init__ or its length argument handling
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-05c74579e177eefcc8db9b8a.md)

## Rule 006 — `dirty_equals/_dict.py`

- **Rule:**
  ```text
  When `ignore` is not callable, `_ignore_value` must treat it as a membership container and return `v in self.ignore`, catching `TypeError` for unhashable values and returning False; the supported ignore forms are therefore callable or membership container.
  ```
- **Applies to:**
  - `dirty_equals/_dict.py`
- **Condition:**
  ```text
  when modifying the `ignore` handling in `IsDict._ignore_value` or the accepted forms of the `ignore` setting
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-072412a09f1fb2d552740b75.md)

## Rule 007 — `.github/workflows/upload-previews.yml`

- **Rule:** The workflow installs smokeshow via pip.
- **Applies to:**
  - `.github/workflows/upload-previews.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-09d0314705847ce1d629a201.md)

## Rule 008 — `mkdocs.yml`

- **Rule:** The MkDocs site is configured with the Material theme.
- **Applies to:**
  - `mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0b007da69d4b6c7c23fb969f.md)

## Rule 009 — `.github/workflows/upload-previews.yml`

- **Rule:** The workflow installs click version 8.0.4 via pip.
- **Applies to:**
  - `.github/workflows/upload-previews.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0b1e70a89f015c520454afa2.md)

## Rule 010 — `dirty_equals/_base.py`

- **Rule:**
  ```text
  `__invert__` must return DirtyNot(self), defining the `~` operator as the negation wrapper for dirty-equals instances.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:**
  ```text
  when modifying `__invert__` or the `~` negation operator on dirty-equals instances
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0b9ef366eddc599cb5b4add8.md)

## Rule 011 — `.github/workflows/ci.yml`

- **Rule:** The test job installs test requirements from tests/requirements.txt, installs the project with poetry, runs make test, and generates a coverage XML report.
- **Applies to:**
  - `.github/workflows/ci.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0c1f6dbf8584c4be9edc8b7d.md)

## Rule 012 — `tests/test_inspection.py`

- **Rule:** Inspection tests must import the public matcher surface (AnyThing, HasAttributes, HasName, HasRepr, IsInstance, IsInt, IsStr), documenting the expected public API names.
- **Applies to:**
  - `tests/test_inspection.py`
- **Condition:** when modifying inspection test imports or public API surface
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0de4ea667e2ffcae83ff88cd.md)

## Rule 013 — `**/*.py`

- **Rule:** mypy runs in strict mode for Python source files.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-139f5c61f08df4ea60677c71.md)

## Rule 014 — `tests/test_inspection.py`

- **Rule:**
  ```text
  HasName must match classes, instances, functions, and attributes by __name__, support allow_instances=False to reject instances, and accept nested predicates such as IsStr(regex=...) for the name.
  ```
- **Applies to:**
  - `tests/test_inspection.py`
- **Condition:** when adding or modifying tests for HasName matching targets and options
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-15728901b989489cde5899c2.md)

## Rule 015 — `dirty_equals/_datetime.py`

- **Rule:** The datetime prepare method must refresh self.approx to the current time on every comparison so relative datetime matchers evaluate against the moment of comparison.
- **Applies to:**
  - `dirty_equals/_datetime.py`
- **Condition:** when modifying the prepare method of a relative datetime matcher
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-15951644dd5e2fbb0955135a.md)

## Rule 016 — `dirty_equals/_base.py`

- **Rule:**
  ```text
  DirtyEqualsMeta.__repr__ must return self.__name__, so class-level dirty sentinels repr as their bare class name.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:**
  ```text
  when modifying DirtyEqualsMeta.__repr__ or the class-level sentinel repr
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-15ca403445dc11eb758a2110.md)

## Rule 017 — `dirty_equals/_other.py`

- **Rule:**
  ```text
  `IsUUID.equals` must accept UUID instances or UUID-parsable strings, return False for other types, and enforce the configured version when set.
  ```
- **Applies to:**
  - `dirty_equals/_other.py`
- **Condition:**
  ```text
  when modifying `IsUUID.equals` or its version enforcement
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1bc87fadefc12e1f2f66b9f4.md)

## Rule 018 — `dirty_equals/_numeric.py`

- **Rule:**
  ```text
  IsNumeric.__init__ must raise TypeError when approx is combined with any of gt, lt, ge, or le, and must set has_bounds_checks based on whether any comparison parameter was provided.
  ```
- **Applies to:**
  - `dirty_equals/_numeric.py`
- **Condition:**
  ```text
  Modifying IsNumeric.__init__ parameter handling or bound-check initialization.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1c717c38c74a9563bf2d0d12.md)
