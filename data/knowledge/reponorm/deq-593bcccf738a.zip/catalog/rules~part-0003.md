# Full rule catalog

## Rule 035 — `tests/test_numeric.py`

- **Rule:** IsInt must reject combining approx with gt, lt, ge, or le, raising TypeError with the message '"approx" cannot be combined with "gt", "lt", "ge", or "le"'.
- **Applies to:**
  - `tests/test_numeric.py`
- **Condition:** When changing IsInt argument validation, preserve the mutual-exclusion contract between approx and comparison bounds and its exact TypeError message.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-448a1c1d7b7f5531340f65d4.md)

## Rule 036 — `dirty_equals/_base.py`

- **Rule:**
  ```text
  DirtyEquals equals for expected_values must return True if any expected value equals the other value, defining OR-composition semantics.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:**
  ```text
  Modifying IsOneOf.equals or the OR-composition comparison semantics for expected_values.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-47fd7eaefef44e2317d81241.md)

## Rule 037 — `dirty_equals/_numeric.py`

- **Rule:** IsPositiveFloat must only match float values greater than zero; ints and Decimal values must not be equal even when positive.
- **Applies to:**
  - `dirty_equals/_numeric.py`
- **Condition:** when modifying IsPositiveFloat or its type acceptance rules
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-4bdffa6f7fa370cf0a17d2ad.md)

## Rule 038 — `dirty_equals/_sequence.py`

- **Rule:**
  ```text
  Contains.__init__ must accept one or more contained values and store them as a tuple, supporting containment checks against lists, tuples, strings, and dict keys.
  ```
- **Applies to:**
  - `dirty_equals/_sequence.py`
- **Condition:**
  ```text
  when modifying Contains.__init__ or the containment-check semantics
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-4eab746eb6a27165ae34a3db.md)

## Rule 039 — `dirty_equals/_base.py`

- **Rule:**
  ```text
  `DirtyEquals.__hash__` must be based on the class name, so matcher instances are hashable consistently with their type identity.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:**
  ```text
  when modifying `DirtyEqualsMeta.__hash__` or the hash basis for matcher instances
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-4f50862cf767cd8469251a78.md)

## Rule 040 — `**`

- **Rule:**
  ```text
  Running `make clean` removes Python bytecode caches by deleting `__pycache__` directories and `*.py[co]` files.
  ```
- **Applies to:**
  - `**`
- **Condition:** command target: clean
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5187f499b90673f7ae74bd54.md)

## Rule 041 — `dirty_equals/**`

- **Rule:**
  ```text
  Coverage measurement is restricted to the dirty_equals package as the source.
  ```
- **Applies to:**
  - `dirty_equals/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-52ddbf8e2a207bf430bb2bc6.md)

## Rule 042 — `tests/test_inspection.py`

- **Rule:**
  ```text
  IsInstance must match subclasses by inheritance, reject subclasses when only_direct_instance=True, and not treat the class itself as an instance.
  ```
- **Applies to:**
  - `tests/test_inspection.py`
- **Condition:** when adding or modifying tests for IsInstance inheritance and direct-instance semantics
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-57041e7528c92eef2e871c70.md)

## Rule 043 — `dirty_equals/_inspection.py`

- **Rule:**
  ```text
  HasRepr.__class_getitem__ must return cls(expected_repr), enabling subscript syntax HasRepr['...'] as an alternative to calling the constructor.
  ```
- **Applies to:**
  - `dirty_equals/_inspection.py`
- **Condition:**
  ```text
  when modifying HasRepr.__class_getitem__ or the subscript construction path
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-575c05011a324c34b564f787.md)

## Rule 044 — `dirty_equals/_dict.py`

- **Rule:**
  ```text
  IsDict must expose an overloaded __init__ accepting a single expected Dict[Any, Any] argument.
  ```
- **Applies to:**
  - `dirty_equals/_dict.py`
- **Condition:**
  ```text
  Modifying IsDict.__init__ signature or overloads.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5c82e65a78f6bba3a17a0434.md)

## Rule 045 — `dirty_equals/_base.py`

- **Rule:** DirtyEqualsMeta must remain an ABCMeta subclass so dirty matcher classes stay abstract-base compatible and support class-level sentinel behavior; do not replace it with a plain metaclass or type.
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:** when modifying the DirtyEqualsMeta metaclass definition or its base classes
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5dfa53c77bb0cebd622b9b7a.md)

## Rule 046 — `tests/test_base.py`

- **Rule:**
  ```text
  Combining dirty-equals predicates with & must produce a conjunction that passes only when both operands hold, and its repr must join the two operand names with ' & '.
  ```
- **Applies to:**
  - `tests/test_base.py`
- **Condition:**
  ```text
  when adding or modifying tests for & composition of dirty-equals predicates
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5ea0f21bb0e48863b734cbd1.md)

## Rule 047 — `**/*.py`

- **Rule:**
  ```text
  isort is configured with line_length = 120.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6103633c21abf4ad0968b4e6.md)

## Rule 048 — `dirty_equals/_dict.py`

- **Rule:** IsDict must remain usable as a normal dict on its own while serving as the base class for IsPartialDict and IsStrictDict and supporting .settings(...) to change comparison behavior; do not make it abstract or remove the settings hook.
- **Applies to:**
  - `dirty_equals/_dict.py`
- **Condition:** when modifying IsDict or its subclassing/settings extension points
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-610ec298dc8af56fe07c049c.md)

## Rule 049 — `**/*.py`

- **Rule:** Black formatting is configured with a line length of 120.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-61626d901f9683c265b5fd0d.md)

## Rule 050 — `tests/test_numeric.py`

- **Rule:**
  ```text
  `test_dirty_equals` must parametrize many numeric matchers, including class forms like `IsInt` and call forms like `IsInt()`, plus combined matchers such as `IsNonPositive & IsInt`, asserting equality in each case.
  ```
- **Applies to:**
  - `tests/test_numeric.py`
- **Condition:** when modifying numeric matcher equality tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-63369d257a5becf86423c1f7.md)

## Rule 051 — `dirty_equals/_dict.py`

- **Rule:**
  ```text
  IsDict._post_init must remain a no-op hook that subclasses override to adjust dict matcher settings after initialization.
  ```
- **Applies to:**
  - `dirty_equals/_dict.py`
- **Condition:**
  ```text
  when modifying IsDict._post_init or a subclass that overrides it to adjust dict matcher settings
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-66beabaec014a1aff1abe782.md)

## Rule 052 — `dirty_equals/**`

- **Rule:**
  ```text
  Running `make lint` executes flake8 with `--max-complexity 10 --max-line-length 120 --ignore E203,W503` over the `dirty_equals` and `tests` directories.
  ```
- **Applies to:**
  - `dirty_equals/**`
  - `tests/**`
- **Condition:** command target: lint
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-671ef278c280ea2d04a75296.md)
