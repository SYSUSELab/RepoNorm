# Rule details

- **Rule:** IsPositiveFloat must only match float values greater than zero; ints and Decimal values must not be equal even when positive.
- **Applies to:**
  - `dirty_equals/_numeric.py`
- **Condition:** when modifying IsPositiveFloat or its type acceptance rules
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
IsPositiveFloat subclasses IsFloat and its docstring asserts 1.0 == IsPositiveFloat while 1 != IsPositiveFloat, Decimal('3.14') != IsPositiveFloat, and 0.0/-1.0 != IsPositiveFloat, preserving float-only positive matching.
```

- **Sources:**
  - `dirty_equals/_numeric.py:352-370`
