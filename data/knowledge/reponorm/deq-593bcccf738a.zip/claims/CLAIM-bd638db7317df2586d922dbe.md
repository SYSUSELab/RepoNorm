# Rule details

- **Rule:**
  ```text
  Modules that import Literal from typing must fall back to typing_extensions on ImportError to preserve compatibility with older Python versions.
  ```
- **Applies to:**
  - `dirty_equals/_other.py`
  - `dirty_equals/_strings.py`
- **Condition:** when adding or modifying typing imports in dirty-equals modules
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
dirty_equals/_other.py imports Literal from typing inside a try block with an except ImportError fallback to typing_extensions, matching the r10 compatibility rule.
```

- **Sources:**
  - `dirty_equals/_other.py`

### Evidence 2 — current_observation

```text
The file imports Literal from typing inside a try block and falls back to typing_extensions on ImportError, matching the required cross-version compatibility pattern.
```

- **Sources:**
  - `dirty_equals/_strings.py`
