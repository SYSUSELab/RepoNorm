# Rule details

- **Rule:**
  ```text
  HasLen.__init__ must store an int min_length as the exact length when max_length is None, otherwise store (min_length, max_length) and pass the length repr to super, with ellipsis meaning no maximum.
  ```
- **Applies to:**
  - `dirty_equals/_sequence.py`
- **Condition:**
  ```text
  when modifying HasLen.__init__ or its length argument handling
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
HasLen.__init__ (the int-length overload) preserves the length argument semantics required by the r12 rule for exact-length storage.
```

- **Sources:**
  - `dirty_equals/_sequence.py:20-21`

### Evidence 2 — current_observation

```text
HasLen.__init__ stores int min_length as exact length when max_length is None, otherwise stores (min_length, max_length) and passes the length repr to super, preserving the length argument semantics.
```

- **Sources:**
  - `dirty_equals/_sequence.py:27-52`
