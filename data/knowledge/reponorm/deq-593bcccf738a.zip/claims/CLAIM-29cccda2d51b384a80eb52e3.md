# Rule details

- **Rule:**
  ```text
  `IsUUID` must accept version values None, 1, 2, 3, 4, or 5; omitting version accepts all UUID versions, and hyphenated and non-hyphenated UUID strings are both accepted.
  ```
- **Applies to:**
  - `dirty_equals/_other.py`
- **Condition:**
  ```text
  when modifying `IsUUID.__init__` or the accepted version values and string formats
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
IsUUID.__init__ accepts version None/1-5 and delegates to plain_repr('*') when omitted, matching the documented version contract.
```

- **Sources:**
  - `dirty_equals/_other.py:19-36`
