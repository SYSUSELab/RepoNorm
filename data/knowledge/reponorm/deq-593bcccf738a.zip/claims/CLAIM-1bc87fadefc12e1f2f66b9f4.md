# Rule details

- **Rule:**
  ```text
  `IsUUID.equals` must accept UUID instances or UUID-parsable strings, return False for other types, and enforce the configured version when set.
  ```
- **Applies to:**
  - `dirty_equals/_other.py`
- **Condition:**
  ```text
  when modifying `IsUUID.equals` or its version enforcement
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
IsUUID.equals accepts UUID instances or UUID-parsable strings, returns False for other types, and enforces the configured version when set, matching the rule.
```

- **Sources:**
  - `dirty_equals/_other.py:38-51`
