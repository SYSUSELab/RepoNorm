# Rule details

- **Rule:**
  ```text
  `_ignore_value` must use `type(v) in (DirtyEquals, DirtyEqualsMeta)` rather than `isinstance`, because `isinstance` reportedly always returns True on PyPy; contributors changing this check must preserve the exact-type semantics.
  ```
- **Applies to:**
  - `dirty_equals/_dict.py`
- **Condition:**
  ```text
  when modifying the type check inside `IsDict._ignore_value` or refactoring it to use `isinstance`
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
IsDict._ignore_value uses the exact-type check type(v) in (DirtyEquals, DirtyEqualsMeta) with the documented PyPy rationale, matching the rule.
```

- **Sources:**
  - `dirty_equals/_dict.py:123-134`
