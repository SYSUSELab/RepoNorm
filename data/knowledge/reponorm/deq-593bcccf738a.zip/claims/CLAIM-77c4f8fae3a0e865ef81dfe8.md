# Rule details

- **Rule:**
  ```text
  The mypy_checks.py module must remain type-checkable by mypy and must document intentional type-error boundaries with explicit type: ignore comments rather than removing the offending expression.
  ```
- **Applies to:**
  - `tests/mypy_checks.py`
- **Condition:**
  ```text
  when modifying tests/mypy_checks.py to add or adjust type-checking assertions
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
tests/mypy_checks.py is the mypy verification module: it contains type-checking assertions and an explicit `# type: ignore[arg-type]` documenting an intentional type-error boundary, matching the rule.
```

- **Sources:**
  - `tests/mypy_checks.py`
