# Rule details

- **Rule:**
  ```text
  The base module must import Protocol from typing but fall back to Protocol = object on Python 3.7, and define InstanceOrType as Union[DirtyEquals[Any], DirtyEqualsMeta].
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:** when modifying typing imports or the InstanceOrType alias in the base module
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The base module imports Protocol from typing with a fallback to object on Python 3.7 and defines InstanceOrType as Union[DirtyEquals[Any], DirtyEqualsMeta].
```

- **Sources:**
  - `dirty_equals/_base.py`
