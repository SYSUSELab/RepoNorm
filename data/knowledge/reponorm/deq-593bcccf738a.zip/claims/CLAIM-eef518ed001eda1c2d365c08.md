# Rule details

- **Rule:**
  ```text
  Running `make lint` executes isort in check-only mode with `--df`.
  ```
- **Applies to:**
  - `**/*.py`
- **Condition:** command target: lint
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
lint:
	flake8 --max-complexity 10 --max-line-length 120 --ignore E203,W503 dirty_equals tests
	$(isort) --check-only --df

```

- **Sources:**
  - `Makefile:19-21`
