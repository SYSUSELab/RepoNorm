# Rule details

- **Rule:**
  ```text
  IsListOrTuple must keep allowed_type defaulting to (list, tuple), constraining which container types the predicate accepts; do not broaden the default to arbitrary iterables.
  ```
- **Applies to:**
  - `dirty_equals/_sequence.py`
- **Condition:**
  ```text
  when modifying IsListOrTuple or its allowed_type default
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
IsListOrTuple in dirty_equals/_sequence.py defines allowed_type defaulting to (list, tuple), preserving the list/tuple default and not broadening to arbitrary iterables.
```

- **Sources:**
  - `dirty_equals/_sequence.py:87-214`
