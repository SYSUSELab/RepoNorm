# Rule details

- **Rule:**
  ```text
  Running `make testcov` depends on the `test` target and then runs `coverage report --show-missing` and `coverage html`.
  ```
- **Applies to:**
  - `**`
- **Condition:** command target: testcov
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
testcov: test
	@coverage report --show-missing
	@coverage html

```

- **Sources:**
  - `Makefile:30-32`
