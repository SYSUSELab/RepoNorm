# Rule details

- **Rule:** HasAttributes must remain a partial check: the attributes provided to check do not need to be exhaustive, so contributors must not assume it requires an exact attribute set.
- **Applies to:**
  - `dirty_equals/_inspection.py`
- **Condition:** when modifying HasAttributes or its attribute comparison behavior
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
HasAttributes class docstring states it is a partial check where provided attributes need not be exhaustive, preserving the partial attribute check contract.
```

- **Sources:**
  - `dirty_equals/_inspection.py:152-204`
