# Rule details

- **Rule:**
  ```text
  IsListOrTuple.equals must enforce allowed_type and length before comparing, and for order-insensitive comparison must remove each expected item from a copy of the other sequence so duplicates are handled without set hashing.
  ```
- **Applies to:**
  - `dirty_equals/_sequence.py`
- **Condition:** When modifying IsListOrTuple.equals or adding new sequence comparison modes.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
IsListOrTuple.equals checks isinstance(other, self.allowed_type) and _length_correct first, then for order-insensitive comparison copies other and removes each expected item, handling duplicates without set hashing.
```

- **Sources:**
  - `dirty_equals/_sequence.py:187-214`
