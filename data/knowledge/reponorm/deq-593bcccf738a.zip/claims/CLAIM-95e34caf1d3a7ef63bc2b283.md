# Rule details

- **Rule:**
  ```text
  DirtyEquals.__eq__ must special-case self is DirtyEquals or other is Generic/Protocol to avoid recursive errors during generic creation, and must swallow TypeError to avoid disrupting pytest error reporting.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:**
  ```text
  when modifying DirtyEquals.__eq__ or the generic-creation comparison path
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
DirtyEqualsMeta.__eq__ special-cases self is DirtyEquals and other is Generic/Protocol and swallows TypeError, preserving the recursion guard.
```

- **Sources:**
  - `dirty_equals/_base.py:19-30`
