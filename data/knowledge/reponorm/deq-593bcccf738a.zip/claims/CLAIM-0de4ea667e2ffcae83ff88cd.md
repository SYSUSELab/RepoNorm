# Rule details

- **Rule:** Inspection tests must import the public matcher surface (AnyThing, HasAttributes, HasName, HasRepr, IsInstance, IsInt, IsStr), documenting the expected public API names.
- **Applies to:**
  - `tests/test_inspection.py`
- **Condition:** when modifying inspection test imports or public API surface
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
tests/test_inspection.py imports the public matcher surface AnyThing, HasAttributes, HasName, HasRepr, IsInstance, IsInt, IsStr from dirty_equals.
```

- **Sources:**
  - `tests/test_inspection.py`
