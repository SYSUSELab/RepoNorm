# Rule details

- **Rule:**
  ```text
  Tests for `IsNow` with `iso_string=True` must assert that the matcher equals the current datetime's ISO-formatted string.
  ```
- **Applies to:**
  - `tests/test_datetime.py`
- **Condition:**
  ```text
  when adding or modifying tests that cover `IsNow` ISO-string matching
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_is_now_str asserts datetime.now().isoformat() == IsNow(iso_string=True), matching the required ISO-string assertion.
```

- **Sources:**
  - `tests/test_datetime.py:92-93`
