# Rule details

- **Rule:**
  ```text
  DirtyEquals subclasses that accept multiple instance-or-type arguments must store them as a tuple in self.dirties, as shown by __init__(self, a, b, *extra).
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:** when modifying a DirtyEquals subclass constructor that accepts multiple instance-or-type arguments
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
DirtyOr.__init__ stores the multiple instance-or-type arguments as a tuple in self.dirties, matching the required storage convention.
```

- **Sources:**
  - `dirty_equals/_base.py:145-147`
