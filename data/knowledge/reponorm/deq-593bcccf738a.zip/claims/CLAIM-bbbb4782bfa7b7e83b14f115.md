# Rule details

- **Rule:**
  ```text
  HasLen must be a DirtyEquals[Sized] predicate for checking a value's length or that its length falls within a range.
  ```
- **Applies to:**
  - `dirty_equals/_sequence.py`
- **Condition:** Modifying HasLen class definition or its length-checking semantics.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
HasLen is defined as class HasLen(DirtyEquals[Sized]) with the docstring 'Check that some has a given length, or length in a given range', matching the DirtyEquals[Sized] length-predicate rule.
```

- **Sources:**
  - `dirty_equals/_sequence.py:14-55`
