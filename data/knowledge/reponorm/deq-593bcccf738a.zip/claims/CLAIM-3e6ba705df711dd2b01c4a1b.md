# Rule details

- **Rule:**
  ```text
  IsNumber must restrict allowed_types to int, float, and Decimal, excluding date and datetime, so numeric comparisons reject date-like values even though IsNumeric accepts them.
  ```
- **Applies to:**
  - `dirty_equals/_numeric.py`
- **Condition:**
  ```text
  Modifying IsNumber allowed_types or its relationship to IsNumeric.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
IsNumber's class body sets allowed_types = int, float, Decimal, exactly restricting numeric comparisons to those types and excluding date/datetime, matching the r2 rule.
```

- **Sources:**
  - `dirty_equals/_numeric.py:136-146`
