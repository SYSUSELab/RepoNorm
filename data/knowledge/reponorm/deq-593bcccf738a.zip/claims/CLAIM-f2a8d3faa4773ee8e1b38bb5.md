# Rule details

- **Rule:**
  ```text
  Tests for `IsTuple` length repr must assert that open-ended length bounds normalize a tuple length like `(6, 'x')` to `(6, ...)` while concrete bounds like `(6, 10)` are preserved.
  ```
- **Applies to:**
  - `tests/test_list_tuple.py`
- **Condition:**
  ```text
  when adding or modifying tests that pin `IsTuple` length repr canonicalization
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_repr parametrizes IsTuple length cases including (6, 'x') normalized to (6, ...) and (6, 10) preserved, asserting repr equality.
```

- **Sources:**
  - `tests/test_list_tuple.py:118-119`
