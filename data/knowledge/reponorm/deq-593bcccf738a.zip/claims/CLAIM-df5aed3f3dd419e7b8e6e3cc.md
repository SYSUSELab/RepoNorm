# Rule details

- **Rule:** The docs job builds the documentation site with mkdocs build --strict.
- **Applies to:**
  - `.github/workflows/ci.yml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
    - name: build site
      run: mkdocs build --strict

```

- **Sources:**
  - `.github/workflows/ci.yml:97-98`
