# Rule details

- **Rule:** The MkDocs site is configured with the Material theme.
- **Applies to:**
  - `mkdocs.yml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
theme:
  name: material

```

- **Sources:**
  - `mkdocs.yml:5-6`
