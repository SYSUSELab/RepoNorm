# Rule details

- **Rule:**
  ```text
  `__invert__` must return DirtyNot(self), defining the `~` operator as the negation wrapper for dirty-equals instances.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:**
  ```text
  when modifying `__invert__` or the `~` negation operator on dirty-equals instances
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
DirtyEqualsMeta.__invert__ returns DirtyNot(self), directly establishing the negation wrapper protocol required by the rule.
```

- **Sources:**
  - `dirty_equals/_base.py:38-39`
