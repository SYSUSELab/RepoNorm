# Rule details

- **Rule:** The deploy job publishes the built docs site to the gh-pages branch.
- **Applies to:**
  - `.github/workflows/ci.yml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
        uses: JamesIves/github-pages-deploy-action@v4.2.5
        with:
          branch: gh-pages
          folder: site

```

- **Sources:**
  - `.github/workflows/ci.yml:138-141`
