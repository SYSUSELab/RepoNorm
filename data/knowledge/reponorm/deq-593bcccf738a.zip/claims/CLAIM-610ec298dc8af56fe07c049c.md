# Rule details

- **Rule:** IsDict must remain usable as a normal dict on its own while serving as the base class for IsPartialDict and IsStrictDict and supporting .settings(...) to change comparison behavior; do not make it abstract or remove the settings hook.
- **Applies to:**
  - `dirty_equals/_dict.py`
- **Condition:** when modifying IsDict or its subclassing/settings extension points
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
IsDict is a concrete class usable as a normal dict, subclassed by IsPartialDict and IsStrictDict, and exposes .settings(...) via its settings hook, preserving all three properties.
```

- **Sources:**
  - `dirty_equals/_dict.py:11-153`
