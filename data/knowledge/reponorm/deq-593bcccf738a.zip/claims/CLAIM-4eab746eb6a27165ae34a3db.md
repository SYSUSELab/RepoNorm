# Rule details

- **Rule:**
  ```text
  Contains.__init__ must accept one or more contained values and store them as a tuple, supporting containment checks against lists, tuples, strings, and dict keys.
  ```
- **Applies to:**
  - `dirty_equals/_sequence.py`
- **Condition:**
  ```text
  when modifying Contains.__init__ or the containment-check semantics
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
Contains.__init__ accepts contained_value plus *more_contained_values and stores them as a tuple via (contained_value,) + more_contained_values, preserving tuple storage and multi-value acceptance.
```

- **Sources:**
  - `dirty_equals/_sequence.py:63-81`
