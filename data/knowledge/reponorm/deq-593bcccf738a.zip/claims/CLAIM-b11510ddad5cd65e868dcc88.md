# Rule details

- **Rule:**
  ```text
  DirtyEquals.__repr__ must return repr(self._other) after a successful equality and self._repr_ne() otherwise, so that failed comparisons show the expected value in diffs.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:**
  ```text
  when modifying DirtyEquals.__repr__ or the repr of a subclass that relies on the base repr
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
DirtyEquals.__repr__ returns repr(self._other) when _was_equal and self._repr_ne() otherwise, matching the diff-oriented repr contract.
```

- **Sources:**
  - `dirty_equals/_base.py:132-138`
