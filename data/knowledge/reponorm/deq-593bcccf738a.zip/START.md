# Repository knowledge

Apply rules within their stated scope and when their conditions hold, respecting
exceptions. `required`, `recommended`, and `observed` have different strength:
an observed convention does not by itself prohibit a change requested by the task.
`reference_only` is context, not a default action.
Evidence locations identify sources, not the rule's scope.
Commands in rules do not authorize unrelated changes or external side effects.
Use relevant rules alongside the task and repository code; keep edits focused.

## Find rules

Path links and the [full catalog](catalog.md) are alternative routes. Search or
open relevant files directly; open claim details when evidence or a conflict matters.
Paths are navigation anchors, not a replacement for each rule's complete scope.

- `repository root`: [Read rules](paths/repository.md)
- `.github/workflows/ci.yml`: [Read rules](paths/.github/workflows/ci.yml.md)
- `.github/workflows/upload-previews.yml`: [Read rules](paths/.github/workflows/upload-previews.yml.md)
- `dirty_equals`: [Read rules](paths/dirty_equals.md)
- `dirty_equals/__init__.py`: [Read rules](paths/dirty_equals/__init__.py.md)
- `dirty_equals/_base.py`: [Read rules (part 1)](paths/dirty_equals/_base.py~part-0001.md)
- `dirty_equals/_base.py`: [Read rules (part 2)](paths/dirty_equals/_base.py~part-0002.md)
- `dirty_equals/_boolean.py`: [Read rules](paths/dirty_equals/_boolean.py.md)
- `dirty_equals/_datetime.py`: [Read rules](paths/dirty_equals/_datetime.py.md)
- `dirty_equals/_dict.py`: [Read rules](paths/dirty_equals/_dict.py.md)
- `dirty_equals/_inspection.py`: [Read rules](paths/dirty_equals/_inspection.py.md)
- `dirty_equals/_numeric.py`: [Read rules](paths/dirty_equals/_numeric.py.md)
- `dirty_equals/_other.py`: [Read rules](paths/dirty_equals/_other.py.md)
- `dirty_equals/_sequence.py`: [Read rules](paths/dirty_equals/_sequence.py.md)
- `dirty_equals/_strings.py`: [Read rules](paths/dirty_equals/_strings.py.md)
- `dirty_equals/_utils.py`: [Read rules](paths/dirty_equals/_utils.py.md)
- `docs/plugins.py`: [Read rules](paths/docs/plugins.py.md)
- `mkdocs.yml`: [Read rules](paths/mkdocs.yml.md)
- `tests`: [Read rules](paths/tests.md)
- `tests/mypy_checks.py`: [Read rules](paths/tests/mypy_checks.py.md)
- `tests/test_base.py`: [Read rules](paths/tests/test_base.py.md)
- `tests/test_boolean.py`: [Read rules](paths/tests/test_boolean.py.md)
- `tests/test_datetime.py`: [Read rules](paths/tests/test_datetime.py.md)
- `tests/test_dict.py`: [Read rules](paths/tests/test_dict.py.md)
- `tests/test_docs.py`: [Read rules](paths/tests/test_docs.py.md)
- `tests/test_inspection.py`: [Read rules](paths/tests/test_inspection.py.md)
- `tests/test_list_tuple.py`: [Read rules](paths/tests/test_list_tuple.py.md)
- `tests/test_numeric.py`: [Read rules](paths/tests/test_numeric.py.md)
- `tests/test_other.py`: [Read rules](paths/tests/test_other.py.md)
- `tests/test_strings.py`: [Read rules](paths/tests/test_strings.py.md)
