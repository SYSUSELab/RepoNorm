# Rules for `tests`

## Rule 052 — `dirty_equals/**`

- **Rule:**
  ```text
  Running `make lint` executes flake8 with `--max-complexity 10 --max-line-length 120 --ignore E203,W503` over the `dirty_equals` and `tests` directories.
  ```
- **Applies to:**
  - `dirty_equals/**`
  - `tests/**`
- **Condition:** command target: lint
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-671ef278c280ea2d04a75296.md)

## Rule 077 — `tests/**`

- **Rule:** Pytest test discovery is restricted to the "tests" directory via testpaths.
- **Applies to:**
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9417ac0939a0b7613196899c.md)

## Rule 111 — `tests/**/*.py`

- **Rule:**
  ```text
  Matcher classes must raise AssertionError when compared with `==` against a non-matching value, and their `repr`/`str` must remain stable after a failed comparison.
  ```
- **Applies to:**
  - `tests/**/*.py`
- **Condition:** when adding or modifying matcher equality/repr assertions in the test suite
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c47f45683d4e522b4ff6f5f4.md)
