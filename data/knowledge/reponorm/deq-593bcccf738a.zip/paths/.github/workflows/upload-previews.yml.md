# Rules for `.github/workflows/upload-previews.yml`

## Rule 007 — `.github/workflows/upload-previews.yml`

- **Rule:** The workflow installs smokeshow via pip.
- **Applies to:**
  - `.github/workflows/upload-previews.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-09d0314705847ce1d629a201.md)

## Rule 009 — `.github/workflows/upload-previews.yml`

- **Rule:** The workflow installs click version 8.0.4 via pip.
- **Applies to:**
  - `.github/workflows/upload-previews.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0b1e70a89f015c520454afa2.md)

## Rule 100 — `.github/workflows/upload-previews.yml`

- **Rule:** The workflow sets up Python version 3.10 via actions/setup-python.
- **Applies to:**
  - `.github/workflows/upload-previews.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-bb42c5ecb945233a4219a5f0.md)

## Rule 103 — `.github/workflows/upload-previews.yml`

- **Rule:** The workflow downloads artifacts from the ci.yml workflow at the triggering run's head SHA using dawidd6/action-download-artifact.
- **Applies to:**
  - `.github/workflows/upload-previews.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-bc0ac0e8e743aff65ef354c0.md)

## Rule 109 — `.github/workflows/upload-previews.yml`

- **Rule:**
  ```text
  The workflow runs `smokeshow upload docs` with SMOKESHOW_GITHUB_STATUS_DESCRIPTION set to 'Docs Preview', SMOKESHOW_GITHUB_CONTEXT set to 'docs', SMOKESHOW_GITHUB_TOKEN from secrets.github_token, SMOKESHOW_GITHUB_PR_HEAD_SHA from the triggering run's head SHA, and SMOKESHOW_AUTH_KEY from secrets.smokeshow_auth_key.
  ```
- **Applies to:**
  - `.github/workflows/upload-previews.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c4336e423f1f99837c9edc02.md)
