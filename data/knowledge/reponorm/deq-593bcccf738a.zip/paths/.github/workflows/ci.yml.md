# Rules for `.github/workflows/ci.yml`

## Rule 011 — `.github/workflows/ci.yml`

- **Rule:** The test job installs test requirements from tests/requirements.txt, installs the project with poetry, runs make test, and generates a coverage XML report.
- **Applies to:**
  - `.github/workflows/ci.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0c1f6dbf8584c4be9edc8b7d.md)

## Rule 086 — `.github/workflows/ci.yml`

- **Rule:** The deploy job publishes the built docs site to the gh-pages branch.
- **Applies to:**
  - `.github/workflows/ci.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a3d0ac8084f8c7a0b55cfec4.md)

## Rule 089 — `.github/workflows/ci.yml`

- **Rule:** The lint job runs make lint and make mypy.
- **Applies to:**
  - `.github/workflows/ci.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ae7bda9d7d2687d337894ada.md)

## Rule 123 — `.github/workflows/ci.yml`

- **Rule:** The docs job builds the documentation site with mkdocs build --strict.
- **Applies to:**
  - `.github/workflows/ci.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-df5aed3f3dd419e7b8e6e3cc.md)
