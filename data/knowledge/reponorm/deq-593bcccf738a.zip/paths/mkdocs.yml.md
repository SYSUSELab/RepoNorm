# Rules for `mkdocs.yml`

## Rule 008 — `mkdocs.yml`

- **Rule:** The MkDocs site is configured with the Material theme.
- **Applies to:**
  - `mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0b007da69d4b6c7c23fb969f.md)

## Rule 059 — `docs/plugins.py`

- **Rule:**
  ```text
  The mkdocs-simple-hooks plugin maps the on_pre_build hook to docs.plugins:on_pre_build.
  ```
- **Applies to:**
  - `docs/plugins.py`
  - `mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-79a294cc94c1ce6a9cd8cb8a.md)

## Rule 115 — `docs/plugins.py`

- **Rule:**
  ```text
  The mkdocs-simple-hooks plugin maps the on_page_markdown hook to docs.plugins:on_page_markdown.
  ```
- **Applies to:**
  - `docs/plugins.py`
  - `mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-cc020b16a58b337309373e2a.md)
