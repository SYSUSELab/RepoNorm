# Rules for `repository root`

## Rule 013 — `**/*.py`

- **Rule:** mypy runs in strict mode for Python source files.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-139f5c61f08df4ea60677c71.md)

## Rule 030 — `**`

- **Rule:**
  ```text
  Running `make clean` removes editor backup files matching `*~` and `.*~`.
  ```
- **Applies to:**
  - `**`
- **Condition:** command target: clean
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3cb0e99d2675c574e3edbe97.md)

## Rule 040 — `**`

- **Rule:**
  ```text
  Running `make clean` removes Python bytecode caches by deleting `__pycache__` directories and `*.py[co]` files.
  ```
- **Applies to:**
  - `**`
- **Condition:** command target: clean
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5187f499b90673f7ae74bd54.md)

## Rule 047 — `**/*.py`

- **Rule:**
  ```text
  isort is configured with line_length = 120.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6103633c21abf4ad0968b4e6.md)

## Rule 049 — `**/*.py`

- **Rule:** Black formatting is configured with a line length of 120.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-61626d901f9683c265b5fd0d.md)

## Rule 055 — `**`

- **Rule:**
  ```text
  Running `make install` installs test, linting, and docs requirements via pip, installs project dependencies via poetry, and installs pre-commit hooks.
  ```
- **Applies to:**
  - `**`
- **Condition:** command target: install
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6efa68676f601767d0a18f8d.md)

## Rule 068 — `**`

- **Rule:**
  ```text
  Running `make testcov` depends on the `test` target and then runs `coverage report --show-missing` and `coverage html`.
  ```
- **Applies to:**
  - `**`
- **Condition:** command target: testcov
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8b809f3a9447bc14c89e0bfe.md)

## Rule 078 — `**`

- **Rule:** Codecov project status checks are disabled.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-950d79871ac23d97e85c878c.md)

## Rule 092 — `**/*.py`

- **Rule:** mypy does not warn when a function returns a value typed as Any.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b1b0dfb04139589d7b971e4a.md)

## Rule 114 — `**`

- **Rule:**
  ```text
  Running `make clean` removes the `.cache`, `.pytest_cache`, and `.mypy_cache` directories.
  ```
- **Applies to:**
  - `**`
- **Condition:** command target: clean
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-cb17ef3b1ca77d38f950d090.md)

## Rule 119 — `**/*.py`

- **Rule:** A local pre-commit hook with id 'mypy' runs 'make mypy' on Python-typed files using the system language.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d5a3d025170faf41bc3d01bf.md)

## Rule 124 — `**/*.py`

- **Rule:** A local pre-commit hook with id 'lint' runs 'make lint' on Python-typed files using the system language.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e03e1acad1bd7c3006631282.md)

## Rule 127 — `**/*.py`

- **Rule:**
  ```text
  isort is configured with include_trailing_comma = true.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e50dfb2ff33ee6293d57c356.md)

## Rule 129 — `**`

- **Rule:**
  ```text
  Running `make test` executes `coverage run -m pytest` followed by `python tests/mypy_checks.py`.
  ```
- **Applies to:**
  - `**`
- **Condition:** command target: test
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e7c55d3a01b0b0462f73b210.md)

## Rule 131 — `**/*.py`

- **Rule:**
  ```text
  isort is configured with force_grid_wrap = 0.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ea1ba70d0b0a07eac66d62cc.md)

## Rule 135 — `**/*.py`

- **Rule:**
  ```text
  Running `make lint` executes isort in check-only mode with `--df`.
  ```
- **Applies to:**
  - `**/*.py`
- **Condition:** command target: lint
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-eef518ed001eda1c2d365c08.md)

## Rule 137 — `**/*.py`

- **Rule:**
  ```text
  Coverage excludes lines matching "pragma: no cover", "raise NotImplementedError", "raise NotImplemented", "if TYPE_CHECKING:", and "@overload" from coverage reporting.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f2ac77769ebae6b48111accf.md)
