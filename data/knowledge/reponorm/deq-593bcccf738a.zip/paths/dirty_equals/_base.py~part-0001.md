# Rules for `dirty_equals/_base.py`

## Rule 010 — `dirty_equals/_base.py`

- **Rule:**
  ```text
  `__invert__` must return DirtyNot(self), defining the `~` operator as the negation wrapper for dirty-equals instances.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:**
  ```text
  when modifying `__invert__` or the `~` negation operator on dirty-equals instances
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-0b9ef366eddc599cb5b4add8.md)

## Rule 016 — `dirty_equals/_base.py`

- **Rule:**
  ```text
  DirtyEqualsMeta.__repr__ must return self.__name__, so class-level dirty sentinels repr as their bare class name.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:**
  ```text
  when modifying DirtyEqualsMeta.__repr__ or the class-level sentinel repr
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-15ca403445dc11eb758a2110.md)

## Rule 023 — `dirty_equals/_base.py`

- **Rule:**
  ```text
  DirtyEquals.__init__ must store repr_args/repr_kwargs and initialize _other/_was_equal, establishing the shared repr and comparison-state protocol for subclasses.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:**
  ```text
  Modifying DirtyEquals.__init__ or the shared repr/comparison-state protocol used by subclasses.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-287333f88250b607da401ae8.md)

## Rule 024 — `dirty_equals/_base.py`

- **Rule:**
  ```text
  The base module must import Protocol from typing but fall back to Protocol = object on Python 3.7, and define InstanceOrType as Union[DirtyEquals[Any], DirtyEqualsMeta].
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:** when modifying typing imports or the InstanceOrType alias in the base module
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-28cdbc64df0bebc211d0c5f8.md)

## Rule 036 — `dirty_equals/_base.py`

- **Rule:**
  ```text
  DirtyEquals equals for expected_values must return True if any expected value equals the other value, defining OR-composition semantics.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:**
  ```text
  Modifying IsOneOf.equals or the OR-composition comparison semantics for expected_values.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-47fd7eaefef44e2317d81241.md)

## Rule 039 — `dirty_equals/_base.py`

- **Rule:**
  ```text
  `DirtyEquals.__hash__` must be based on the class name, so matcher instances are hashable consistently with their type identity.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:**
  ```text
  when modifying `DirtyEqualsMeta.__hash__` or the hash basis for matcher instances
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-4f50862cf767cd8469251a78.md)

## Rule 045 — `dirty_equals/_base.py`

- **Rule:** DirtyEqualsMeta must remain an ABCMeta subclass so dirty matcher classes stay abstract-base compatible and support class-level sentinel behavior; do not replace it with a plain metaclass or type.
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:** when modifying the DirtyEqualsMeta metaclass definition or its base classes
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-5dfa53c77bb0cebd622b9b7a.md)

## Rule 054 — `dirty_equals/_base.py`

- **Rule:** The base equals implementation must return True unconditionally, defining the default equality behavior that subclasses override.
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:** when modifying the base equals implementation or AnyThing equality behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-6cf3b3713513e18c38b14051.md)

## Rule 058 — `dirty_equals/_base.py`

- **Rule:**
  ```text
  _repr_ne must dispatch to repr(v) for DirtyEqualsMeta instances and to v._repr_ne() otherwise, preserving class vs instance repr behavior under negation.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:**
  ```text
  when modifying _repr_ne or the negation repr dispatch logic
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-798394956447c4e31a00b331.md)

## Rule 062 — `dirty_equals/_base.py`

- **Rule:**
  ```text
  When a matcher class is composed via & or |, the composed result must remain a DirtyEquals subclass so it can be used anywhere a DirtyEquals is accepted; do not change DirtyAnd/DirtyOr to non-DirtyEquals types.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:** Modifying or adding composition operators on matcher classes.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-7db8b0c1966a8b2158081f5c.md)

## Rule 063 — `dirty_equals/_base.py`

- **Rule:**
  ```text
  DirtyEquals.__or__ must return a DirtyOr combining self and other, so the | operator is part of the public composition protocol for dirty equality objects.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:**
  ```text
  when modifying DirtyEquals.__or__ or the public composition protocol
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-81e44b1e290cad9446886799.md)

## Rule 070 — `dirty_equals/_base.py`

- **Rule:** AnyThing must match any value and is intended for use inside other comparisons such as IsList and IsStrictDict.
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:** when modifying AnyThing or using it as a wildcard inside composite matchers
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-8f417f7ca0c4a1894b74f0f2.md)

## Rule 071 — `dirty_equals/_base.py`

- **Rule:**
  ```text
  DirtyEquals.__invert__ must return DirtyNot(self) so ~dirty produces a negated matcher; do not change the negation result type or drop the inversion behavior.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:**
  ```text
  when modifying DirtyEquals.__invert__ or the negation operator behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-8f888d8f686bdac375efdfcd.md)

## Rule 079 — `dirty_equals/_base.py`

- **Rule:**
  ```text
  DirtyEquals.__eq__ must special-case self is DirtyEquals or other is Generic/Protocol to avoid recursive errors during generic creation, and must swallow TypeError to avoid disrupting pytest error reporting.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:**
  ```text
  when modifying DirtyEquals.__eq__ or the generic-creation comparison path
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-95e34caf1d3a7ef63bc2b283.md)

## Rule 082 — `dirty_equals/_base.py`

- **Rule:**
  ```text
  DirtyEquals.__eq__ must catch TypeError and ValueError raised by the subclass equals() implementation and return False instead of propagating the exception.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:**
  ```text
  When modifying DirtyEquals.__eq__ or adding a new DirtyEquals subclass whose equals() may raise TypeError or ValueError.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-9896a5d47b4b4af7ba46ccaf.md)

## Rule 085 — `dirty_equals/_base.py`

- **Rule:**
  ```text
  DirtyAnd requires at least two operands (a, b) plus optional extras, so `&` composition cannot produce a single-operand DirtyAnd.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:**
  ```text
  when modifying DirtyAnd.__init__ or the `&` composition operator
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-9e25db71c81bdb683aa39975.md)
