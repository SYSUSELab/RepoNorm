# Rules for `dirty_equals/_numeric.py`

## Rule 001 — `dirty_equals/_numeric.py`

- **Rule:**
  ```text
  IsNumeric.prepare must reject booleans (True/False) with TypeError even though bool is a subclass of int, and must reject values outside allowed_types.
  ```
- **Applies to:**
  - `dirty_equals/_numeric.py`
- **Condition:** When modifying IsNumeric.prepare or extending numeric type acceptance in the numeric matcher.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-00770ed6c04e6a6a5c95b2c4.md)

## Rule 004 — `dirty_equals/_numeric.py`

- **Rule:** IsApprox must remain a subclass of IsNumber that only permits approximate comparisons; contributors adding exact-comparison behavior to IsNumber must not assume IsApprox inherits it.
- **Applies to:**
  - `dirty_equals/_numeric.py`
- **Condition:** when adding or changing exact-comparison behavior on IsNumber or its subclasses
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-0412eb77cbe0607c7f10b096.md)

## Rule 018 — `dirty_equals/_numeric.py`

- **Rule:**
  ```text
  IsNumeric.__init__ must raise TypeError when approx is combined with any of gt, lt, ge, or le, and must set has_bounds_checks based on whether any comparison parameter was provided.
  ```
- **Applies to:**
  - `dirty_equals/_numeric.py`
- **Condition:**
  ```text
  Modifying IsNumeric.__init__ parameter handling or bound-check initialization.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-1c717c38c74a9563bf2d0d12.md)

## Rule 031 — `dirty_equals/_numeric.py`

- **Rule:**
  ```text
  `IsNonPositive` must check values `<= 0` and accept `int`, `float`, `Decimal`, or any value implementing `__le__` for 0, including `Decimal('-0')` and `Decimal('0')`.
  ```
- **Applies to:**
  - `dirty_equals/_numeric.py`
- **Condition:**
  ```text
  when modifying `IsNonPositive` or its comparison semantics
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-3e663f6d7c8e6262237902db.md)

## Rule 032 — `dirty_equals/_numeric.py`

- **Rule:**
  ```text
  IsNumber must restrict allowed_types to int, float, and Decimal, excluding date and datetime, so numeric comparisons reject date-like values even though IsNumeric accepts them.
  ```
- **Applies to:**
  - `dirty_equals/_numeric.py`
- **Condition:**
  ```text
  Modifying IsNumber allowed_types or its relationship to IsNumeric.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-3e6ba705df711dd2b01c4a1b.md)

## Rule 037 — `dirty_equals/_numeric.py`

- **Rule:** IsPositiveFloat must only match float values greater than zero; ints and Decimal values must not be equal even when positive.
- **Applies to:**
  - `dirty_equals/_numeric.py`
- **Condition:** when modifying IsPositiveFloat or its type acceptance rules
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-4bdffa6f7fa370cf0a17d2ad.md)

## Rule 080 — `dirty_equals/_numeric.py`

- **Rule:**
  ```text
  The positive-int predicate must initialize its bound via super().__init__(gt=0) and clear _repr_kwargs, so its repr omits the implicit bound.
  ```
- **Applies to:**
  - `dirty_equals/_numeric.py`
- **Condition:**
  ```text
  Modifying IsPositive.__init__ bound initialization or repr kwargs handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-96c1a14de9a7ed539b854129.md)

## Rule 083 — `dirty_equals/_numeric.py`

- **Rule:**
  ```text
  IsPositive must accept any value implementing __gt__ against 0, not only int/float/Decimal, and must keep 0 != IsPositive and -1 != IsPositive.
  ```
- **Applies to:**
  - `dirty_equals/_numeric.py`
- **Condition:** when modifying IsPositive or its comparison acceptance rules
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-9951ee905731b3bf97adb396.md)

## Rule 093 — `dirty_equals/_numeric.py`

- **Rule:**
  ```text
  IsNumeric.equals must prepare the value and return bounds_checks(other) only when has_bounds_checks is set, otherwise return True, so an unconstrained numeric predicate accepts any prepared value.
  ```
- **Applies to:**
  - `dirty_equals/_numeric.py`
- **Condition:** Modifying IsNumeric.equals comparison dispatch or bounds-check gating.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-b2df647aa015d17765ca87c0.md)

## Rule 113 — `dirty_equals/_numeric.py`

- **Rule:** When a numeric matcher restricts allowed types, booleans must be explicitly excluded even though they are int subclasses; do not allow bool to match an int matcher.
- **Applies to:**
  - `dirty_equals/_numeric.py`
- **Condition:** Modifying allowed-type constraints for numeric matchers.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-caae73890afbd218cdde88a1.md)
