# Rules for `dirty_equals/_base.py`

## Rule 091 — `dirty_equals/_base.py`

- **Rule:**
  ```text
  DirtyEquals.__repr__ must return repr(self._other) after a successful equality and self._repr_ne() otherwise, so that failed comparisons show the expected value in diffs.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:**
  ```text
  when modifying DirtyEquals.__repr__ or the repr of a subclass that relies on the base repr
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-b11510ddad5cd65e868dcc88.md)

## Rule 101 — `dirty_equals/_base.py`

- **Rule:**
  ```text
  _repr_ne must omit arguments and kwargs whose value is Omit, so sentinel values are excluded from generated reprs.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:**
  ```text
  when modifying _repr_ne or its argument/kwarg filtering
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-bb827b6369158f0fc3d3b1a3.md)

## Rule 106 — `dirty_equals/_base.py`

- **Rule:** DirtyEquals equals for a dirty tuple must return True only if all dirty values equal the other value, defining AND-composition semantics for tuple matchers.
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:** When modifying DirtyAnd.equals or the tuple-composition equality path.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-bffd302c0c06975da783b62a.md)

## Rule 108 — `dirty_equals/_base.py`

- **Rule:**
  ```text
  IsOneOf.__init__ must store expected_value plus more_expected_values as a tuple and pass them to super, so IsOneOf supports variadic expected values and can be combined with Contains via |.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:**
  ```text
  When modifying IsOneOf.__init__ or the variadic expected-value construction path.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-c1650a9f39c8f129936efe9b.md)

## Rule 128 — `dirty_equals/_base.py`

- **Rule:**
  ```text
  DirtyEquals subclasses that accept multiple instance-or-type arguments must store them as a tuple in self.dirties, as shown by __init__(self, a, b, *extra).
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:** when modifying a DirtyEquals subclass constructor that accepts multiple instance-or-type arguments
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-e6bc03bac8c1d939b58752bc.md)
