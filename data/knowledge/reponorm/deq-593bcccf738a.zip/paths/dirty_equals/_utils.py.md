# Rules for `dirty_equals/_utils.py`

## Rule 065 — `dirty_equals/_utils.py`

- **Rule:**
  ```text
  get_dict_arg must enforce dict-like initialization: kwargs and positional args cannot both be supplied, at most one positional dict is allowed, and a non-dict positional raises TypeError.
  ```
- **Applies to:**
  - `dirty_equals/_utils.py`
- **Condition:**
  ```text
  Modifying get_dict_arg argument validation or dict-like initialization enforcement.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-867835172502d44b9f4271c0.md)
