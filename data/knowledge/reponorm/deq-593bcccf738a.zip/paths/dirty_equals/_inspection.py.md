# Rules for `dirty_equals/_inspection.py`

## Rule 002 — `dirty_equals/_inspection.py`

- **Rule:**
  ```text
  IsInstance equality must use exact type comparison when only_direct_instance is set, otherwise fall back to isinstance checks.
  ```
- **Applies to:**
  - `dirty_equals/_inspection.py`
- **Condition:**
  ```text
  Modifying IsInstance.equals type-matching logic or only_direct_instance handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-0180222f349ad47a29ecbf98.md)

## Rule 043 — `dirty_equals/_inspection.py`

- **Rule:**
  ```text
  HasRepr.__class_getitem__ must return cls(expected_repr), enabling subscript syntax HasRepr['...'] as an alternative to calling the constructor.
  ```
- **Applies to:**
  - `dirty_equals/_inspection.py`
- **Condition:**
  ```text
  when modifying HasRepr.__class_getitem__ or the subscript construction path
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-575c05011a324c34b564f787.md)

## Rule 066 — `dirty_equals/_inspection.py`

- **Rule:**
  ```text
  `IsInstance` must be a `DirtyEquals` subclass parameterized by `ExpectedType`, so instance checks participate in the same dirty-equals comparison protocol as other matchers.
  ```
- **Applies to:**
  - `dirty_equals/_inspection.py`
- **Condition:**
  ```text
  when modifying `IsInstance` or its base class relationship
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-86b50df4c3887309fd6af16b.md)

## Rule 073 — `dirty_equals/_inspection.py`

- **Rule:**
  ```text
  `IsInstanceOf` must provide an overloaded `__init__` accepting `**expected: Any`, indicating keyword-based expected attribute matching in addition to positional forms.
  ```
- **Applies to:**
  - `dirty_equals/_inspection.py`
- **Condition:**
  ```text
  when modifying `IsInstanceOf.__init__` or its overloaded signatures
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-911f68e5de1b1e1c2270de33.md)

## Rule 075 — `dirty_equals/_inspection.py`

- **Rule:**
  ```text
  `HasName.equals` must first check the value's own `__name__`; only when `allow_instances` is true may it fall back to checking the value's `__class__.__name__`, so instance matching is opt-in.
  ```
- **Applies to:**
  - `dirty_equals/_inspection.py`
- **Condition:**
  ```text
  when modifying `HasName.equals` or the `allow_instances` behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-9268f6032c6f5d359c4ad32f.md)

## Rule 094 — `dirty_equals/_inspection.py`

- **Rule:**
  ```text
  HasAttributes.__init__ must accept either positional dicts or keyword arguments via get_dict_arg and pass the resulting expected attributes to the superclass, so attribute expectations follow dict-style construction.
  ```
- **Applies to:**
  - `dirty_equals/_inspection.py`
- **Condition:**
  ```text
  when modifying HasAttributes.__init__ or the attribute-expectation construction path
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-b33039425222088d2b666c9a.md)

## Rule 118 — `dirty_equals/_inspection.py`

- **Rule:**
  ```text
  When a matcher class exposes a __class_getitem__ shorthand, it must return cls(expected) so that subscript syntax is exactly equivalent to the constructor call; do not change the shorthand to return a different type or defer construction.
  ```
- **Applies to:**
  - `dirty_equals/_inspection.py`
  - `dirty_equals/_other.py`
- **Condition:**
  ```text
  Modifying or adding a __class_getitem__ shorthand on a matcher class.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-d305869d340f00e8c64f80cd.md)

## Rule 120 — `dirty_equals/_inspection.py`

- **Rule:**
  ```text
  IsInstance must accept expected_type and only_direct_instance, support both IsInstance[Foo] and IsInstance(Foo), and only_direct_instance=True must reject subclass instances.
  ```
- **Applies to:**
  - `dirty_equals/_inspection.py`
- **Condition:**
  ```text
  Modifying IsInstance constructor signature or only_direct_instance behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-d696e428136ffd44f916b66c.md)

## Rule 121 — `dirty_equals/_inspection.py`

- **Rule:** HasAttributes must remain a partial check: the attributes provided to check do not need to be exhaustive, so contributors must not assume it requires an exact attribute set.
- **Applies to:**
  - `dirty_equals/_inspection.py`
- **Condition:** when modifying HasAttributes or its attribute comparison behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-de7e13cda1d1970dd9c4bf7c.md)
