# Rules for `dirty_equals/_boolean.py`

## Rule 060 — `dirty_equals/_boolean.py`

- **Rule:**
  ```text
  `IsFalseLike.equals` must return `not bool(other)` for non-string values, but when `allow_strings` is true and `other` is a `str` it must delegate to `make_string_check`.
  ```
- **Applies to:**
  - `dirty_equals/_boolean.py`
- **Condition:**
  ```text
  when modifying `IsFalseLike.equals` or the `allow_strings` behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-7c8de7d51467aac8c92d2d84.md)

## Rule 117 — `dirty_equals/_boolean.py`

- **Rule:** IsTrueLike.equals must return bool(other), so truthiness rather than identity with True is the comparison rule.
- **Applies to:**
  - `dirty_equals/_boolean.py`
- **Condition:** Modifying IsTrueLike.equals comparison logic.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-cd8eab0e635d3798d727bc22.md)

## Rule 134 — `dirty_equals/_boolean.py`

- **Rule:**
  ```text
  Boolean matchers must depend on DirtyEquals from _base and Omit from _utils, using Omit as the shared sentinel for suppressing repr kwargs.
  ```
- **Applies to:**
  - `dirty_equals/_boolean.py`
- **Condition:** when modifying boolean matchers or their repr-kwarg suppression behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-ec9c9ad5d30440047a323911.md)
