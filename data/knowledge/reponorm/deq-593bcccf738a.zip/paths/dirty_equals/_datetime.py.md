# Rules for `dirty_equals/_datetime.py`

## Rule 015 — `dirty_equals/_datetime.py`

- **Rule:** The datetime prepare method must refresh self.approx to the current time on every comparison so relative datetime matchers evaluate against the moment of comparison.
- **Applies to:**
  - `dirty_equals/_datetime.py`
- **Condition:** when modifying the prepare method of a relative datetime matcher
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-15951644dd5e2fbb0955135a.md)

## Rule 028 — `dirty_equals/_datetime.py`

- **Rule:**
  ```text
  Datetime prepare must accept datetime values, numeric timestamps only when unix_number is set, and strings only when iso_string or format_string is configured; otherwise it must raise TypeError or ValueError.
  ```
- **Applies to:**
  - `dirty_equals/_datetime.py`
- **Condition:** when modifying IsDatetime.prepare or its input-type acceptance rules
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-32bdad8133f81372ed777c9f.md)

## Rule 087 — `dirty_equals/_datetime.py`

- **Rule:**
  ```text
  _datetime.py must import IsNumeric from ._numeric and reuse it for numeric comparison behavior rather than reimplementing numeric matching.
  ```
- **Applies to:**
  - `dirty_equals/_datetime.py`
- **Condition:**
  ```text
  When modifying _datetime.py's numeric comparison behavior or refactoring numeric matcher reuse.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-a5736fc8c5fd248418b914fd.md)

## Rule 090 — `dirty_equals/_datetime.py`

- **Rule:**
  ```text
  IsDate must accept approx/delta/gt/lt/ge/le plus iso_string and format_string, and numeric delta must be interpreted as seconds and converted to timedelta.
  ```
- **Applies to:**
  - `dirty_equals/_datetime.py`
- **Condition:**
  ```text
  Modifying IsDate.__init__ parameter handling or delta conversion.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-aeeb0e785b8cded510890aeb.md)

## Rule 112 — `dirty_equals/_datetime.py`

- **Rule:**
  ```text
  When a datetime matcher compares with enforce_tz enabled, approx_equals must compare only UTC offsets rather than full tzinfo identity, and a naive approx must require the other value to be naive; do not tighten to full tzinfo equality.
  ```
- **Applies to:**
  - `dirty_equals/_datetime.py`
- **Condition:** Modifying timezone handling in datetime approximate comparison.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-ca0d0fe49d35dabed6290582.md)
