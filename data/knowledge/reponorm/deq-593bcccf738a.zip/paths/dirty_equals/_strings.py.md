# Rules for `dirty_equals/_strings.py`

## Rule 029 — `dirty_equals/_strings.py`

- **Rule:** When a string/bytes matcher is constructed, unset options must be passed to super as Omit so they do not appear in repr; do not pass None or default values that would surface in repr.
- **Applies to:**
  - `dirty_equals/_strings.py`
- **Condition:** Modifying construction of a string/bytes matcher.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-389073e647b7aa37b67bd771.md)

## Rule 097 — `dirty_equals/_strings.py`

- **Rule:**
  ```text
  When a regex is prepared for a string matcher, flex mode must strip flags other than re.UNICODE and extract the pattern, encoding string patterns to bytes, while non-flex mode extracts the pattern only when regex_flags is nonzero; do not change this flag-handling behavior.
  ```
- **Applies to:**
  - `dirty_equals/_strings.py`
- **Condition:** Modifying regex preparation for string matchers.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-b6582437b0dccfdaa1db9143.md)

## Rule 104 — `dirty_equals/_other.py`

- **Rule:**
  ```text
  Modules that import Literal from typing must fall back to typing_extensions on ImportError to preserve compatibility with older Python versions.
  ```
- **Applies to:**
  - `dirty_equals/_other.py`
  - `dirty_equals/_strings.py`
- **Condition:** when adding or modifying typing imports in dirty-equals modules
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-bd638db7317df2586d922dbe.md)
