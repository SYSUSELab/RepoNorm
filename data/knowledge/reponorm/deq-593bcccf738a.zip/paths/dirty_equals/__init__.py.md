# Rules for `dirty_equals/__init__.py`

## Rule 110 — `dirty_equals/__init__.py`

- **Rule:**
  ```text
  The package `__init__` must re-export the full public API and define `__all__` including `__version__`, with `__version__ = '0.0.dev0'`.
  ```
- **Applies to:**
  - `dirty_equals/__init__.py`
- **Condition:**
  ```text
  when modifying the package `__init__` re-exports, `__all__`, or `__version__`
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-c4765e2ee7da9d5393940523.md)
