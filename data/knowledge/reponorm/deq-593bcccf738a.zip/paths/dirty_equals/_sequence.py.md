# Rules for `dirty_equals/_sequence.py`

## Rule 005 — `dirty_equals/_sequence.py`

- **Rule:**
  ```text
  HasLen.__init__ must store an int min_length as the exact length when max_length is None, otherwise store (min_length, max_length) and pass the length repr to super, with ellipsis meaning no maximum.
  ```
- **Applies to:**
  - `dirty_equals/_sequence.py`
- **Condition:**
  ```text
  when modifying HasLen.__init__ or its length argument handling
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-05c74579e177eefcc8db9b8a.md)

## Rule 038 — `dirty_equals/_sequence.py`

- **Rule:**
  ```text
  Contains.__init__ must accept one or more contained values and store them as a tuple, supporting containment checks against lists, tuples, strings, and dict keys.
  ```
- **Applies to:**
  - `dirty_equals/_sequence.py`
- **Condition:**
  ```text
  when modifying Contains.__init__ or the containment-check semantics
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-4eab746eb6a27165ae34a3db.md)

## Rule 061 — `dirty_equals/_sequence.py`

- **Rule:**
  ```text
  IsListOrTuple must keep allowed_type defaulting to (list, tuple), constraining which container types the predicate accepts; do not broaden the default to arbitrary iterables.
  ```
- **Applies to:**
  - `dirty_equals/_sequence.py`
- **Condition:**
  ```text
  when modifying IsListOrTuple or its allowed_type default
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-7c9bfc68a78dfa412c076e2d.md)

## Rule 074 — `dirty_equals/_sequence.py`

- **Rule:**
  ```text
  _sequence.py must export HasLen, Contains, IsListOrTuple, IsList, and IsTuple, and define LengthType as Union[None, int, Tuple[int, Union[int, Any]]], establishing the accepted length argument shapes.
  ```
- **Applies to:**
  - `dirty_equals/_sequence.py`
- **Condition:**
  ```text
  Modifying _sequence.py exports or LengthType definition.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-922a266c4348e2cd1da65cce.md)

## Rule 081 — `dirty_equals/_sequence.py`

- **Rule:**
  ```text
  When a container matcher checks containment, it must verify the object contains one or more values as a DirtyEquals[Container[Any]] matcher; do not change it to a non-DirtyEquals or non-container matcher.
  ```
- **Applies to:**
  - `dirty_equals/_sequence.py`
- **Condition:** Modifying container containment matching.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-97d8262c342617d846ba03f7.md)

## Rule 095 — `dirty_equals/_sequence.py`

- **Rule:**
  ```text
  IsListOrTuple.equals must enforce allowed_type and length before comparing, and for order-insensitive comparison must remove each expected item from a copy of the other sequence so duplicates are handled without set hashing.
  ```
- **Applies to:**
  - `dirty_equals/_sequence.py`
- **Condition:** When modifying IsListOrTuple.equals or adding new sequence comparison modes.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-b4c023ecd74571ef6d80d19e.md)

## Rule 099 — `dirty_equals/_sequence.py`

- **Rule:**
  ```text
  When a matcher accepts a length constraint, _length_repr must raise TypeError for non-int lengths that are not a 2-tuple and render a non-int upper bound as '...'; do not silently accept other length forms.
  ```
- **Applies to:**
  - `dirty_equals/_sequence.py`
- **Condition:** Modifying length-constraint validation or repr.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-b94d2bdd82939c86efc52737.md)

## Rule 102 — `dirty_equals/_sequence.py`

- **Rule:**
  ```text
  HasLen must be a DirtyEquals[Sized] predicate for checking a value's length or that its length falls within a range.
  ```
- **Applies to:**
  - `dirty_equals/_sequence.py`
- **Condition:** Modifying HasLen class definition or its length-checking semantics.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-bbbb4782bfa7b7e83b14f115.md)
