# Rules for `tests/test_datetime.py`

## Rule 025 — `tests/test_datetime.py`

- **Rule:**
  ```text
  Tests for `IsNow` with `iso_string=True` must assert that the matcher equals the current datetime's ISO-formatted string.
  ```
- **Applies to:**
  - `tests/test_datetime.py`
- **Condition:**
  ```text
  when adding or modifying tests that cover `IsNow` ISO-string matching
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-2963cb23ab4e5cc70ef8ab74.md)

## Rule 053 — `tests/test_datetime.py`

- **Rule:**
  ```text
  IsDate must support approx, iso_string, format_string, ge, gt, and delta matching, and must reject wrong types and datetime-vs-date mismatches.
  ```
- **Applies to:**
  - `tests/test_datetime.py`
- **Condition:** when adding or modifying tests for IsDate matching options and type mismatches
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-6be59f414e5df35b6332f566.md)

## Rule 056 — `tests/test_datetime.py`

- **Rule:**
  ```text
  Datetime tests must import `IsDate`, `IsDatetime`, `IsNow`, and `IsToday` from dirty_equals and may use pytz and unittest.mock.Mock for timezone and mock-based behavior.
  ```
- **Applies to:**
  - `tests/test_datetime.py`
- **Condition:** when adding or modifying datetime tests that need timezone or mock-based coverage
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-715a672bfa1169d910008203.md)
