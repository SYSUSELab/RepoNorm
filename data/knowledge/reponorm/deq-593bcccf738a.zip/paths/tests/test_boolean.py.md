# Rules for `tests/test_boolean.py`

## Rule 138 — `tests/test_boolean.py`

- **Rule:**
  ```text
  Tests that pin the truthiness semantics of IsTrueLike and IsFalseLike must parametrize across bools, containers, None, and numeric zero/one, and must assert both the positive matcher and its negation (~IsTrueLike) where applicable.
  ```
- **Applies to:**
  - `tests/test_boolean.py`
- **Condition:** when adding or modifying tests for IsTrueLike or IsFalseLike truthiness behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-f93e96bc743b5e6913e23b5c.md)
