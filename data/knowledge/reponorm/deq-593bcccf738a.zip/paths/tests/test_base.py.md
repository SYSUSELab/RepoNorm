# Rules for `tests/test_base.py`

## Rule 046 — `tests/test_base.py`

- **Rule:**
  ```text
  Combining dirty-equals predicates with & must produce a conjunction that passes only when both operands hold, and its repr must join the two operand names with ' & '.
  ```
- **Applies to:**
  - `tests/test_base.py`
- **Condition:**
  ```text
  when adding or modifying tests for & composition of dirty-equals predicates
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-5ea0f21bb0e48863b734cbd1.md)

## Rule 084 — `tests/test_base.py`

- **Rule:**
  ```text
  repr of dirty-equals matchers must preserve class vs instance distinction and operator composition forms, including ~, &, |, and parameterized instances like IsInt(lt=5).
  ```
- **Applies to:**
  - `tests/test_base.py`
- **Condition:** when adding or modifying tests for matcher repr of class/instance and operator composition forms
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-9a1e838856dd024611daeb5f.md)

## Rule 141 — `tests/test_base.py`

- **Rule:** Tests that verify class-level sentinel matchers such as IsApprox must assert that the sentinel class itself is usable directly in comparisons without instantiation.
- **Applies to:**
  - `tests/test_base.py`
- **Condition:** when adding or modifying tests for class-level sentinel matchers
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-fe6041c7887e3d137b957772.md)
