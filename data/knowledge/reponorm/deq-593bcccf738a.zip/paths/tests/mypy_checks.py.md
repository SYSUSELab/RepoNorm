# Rules for `tests/mypy_checks.py`

## Rule 057 — `tests/mypy_checks.py`

- **Rule:**
  ```text
  The mypy_checks.py module must remain type-checkable by mypy and must document intentional type-error boundaries with explicit type: ignore comments rather than removing the offending expression.
  ```
- **Applies to:**
  - `tests/mypy_checks.py`
- **Condition:**
  ```text
  when modifying tests/mypy_checks.py to add or adjust type-checking assertions
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-77c4f8fae3a0e865ef81dfe8.md)

## Rule 139 — `dirty_equals/**`

- **Rule:**
  ```text
  Running `make mypy` executes `mypy dirty_equals tests/mypy_checks.py`.
  ```
- **Applies to:**
  - `dirty_equals/**`
  - `tests/mypy_checks.py`
- **Condition:** command target: mypy
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-f99ae9d77f3271fc33594a73.md)
