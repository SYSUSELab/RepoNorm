# Rules for `tests/test_docs.py`

## Rule 122 — `tests/test_docs.py`

- **Rule:** Documentation examples in .py and .md files are executed by the docs test suite, so docstring and markdown code chunks must remain runnable.
- **Applies to:**
  - `tests/test_docs.py`
- **Condition:** When changing documentation examples in .py or .md files, ensure the extracted docstring and markdown code chunks remain executable by the docs test suite.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-df279041896039ccd1f0256b.md)

## Rule 133 — `tests/test_docs.py`

- **Rule:**
  ```text
  The docs test must use `pytest_generate_tests` to parametrize `module_name` and `source_code` from `generate_code_chunks('dirty_equals', 'docs')` so every runnable docs code chunk becomes a test case.
  ```
- **Applies to:**
  - `tests/test_docs.py`
- **Condition:** when adding or modifying the docs test harness that parametrizes runnable documentation code chunks
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-ec1576121832f7ea5ac56072.md)
