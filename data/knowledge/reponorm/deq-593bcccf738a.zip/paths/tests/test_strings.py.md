# Rules for `tests/test_strings.py`

## Rule 116 — `tests/test_strings.py`

- **Rule:**
  ```text
  IsBytes(regex=...) must match bytes patterns, including wildcard bytes regexes such as b'wh.*er'.
  ```
- **Applies to:**
  - `tests/test_strings.py`
- **Condition:** when adding or modifying tests for IsBytes regex matching
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-cc507b80d722c1a238b861b8.md)
