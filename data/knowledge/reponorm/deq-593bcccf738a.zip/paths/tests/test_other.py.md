# Rules for `tests/test_other.py`

## Rule 020 — `tests/test_other.py`

- **Rule:**
  ```text
  IsJson must compare equal to both IsJson(expected_value) and the subscript form IsJson[expected_value] for null, string, list, and object JSON values.
  ```
- **Applies to:**
  - `tests/test_other.py`
- **Condition:** when adding or modifying tests for IsJson equality across constructor and subscript forms
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-248d4ba17d8f4aed345ee6ec.md)

## Rule 021 — `tests/test_other.py`

- **Rule:**
  ```text
  Tests for `IsJson` must assert that a JSON array matcher does not equal a JSON object string and that its `str` is the matcher's repr.
  ```
- **Applies to:**
  - `tests/test_other.py`
- **Condition:**
  ```text
  when adding or modifying tests that pin `IsJson` inequality and repr behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-25a47df13a63df29145e0f32.md)
