# Rules for `tests/test_numeric.py`

## Rule 035 — `tests/test_numeric.py`

- **Rule:** IsInt must reject combining approx with gt, lt, ge, or le, raising TypeError with the message '"approx" cannot be combined with "gt", "lt", "ge", or "le"'.
- **Applies to:**
  - `tests/test_numeric.py`
- **Condition:** When changing IsInt argument validation, preserve the mutual-exclusion contract between approx and comparison bounds and its exact TypeError message.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-448a1c1d7b7f5531340f65d4.md)

## Rule 050 — `tests/test_numeric.py`

- **Rule:**
  ```text
  `test_dirty_equals` must parametrize many numeric matchers, including class forms like `IsInt` and call forms like `IsInt()`, plus combined matchers such as `IsNonPositive & IsInt`, asserting equality in each case.
  ```
- **Applies to:**
  - `tests/test_numeric.py`
- **Condition:** when modifying numeric matcher equality tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-63369d257a5becf86423c1f7.md)
