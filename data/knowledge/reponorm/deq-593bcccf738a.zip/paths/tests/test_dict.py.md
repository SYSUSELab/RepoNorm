# Rules for `tests/test_dict.py`

## Rule 022 — `tests/test_dict.py`

- **Rule:**
  ```text
  Tests for dict matcher reprs must parametrize `IsDict`, `IsPartialDict`, `IsIgnoreDict`, and `IsStrictDict` repr output, including settings such as partial, ignore, and strict reflected in bracket notation.
  ```
- **Applies to:**
  - `tests/test_dict.py`
- **Condition:** when adding or modifying tests that pin repr output for dict matchers
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-27929f8df7081718dfaf1750.md)

## Rule 064 — `tests/test_dict.py`

- **Rule:**
  ```text
  Tests for nested dirty-equals matchers inside `IsIgnoreDict` must assert that the nested matcher's `.value` property returns the matched value after a successful comparison.
  ```
- **Applies to:**
  - `tests/test_dict.py`
- **Condition:**
  ```text
  when adding or modifying tests that cover stateful nested matchers inside `IsIgnoreDict`
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-83ec8274618e8c8f39dc6f77.md)
